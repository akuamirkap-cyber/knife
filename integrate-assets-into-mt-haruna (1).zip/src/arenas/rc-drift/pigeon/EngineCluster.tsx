import { useEffect, useRef } from 'react';
import { sound, type BmwEngine, type BmwTrans } from './bmw/sound';

const CX = 200, CY = 204, R = 168, MAXR = 8000;
const A0 = 135, SWEEP = 270;
const ang = (rpm: number) => A0 + SWEEP * Math.min(1, Math.max(0, rpm / MAXR));
const pt = (deg: number, r: number) => { const a = (deg * Math.PI) / 180; return [CX + r * Math.cos(a), CY + r * Math.sin(a)] as const; };
const arc = (a0: number, a1: number, r: number) => {
  const [x0, y0] = pt(a0, r), [x1, y1] = pt(a1, r);
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
};
const ARC_LEN = (R * SWEEP * Math.PI) / 180;
const LEDS = ['#ffb347', '#ffb347', '#ffb347', '#ff8a2b', '#ff8a2b', '#ff8a2b', '#ef3340', '#ef3340', '#ef3340'];

export const BMW_ENGINES: Record<BmwEngine, { button: string; long: string; car: string; redline: number }> = {
  s55: { button: 'S55 - I6 turbo', long: 'Inline-6 3.0 L Twin-Turbo', car: 'M4 F82', redline: 7600 },
  s54: { button: 'S54 - I6 NA', long: 'Inline-6 3.2 L NA · Airbox Karbon', car: 'M3 CSL E46', redline: 7900 },
  s63: { button: 'S63 - V8 turbo', long: 'V8 4.4 L Twin-Turbo Hot-V', car: 'M5 F10', redline: 7200 },
};
export const BMW_TRANS: Record<BmwTrans, { button: string; auto: string }> = {
  dct: { button: 'M-DCT 7', auto: 'M-DCT 7 · D' },
  mt: { button: 'Manual 6', auto: 'MANUAL 6' },
};

/**
 * Panel mesin ala BMW engine-sound-simulation (kanan bawah, ukuran sedang):
 * pemilihan MESIN & TRANSMISI, takometer, gigi, kecepatan, dan RPM — semua dibaca
 * langsung dari state simulasi audio yang sama yang membunyikan mesin.
 */
export default function EngineCluster({ engine, trans, onEngine, onTrans }: {
  engine: BmwEngine; trans: BmwTrans; onEngine: (e: BmwEngine) => void; onTrans: (t: BmwTrans) => void;
}) {
  const info = BMW_ENGINES[engine];
  const redline = info.redline;
  const needle = useRef<SVGGElement>(null);
  const prog = useRef<SVGPathElement>(null);
  const rpmTxt = useRef<SVGTextElement>(null);
  const spdTxt = useRef<SVGTextElement>(null);
  const gearTxt = useRef<SVGTextElement>(null);
  const transTxt = useRef<HTMLSpanElement>(null);
  const leds = useRef<SVGGElement>(null);

  useEffect(() => {
    let shown = 0;
    let raf = 0, last = 0;
    const frame = (t: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, last ? (t - last) / 1000 : 0.016);
      last = t;
      const s = sound.state;
      shown += (s.rpm - shown) * Math.min(1, dt * 30);
      const a = ang(shown);
      needle.current?.setAttribute('transform', `rotate(${a.toFixed(2)} ${CX} ${CY})`);
      const hot = s.lim ? '#ef3340' : '#ff8a2b';
      if (prog.current) {
        prog.current.style.strokeDasharray = `${(ARC_LEN * (a - A0)) / SWEEP} ${ARC_LEN}`;
        prog.current.style.stroke = hot;
      }
      if (rpmTxt.current) rpmTxt.current.textContent = String(Math.round(shown / 10) * 10);
      if (spdTxt.current) spdTxt.current.textContent = String(Math.round(s.v * 3.6));
      if (gearTxt.current) gearTxt.current.textContent = s.gear > 0 ? String(s.gear) : 'N';
      if (transTxt.current) transTxt.current.textContent = trans === 'dct' ? 'M-DCT 7 · D' : `MANUAL 6 · ${s.gear > 0 ? s.gear : 'N'}`;
      if (leds.current) {
        const f = (s.rpm - redline * 0.68) / (redline * 0.3);
        const n = s.lim ? 9 : Math.floor(Math.max(0, Math.min(1, f)) * 9);
        const ch = leds.current.children;
        for (let i = 0; i < ch.length; i++) (ch[i] as SVGElement).style.opacity = i < n ? '1' : '0.12';
      }
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [redline, trans]);

  const ticks = [];
  for (let i = 0; i <= 32; i++) {
    const rpm = i * 250, major = i % 4 === 0, half = i % 2 === 0;
    const a = ang(rpm);
    const [x0, y0] = pt(a, R - (major ? 20 : half ? 12 : 7));
    const [x1, y1] = pt(a, R - 2);
    const red = rpm >= redline;
    ticks.push(<line key={i} x1={x0} y1={y0} x2={x1} y2={y1} stroke={red ? '#ef3340' : major ? '#ece9e3' : '#5a606a'} strokeWidth={major ? 2.2 : 1.2} />);
    if (major) {
      const [tx, ty] = pt(a, R - 38);
      ticks.push(<text key={`t${i}`} x={tx} y={ty + 8} textAnchor="middle" fontSize="23" fontWeight="600" fill={red ? '#ef3340' : '#a3a8b1'}>{i / 4}</text>);
    }
  }

  return (
    <aside className="engine-cluster" aria-label="Panel mesin BMW">
      <div className="ec-head">
        <div className="ec-group">
          <span className="ec-label">Mesin</span>
          <div className="ec-seg" role="group" aria-label="Pilih mesin">
            {(Object.keys(BMW_ENGINES) as BmwEngine[]).map(e => (
              <button key={e} type="button" aria-pressed={engine === e} onClick={() => onEngine(e)}>{BMW_ENGINES[e].button}</button>
            ))}
          </div>
        </div>
        <div className="ec-group">
          <span className="ec-label">Transmisi</span>
          <div className="ec-seg" role="group" aria-label="Pilih transmisi">
            {(Object.keys(BMW_TRANS) as BmwTrans[]).map(t => (
              <button key={t} type="button" aria-pressed={trans === t} onClick={() => onTrans(t)}>{BMW_TRANS[t].button}</button>
            ))}
          </div>
        </div>
      </div>
      <div className="ec-caption">
        <span>{info.long.toUpperCase()} · {info.car}</span>
        <span ref={transTxt}>{BMW_TRANS[trans].auto}</span>
      </div>
      <p className="ec-hint" aria-hidden="true">Tahan <kbd>W</kbd> untuk gas · <kbd>E</kbd> masuk gigi</p>
      <svg className="ec-gauge" viewBox="62 60 276 276" role="img" aria-label="Takometer, gigi, dan kecepatan">
        <defs>
          <filter id="ec-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="4" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
          <radialGradient id="ec-face" cx="50%" cy="50%" r="50%"><stop offset="60%" stopColor="#0c0e11" /><stop offset="100%" stopColor="#14171c" /></radialGradient>
        </defs>
        <circle cx={CX} cy={CY} r={R + 12} fill="url(#ec-face)" stroke="#272c34" />
        <path d={arc(A0, A0 + SWEEP, R)} fill="none" stroke="#20242b" strokeWidth="5" strokeLinecap="round" />
        <path d={arc(ang(redline), A0 + SWEEP, R)} fill="none" stroke="#ef3340" strokeWidth="5" strokeLinecap="round" opacity="0.85" />
        <path ref={prog} d={arc(A0, A0 + SWEEP, R)} fill="none" stroke="#ff8a2b" strokeWidth="5" strokeLinecap="round" filter="url(#ec-glow)" style={{ strokeDasharray: `0 ${ARC_LEN}` }} />
        {ticks}
        <g ref={leds}>
          {LEDS.map((c, i) => <rect key={i} x={CX - 76 + i * 17.4} y={104} width="13" height="5" rx="1.5" fill={c} style={{ opacity: 0.12 }} />)}
        </g>
        <g ref={needle}>
          <path d={`M ${CX - 132} ${CY} L ${CX - 4} ${CY - 5} L ${CX + 4} ${CY + 5} Z`} fill="#ff8a2b" />
          <path d={`M ${CX - 4} ${CY - 5} L ${CX + 62} ${CY} L ${CX - 4} ${CY + 5} Z`} fill="#f3efe6" opacity="0.9" />
        </g>
        <circle cx={CX} cy={CY} r={13} fill="#181c22" stroke="#3a414b" />
        <text ref={gearTxt} className="ec-gear" x={CX} y={CY + 58} textAnchor="middle" fontSize="64" fontWeight="700" fill="#f3efe6">N</text>
        <text ref={spdTxt} className="ec-speed" x={CX} y={CY + 92} textAnchor="middle" fontSize="22" fontWeight="600" fill="#c9cdd4">0</text>
        <text x={CX} y={CY + 106} textAnchor="middle" fontSize="10" letterSpacing="2.5" fill="#6d727b">KM/H</text>
        <text ref={rpmTxt} className="ec-rpm" x={CX} y={CY + 128} textAnchor="middle" fontSize="20" fontWeight="600" fill="#ff8a2b">0</text>
        <text x={CX} y={CY + 141} textAnchor="middle" fontSize="10" letterSpacing="2.5" fill="#6d727b">RPM</text>
      </svg>
    </aside>
  );
}
