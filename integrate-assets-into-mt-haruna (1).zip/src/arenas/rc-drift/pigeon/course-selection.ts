export const COURSES = {
  pigeon: { name: 'Pigeon Touge', type: 'Loop pegunungan', detail: 'Jalan hutan dengan tanjakan dan lereng terbuka.', number: '01' },
  haruna: { name: 'Mt. Haruna', type: 'Turunan pegunungan', detail: 'Kontur, start, dan kendali asli ProDrift dengan hutan PIGEON.', number: '02' },
  pinus: { name: 'Sirkuit Pinus', type: 'Sirkuit klasik', detail: 'Lintasan ProDrift asli dengan mode Ghost AI.', number: '03' },
} as const;

export type CourseId = keyof typeof COURSES;
export const COURSE_IDS: readonly CourseId[] = ['pigeon', 'haruna', 'pinus'];
export const DEFAULT_COURSE: CourseId = 'pigeon';
const key = 'prodrift.selected-course';
let current: CourseId = DEFAULT_COURSE;

export function readSelectedCourse(): CourseId {
  try {
    const saved = localStorage.getItem(key);
    return COURSE_IDS.find(id => id === saved) ?? current;
  } catch { return current; }
}

export function saveSelectedCourse(id: CourseId) {
  current = id;
  try { localStorage.setItem(key, id); } catch { /* Storage is optional. */ }
}