import { startTransition, useEffect, useRef, useState } from 'react';
import type { PointerEvent, ReactNode } from 'react';
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Box, CircleHelp, Compass, Flag, Focus, Gauge, Maximize, Video,
  CloudRain, Minimize, Minus, MoonStar, Pause, Play, Plus, RotateCcw, Sun, Trophy, Volume2, VolumeX, X, SlidersHorizontal, Wind,
} from 'lucide-react';
import { BuildPanel } from './BuildPanel';
import { DriftReadout, DrivePrompt, formatScore, LapReadout, RaceBrand, RouteMap, SpeedReadout } from './DriveHud';
import { GhostCoach, GhostIcon } from './GhostHud';
import type { GhostHudData, GhostMode } from './ghost-replay.js';
import type { Route } from './DriveHud';
import { driftMedal, medalGoals } from './drift-score.js';
import { defaultBuild, readBuild, skins, writeBuild } from './rally-config';
import type { RallyBuild } from './rally-config';
import type { FilmFlags } from './rally-studio';
import { DEFAULT_FILM } from './rally-studio';
import { DEFAULT_ATMOSPHERE, DEFAULT_LIGHTING, DEFAULT_MOUNTAIN_LOOK, DRIVE_SETTINGS_KEY, LIGHT_SLIDERS, normalizeLighting, normalizeAtmosphere, saveAtmosphere, SKY_THEMES, type AtmosphereState, type SkyTheme } from './drive-lighting';
import EngineCluster from './EngineCluster';
import type { BmwCfg, BmwEngine, BmwTrans } from './bmw/sound';
import type { LightingState, LightingMood, MountainLook } from './drive-lighting';
import { COURSE_IDS, COURSES, readSelectedCourse, saveSelectedCourse, type CourseId } from './course-selection';
import { emptyTelemetry } from './rally-course';
import { rmxLive } from './rmx-drift-adapter';
import type { HarunaDriveMode, RunMode } from './rally-course';
import { createStudio } from './rally-studio';
import RmxRallyOverlay from './RmxRallyOverlay';
import type { DriveCamera, GripKey, Studio, ViewId, ViewerMode } from './rally-studio';

const cameras: { id: DriveCamera; label: string; accessible: string }[] = [
  { id: 'chase', label: 'Belakang', accessible: 'Kamera belakang' },
  { id: 'overhead', label: 'Atas', accessible: 'Kamera atas' },
  { id: 'cockpit', label: 'Kokpit', accessible: 'Kamera kokpit' },
  { id: 'bumper', label: 'Bemper', accessible: 'Kamera bemper' },
];
const garageViews: { id: ViewId; label: string }[] = [
  { id: 'threeQuarter', label: 'Sudut 3/4' }, { id: 'front', label: 'Depan' }, { id: 'rear', label: 'Belakang' },
  { id: 'left', label: 'Kiri' }, { id: 'right', label: 'Kanan' }, { id: 'top', label: 'Atas' },
];
const keyBindings: Partial<Record<string, GripKey>> = {
  KeyW:'w', KeyS:'s', KeyA:'a', KeyD:'d', Space:'space', ArrowUp:'w', ArrowDown:'s', ArrowLeft:'a', ArrowRight:'d',
};
const names: Record<GripKey, string> = { w:'Gas', s:'Rem atau mundur', a:'Belok kiri', d:'Belok kanan', space:'Handbrake / E-Brake Drift' };
const settingKey = DRIVE_SETTINGS_KEY;
const recordKey = 'rally-lab.drift.record.v1';

function readRecord() {
  try {
    const score=Number(localStorage.getItem(recordKey));
    return Number.isFinite(score)?Math.max(0,Math.floor(score)):0;
  } catch { return 0; }
}

// Default switches ON in the panel: Kontras & Exposure, Bloom & Glare (10%), Chromatic Aberration & Film Grain, FOV Sempit.
const defaultFilm: FilmFlags = { ...DEFAULT_FILM };
function getSettings() {
  try {
    const values = JSON.parse(localStorage.getItem(settingKey) ?? '{}');
    return { assist: values?.assist !== false, sound: values?.sound !== false, speedEffects:values?.speedEffects!==false, feintFlick:values?.feintFlick===true,
      film: { ...defaultFilm, ...(values?.film ?? {}) },
      lighting: normalizeLighting(values?.lighting ?? {}),
      mountainLook: (values?.mountainLook === 'prodrift' ? 'prodrift' : DEFAULT_MOUNTAIN_LOOK) as MountainLook,
      atmosphere: normalizeAtmosphere(values?.atmosphere),
      drivetrain: {
        engine: (values?.drivetrain?.engine === 's54' || values?.drivetrain?.engine === 's63' ? values.drivetrain.engine : 's55') as BmwEngine,
        trans: (values?.drivetrain?.trans === 'mt' ? 'mt' : 'dct') as BmwTrans,
      } as BmwCfg,
      tod: (values?.tod === 'rain' || values?.tod === 'night' ? values.tod : 'day') as LightingMood };
  } catch { return { assist:true, sound:true, speedEffects:true, feintFlick:false, film:{...defaultFilm}, lighting:{...DEFAULT_LIGHTING}, mountainLook:DEFAULT_MOUNTAIN_LOOK, atmosphere:{...DEFAULT_ATMOSPHERE}, drivetrain:{engine:'s55' as BmwEngine, trans:'dct' as BmwTrans}, tod:'day' as LightingMood }; }
}
const ALL_FILM = Object.keys(DEFAULT_FILM) as (keyof FilmFlags)[];
const FILM_GROUPS: { title: string; items: { key: keyof FilmFlags; name: string; desc: string }[] }[] = [
  { title: 'EXPOSURE & WARNA', items: [
    { key: 'rays', name: 'God Rays Matahari', desc: 'Sinar matahari siang cerah tembus celah awan' },
    { key: 'contrastExposure', name: 'Kontras & Exposure', desc: 'Langit & pantulan bodi sedikit silau (overexposed)' },
    { key: 'aces', name: 'Tone Mapping ACES Filmic', desc: 'Bayangan kolong & asap ban lebih pekat dan bervolume' },
    { key: 'bloom', name: 'Bloom & Glare Halus', desc: 'Lampu rem, percikan knalpot, pantulan matahari menyilaukan (kekuatan 10%)' },
  ]},
  { title: 'LENSA & GERAKAN', items: [
    { key: 'motionBlur', name: 'Motion Blur (shutter ~1/60)', desc: 'Aspal & velg memanjang (streaking) saat melaju' },
    { key: 'shake', name: 'Camera Shake & G-Force', desc: 'Guncangan saat kerb / rev tinggi, kamera ikut pitch & roll' },
    { key: 'grain', name: 'Chromatic Aberration & Film Grain', desc: 'Pergeseran warna di tepi layar + bintik film tipis' },
    { key: 'dof', name: 'Depth of Field rendah', desc: 'Latar yang sangat jauh sedikit buram, mobil tetap tajam' },
  ]},
  { title: 'SUDUT PANDANG', items: [
    { key: 'fovNarrow', name: 'FOV Sempit 45–55°', desc: 'Proporsi mobil lebih padat, tandem terasa rapat' },
  ]},
];

function CameraIcon({ kind }: { kind: DriveCamera }) {
  return <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {kind === 'chase' && <><path d="m5.1 10.3 1.7-4.2h10.4l1.7 4.2M4 11.5l1.4-1.4h13.2l1.4 1.4v4.8H4v-4.8ZM5.7 16.4v2.2m12.6-2.2v2.2M7 13.3h2.4m5.2 0H17M10.9 16.3h2.2"/></>}
    {kind === 'overhead' && <><path d="M5 9V5h4m6 0h4v4m0 6v4h-4m-6 0H5v-4M9 11.2l3-3.7 3 3.7v4.5l-3-1.6-3 1.6v-4.5Z"/></>}
    {kind === 'cockpit' && <><circle cx="12" cy="12" r="8.1"/><circle cx="12" cy="12" r="2.24"/><path d="m4.1 10.7 5.6.83m4.6 0 5.6-.83M12 14.2v5.9"/></>}
    {kind === 'bumper' && <><path d="M4 9V6h3m10 0h3v3M4 15v3h3m10 0h3v-3M7.2 14.5l3-4.9m6.6 4.9-3-4.9M12 14.5v.1"/><path d="M8 14.5h8"/></>}
  </svg>;
}

function ShiftIcon() {
  return <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
    <path d="M5 6v12m7-12v12m7-12v12M5 12h14M4 5h2m5 0h2m5 0h2M4 19h2m5 0h2m5 0h2"/>
  </svg>;
}

function ToolButton({ label, title, onClick, children, disabled }: {
  label: string; title?: string; onClick: () => void; children: ReactNode; disabled?: boolean;
}) {
  return <button type="button" className="hud-button" aria-label={label} title={title ?? label} onClick={onClick} disabled={disabled}>{children}</button>;
}

export default function App({ onExit, initialMode }: { onExit?: () => void; initialMode?: ViewerMode } = {}) {
  const viewport = useRef<HTMLDivElement>(null), stage = useRef<HTMLElement>(null), menu = useRef<HTMLDialogElement>(null);
  const engine = useRef<Studio | undefined>(undefined), held = useRef(new Map<GripKey, Set<string>>());
  const [build,setBuild] = useState(readBuild);
  const [settings,setSettings] = useState(getSettings);
  const [filmPanel,setFilmPanel] = useState(false);
  const [record,setRecord] = useState(readRecord);
  const initialView = build.rear === 's1' ? 'rearQuarter' : 'threeQuarter';
  const [courseId,setCourseId] = useState(readSelectedCourse);
  const [loadingCourse,setLoadingCourse] = useState<CourseId | null>(null);
  const live = useRef({build,settings,record,finished:false,view:initialView as ViewId,mode:initialMode ?? 'drive',course:courseId,switching:false,camera:'chase' as DriveCamera,ghostCamera:'chase' as DriveCamera,ghost:'off' as GhostMode,paused:false,inspect:false,headlights:false,turning:false,guide:false});
  const rmxRef = useRef(false);
  const [rmxOpen, setRmxOpen] = useState(false);
  const [mode,setMode] = useState<ViewerMode>(initialMode ?? 'drive');
  const [selected,setSelected] = useState<DriveCamera>('chase');
  const [selectedGhost,setSelectedGhost] = useState<DriveCamera>('chase');
  const [ghostMode,setGhostMode] = useState<GhostMode>('off');
  const [ghostData,setGhostData] = useState<GhostHudData|null>(null);
  const ghostState = useRef<GhostHudData|null>(null);
  const [inspect,setInspect] = useState(false);
  const [paused,setPaused] = useState(false);
  const [guide,setGuide] = useState(false);
  const [ready,setReady] = useState(false);
  const [error,setError] = useState(false);
  const [pressed,setPressed] = useState<GripKey[]>([]);
  const [fullscreen,setFullscreen] = useState(false);
  const [telemetry,setTelemetry] = useState(emptyTelemetry);
  const [route,setRoute] = useState<Route>({path:'',start:{x:0,y:0},length:1,zones:[]});
  const [newRecord,setNewRecord] = useState(false);
  const [view,setView] = useState<ViewId|null>(initialView);
  const [turning,setTurning] = useState(false);

  const driving = mode === 'drive';
  const mountainCourse = courseId !== 'pinus';
  const isCustomFilm = !mountainCourse || settings.mountainLook === 'prodrift';
  const filmEnabled = mountainCourse ? isCustomFilm : filmAllOn(settings.film);
  // Minimal HUD while driving (user request): only corner-left (timer/score), corner bottom-left (speed/drift) and
  // the bottom-right route map stay visible. Everything else appears only in the pause menu (P / Esc).
  const minimalHud = driving && !paused && !telemetry.finished && ghostMode !== 'watch' && !inspect;
  const watching=ghostMode==='watch';
  const visibleTelemetry=watching&&ghostData?ghostData.telemetry:telemetry;
  const finished = telemetry.finished&&!watching;
  const medal = driftMedal(telemetry.drift.total);
  const alternate:RunMode = telemetry.mode==='attack'?'practice':'attack';
  const camera = watching?selectedGhost:inspect?'cockpit':selected;
  const isRear = view === 'rear' || view === 'rearQuarter' || view === 'rearDetail';

  function focusDrive() { viewport.current?.focus({preventScroll:true}); }

  function clearInputs() {
    held.current.clear();engine.current?.releaseInputs();setPressed([]);
  }

  function input(key:GripKey, source:string, down:boolean) {
    if (down && (!engine.current || live.current.mode !== 'drive' || live.current.ghost==='watch' || live.current.paused || live.current.inspect || live.current.finished)) return;
    const state = held.current, sources=state.get(key);
    if (down) {
      if (sources?.size) { sources.add(source); return; }
      state.set(key,new Set([source]));
      if(key==='w'||key==='s') engine.current?.unlockAudio();
      engine.current?.input(key,true);
    } else {
      if(!sources?.delete(source)||sources.size) return;
      state.delete(key);engine.current?.input(key,false);
    }
    const next=[...state.keys()];
    startTransition(()=>setPressed(next));
  }

  function changeInspect(next:boolean) {
    if (live.current.mode !== 'drive' || live.current.ghost==='watch' || live.current.inspect === next || !engine.current) return;
    live.current.inspect=next;setInspect(next);clearInputs();engine.current.inspectGear(next);
    if(!next) focusDrive();
  }

  function chooseCamera(next:DriveCamera) {
    if(live.current.ghost==='watch') {live.current.ghostCamera=next;setSelectedGhost(next);}
    else {live.current.camera=next;setSelected(next);}
    engine.current?.camera(next);
    if(live.current.inspect) changeInspect(false);
  }

  function cycleCamera() {
    const active=live.current.ghost==='watch'?live.current.ghostCamera:live.current.camera;
    const i=cameras.findIndex(item=>item.id===active);
    chooseCamera(cameras[(i+1)%cameras.length].id);
    focusDrive();
  }

  function toggleBumper() {
    const active=live.current.ghost==='watch'?live.current.ghostCamera:live.current.camera;
    chooseCamera(active==='bumper'?'chase':'bumper');focusDrive();
  }

  function chooseGhost(next:GhostMode) {
    const current=live.current,player=engine.current;
    if(!player||current.mode!=='drive'||current.ghost===next)return;
    if(current.inspect)changeInspect(false);
    if(next==='watch'||current.ghost==='watch') {
      clearInputs();current.paused=current.guide=false;setPaused(false);setGuide(false);
      player.pause(false);menu.current?.close();
    }
    current.ghost=next;setGhostMode(next);
    if(next==='watch')player.unlockAudio();
    player.ghost(next);player.camera(next==='watch'?current.ghostCamera:current.camera);
    focusDrive();
  }

  function toggleGhostCamera() {chooseGhost(live.current.ghost==='watch'?'follow':'watch');}

  function playGhost() {
    if(!engine.current||live.current.ghost!=='watch')return;
    engine.current.unlockAudio();engine.current.ghostPlay(!ghostState.current?.playing);
  }

  function replayGhost() {
    if(live.current.paused)togglePause(false);
    engine.current?.ghostSeek(0);engine.current?.ghostPlay(true);focusDrive();
  }

  function togglePause(next:boolean) {
    if (live.current.mode!=='drive'||live.current.paused===next||(live.current.finished&&live.current.ghost!=='watch')||!engine.current) return;
    live.current.paused=next;
    live.current.guide=false;setGuide(false);
    if (next) setFilmPanel(false);
    clearInputs();engine.current.pause(next);setPaused(next);
    if(!next) {
      menu.current?.close();
      focusDrive();
    }
  }

  function openRmx() {
    if(!engine.current) return;
    rmxRef.current=true;
    if(live.current.mode==='drive'&&!live.current.paused&&!live.current.finished) togglePause(true);
    clearInputs();
    if(menu.current?.open) menu.current.close();
    setRmxOpen(true);
  }

  function closeRmx() {
    rmxRef.current=false;setRmxOpen(false);
    if(live.current.mode==='drive'&&live.current.paused) togglePause(false);
    else if(live.current.finished&&!menu.current?.open) menu.current?.showModal();
  }

  function restart(type?:RunMode, drive?:HarunaDriveMode) {
    if(live.current.ghost==='watch'){replayGhost();return;}
    togglePause(false);clearInputs();
    live.current.finished=false;setNewRecord(false);
    live.current.inspect=false;setInspect(false);
    engine.current?.restart(type, drive);
    if(menu.current?.open) menu.current.close();
    focusDrive();
  }

  function chooseView(next:ViewId) {
    live.current.view=next;live.current.turning=false;setView(next);setTurning(false);
    engine.current?.turntable(false);engine.current?.view(next);
  }

  function switchMode(next:ViewerMode) {
    if(live.current.mode===next) return;
    togglePause(false);menu.current?.close();clearInputs();
    live.current.mode=next;live.current.inspect=false;setInspect(false);setMode(next);
    engine.current?.mode(next);
    if(next==='garage') {
      chooseView(live.current.build.rear==='s1'?'rearQuarter':'threeQuarter');
    } else focusDrive();
  }

  function switchCourse(next:CourseId) {
    const current=live.current, studio=engine.current;
    if(!studio||current.switching||current.course===next) return;
    clearInputs();
    if(current.inspect) changeInspect(false);
    if(current.ghost!=='off') {
      current.ghost='off';setGhostMode('off');
      ghostState.current=null;setGhostData(null);
      studio.ghost('off');
    }
    current.switching=true;setLoadingCourse(next);
    current.finished=false;current.paused=false;setPaused(false);
    setFilmPanel(false);
    menu.current?.close();
    // Paint the load state before constructing the next scene on the render thread.
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(engine.current!==studio) return;
      try {
        studio.course(next);
        current.course=next;setCourseId(next);saveSelectedCourse(next);focusDrive();
      } catch (reason) {
        console.error(reason);setReady(false);setError(true);
      } finally {
        current.switching=false;setLoadingCourse(null);
      }
    }));
  }

  function selectPart<K extends keyof RallyBuild>(part:K,value:RallyBuild[K]) {
    if (value === live.current.build[part]) return;
    const next={...live.current.build,[part]:value};
    live.current.build=next;setBuild(next);engine.current?.configure(next);writeBuild(next);
    if(part==='nose') chooseView('noseDetail');
    if(part==='rear'||part==='wing') chooseView('rearQuarter');
  }

  function resetBuild() {
    const fresh={...defaultBuild};live.current.build=fresh;setBuild(fresh);engine.current?.configure(fresh);writeBuild(fresh);chooseView('rearQuarter');
  }

  function toggleTurntable() {
    const next=!live.current.turning;
    if(next&&live.current.view==='noseDetail') chooseView('threeQuarter');
    if(next&&live.current.view==='rearDetail') chooseView('rearQuarter');
    live.current.turning=next;setTurning(next);engine.current?.turntable(next);
  }

  function changeSetting(key:keyof typeof settings) {
    const next={...live.current.settings,[key]:!live.current.settings[key]};
    live.current.settings=next;
    if(key==='sound')engine.current?.sound(next.sound);
    else if(key==='assist')engine.current?.assist(next.assist);
    else engine.current?.speedEffects(next.speedEffects);
    setSettings(next);
    try { localStorage.setItem(settingKey,JSON.stringify(next)); } catch { /* Storage is optional. */ }
  }

  function changeLighting(patch: Partial<LightingState>) {
    const next = { ...live.current.settings, lighting: { ...live.current.settings.lighting, ...patch } };
    live.current.settings = next;
    engine.current?.lighting(next.lighting);
    setSettings(next);
    try { localStorage.setItem(settingKey, JSON.stringify(next)); } catch { /* Storage is optional. */ }
  }
  function toggleFeintFlick() {
    const next = { ...live.current.settings, feintFlick: !live.current.settings.feintFlick };
    live.current.settings = next;
    engine.current?.feint(next.feintFlick);
    setSettings(next);
    try { rmxLive.events.push({ id: -Date.now(), kind: 'feint', label: next.feintFlick ? 'FEINT — SCANDINAVIAN FLICK ON!' : 'FEINT MODE OFF', accent: 'emerald', time: performance.now() }); } catch { /* popup is cosmetic */ }
    try { localStorage.setItem(settingKey, JSON.stringify(next)); } catch { /* Storage is optional. */ }
  }
  function changeMood(next: LightingMood) {
    const nextSettings = { ...live.current.settings, tod: next };
    live.current.settings = nextSettings;
    engine.current?.mood(next);
    setSettings(nextSettings);
    try { localStorage.setItem(settingKey, JSON.stringify(nextSettings)); } catch { /* Storage is optional. */ }
  }
  function changeAtmosphere(next: Partial<AtmosphereState>) {
    const atmosphere = { ...live.current.settings.atmosphere, ...next };
    saveAtmosphere(atmosphere);
    engine.current?.atmosphere(next);
    setSettings({ ...live.current.settings, atmosphere });
  }
  function changeDrivetrain(next: BmwCfg) {
    const nextSettings = { ...live.current.settings, drivetrain: next };
    live.current.settings = nextSettings;
    engine.current?.drivetrain(next);
    setSettings(nextSettings);
    try { localStorage.setItem(settingKey, JSON.stringify(nextSettings)); } catch { /* Storage is optional. */ }
  }
  function changeMountainLook(look: MountainLook, restore = false) {
    const next = { ...live.current.settings, mountainLook: look };
    if (restore) {
      next.tod = 'day';
      next.lighting = { ...DEFAULT_LIGHTING };
      engine.current?.mood(next.tod);
      engine.current?.lighting(next.lighting);
    }
    live.current.settings = next;
    engine.current?.mountainLook(look);
    setSettings(next);
    try { localStorage.setItem(settingKey, JSON.stringify(next)); } catch { /* Storage is optional. */ }
  }
  function toggleFilmLook() {
    if (live.current.course === 'pinus') changeFilm(null);
    else changeMountainLook(live.current.settings.mountainLook === 'pigeon' ? 'prodrift' : 'pigeon');
  }
  function filmAllOn(film: FilmFlags) { return ALL_FILM.every(key => film[key]); }
  function filmCount(film: FilmFlags) { return ALL_FILM.filter(key => film[key]).length; }
  function filmLabel(film: FilmFlags) { const n = filmCount(film); return filmAllOn(film) ? 'SESUDAH · SEMUA ON' : n === 0 ? 'SEBELUM · SEMUA OFF' : `KUSTOM · ${n}/${ALL_FILM.length} EFEK ON`; }
  function changeFilm(key: keyof FilmFlags | null) {
    const nextFilm = key === null
      ? (filmAllOn(live.current.settings.film) ? Object.fromEntries(ALL_FILM.map(k => [k, false])) as FilmFlags
        : { ...live.current.settings.film, ...Object.fromEntries(ALL_FILM.map(k => [k, true])) } as FilmFlags)
      : { ...live.current.settings.film, [key]: !live.current.settings.film[key] };
    const next = { ...live.current.settings, film: nextFilm };
    live.current.settings = next;
    engine.current?.cinematic(nextFilm);
    setSettings(next);
    try { localStorage.setItem(settingKey, JSON.stringify(next)); } catch { /* Storage is optional. */ }
  }

  async function toggleFullscreen() {
    if(!stage.current) return;
    if(document.fullscreenElement===stage.current) {await document.exitFullscreen().catch(()=>undefined);return;}
    if(stage.current.requestFullscreen) await stage.current.requestFullscreen().catch(()=>undefined);
  }

  useEffect(()=>{
    if(!viewport.current) return;
    const abort=new AbortController(), start=live.current;
    createStudio(viewport.current,{
      onManualOrbit:()=>{live.current.turning=false;setTurning(false);setView(null);},
      onTelemetry:data=>{
        if(data.finished&&!live.current.finished) {
          live.current.finished=true;clearInputs();
          const total=data.drift.total;
          if(total>live.current.record) {
            live.current.record=total;setRecord(total);setNewRecord(true);
            try {localStorage.setItem(recordKey,String(total));} catch { /* A run can finish without storage. */ }
          }
        }
        setTelemetry(data);
      },
      onGhost:data=>{ghostState.current=data;setGhostData(data);},
      onCourse:(path,marker,length,zones,name)=>setRoute({path,start:marker,length,zones,name}),
    },abort.signal,{build:start.build,headlights:start.headlights,view:start.view,mode:start.mode,course:start.course,camera:start.camera,assist:start.settings.assist,sound:start.settings.sound,speedEffects:start.settings.speedEffects,cinematic:start.settings.film,mountainLook:start.settings.mountainLook,lighting:start.settings.lighting,atmosphere:start.settings.atmosphere,drivetrain:start.settings.drivetrain,feintFlick:start.settings.feintFlick,mood:start.settings.tod}).then(studio=>{
      if(!studio) return;
      if(abort.signal.aborted) {studio.dispose();return;}
      engine.current=studio;setReady(true);
    }).catch((reason:unknown)=>{if(!abort.signal.aborted){console.error(reason);setError(true);}});

    function keyDown(event:KeyboardEvent) {
      const code=event.code, target=event.target as HTMLElement|null;
      if(event.metaKey||event.ctrlKey||event.altKey)return;
      if(target?.closest('.film-panel')) {
        if(code==='Escape'||code==='KeyG') {event.preventDefault();setFilmPanel(false);focusDrive();}
        return; // panel owns keyboard focus; let its switches handle Space/Enter natively
      }
      if(target?.closest('input,textarea,[contenteditable]'))return;
      if(code==='F2'&&onExit&&!event.repeat){event.preventDefault();onExit();return;}
      const state=live.current;
      if(!engine.current||state.switching)return;
      if(code==='KeyV'&&state.mode==='drive'&&!event.repeat){event.preventDefault();toggleGhostCamera();return;}
      if(state.finished&&state.ghost!=='watch') {if(code==='KeyR'&&!event.repeat) restart();return;}
      if(state.paused) {
        if(code==='KeyP'&&!event.repeat){event.preventDefault();togglePause(false);}
        return;
      }
      if(state.mode==='garage') {
        if(code==='Escape'&&!event.repeat) switchMode('drive');
        return;
      }
      if(state.ghost==='watch') {
        if(event.repeat)return;
        if(code==='Space'&&!target?.closest('button:focus-visible, a:focus-visible')){event.preventDefault();playGhost();}
        if(code==='KeyR')replayGhost();
        if(code==='KeyC')cycleCamera();
        if(code==='KeyB')toggleBumper();
        if(code==='KeyF')toggleFilmLook();
        if(code==='KeyP')togglePause(true);
        if(code==='Escape'&&!document.fullscreenElement) chooseGhost('follow');
        if(code==='KeyM')toggleFeintFlick();
        return;
      }
      if(code==='KeyE'&&!event.repeat){engine.current?.shift(1);return;}
      if(code==='KeyQ'&&!event.repeat){engine.current?.shift(-1);return;}
      const key=keyBindings[code];
      if(key&&!state.inspect) {
        event.preventDefault();
        if(!event.repeat) {
          focusDrive();
          input(key,code,true);
        }
        return;
      }
      if(event.repeat)return;
      if(code==='KeyC') cycleCamera();
      if(code==='KeyB') toggleBumper();
      if(code==='KeyF') toggleFilmLook();
      if(code==='KeyG' && state.mode==='drive') setFilmPanel(open => !open);
      if(code==='KeyI') changeInspect(!state.inspect);
      if(code==='KeyR') restart();
      if(code==='KeyM') toggleFeintFlick();
      if(code==='KeyL') {state.headlights=!state.headlights;engine.current?.headlights(state.headlights);}
      if(code==='KeyP'||code==='Escape') {
        if(code==='Escape'&&state.inspect) changeInspect(false);
        else if(code!=='Escape'||!document.fullscreenElement) togglePause(true);
      }
    }
    const keyUp=(event:KeyboardEvent)=>{const key=keyBindings[event.code];if(key)input(key,event.code,false);};
    const onFull=()=>setFullscreen(document.fullscreenElement===stage.current);
    const onVisibility=()=>{
      if(document.hidden && live.current.mode==='drive') {
        clearInputs();
        if(engine.current&&!live.current.paused) togglePause(true);
      }
    };
    window.addEventListener('keydown',keyDown);window.addEventListener('keyup',keyUp);window.addEventListener('blur',clearInputs);
    document.addEventListener('fullscreenchange',onFull);document.addEventListener('visibilitychange',onVisibility);
    return ()=>{
      abort.abort();engine.current?.dispose();engine.current=undefined;
      window.removeEventListener('keydown',keyDown);window.removeEventListener('keyup',keyUp);window.removeEventListener('blur',clearInputs);
      document.removeEventListener('fullscreenchange',onFull);document.removeEventListener('visibilitychange',onVisibility);
    };
  },[]);

  useEffect(()=>{
    if((paused||finished)&&!menu.current?.open&&!rmxRef.current) menu.current?.showModal();
    else if(!paused&&!finished&&menu.current?.open) menu.current.close();
  },[paused,finished]);

  function pedal(key:GripKey, mobile=false, icon?:ReactNode) {
    const pressedNow=pressed.includes(key);
    function down(event:PointerEvent<HTMLButtonElement>) {
      if(event.button!==0)return;
      event.currentTarget.setPointerCapture(event.pointerId);
      input(key,`pointer-${event.pointerId}`,true);
    }
    const release=(event:PointerEvent<HTMLButtonElement>)=>input(key,`pointer-${event.pointerId}`,false);
    return <button type="button" className={`${mobile?'touch-pedal':'keycap'}${key==='space'?' handbrake-key':''}${pressedNow?' key-active':''}`}
      aria-label={names[key]} aria-pressed={pressedNow} disabled={!ready||paused||inspect} title={names[key]}
      onPointerDown={down} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}
      onClick={event=>{
        if(event.detail===0){input(key,'accessible-tap',true);window.setTimeout(()=>input(key,'accessible-tap',false),195);}
      }}>
      {icon ?? (key==='space'?'SPASI':key.toUpperCase())}
    </button>;
  }

  const coursePicker = <div className="pause-course-picker">
    <span>PILIH MAP</span>
    <div className="course-switch" role="group" aria-label="Pilih map ProDrift">
      {COURSE_IDS.map(id => <button key={id} type="button" aria-pressed={courseId === id} onClick={() => switchCourse(id)}>{COURSES[id].name}</button>)}
    </div>
  </div>;

  return <main className={`race-screen${driving?'':' garage-screen'}${ready?' is-ready':''}${error?' race-error':''}${inspect?' is-inspecting':''}${watching?' ghost-watch':''}`} ref={stage} data-mode={mode} data-course={courseId} data-camera={driving?inspect?'gear':camera:'garage'} data-ghost={ghostMode} aria-label="PRODRIFT Rally Group B Drift">
    <div className="game-viewport" ref={viewport} tabIndex={-1} onPointerDown={()=>{if(driving&&!paused&&!inspect) focusDrive();}}/>

    <div className="corner corner-left">
      <RaceBrand/>
      {driving&&ready&&!inspect&&<LapReadout data={visibleTelemetry} route={route} record={record} ghost={ghostData}/>}
      {driving&&ready&&inspect&&<div className="inspect-view" aria-label="Inspeksi genggaman persneling">
        <span>INSPEKSI / KOKPIT</span><h1>Persneling</h1><p>Genggaman tangan kanan pada tuas otomatis.</p>
      </div>}
      {!driving&&<div className="garage-heading"><span>GROUP B / STUDIO</span><h1>Garasi</h1></div>}
    </div>

    {driving&&ready&&paused&&!finished&&!inspect&&camera==='cockpit'&&<div className="skin-quick-bar" role="group" aria-label="Warna kulit tangan pengemudi">
      <span>KULIT</span>
      {skins.map(s=><button key={s.id} type="button" aria-pressed={build.skin===s.id} title={s.label} onClick={()=>{selectPart('skin',s.id);focusDrive();}}>
        <i className="skin-dot" style={{background:s.tone}} aria-hidden="true"/><span>{s.name}</span>
      </button>)}
    </div>}

    {minimalHud&&ready&&!loadingCourse&&<div className="drive-quick-tools">
      <button type="button" className="hud-button" aria-label="Pencahayaan dan bayangan" title="Pencahayaan dan bayangan (G)"
        aria-expanded={filmPanel} aria-keyshortcuts="G" onClick={()=>setFilmPanel(open=>!open)}><SlidersHorizontal size={16}/><span>Pencahayaan</span></button>
      <ToolButton label="Jeda (P)" onClick={()=>togglePause(true)}><Pause size={16}/></ToolButton>
    </div>}
    {!minimalHud&&<div className="corner corner-right">
      {driving ? <>
        <div className="camera-switch" role="group" aria-label="Pilih kamera (C)">
          {cameras.map(item=><button type="button" key={item.id} aria-label={item.accessible} aria-pressed={camera===item.id}
            title={item.id==='bumper'?'Kamera bemper dekat aspal (B)':`${item.accessible} (C)`} aria-keyshortcuts={item.id==='bumper'?'B':undefined} onClick={event=>{chooseCamera(item.id);if(event.detail>0)focusDrive();}} disabled={!ready}>
            <CameraIcon kind={item.id}/><span>{item.label}</span>
          </button>)}
        </div>
        <div className="film-cluster">
          <button type="button" role="switch" className={`film-toggle${filmEnabled?' film-on':''}`} aria-checked={filmEnabled} aria-keyshortcuts="F"
            title={mountainCourse?'Bandingkan tampilan PIGEON dan sinematik ProDrift (F)':'Nyalakan atau matikan efek sinematik (F)'}
            onClick={event=>{toggleFilmLook();if(event.detail>0)focusDrive();}} disabled={!ready}>
            <Video size={16}/><span className="film-label"><b>SINEMATIK</b><small>{mountainCourse?(filmEnabled?'PRODRIFT':'PIGEON ASLI'):filmLabel(settings.film)}</small></span><kbd aria-hidden="true">F</kbd>
          </button>
          <button type="button" className={`film-open${filmPanel?' film-on':''}`} aria-expanded={filmPanel} aria-keyshortcuts="G"
            title="Buka panel Kamera & Eksposure: toggle tiap efek, bloom 10%, kontras kulit 10%"
            onClick={event=>{if(event.detail>0)focusDrive();setFilmPanel(open => !open);}} disabled={!ready}>
            <SlidersHorizontal size={16}/><span>Panel</span><kbd aria-hidden="true">G</kbd>
          </button>
        </div>
        <ToolButton label="Jeda" title="Jeda (Esc / P)" onClick={()=>togglePause(true)} disabled={!ready}><Pause size={18}/></ToolButton>
      </> : <>
        {onExit&&<ToolButton label="Kembali ke beranda" onClick={onExit}><ArrowLeft size={17}/></ToolButton>}
        <button className="back-to-track" type="button" onClick={()=>switchMode('drive')}><Flag size={17}/> Ke lintasan</button>
      </>}
      {document.fullscreenEnabled&&<ToolButton label={fullscreen?'Keluar layar penuh':'Layar penuh'} onClick={()=>void toggleFullscreen()}>{fullscreen?<Minimize size={18}/>:<Maximize size={18}/>}</ToolButton>}
    </div>}

    {filmPanel&&driving&&ready&&!paused&&<section className="film-panel" role="dialog" aria-label="Pengaturan pencahayaan langsung">
      <header className="film-head">
        <div className="film-head-text">
          <strong><SlidersHorizontal size={15}/> PENCAHAYAAN &amp; BAYANGAN</strong>
          <small>{mountainCourse?'Berkas matahari dan kabut dari PIGEON':'Rig klasik ProDrift'} / Pratinjau langsung</small>
        </div>
        <button type="button" className="film-close" aria-label="Tutup panel" onClick={()=>setFilmPanel(false)}><X size={17}/></button>
      </header>
      <div className="film-group">
        {mountainCourse&&<div className="lighting-preset" role="group" aria-label="Tampilan lintasan">
          <button type="button" aria-pressed={!isCustomFilm} onClick={()=>changeMountainLook('pigeon')}>PIGEON asli</button>
          <button type="button" aria-pressed={isCustomFilm} onClick={()=>changeMountainLook('prodrift')}>Sinematik ProDrift</button>
        </div>}
        <div className="mood-row" role="group" aria-label="Waktu dan cuaca">
          <button type="button" className={`mood-btn${settings.tod==='day'?' mood-on':''}`} aria-pressed={settings.tod==='day'} onClick={()=>changeMood('day')}><Sun size={15}/><b>Cerah Siang</b></button>
          <button type="button" className={`mood-btn${settings.tod==='rain'?' mood-on':''}`} aria-pressed={settings.tod==='rain'} onClick={()=>changeMood('rain')}><CloudRain size={15}/><b>Hujan Siang</b></button>
          <button type="button" className={`mood-btn${settings.tod==='night'?' mood-on':''}`} aria-pressed={settings.tod==='night'} onClick={()=>changeMood('night')}><MoonStar size={15}/><b>Malam</b></button>
        </div>
        {LIGHT_SLIDERS.map(slider => {
          const value = settings.lighting[slider.key];
          return <label className="light-slider" key={slider.key}>
            <span className="light-slider-head">
              <span className="light-slider-text"><b>{slider.name}</b><small>{mountainCourse && slider.key === 'dir' ? 'Cahaya langsung, halo, dan berkas di hutan' : slider.desc}</small></span>
              <output>{Math.round(value)}%</output>
            </span>
            <input type="range" min="0" max="100" step="1" value={value} aria-label={slider.name} aria-valuetext={`${value}%`}
              style={{ ['--fill' as string]: `${value}%` }}
              onChange={event => changeLighting({ [slider.key]: Number(event.target.value),
                ...(slider.key === 'hemi' ? { hemiOn: true } : slider.key === 'dir' ? { dirOn: true } : {}) })} />
          </label>;
        })}
        <div className="lighting-compare">
          <button type="button" onClick={()=>changeLighting({shadow:0})}>Tanpa bayangan</button>
          <button type="button" onClick={()=>{
            if (mountainCourse) { changeMountainLook('pigeon', true); changeAtmosphere({ ...DEFAULT_ATMOSPHERE }); }
            else changeLighting(DEFAULT_LIGHTING);
          }}>{mountainCourse?'Pulihkan PIGEON asli':'Kembalikan ke 100%'}</button>
        </div>
      </div>
      {mountainCourse&&<div className="film-group">
        <h3>KABUT &amp; LANGIT</h3>
        <label className="light-slider">
          <span className="light-slider-head">
            <span className="light-slider-text"><b>Tebal kabut</b><small>Kepekatan kabut di sekitar hutan</small></span>
            <output>{Math.round(settings.atmosphere.fogThickness)}%</output>
          </span>
          <input type="range" min="0" max="100" step="1" value={settings.atmosphere.fogThickness} aria-label="Tebal kabut" aria-valuetext={`${settings.atmosphere.fogThickness}%`}
            style={{ ['--fill' as string]: `${settings.atmosphere.fogThickness}%` }}
            onChange={event => changeAtmosphere({ fogThickness: Number(event.target.value) })} />
        </label>
        <label className="light-slider">
          <span className="light-slider-head">
            <span className="light-slider-text"><b>Jarak kabut</b><small>Sejauh mana lereng dan gunung tetap terlihat</small></span>
            <output>{Math.round(settings.atmosphere.fogDistance)} m</output>
          </span>
          <input type="range" min="80" max="1000" step="20" value={settings.atmosphere.fogDistance} aria-label="Jarak kabut" aria-valuetext={`${settings.atmosphere.fogDistance} meter`}
            style={{ ['--fill' as string]: `${((settings.atmosphere.fogDistance - 80) / 920) * 100}%` }}
            onChange={event => changeAtmosphere({ fogDistance: Number(event.target.value) })} />
        </label>
        <div className="sky-themes" role="group" aria-label="Tema warna langit">
          {(Object.keys(SKY_THEMES) as SkyTheme[]).map(theme => (
            <button key={theme} type="button" aria-pressed={settings.atmosphere.skyTheme === theme}
              onClick={() => changeAtmosphere({ skyTheme: theme })}>{SKY_THEMES[theme].name}</button>
          ))}
        </div>
      </div>}
      {isCustomFilm&&<details><summary>Efek kamera sinematik</summary>
        {FILM_GROUPS.map(group=><div className="film-group" key={group.title}>
          <h3>{group.title}</h3>
          {group.items.map(item=>{
            const on=settings.film[item.key];
            return <button type="button" role="switch" key={item.key} className={`film-row${on?' film-on':''}`} aria-checked={on} onClick={()=>changeFilm(item.key)}>
              <span className="row-switch" aria-hidden="true"><i/></span>
              <span className="film-row-text"><b>{item.name}</b><small>{item.desc}</small></span>
              <span className="row-state">{on?'ON':'OFF'}</span>
            </button>;
          })}
        </div>)}
      </details>}
    </section>}

    {(!ready||loadingCourse)&&<div className="game-loading" role="status">
      {error?<><CircleHelp size={26}/><strong>Lintasan 3D gagal dimuat</strong><p>Pastikan browser mendukung WebGL 2 dan akselerasi grafis.</p><button className="primary-action" type="button" onClick={()=>location.reload()}><RotateCcw size={16}/> Muat ulang</button>{onExit&&<button type="button" onClick={onExit}>Kembali ke beranda</button>}</>
        :<><span className="spinner"/><span>MEMUAT {driving ? COURSES[loadingCourse ?? courseId].name.toUpperCase() : 'GARASI'}</span></>}
    </div>}

    {driving&&ready&&!paused&&!finished&&(!inspect?<>
      <SpeedReadout data={visibleTelemetry} pedal={!watching}/>
      <RouteMap data={visibleTelemetry} route={route} ghost={watching} companion={ghostMode==='follow'?ghostData?.telemetry:undefined}/>
      <EngineCluster engine={settings.drivetrain.engine} trans={settings.drivetrain.trans}
        onEngine={e => changeDrivetrain({ ...settings.drivetrain, engine: e })}
        onTrans={t => changeDrivetrain({ ...settings.drivetrain, trans: t })}/>
      <DriftReadout data={visibleTelemetry}/>
      {minimalHud&&telemetry.time===0&&!loadingCourse&&<div className="drive-start-hint"><kbd>W</kbd> untuk mulai</div>}
      {!minimalHud&&watching&&ghostData?<GhostCoach data={ghostData} onPlay={playGhost} onReplay={replayGhost} onExit={()=>chooseGhost('follow')}
        onRate={()=>engine.current?.ghostRate(ghostData.rate===.5?1:.5)} onSeek={time=>{engine.current?.ghostPlay(false);engine.current?.ghostSeek(time);}}/>:!minimalHud&&<>
      {camera==='cockpit'&&<button type="button" className="gear-inspect" aria-keyshortcuts="I" title="Detail gear (I)" onClick={()=>changeInspect(true)}><ShiftIcon/><span>Detail gear</span><kbd aria-hidden="true">I</kbd></button>}
      <div className="controls-cluster">
        {telemetry.time===0?<div className="start-hint"><i/> TAHAN W UNTUK MULAI <i/></div>:<DrivePrompt data={telemetry}/>}
        <div className="keyboard-controls" aria-label="Kontrol berkendara">
          <div><span className="key-group">{pedal('w')}{pedal('s')}</span><span>Gas / Rem</span></div>
          <div><span className="key-group">{pedal('a')}{pedal('d')}</span><span>Belok</span></div>
          <div><span className="key-group">{pedal('space')}</span><span>Handbrake</span></div>
        </div>
      </div>
      </>}
      {!watching&&<div className="touch-controls" aria-label="Kontrol sentuh">
        <div className="touch-steer">{pedal('a',true,<ArrowLeft/>)}{pedal('d',true,<ArrowRight/>)}</div>
        <div className="touch-drive">{pedal('space',true,<span>REM<br/>TANGAN</span>)}{pedal('s',true,<ArrowDown/>)}{pedal('w',true,<ArrowUp/>)}</div>
      </div>}
    </>:<button type="button" className="leave-inspect" aria-keyshortcuts="I" onClick={()=>changeInspect(false)}><ArrowLeft size={16}/> Kembali mengemudi <kbd aria-hidden="true">I</kbd></button>)}

    {!driving&&ready&&<>
      <div className="garage-build"><BuildPanel build={build} onPart={selectPart} onReset={resetBuild} onPreview={()=>chooseView('threeQuarter')}/></div>
      <div className="garage-bottom">
        <div className="garage-views" aria-label="Sudut pandang mobil">
          {garageViews.map(item=><button type="button" key={item.id} aria-pressed={view===item.id||(item.id==='rear'&&isRear)} onClick={()=>chooseView(item.id)}>{item.label}</button>)}
        </div>
        <div className="garage-tools">
          <ToolButton label="Perkecil kamera" onClick={()=>engine.current?.zoomBy(-1)}><Minus size={17}/></ToolButton>
          <ToolButton label="Perbesar kamera" onClick={()=>engine.current?.zoomBy(1)}><Plus size={17}/></ToolButton>
          <ToolButton label="Detail mobil" onClick={()=>chooseView(isRear?'rearDetail':'noseDetail')}><Focus size={17}/></ToolButton>
          <button className="hud-button" type="button" title="Putar otomatis" aria-label="Putar otomatis" aria-pressed={turning} onClick={toggleTurntable}><RotateCcw size={17}/></button>
        </div>
      </div>
    </>}

    <dialog className={`pause-menu${finished?' finish-menu':''}`} ref={menu} aria-labelledby="menu-title" onCancel={event=>{event.preventDefault();if(finished)return;if(live.current.guide){live.current.guide=false;setGuide(false);}else togglePause(false);}}>
      <div className="pause-top"><span><i/> PRODRIFT / {watching?'GHOST AI':COURSES[courseId].name.toUpperCase()}</span>{!finished&&<ToolButton label={guide?'Kembali ke menu':'Tutup menu'} onClick={()=>{if(guide){live.current.guide=false;setGuide(false);}else togglePause(false);}}>{guide?<ArrowLeft size={18}/>:<X size={19}/>}</ToolButton>}</div>
      <h1 id="menu-title">{finished?'FINIS':guide?'Kontrol':'Dijeda'}</h1>
      {!guide&&!watching&&coursePicker}
      {finished?<>
        <div className="finish-score"><span>{newRecord?'REKOR BARU':'SKOR PUTARAN'}</span><strong>{formatScore(telemetry.drift.total)}</strong></div>
        <div className="finish-splits"><div><span>KOMBO TERBAIK</span><b>{formatScore(telemetry.drift.top)}</b></div><div><span>SAMBUNGAN</span><b>{telemetry.drift.allLinks}</b></div></div>
        <div className={`finish-medal${medal?` medal-${medal}`:''}`}><Trophy size={17}/><span>{medal?({gold:'MEDALI EMAS',silver:'MEDALI PERAK',bronze:'MEDALI PERUNGGU'} as const)[medal]:'TARGET PERUNGGU'}</span>
          {!medal&&<b>{formatScore(medalGoals.bronze)} poin</b>}</div>
        <div className="pause-actions"><button className="primary-action" type="button" onClick={()=>restart('attack')}><RotateCcw size={18}/> Coba lagi</button><button type="button" onClick={()=>restart('practice')}><Flag size={18}/> Latihan bebas</button>{courseId==='haruna'&&<button type="button" onClick={()=>restart('practice','terrain')}><Compass size={18}/> Jelajah medan</button>}{courseId==='pinus'&&<button type="button" onClick={()=>chooseGhost('watch')}><GhostIcon size={18}/> Tonton Ghost AI</button>}{onExit&&<button type="button" onClick={onExit}><ArrowLeft size={18}/> Kembali ke beranda</button>}</div>
      </>:guide ? <>
        <dl className="help-controls">
          <div><dt>Gas / rem dan mundur</dt><dd><kbd>W</kbd><kbd>S</kbd></dd></div>
          <div><dt>Belok kiri / kanan</dt><dd><kbd>A</kbd><kbd>D</kbd></dd></div>
          <div><dt>Handbrake / E-Brake Drift (tahan + A/D penuh untuk 360° &amp; donut)</dt><dd><kbd>SPASI</kbd></dd></div>
          <div><dt>Ganti kamera (Belakang / Atas / Kokpit / Bemper)</dt><dd><kbd>C</kbd></dd></div>
          <div><dt>Info fisika Drift Simulator / detail persneling</dt><dd><kbd>TAB</kbd><kbd>I</kbd></dd></div>
          <div><dt>Kamera bemper dekat aspal / lampu depan</dt><dd><kbd>B</kbd><kbd>L</kbd></dd></div>
          <div><dt>Lihat kamera Ghost AI</dt><dd><kbd>V</kbd></dd></div>
          <div><dt>Ulang lintasan / jeda</dt><dd><kbd>R</kbd><kbd>P</kbd></dd></div>
          <div><dt>Feint — mode Scandinavian Flick (banting setir A↔D penuh &amp; cepat)</dt><dd><kbd>M</kbd></dd></div>
        </dl>
        <p className="drift-tip">Menggunakan 100% fisika 3D Car Drift Simulator: tahan W + A/D untuk Power Over Drift, tarik Spasi untuk E-Brake Drift instan, banting A↔D cepat untuk Feint &amp; Manji (aktifkan mode Scandinavian Flick dengan M), atau tahan Spasi + A/D penuh untuk 360° Spin &amp; Donut dengan auto counter-steer assist mulus.</p>
        <div className="drift-howto">
          <h4>CARA DRIFT YANG BENAR (singkat):</h4>
          <ol>
            <li><b>Rem SEBELUM tikungan</b> — masuk tikungan dengan kecepatan pas, lepas rem &amp; langsung gas saat masuk.</li>
            <li><b>Inisialisasi kick</b> — tarik <kbd>SPASI</kbd> (E-Brake) + <kbd>A</kbd>/<kbd>D</kbd> lock, atau banting <kbd>A</kbd>↔<kbd>D</kbd> cepat (FEINT), atau power-over (gas penuh + lock).</li>
            <li><b>Tahan angle</b> — jaga <kbd>W</kbd> di tengah (jangan flooring terus), <b>counter-steer</b> ke arah slide, jangan injak rem di tengah slide.</li>
            <li><b>Keluar corner</b> — luruskan setir pelan-pelan, tambah gas penuh, mobil kembali grip — itu cleans line.</li>
            <li><i>Belok kanan/kiri biasa = mobil GRIP (stabil &amp; rata). Drift hanya keluar kalau Anda yang memulai — jadi cornering santai bebas slide.</i></li>
          </ol>
        </div>
        <p className="gamepad-help">Gamepad: stik kiri untuk belok, RT untuk gas, LT untuk rem, dan tombol bawah (A) untuk drift.</p>
      </> : watching ? <div className="pause-actions">
        <button className="primary-action" type="button" autoFocus onClick={()=>{togglePause(false);engine.current?.ghostPlay(true);}}><Play size={19}/> Lanjutkan demo</button>
        <button type="button" onClick={replayGhost}><RotateCcw size={18}/> Ulang demo Ghost</button>
        <button type="button" onClick={()=>chooseGhost('follow')}><ArrowLeft size={18}/> Kembali ke mobil sendiri</button>
      </div> : <>
        <div className="pause-actions">
          <button className="primary-action" type="button" autoFocus onClick={()=>togglePause(false)}><Play size={19}/> Lanjut mengemudi</button>
          <button type="button" aria-keyshortcuts="R" onClick={()=>restart()}><RotateCcw size={18}/> Ulang lintasan <kbd aria-hidden="true">R</kbd></button>
          {telemetry.harunaDrive !== 'terrain' && <button type="button" onClick={()=>restart(alternate)}><Flag size={18}/> {alternate==='practice'?'Latihan bebas':'Drift Attack'}</button>}
          {courseId === 'haruna' && <button type="button" title={telemetry.harunaDrive === 'terrain' ? 'Mulai ulang di gerbang dengan kendali asli' : 'Kembali ke start tanpa pembatas lintasan'}
            onClick={()=>telemetry.harunaDrive === 'terrain' ? restart('attack','prodrift') : restart('practice','terrain')}>
            {telemetry.harunaDrive === 'terrain' ? <Flag size={18}/> : <Compass size={18}/>}
            {telemetry.harunaDrive === 'terrain' ? 'Kembali ke kendali ProDrift' : 'Jelajah medan'}
          </button>}
          {courseId==='pinus'&&<button type="button" onClick={()=>chooseGhost('watch')}><GhostIcon size={18}/> Tonton Ghost AI <kbd aria-hidden="true">V</kbd></button>}
          <button type="button" onClick={()=>{live.current.guide=true;setGuide(true);}}><CircleHelp size={18}/> Kontrol dan cara drift</button>
          <button type="button" onClick={()=>switchMode('garage')}><Box size={18}/> Garasi</button>
          {onExit&&<button type="button" onClick={onExit}><ArrowLeft size={18}/> Kembali ke beranda</button>}
        </div>
        <div className="pause-settings">
          <button type="button" onClick={()=>{togglePause(false);setFilmPanel(true);}}><SlidersHorizontal size={18}/> Pencahayaan dan bayangan <span>G</span></button>
          <button type="button" onClick={openRmx}><Gauge size={18}/> Info fisika Drift Sim <span>TAB</span></button>
          <button type="button" role="switch" aria-checked={settings.sound} onClick={()=>changeSetting('sound')}>{settings.sound?<Volume2 size={17}/>:<VolumeX size={17}/>} Suara <span>{settings.sound?'ON':'OFF'}</span></button>
          <button type="button" role="switch" aria-label="Efek laju" aria-checked={settings.speedEffects} onClick={()=>changeSetting('speedEffects')}><Gauge size={18}/> Efek laju <span>{settings.speedEffects?'ON':'OFF'}</span></button>
          <button type="button" role="switch" aria-label="Scandinavian Flick feint mode" aria-checked={settings.feintFlick} onClick={toggleFeintFlick}><Wind size={18}/> Scandinavian Flick <span>{settings.feintFlick?'ON':'OFF'}</span></button>
          <button type="button" role="switch" className="speed-setting" aria-checked={filmEnabled} onClick={toggleFilmLook}><Video size={18}/> Efek kamera sinematik <span>{filmEnabled?'ON':'OFF'}</span></button>
        </div>
      </>}
    </dialog>
    <RmxRallyOverlay hud={driving&&!paused&&!finished&&!watching&&!rmxOpen&&!minimalHud} popupsOnly={driving} garage={!driving} canHotkey={driving&&!paused&&!finished&&!watching} panelOpen={rmxOpen}
      onOpenPanel={openRmx} onClosePanel={closeRmx} onRestart={()=>{rmxRef.current=false;setRmxOpen(false);restart();}} onExit={()=>onExit?.()}/>
  </main>;
}