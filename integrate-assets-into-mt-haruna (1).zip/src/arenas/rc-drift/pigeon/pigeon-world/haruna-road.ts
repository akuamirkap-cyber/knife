import * as T from 'three';
import { buildRoad } from '../../../haruna-downhill/game/roadMesh';
import { buildHarunaLandmarks } from '../../../haruna-downhill/game/scenery';
import type { harunaRoute } from './route';
import type { RoadContact } from './road-contact';
import { GroundKind } from './suspension';

const CROSS_SECTION = [-4.6, -4.25, -1.95, -0.85, 0, 0.85, 1.95, 4.25, 4.6];
const CROWN = [0.015, 0.025, 0.055, 0.065, 0.066, 0.065, 0.055, 0.025, 0.015];

export function buildArchivedHarunaRoad(spec: ReturnType<typeof harunaRoute>, contact: RoadContact,
  pavement: T.MeshStandardMaterial, concrete: T.MeshStandardMaterial, floor: T.MeshStandardMaterial) {
  const { track, field, startLot, finishPlaza } = spec;
  const original = buildRoad(track, field);
  original.group.name = 'Mt. Haruna original roadway and start grid';
  original.markings.material.color.set(0xd5d2c8);

  // Build the archive's smooth, 1 m asphalt mesh; PIGEON supplies its material, not its geometry.
  const cols = CROSS_SECTION.length, rows = track.n;
  const coordinates = new Float32Array(rows * cols * 3), uv = new Float32Array(rows * cols * 2);
  const elements = new Uint32Array((rows - 1) * (cols - 1) * 6);
  let offset = 0;
  for (let i = 0; i < rows; i++) {
    const cos = Math.cos(track.psi[i]), sin = Math.sin(track.psi[i]);
    for (let j = 0; j < cols; j++) {
      const lat = CROSS_SECTION[j], a = i * cols + j;
      coordinates.set([track.x[i] + lat * cos, track.y[i] + CROWN[j], track.z[i] - lat * sin], a * 3);
      // Keep the painted lane positions from Haruna rather than repeating PIGEON's baked edge paint.
      uv.set([0.06 + 0.88 * (lat + 4.6) / 9.2, i / 7], a * 2);
      if (i + 1 < rows && j + 1 < cols) {
        elements.set([a, a + cols, a + cols + 1, a, a + cols + 1, a + 1], offset);
        offset += 6;
      }
    }
  }
  const asphaltGeometry = new T.BufferGeometry();
  asphaltGeometry.setAttribute('position', new T.BufferAttribute(coordinates, 3));
  asphaltGeometry.setAttribute('uv', new T.BufferAttribute(uv, 2));
  asphaltGeometry.setIndex(new T.BufferAttribute(elements, 1));
  asphaltGeometry.computeVertexNormals();
  pavement.side = T.DoubleSide;
  pavement.polygonOffset = true;
  pavement.polygonOffsetFactor = pavement.polygonOffsetUnits = -2;
  const asphalt = new T.Mesh(asphaltGeometry, pavement);
  asphalt.name = 'Haruna original crowned asphalt';
  asphalt.receiveShadow = true;
  original.group.add(asphalt);
  contact.add(asphalt, GroundKind.Asphalt);

  // The same curb, cut drains and shoulder triangles get separate surface materials.
  const positions = original.shoulders.geometry.getAttribute('position');
  const packed = [0, 1].map(() => ({ pos: [] as number[], uv: [] as number[], color: [] as number[] }));
  for (let i = 0; i < positions.count; i += 3) {
    const part = packed[original.shoulderConcrete[i / 3]];
    for (let j = i; j < i + 3; j++) {
      const x = positions.getX(j), y = positions.getY(j), z = positions.getZ(j);
      part.pos.push(x, y, z);
      const n = 0.5 + 0.26 * Math.sin(x * 0.081 + z * 0.123) + 0.21 * Math.cos(z * 0.29 - x * 0.13);
      part.color.push(0.60 + n * 0.18, 0.72 + n * 0.22, 0.43 + n * 0.14);
      part.uv.push(x / 9, z / 9);
    }
  }
  const shoulderFloor = floor.clone();
  shoulderFloor.onBeforeCompile = floor.onBeforeCompile;
  shoulderFloor.side = T.DoubleSide;
  concrete.side = T.DoubleSide;
  packed.forEach(({ pos, uv, color }, part) => {
    const geometry = new T.BufferGeometry();
    geometry.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
    geometry.setAttribute('uv', new T.Float32BufferAttribute(uv, 2));
    if (!part) geometry.setAttribute('color', new T.Float32BufferAttribute(color, 3));
    geometry.computeVertexNormals();
    const mesh = new T.Mesh(geometry, part ? concrete : shoulderFloor);
    mesh.name = part ? 'Haruna original curbs and drains' : 'Haruna original shoulders';
    mesh.receiveShadow = true;
    original.group.add(mesh);
    contact.add(mesh, part ? GroundKind.Gutter : GroundKind.Earth);
  });
  original.baseAsphalt.removeFromParent();
  original.shoulders.removeFromParent();
  original.baseAsphalt.geometry.dispose();
  original.shoulders.geometry.dispose();
  original.baseAsphalt.material.dispose();

  const landmarks = buildHarunaLandmarks(track, startLot, finishPlaza);
  original.group.add(landmarks.group);
  for (const surface of landmarks.surfaces) contact.add(surface, GroundKind.Asphalt);
  return { group: original.group, guardrails: original.guardrails };
}