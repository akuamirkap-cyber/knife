import * as T from 'three';
import { DEFAULT_ATMOSPHERE, DEFAULT_LIGHTING, SKY_THEMES, type AtmosphereState, type LightingMood, type LightingState } from '../drive-lighting';
import type { PigeonAssets } from './assets';
import type { MountainSpec } from './route';
import { createSunAtmosphere } from './sun-atmosphere';
import type { GroundAt } from './suspension';

const SUN_DIR = new T.Vector3(0.22, 1, 0.16).normalize();
const DARK_SUN = new T.Vector3(-0.38, 0.81, -0.19).normalize();
const palettes = {
  day:   { zenith: 0xbcd3e2, horizon: 0xeef1e6, background: 0xe3e9de, fog: 0xd6e0cf, hemi: 0xdfeadf, ground: 0x52623a, sun: 0xfff0d2, halo: 0xfff2cc, h: 2.0, d: 3.4, a: 0.35, skyGlow: 1 },
  rain:  { zenith: 0x6e7c84, horizon: 0xaab5b8, background: 0xaab5b8, fog: 0x9da9a8, hemi: 0xd4e2e5, ground: 0x4b5046, sun: 0xc9dbef, halo: 0xc9dbef, h: 1.85, d: 0.72, a: 0.28, skyGlow: 0.12 },
  night: { zenith: 0x101d33, horizon: 0x283340, background: 0x283340, fog: 0x202d39, hemi: 0x829dc0, ground: 0x333f31, sun: 0xb6cdf7, halo: 0xb6cdf7, h: 0.95, d: 0.62, a: 0.15, skyGlow: 0.17 },
} as const;

export function createPigeonLighting(scene: T.Scene, spec: MountainSpec, groundAt: GroundAt, renderer: T.WebGLRenderer, assets: PigeonAssets, shadowResolution?: number) {
  let state = { ...DEFAULT_LIGHTING };
  let atmosphere: AtmosphereState = { ...DEFAULT_ATMOSPHERE };
  let mood: LightingMood = 'day';
  const sunDirection = SUN_DIR.clone();
  const ambient = new T.AmbientLight(0x9db394);
  const hemi = new T.HemisphereLight();
  const dir = new T.DirectionalLight();
  dir.castShadow = true;
  const extent = 55;
  const size = Math.min(renderer.capabilities.maxTextureSize, shadowResolution ?? 2048);
  dir.shadow.mapSize.set(size, size);
  const c = dir.shadow.camera;
  Object.assign(c, { left: -extent, right: extent, top: extent, bottom: -extent, near: 10, far: 220 });
  c.updateProjectionMatrix();
  dir.shadow.bias = -0.00025;
  dir.shadow.normalBias = 0.03;
  dir.shadow.radius = 3;
  scene.add(hemi, ambient, dir, dir.target);

  const background = new T.Color(0xe3e9de);
  const fog = new T.Fog(0xd6e0cf, 58, 300);
  scene.background = background;
  scene.fog = fog;
  const uniforms = { sunDir: { value: sunDirection }, zenith: { value: new T.Color() },
    horizon: { value: new T.Color() }, sunCol: { value: new T.Color() }, gain: { value: 1 } };
  const dome = new T.Mesh(new T.SphereGeometry(300, 32, 16), new T.ShaderMaterial({
    side: T.BackSide, depthWrite: false, fog: false, uniforms,
    vertexShader: `varying vec3 vDir; void main() { vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `
      uniform vec3 sunDir, zenith, horizon, sunCol; uniform float gain; varying vec3 vDir;
      void main() {
        float h = clamp(vDir.y, 0.0, 1.0);
        vec3 col = mix(horizon, zenith, pow(h, 0.55));
        float s = max(dot(normalize(vDir), sunDir), 0.0);
         col += sunCol * (pow(s, 6.0) * 0.55 + pow(s, 60.0) * 1.6) * gain;
        gl_FragColor = vec4(col, 1.0);
      }`,
  }));
  dome.name = 'PIGEON gradient sky';
  dome.renderOrder = -10;
  dome.frustumCulled = false;
  scene.add(dome);

  const atmosphereRef = createSunAtmosphere(spec, groundAt, assets, SUN_DIR);
  scene.add(atmosphereRef.group);

  const last = new T.Vector3(Infinity, Infinity, Infinity);
  let lastYaw = Infinity;
  let lastUpdate = -Infinity;

  function sync() {
    const p = palettes[mood];
    const theme = mood === 'day' ? SKY_THEMES[atmosphere.skyTheme] : null;
    const fill = state.hemiOn ? state.hemi / 100 : 0;
    const direct = state.dirOn ? state.dir / 100 : 0;
    const shadowWasActive = dir.intensity > 0 && dir.shadow.intensity > 0;
    const nextDirection = mood === 'night' ? DARK_SUN : SUN_DIR;
    if (!sunDirection.equals(nextDirection) || (!shadowWasActive && direct > 0 && state.shadow > 0)) last.x = Infinity;
    hemi.color.set(p.hemi); hemi.groundColor.set(p.ground); hemi.intensity = p.h * fill;
    ambient.intensity = p.a * fill;
    dir.color.set(p.sun); dir.intensity = p.d * direct;
    dir.shadow.intensity = state.shadow / 100;
    sunDirection.copy(nextDirection);
    background.set(theme ? theme.background : p.background);
    fog.color.set(theme ? theme.fog : p.fog);
    // Tebal & jarak kabut (FOG linear): tebal = kepekatan, jarak = batas jarak pandang.
    const far = T.MathUtils.clamp(atmosphere.fogDistance, 80, 1000) * (mood === 'rain' ? 0.72 : 1);
    fog.far = far;
    fog.near = Math.max(15, far * (1 - atmosphere.fogThickness / 100) ** 2);
    uniforms.zenith.value.set(theme ? theme.zenith : p.zenith);
    uniforms.horizon.value.set(theme ? theme.horizon : p.horizon);
    uniforms.sunCol.value.set(p.halo);
    uniforms.gain.value = p.skyGlow * direct;
    atmosphereRef.setStrength(mood === 'day' ? direct : 0);
  }

  function update(car: T.Vector3, view: T.Vector3, yaw: number, now: number, seconds: number) {
    dome.position.copy(view);
    atmosphereRef.update(car, seconds);
    if (last.x === Infinity || (now - lastUpdate >= (size < 2048 ? 70 : 28) && (last.distanceToSquared(car) > 0.085 || Math.abs(yaw - lastYaw) > 0.07))) {
      last.copy(car);
      lastYaw = yaw;
      lastUpdate = now;
      dir.target.position.copy(car);
      dir.position.copy(dir.target.position).addScaledVector(sunDirection, 90);
      if (!dir.shadow.map || (dir.shadow.intensity > 0 && dir.intensity > 0)) renderer.shadowMap.needsUpdate = true;
    }
  }

  sync();
  return {
    scene, hemi, dir, dome, background, fog, sunDirection, update,
    get state() { return state; },
    get mood() { return mood; },
    get hasDaylightAtmosphere() { return atmosphereRef.group.visible; },
    get sunGain() { return state.dirOn ? state.dir / 100 * palettes[mood].skyGlow : 0; },
    get atmosphereState() { return { ...atmosphere }; },
    setMood(next: LightingMood) { mood = next; sync(); },
    apply(next: Partial<LightingState>) {
      state = { ...state, ...next };
      for (const key of ['hemi', 'dir', 'shadow'] as const) state[key] = T.MathUtils.clamp(state[key], 0, 100);
      sync();
      return state;
    },
    applyAtmosphere(next: Partial<AtmosphereState>) {
      const theme = next.skyTheme === 'lightsky' || next.skyTheme === 'cloudy' ? next.skyTheme : 'normal';
      atmosphere = {
        fogThickness: T.MathUtils.clamp(next.fogThickness ?? atmosphere.fogThickness, 0, 100),
        fogDistance: T.MathUtils.clamp(next.fogDistance ?? atmosphere.fogDistance, 80, 1000),
        skyTheme: theme,
      };
      sync();
      return { ...atmosphere };
    },
  };
}