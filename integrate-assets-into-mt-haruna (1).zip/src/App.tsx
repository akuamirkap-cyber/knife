import { Component, lazy, Suspense, useCallback, useEffect, useState, type ComponentType, type ReactNode } from 'react';

function lazyWithRetry<T extends ComponentType<any>>(loader: () => Promise<{ default: T }>) {
  return lazy(async () => {
    let lastError: unknown;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await loader();
      } catch (err) {
        lastError = err;
        await new Promise((r) => setTimeout(r, 250 * (attempt + 1)));
      }
    }
    throw lastError;
  });
}

import ProdriftMenu from './menu/ProdriftMenu';

const DriftSimGame = lazyWithRetry(() => import('./arenas/drift-sim/DriftSimGame'));
const RmxGame = lazyWithRetry(() => import('./arenas/rc-drift/RmxGame'));
const RallyGame = lazyWithRetry(() => import('./arenas/rc-drift/pigeon/RallyGame'));
const HarunaRoute33Game = lazyWithRetry(() => import('./arenas/haruna-route33/HarunaRoute33Game'));
const HarunaDownhillGame = lazyWithRetry(() => import('./arenas/haruna-downhill/HarunaDownhillGame'));

type ArenaId = 'menu' | 'drift-sim' | 'rc-arena' | 'rally-groupb' | 'rally-groupb-garage' | 'haruna-route33' | 'haruna-downhill';



function ArenaLoadingFallback() {
  return (
    <div role="status" className="fixed inset-0 flex flex-col items-center justify-center gap-3 bg-[#101211] text-slate-100">
      <span className="h-6 w-6 animate-spin rounded-full border-2 border-white/20 border-t-[#ff692f] motion-reduce:animate-none" aria-hidden="true" />
      <b className="font-[Barlow] text-xl tracking-widest text-[#ff884d]">MEMUAT LINTASAN</b>
      <p className="font-[Barlow] text-sm text-slate-400">Menyiapkan arena 3D dan fisika mobil.</p>
    </div>
  );
}

class ArenaErrorBoundary extends Component<
  { children: ReactNode; arenaKey: string; onExit: () => void },
  { hasError: boolean; retryKey: number }
> {
  state = { hasError: false, retryKey: 0 };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidUpdate(prevProps: { arenaKey: string }) {
    if (prevProps.arenaKey !== this.props.arenaKey && this.state.hasError) {
      this.setState({ hasError: false });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 bg-[#07090f] text-slate-100 flex flex-col items-center justify-center gap-4 px-6 text-center">
          <div className="font-title text-2xl font-black tracking-wider text-amber-400">ARENA GAGAL DIMUAT</div>
          <p className="text-sm text-slate-400 max-w-md">
            Koneksi modul arena sempat terputus. Coba muat ulang arena atau kembali ke menu utama.
          </p>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-md bg-amber-500 text-slate-950 font-racing font-bold text-sm uppercase tracking-wider cursor-pointer"
            >
              Muat Ulang
            </button>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false });
                this.props.onExit();
              }}
              className="px-4 py-2 rounded-md bg-white/10 text-white font-racing font-bold text-sm uppercase tracking-wider cursor-pointer"
            >
              Kembali ke Menu
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [activeArena, setActiveArena] = useState<ArenaId>('menu');

  const exitToMenu = useCallback(() => {
    setActiveArena('menu');
  }, []);

  useEffect(() => {
    if (activeArena === 'menu') return;
    const onEsc = (e: KeyboardEvent) => {
      if (e.code === 'Escape' && activeArena === 'drift-sim') {
        e.preventDefault();
        exitToMenu();
      }
    };
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [activeArena, exitToMenu]);

  if (activeArena !== 'menu') {
    return (
      <ArenaErrorBoundary arenaKey={activeArena} onExit={exitToMenu}>
        <Suspense fallback={<ArenaLoadingFallback />}>
          {activeArena === 'drift-sim' && <DriftSimGame onExit={exitToMenu} />}
          {activeArena === 'rc-arena' && <RmxGame onExit={exitToMenu} />}
          {activeArena === 'rally-groupb' && <RallyGame onExit={exitToMenu} />}
          {activeArena === 'rally-groupb-garage' && <RallyGame onExit={exitToMenu} initialMode="garage" />}
          {activeArena === 'haruna-route33' && <HarunaRoute33Game onExit={exitToMenu} />}
          {activeArena === 'haruna-downhill' && <HarunaDownhillGame onExit={exitToMenu} />}
        </Suspense>
      </ArenaErrorBoundary>
    );
  }

  return (
    <ProdriftMenu
      onPlay={() => setActiveArena('rally-groupb')}
      onStudio={() => setActiveArena('rally-groupb-garage')}
      onArena={(id) => setActiveArena(id)}
    />
  );
}
