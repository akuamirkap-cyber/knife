import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { ArrowRight, CarFront, Check, ChevronRight, Compass, Flag, Gamepad2, Gauge, Home, Info, Mountain, Pencil, Settings, X } from 'lucide-react';
import { COURSE_IDS, COURSES, readSelectedCourse, saveSelectedCourse, type CourseId } from '../arenas/rc-drift/pigeon/course-selection';
import { DEFAULT_ATMOSPHERE, DEFAULT_LIGHTING, LIGHT_SLIDERS, readAtmosphere, readLighting, saveAtmosphere, saveLighting, SKY_THEMES, type AtmosphereState, type LightingState, type SkyTheme } from '../arenas/rc-drift/pigeon/drive-lighting';
import { readBuild, writeBuild } from '../arenas/rc-drift/pigeon/rally-config';
import GarageDialog from './GarageDialog';
import './launcher.css';

const MenuScene = lazy(() => import('./MenuScene'));
export type MenuArenaId = 'drift-sim' | 'rc-arena' | 'haruna-route33' | 'haruna-downhill';
type SettingsTab = 'map' | 'lighting' | 'arenas';

const arenas = [
  { id: 'drift-sim', name: 'Drift Park 8 Manuver', info: 'Arena latihan dan kombo trik', icon: Gauge },
  { id: 'rc-arena', name: 'RMX 2.5 RC Arena', info: 'Drift RC di arena indoor', icon: CarFront },
  { id: 'haruna-route33', name: 'Haruna Route 33 Klasik', info: 'Mode klasik, terpisah dari Rally Group B', icon: Compass },
  { id: 'haruna-downhill', name: 'Haruna Downhill Klasik', info: 'Mode time attack dari arsip ProDrift', icon: Mountain },
] as const;

const tabs: { id: SettingsTab; name: string }[] = [
  { id: 'map', name: 'Lintasan' }, { id: 'lighting', name: 'Pencahayaan' },
  { id: 'arenas', name: 'Arena lainnya' },
];
const courseShapes: Record<CourseId, string> = {
  pigeon: 'M12 32c-4-5-4-11 1-15l8-6 8 4 3 7 5 4-4 10-9 2-5-5z',
  haruna: 'M11 11h10c8 0 9 9 2 9h-5c-5 0-5 6 0 6h9c5 0 6 5 0 6h-4l9 7',
  pinus: 'M10 33V19l9-9 7 6 10 1 3 8-12 13-12-1z',
};

function SettingsDialog({ course, setCourse, onPlay, onArena, onClose }: {
  course: CourseId; setCourse: (id: CourseId) => void;
  onPlay: () => void; onArena: (id: MenuArenaId) => void; onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [tab, setTab] = useState<SettingsTab>('map');
  const [lighting, setLighting] = useState(readLighting);
  const [atmosphere, setAtmosphere] = useState<AtmosphereState>(readAtmosphere);
  useEffect(() => {
    const el = dialog.current;
    el?.showModal();
    return () => el?.close();
  }, []);

  function changeAtmosphere(next: Partial<AtmosphereState>) {
    const merged = { ...atmosphere, ...next };
    setAtmosphere(merged);
    saveAtmosphere(merged);
  }
  function changeLighting(next: LightingState, restorePigeon = false) {
    setLighting(next);
    saveLighting(next, restorePigeon ? { mountainLook: 'pigeon', tod: 'day' } : undefined);
  }

  return <dialog ref={dialog} className="pd-dialog menu-panel" aria-labelledby="pd-settings-heading"
    onCancel={event => { event.preventDefault(); onClose(); }} onClick={event => { if (event.target === dialog.current) onClose(); }}>
    <div className="pd-dialog-main">
      <header className="pd-dialog-header">
        <div><p className="pd-kicker">ProDrift / Rally Group B</p><h2 id="pd-settings-heading">Pengaturan</h2></div>
        <button type="button" className="pd-icon-btn" onClick={onClose} aria-label="Tutup pengaturan"><X size={20}/></button>
      </header>
      <div className="pd-tabs" role="group" aria-label="Kategori pengaturan">
        {tabs.map(item => <button key={item.id} type="button" aria-pressed={tab === item.id} onClick={() => setTab(item.id)}>{item.name}</button>)}
      </div>
      {tab === 'map' && <div className="pd-dialog-content">
        <p>Pilih map untuk sesi Rally Group B berikutnya.</p>
        <div className="pd-course-list" role="group" aria-label="Pilihan map ProDrift">
          {COURSE_IDS.map(id => <button className="pd-course" type="button" key={id} onClick={() => setCourse(id)} aria-pressed={course === id}>
            <span className="pd-course-mark"><svg viewBox="0 0 48 48" width="39" height="39" fill="none" stroke="currentColor" strokeWidth="2.05" strokeLinejoin="round" strokeLinecap="round" aria-hidden="true"><path d={courseShapes[id]}/></svg></span>
            <span className="pd-course-copy"><span><b>{COURSES[id].name}</b>{id === 'pigeon' && <em>MAP UTAMA</em>}</span><small>{COURSES[id].detail}</small></span>
            <span className="pd-course-indicator" aria-hidden="true">{course === id && <Check size={13} strokeWidth={3}/>}</span>
          </button>)}
        </div>
        <div className="pd-dialog-actions"><small><Check size={13} aria-hidden="true"/> Pilihan tersimpan</small><button type="button" className="pd-primary" onClick={onPlay}>Masuk lintasan <ArrowRight size={16}/></button></div>
      </div>}
      {tab === 'lighting' && <div className="pd-dialog-content">
        <p>Atur intensitas cahaya dan bayangan secara terpisah. Tekan <b>G</b> saat mengemudi untuk membandingkan tampilan PIGEON asli dan sinematik ProDrift.</p>
        {LIGHT_SLIDERS.map(({ key, name: label, desc }) => <label className="pd-light-control" key={key}>
          <span>{label}<span className="pd-level">{lighting[key]}%</span></span>
          <small>{desc}</small>
          <input type="range" min="0" max="100" value={lighting[key]} aria-label={label} aria-valuetext={`${lighting[key]}%`} onChange={event => changeLighting({ ...lighting,
            [key]: Number(event.target.value), ...(key === 'hemi' ? { hemiOn: true } : key === 'dir' ? { dirOn: true } : {}) })}/>
        </label>)}
        <div className="pd-dialog-actions">
          <button type="button" className="pd-secondary" onClick={() => changeLighting({ ...lighting, shadow: 0 })}>Tanpa bayangan</button>
          <button type="button" className="pd-secondary" onClick={() => { changeLighting({ ...DEFAULT_LIGHTING }, course !== 'pinus'); if (course !== 'pinus') changeAtmosphere({ ...DEFAULT_ATMOSPHERE }); }}>{course !== 'pinus' ? 'Pulihkan PIGEON asli' : 'Kembalikan ke 100%'}</button>
        </div>
        {course !== 'pinus' && <div className="pd-atmosphere" role="group" aria-label="Kabut dan langit">
          {/* sliders dan tema langit */}
          <p className="pd-atmosphere-title">Kabut &amp; langit ({COURSES[course].name})</p>
          <label className="pd-light-control">
            <span>Tebal kabut<span className="pd-level">{Math.round(atmosphere.fogThickness)}%</span></span>
            <input type="range" min="0" max="100" value={atmosphere.fogThickness} aria-label="Tebal kabut" aria-valuetext={`${atmosphere.fogThickness}%`} onChange={event => changeAtmosphere({ fogThickness: Number(event.target.value) })}/>
          </label>
          <label className="pd-light-control">
            <span>Jarak kabut<span className="pd-level">{Math.round(atmosphere.fogDistance)} m</span></span>
            <input type="range" min="80" max="1000" step="20" value={atmosphere.fogDistance} aria-label="Jarak kabut" aria-valuetext={`${atmosphere.fogDistance} meter`} onChange={event => changeAtmosphere({ fogDistance: Number(event.target.value) })}/>
          </label>
          <div className="sky-themes pd-sky" role="group" aria-label="Tema warna langit">
            {(Object.keys(SKY_THEMES) as SkyTheme[]).map(theme => (
              <button key={theme} type="button" aria-pressed={atmosphere.skyTheme === theme} onClick={() => changeAtmosphere({ skyTheme: theme })}>{SKY_THEMES[theme].name}</button>
            ))}
          </div>
        </div>}
      </div>}
      {tab === 'arenas' && <div className="pd-dialog-content">
        <p>Mode tambahan dari arsip ProDrift. Pilihan map Rally Group B tidak berubah.</p>
        <div className="pd-other-list">
          {arenas.map(item => <button type="button" onClick={() => onArena(item.id)} key={item.id}>
            <item.icon size={21} aria-hidden="true"/><span><b>{item.name}</b><small>{item.info}</small></span><ChevronRight size={17} aria-hidden="true"/>
          </button>)}
        </div>
      </div>}
    </div>
  </dialog>;
}

function AboutDialog({ onClose }: { onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const el = dialog.current;
    el?.showModal();
    return () => el?.close();
  }, []);
  return <dialog ref={dialog} className="pd-dialog pd-about menu-panel" aria-labelledby="pd-about-heading"
    onCancel={event => { event.preventDefault(); onClose(); }} onClick={event => { if (event.target === dialog.current) onClose(); }}>
    <div className="pd-dialog-main">
      <header className="pd-dialog-header"><div><p className="pd-kicker">PRODRIFT / RALLY GROUP B</p><h2 id="pd-about-heading">Tentang</h2></div>
        <button type="button" className="pd-icon-btn" aria-label="Tutup tentang" onClick={onClose}><X size={20}/></button>
      </header>
      <div className="pd-dialog-content">
        <p>Simulator drift 3D. Di Mt. Haruna, relief ProDrift dipadukan dengan hutan, aspal, dan pencahayaan PIGEON.</p>
        <p>Gunakan <kbd>WASD</kbd> atau tombol panah untuk mengemudi. <kbd>Spasi</kbd> untuk rem tangan, <kbd>P</kbd> untuk jeda, dan <kbd>G</kbd> untuk pencahayaan.</p>
        <a className="pd-credit" href="https://github.com/akuamirkap-cyber/knife/blob/main/refine-hand-and-lighting%20(2).zip" target="_blank" rel="noreferrer">Arsip ProDrift <ChevronRight size={15}/></a>
        <a className="pd-credit" href="https://github.com/akuamirkap-cyber/PIGEON/blob/main/realistic-3d-map-creation%20(1).zip" target="_blank" rel="noreferrer">Arsip PIGEON <ChevronRight size={15}/></a>
      </div>
    </div>
  </dialog>;
}

export default function ProdriftMenu({ onPlay, onStudio, onArena }: {
  onPlay: () => void; onStudio: () => void; onArena: (id: MenuArenaId) => void;
}) {
  const [course, setCourse] = useState(readSelectedCourse);
  const [screen, setScreen] = useState<'settings' | 'garage' | 'about' | null>(null);
  const [build, setBuild] = useState(readBuild);
  const [draft, setDraft] = useState(build);
  const [username, setUsername] = useState(() => {
    try { return localStorage.getItem('prodrift.username') || '0xDRIFTER'; } catch { return '0xDRIFTER'; }
  });
  const [nameSaved, setNameSaved] = useState(false);
  const usernameRef = useRef<HTMLInputElement>(null);
  const garageButton = useRef<HTMLButtonElement>(null);
  const openSettings = () => setScreen('settings');
  const openGarage = () => { setDraft(build); setScreen('garage'); };
  const closeScreen = () => setScreen(null);
  const applyBuild = () => { setBuild(draft); writeBuild(draft); };

  useEffect(() => {
    function start(event: KeyboardEvent) {
      if (!screen && event.code === 'Enter' && !event.repeat && !(event.target as HTMLElement)?.closest('a,button,input')) onPlay();
    }
    window.addEventListener('keydown', start);
    return () => window.removeEventListener('keydown', start);
  }, [screen, onPlay]);

  return <main className={`archive-menu${screen === 'garage' ? ' archive-menu-garage' : ''}`} aria-label="Menu ProDrift">
    <Suspense fallback={null}><MenuScene build={screen === 'garage' ? draft : build} garage={screen === 'garage'}/></Suspense>

    <div className="archive-main-ui" hidden={screen === 'garage'}>
      <div className="archive-title"><h1 className="menu-title">PRODRIFT</h1></div>
      <div className="archive-profile">
        <form onSubmit={event => {
          event.preventDefault(); const name = username.trim().slice(0, 16) || '0xDRIFTER';
          setUsername(name); setNameSaved(true);
          try { localStorage.setItem('prodrift.username', name); } catch { /* Storage is optional. */ }
        }}>
          <label htmlFor="pd-username">Username</label>
          <div className="archive-profile-entry">
            <input id="pd-username" ref={usernameRef} value={username} maxLength={16}
              onChange={event => { setUsername(event.target.value); setNameSaved(false); }} autoComplete="off" spellCheck={false}/>
            <button type="submit" aria-label="Simpan username">{nameSaved ? <Check size={15} strokeWidth={2.8}/> : 'OK'}</button>
          </div>
          <p aria-live="polite">{nameSaved ? 'Nama tersimpan.' : 'Nama pengemudi disimpan di perangkat ini.'}</p>
        </form>
        <button type="button" className="archive-track" onClick={openSettings} aria-label={`Lintasan aktif: ${COURSES[course].name}. Pilih lintasan`}>
          <Flag size={10}/>{COURSES[course].name}
        </button>
      </div>

      <nav className="archive-actions" aria-label="Menu utama PRODRIFT">
        <button type="button" onClick={onPlay} className="menu-btn menu-btn-solo" style={{ animationDelay: '0.12s' }}>SOLO</button>
        <button type="button" ref={garageButton} onClick={openGarage} className="menu-btn menu-btn-white" style={{ animationDelay: '0.23s' }}>GARASI</button>
        <button type="button" onClick={openSettings} className="menu-btn menu-btn-white" style={{ animationDelay: '0.34s' }}>PENGATURAN</button>
      </nav>

      <div className="archive-shortcuts">
        <button type="button" onClick={openGarage} className="garage-card" aria-label="Buka garasi">
          <span className="garage-card-icon"><Home size={25} strokeWidth={2.6}/></span><span className="garage-card-text">GARAGE</span>
        </button>
        <button type="button" onClick={openSettings} className="settings-chip" aria-label="Pilih map dan pengaturan">
          <span className="settings-chip-icon"><Settings size={20} strokeWidth={2.4}/></span>
          <span className="archive-shortcut-copy"><b>Pengaturan</b><small>Lintasan &amp; pencahayaan</small></span>
          <ChevronRight size={16} strokeWidth={3} className="text-slate-400"/>
        </button>
        <div className="archive-icon-row">
          <button type="button" className="icon-btn" onClick={() => usernameRef.current?.focus()} aria-label="Ubah username"><Pencil size={18}/></button>
          <button type="button" className="icon-btn" onClick={openSettings} aria-label="Buka pengaturan"><Settings size={18}/></button>
          <button type="button" className="icon-btn" onClick={() => setScreen('about')} aria-label="Tentang ProDrift"><Info size={18}/></button>
        </div>
      </div>
      <footer className="archive-credit"><Gamepad2 size={12}/> Mode solo <span aria-hidden="true">/</span><span>Rekor tersimpan lokal</span></footer>
    </div>

    {screen === 'garage' && <GarageDialog draft={draft} onDraft={setDraft} onApply={applyBuild} onStudio={onStudio}
      onClose={() => { closeScreen(); requestAnimationFrame(() => garageButton.current?.focus({ preventScroll: true })); }}/>}
    {screen === 'settings' && <SettingsDialog course={course} setCourse={id => { setCourse(id); saveSelectedCourse(id); }}
      onPlay={onPlay} onArena={onArena} onClose={closeScreen}/>}
    {screen === 'about' && <AboutDialog onClose={closeScreen}/>}
  </main>;
}