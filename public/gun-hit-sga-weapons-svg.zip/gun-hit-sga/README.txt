Gun Hit SGA — weapon SVG exports

Each file is a vector SVG rendered from the game weapon art.
Names and rarity follow the in-game catalog.

UMUM	PISTOL	gun-hit-sga/umum/pistol.svg
UMUM	AK-47	gun-hit-sga/umum/ak-47.svg
UMUM	NAIL GUN	gun-hit-sga/umum/nail-gun.svg
UMUM	CROSSBOW	gun-hit-sga/umum/crossbow.svg
LANGKA	PLASMA GUN	gun-hit-sga/langka/plasma-gun.svg
LANGKA	LASER BEAM	gun-hit-sga/langka/laser-beam.svg
LANGKA	FISH GUN	gun-hit-sga/langka/fish-gun.svg
LANGKA	RPG-7	gun-hit-sga/langka/rpg-7.svg
EPIC	NOISY CRICKET	gun-hit-sga/epic/noisy-cricket.svg
EPIC	ELECTRO GUN	gun-hit-sga/epic/electro-gun.svg
EPIC	BAZOOKA	gun-hit-sga/epic/bazooka.svg
LEGENDARIS	FREEZE RAY	gun-hit-sga/legendaris/freeze-ray.svg
LEGENDARIS	GOLDEN GUN	gun-hit-sga/legendaris/golden-gun.svg
LEGENDARIS	BLACK HOLE	gun-hit-sga/legendaris/black-hole.svg
UMUM	KETAPEL	gun-hit-sga/umum/ketapel.svg
UMUM	SUMPIT DAYAK	gun-hit-sga/umum/sumpit-dayak.svg
UMUM	SHOTGUN	gun-hit-sga/umum/shotgun.svg
UMUM	SUPER SOAKER	gun-hit-sga/umum/super-soaker.svg
UMUM	SNOWBALL CANNON	gun-hit-sga/umum/snowball-cannon.svg
LANGKA	SNIPER AWP	gun-hit-sga/langka/sniper-awp.svg
LANGKA	FLAMETHROWER	gun-hit-sga/langka/flamethrower.svg
LANGKA	DISC GUN	gun-hit-sga/langka/disc-gun.svg
LANGKA	BUBBLE GUN	gun-hit-sga/langka/bubble-gun.svg
LANGKA	MERIAM BAMBU	gun-hit-sga/langka/meriam-bambu.svg
LANGKA	BANANA GUN	gun-hit-sga/langka/banana-gun.svg
LANGKA	HARPOON GUN	gun-hit-sga/langka/harpoon-gun.svg
LANGKA	RUBBER CHICKEN	gun-hit-sga/langka/rubber-chicken.svg
LANGKA	CONFETTI CANNON	gun-hit-sga/langka/confetti-cannon.svg
LANGKA	SEED GUN	gun-hit-sga/langka/seed-gun.svg
LANGKA	PIZZA LAUNCHER	gun-hit-sga/langka/pizza-launcher.svg
EPIC	MINIGUN	gun-hit-sga/epic/minigun.svg
EPIC	RAILGUN	gun-hit-sga/epic/railgun.svg
EPIC	MAGNET GUN	gun-hit-sga/epic/magnet-gun.svg
EPIC	SHRINK RAY	gun-hit-sga/epic/shrink-ray.svg
EPIC	GROW RAY	gun-hit-sga/epic/grow-ray.svg
EPIC	MERIAM BAJAK LAUT	gun-hit-sga/epic/meriam-bajak-laut.svg
EPIC	CARD GUN	gun-hit-sga/epic/card-gun.svg
EPIC	SONIC BLASTER	gun-hit-sga/epic/sonic-blaster.svg
EPIC	MIRROR GUN	gun-hit-sga/epic/mirror-gun.svg
LEGENDARIS	PORTAL GUN	gun-hit-sga/legendaris/portal-gun.svg
LEGENDARIS	CHRONO GUN	gun-hit-sga/legendaris/chrono-gun.svg
LEGENDARIS	GLITCH GUN	gun-hit-sga/legendaris/glitch-gun.svg
LEGENDARIS	DRAGON BREATH	gun-hit-sga/legendaris/dragon-breath.svg
LEGENDARIS	GRAVITY GUN	gun-hit-sga/legendaris/gravity-gun.svg
UMUM	HONEY BLASTER	gun-hit-sga/umum/honey-blaster.svg
UMUM	MERIAM KELAPA	gun-hit-sga/umum/meriam-kelapa.svg
LANGKA	ANGKLUNG	gun-hit-sga/langka/angklung.svg
LANGKA	BEE HIVE GUN	gun-hit-sga/langka/bee-hive-gun.svg
LANGKA	TINTA GURITA	gun-hit-sga/langka/tinta-gurita.svg
LANGKA	YOYO SHOOTER	gun-hit-sga/langka/yoyo-shooter.svg
LANGKA	SAKURA BLOSSOM	gun-hit-sga/langka/sakura-blossom.svg
LANGKA	ACID SPITTER	gun-hit-sga/langka/acid-spitter.svg
EPIC	KERIS SAKTI	gun-hit-sga/epic/keris-sakti.svg
EPIC	TORNADO GUN	gun-hit-sga/epic/tornado-gun.svg
EPIC	FIREWORK LAUNCHER	gun-hit-sga/epic/firework-launcher.svg
EPIC	ANCHOR CANNON	gun-hit-sga/epic/anchor-cannon.svg
EPIC	SHARK LAUNCHER	gun-hit-sga/epic/shark-launcher.svg
EPIC	GHOST GUN	gun-hit-sga/epic/ghost-gun.svg
EPIC	UFO RAY	gun-hit-sga/epic/ufo-ray.svg
LEGENDARIS	RAINBOW GUN	gun-hit-sga/legendaris/rainbow-gun.svg
LEGENDARIS	METEOR LAUNCHER	gun-hit-sga/legendaris/meteor-launcher.svg
LEGENDARIS	DIAMOND GUN	gun-hit-sga/legendaris/diamond-gun.svg
LEGENDARIS	MOONBEAM	gun-hit-sga/legendaris/moonbeam.svg
LEGENDARIS	STORM CALLER	gun-hit-sga/legendaris/storm-caller.svg
UMUM	PENCIL GUN	gun-hit-sga/umum/pencil-gun.svg
UMUM	SANDAL JEPIT	gun-hit-sga/umum/sandal-jepit.svg
UMUM	PAINTBALL GUN	gun-hit-sga/umum/paintball-gun.svg
LANGKA	MAGIC WAND	gun-hit-sga/langka/magic-wand.svg
LANGKA	RUBY REVOLVER	gun-hit-sga/langka/ruby-revolver.svg
EPIC	EMERALD LASER	gun-hit-sga/epic/emerald-laser.svg
EPIC	SAPPHIRE SHOTGUN	gun-hit-sga/epic/sapphire-shotgun.svg
EPIC	CRYSTAL CANNON	gun-hit-sga/epic/crystal-cannon.svg
EPIC	BEE RIFLE	gun-hit-sga/epic/bee-rifle.svg
EPIC	CHARGE BLASTER	gun-hit-sga/epic/charge-blaster.svg
LEGENDARIS	HOLY LIGHT GUN	gun-hit-sga/legendaris/holy-light-gun.svg
LEGENDARIS	RAINBOW UNICORN	gun-hit-sga/legendaris/rainbow-unicorn.svg
LEGENDARIS	OBLITERATOR 9000	gun-hit-sga/legendaris/obliterator-9000.svg
LANGKA	8-BIT RETRO GUN	gun-hit-sga/langka/8-bit-retro-gun.svg
EPIC	COIN GUN	gun-hit-sga/epic/coin-gun.svg
EPIC	REVOLVER KELANA	gun-hit-sga/epic/revolver-kelana.svg
LEGENDARIS	PHOTON SABER	gun-hit-sga/legendaris/photon-saber.svg
EPIC	PLASMA REPEATER	gun-hit-sga/epic/plasma-repeater.svg
LEGENDARIS	WARP DISRUPTOR	gun-hit-sga/legendaris/warp-disruptor.svg
LANGKA	DEFLECTOR SHIELD	gun-hit-sga/langka/deflector-shield.svg
LEGENDARIS	GAUNTLET CANNON	gun-hit-sga/legendaris/gauntlet-cannon.svg
LANGKA	ALIEN RAY	gun-hit-sga/langka/alien-ray.svg
LANGKA	PULSE RIFLE	gun-hit-sga/langka/pulse-rifle.svg
LANGKA	CRYO BLASTER	gun-hit-sga/langka/cryo-blaster.svg
LANGKA	HYPERDRIVE CANNON	gun-hit-sga/langka/hyperdrive-cannon.svg
EPIC	QUANTUM DESTABILIZER	gun-hit-sga/epic/quantum-destabilizer.svg
LANGKA	KUNAI SHURIKEN	gun-hit-sga/langka/kunai-shuriken.svg
LEGENDARIS	WARS BLASTER	gun-hit-sga/legendaris/wars-blaster.svg