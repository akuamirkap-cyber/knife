# PROMPT TEKS — CARA MEMBUAT EFEK SUNBURST GACHA (ala game mobile)

> File ini berisi **prompt teks** yang menjelaskan lengkap cara efek sunburst
> (sinar radial + cahaya inti + item legendary) dibuat secara teknis.
> Copy semua teks di bawah untuk mereplikasi efek ini di project mana pun.

---

## ✅ PROMPT SIAP PAKAI (copy mulai dari sini)

```
Buatkan efek animasi "sunburst gacha" 2D yang terasa seperti momen reveal
item legendary di game mobile. Murni CSS + sedikit JavaScript/Canvas,
tanpa gambar apa pun, target 60fps. Susun dari 7 layer transparan yang
ditumpuk (dari belakang ke depan):

LAYER 1 — BACKGROUND RADIAL GELAP
- Warna dasar sangat gelap, pusatnya sedikit terang di posisi 45% dari atas:
  background: radial-gradient(ellipse 90% 80% at 50% 45%, #15113a 0%, #0a0620 55%, #050312 100%);
- Tambahkan vignette: radial-gradient(ellipse 90% 85% at 50% 50%, transparent 55%, rgba(3,0,15,.55) 100%)
  di atas semua layer, pointer-events: none.

LAYER 2 — SINAR RADIAL (inti efek sunburst)
- Buat sebuah div penuh (posisi absolute, inset: -35% agar ujung-ujung
  sinar berada di luar layar) dengan isi:
  background: repeating-conic-gradient(
    from 0deg at 50% 50%,
    rgba(167,139,250,.55) 0deg 5.4deg,
    transparent 5.4deg 18deg);
  → Ini membuat 20 sinar (360/18), setiap sinar setajam 30% dari satuannya
    (5.4deg). Semakin kecil rasio sudut = sinar semakin tipis.
- WAJIB ada mask radial supaya TIDAK ada lingkaran tepi yang terlihat.
  Aturan mask-nya (INI RAHASIANYA):
  1. Sinar harus SOLID PENUH (opacity normal) dari pusat sampai titik
     "Awal Fade" (default 55%). Jangan biarkan fade memudari seluruh
     sinar — hanya UJUNG-nya yang boleh lumer.
  2. Setelah Awal Fade, buat 3 stop fade bertahap sampai transparan total
     di titik "Akhir Fade" (default 84%):
     -webkit-mask-image: radial-gradient(circle at 50% 50%,
       black 0%, black 55%, rgba(0,0,0,.45) 70%, transparent 84%);
     mask-image: radial-gradient(circle at 50% 50%,
       black 0%, black 55%, rgba(0,0,0,.45) 70%, transparent 84%);
     (stop tengah = titik persis di antara Awal dan Akhir Fade)
  3. Jaga selalu Akhir Fade ≥ Awal Fade + 10%.
- Putar layer-nya pelan dan nyaman:
  animation: spin 27s linear infinite;
  @keyframes spin { to { transform: rotate(360deg); } }
- Set mix-blend-mode: screen supaya sinar menyatu dengan background.
- Opsional (OFF by default): lapis kedua dengan jumlah sinar separuh,
  opasitas ~50%, berputar arah BERLAWANAN 1.7× lebih lambat untuk
  kedalaman. Jangan aktifkan kecuali diminta — bisa terlihat "dobel".

LAYER 3 — INTI CAHAYA (CORE GLOW)
- Di tengah (50%, 46%), sebuah div lingkaran ~30% lebar stage,
  aspect-ratio 1, border-radius 50%, WAJIB filter: blur(14px)
  supaya menjadi halo lembut — JANGAN BOLEH terlihat seperti
  lingkaran/piringan solid (semua stop gradient harus berakhir
  di transparent sebelum 100%).
- WARNA inti HARUS SAMA dengan warna sinar (bukan putih!):
  background: radial-gradient(circle,
    <warna sinar dicampur 55% putih> 0%,   ← pusat paling terang
    rgba(warnaSinar, .75) 16%,
    rgba(warnaSinar, .40) 40%,
    transparent 70%);
  Contoh untuk sinar #a78bfa:
    rgb(211,199,255) 0%, rgba(167,139,250,.75) 16%, rgba(167,139,250,.4) 40%, transparent 70%;
- Animasi "napas" (pulse) 2.6 detik: scale 1 → 1.14 → 1, ease-in-out,
  opacity 0.9 → 1.

LAYER 4 — BINTANG LATAR
- ~46 titik kecil (1-3.5px) tersebar acak, warna putih,
  animasi twinkle 2-5 detik (opacity .15→.9 + scale .7→1.15),
  delay acak. Memberi kesan langit di dalam stage.

LAYER 5 — PARTIKEL SPARKLE (canvas)
- ~70 partikel debu cahaya yang MENDARAT PELAN KE ATAS (vy negatif kecil),
  warna = warna glow, alpha berkedip dengan fungsi sin (freq acak).
- ~12% partikel adalah "besar": digambar sebagai bintang 4-point
  (path: 4 quadratic curve dari satu titik) yang berputar-berkedip.
- Partikel dekat tepi stage di-fade berdasarkan jarak dari pusat
  (fade = max(0, 1 - dist*0.9)).
- Reset posisi ke bawah saat partikel keluar dari atas.

LAYER 6 — ITEM DI TENGAH (misal pedang SVG)
- Item SVG (pedang diagonal 45°) di posisi 50%, 46%,
  float animation 3.2 detik: translateY(0) rotate(-2deg) → translateY(-12px) rotate(2deg).
- Glow: filter: drop-shadow(0 0 20px rgba(240,235,255,.85))
           drop-shadow(0 0 44px rgba(warnaSinar,.5))
           drop-shadow(0 10px 30px rgba(0,0,0,.6));
- PENTING: jangan taruh ellipse/lingkaran apa pun di balik item
  di dalam SVG-nya (halo sudah diurus LAYER 3).

LAYER 7 — SHINE SWEEP (kilau lewat)
- Band putih vertikal ~120px, skewX(-18deg), blur(6px),
  background: linear-gradient(105deg, transparent,
    rgba(255,255,255,.35) 45%, rgba(255,255,255,.7) 50%,
    rgba(255,255,255,.35) 55%, transparent);
- Menyapu dari kiri ke kanan tiap 3.8 detik (left: -30% → 110%),
  opacity 0→1→0 di awal dan akhir sweep.

EFEK BURST (dipicu saat item muncul / tombol):
1. Flash putih radial penuh stage, opacity .85 → 0 dalam .7 detik.
2. Dua ring lingkaran putih dari pusat: scale .2 → 2.6, opacity .9 → 0,
   durasi .9 detik cubic-bezier(.16,1,.3,1), ring kedua delay .12 detik.
3. 90 partikel muncrat dari pusat (kecepatan acak 2-11, gravitasi .12,
   friction .985, life 1 → 0).
4. Item "pop": scale 1 → 1.35 rotate(-8deg) → .94 → 1,
   durasi .8 detik cubic-bezier(.34,1.56,.64,1).

PALET RARITY (standar game — ganti warna sinar/inti/partsikel sesuai ini):
- Common:    #94a3b8   (abu)
- Rare:      #38bdf8   (biru)
- Epic:      #a855f7   (ungu)   ← default
- Legendary: #fbbf24   (emas)
- Mythic:    #f43f5e   (merah)
Background-nya ikut digelapkan ke nuansa warna rarity.

CHECKLIST KUALITAS (jangan sampai):
❌ Sinar tidak boleh dobel/rangkap (1 lapisan kecuali diminta)
❌ Tidak boleh ada lingkaran solid/terti di belakang item
❌ Fade tidak boleh memudari seluruh sinar — hanya di UJUNG
❌ Warna inti cahaya tidak boleh putih, harus = warna sinar
✅ Ujung sinar harus lumer halus sampai benar-benar hilang
✅ Inti cahaya harus silau tapi lembut (blur + stop transparent)
✅ Rotasi pelan & nyaman, semua layer hidup dengan kecepatan berbeda
```

---

## 📎 CATATAN TEKNIS PENUNJANG (opsional, untuk referensi)

| Parameter        | Default  | Range     | Keterangan                          |
|------------------|----------|-----------|-------------------------------------|
| Jumlah sinar     | 20       | 4–36      | `360/n` = sudut unit tiap sinar      |
| Ketajaman sinar  | 30%      | 10–90%    | % bagian unit yang terisi warna     |
| Opasitas sinar   | 55%      | 10–100%   | alpha warna `repeating-conic`       |
| Kecepatan putar  | 27.5s    | 0–∞       | durasi 1 putaran penuh              |
| Ukuran inti      | 30%      | 12–80%    | lebar core relative stage           |
| Awal fade        | 55%      | 25–75%    | posisi solid→mulai pudar            |
| Akhir fade       | 84%      | 55–95%    | posisi pudar→hilang total           |
| Partikel         | 70       | 0–160     | jumlah debu cahaya di canvas        |

**Rumus cepat sinar:**
- sudut unit = `360 / jumlahSinar`
- sudut terisi = `sudutUnit * (ketajaman/100)`
- `repeating-conic-gradient(from 0deg at 50% 50%, WARNA 0deg {terisi}deg, transparent {terisi}deg {unit}deg)`

**Rumus mask ujung (3-stop):**
- `black 0% → black {awal}% → rgba(0,0,0,.45) {(awal+akhir)/2}% → transparent {akhir}%`

**Rumus warna inti:**
- pusat = warnaSinar di-blend 55% ke putih
- stop 16% = rgba(warnaSinar, .75)
- stop 40% = rgba(warnaSinar, .40)
- stop 70% = transparent
- + `filter: blur(14px)`

**Kenapa pakai `repeating-conic-gradient` + mask (bukan gambar)?**
1. Vektor → tajam di semua resolusi, bobot ~0 KB
2. Jumlah sinar, ketajaman, warna bisa diubah lewat variabel → gampang
   buat preset rarity
3. `inset: -35%` + mask radial = teknik standar supaya sinar memanjang
   melewati layar tanpa terlihat tepinya
4. `mix-blend-mode: screen` membuat sinar "menyala" di atas background
   gelap, persis efek cahaya beneran
