import { memo } from 'react';
import type { BowId } from '../game/ragdoll/stick';
import type { HeadStyle } from '../game/ragdoll/head';
import LiveArcher from './LiveArcher';
import './menu.css';

/* Night-forest title backdrop: moon, light rays, layered tree silhouettes,
   grassy cliffs and the live in-game archer standing ready on the left. */

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const STARS = (() => {
  const r = rng(7);
  return Array.from({ length: 64 }, () => ({
    x: r() * 100,
    y: r() * 62,
    s: 1 + r() * 2.2,
    d: r() * 5,
    o: 0.35 + r() * 0.6,
  }));
})();

const FLIES = (() => {
  const r = rng(21);
  return Array.from({ length: 9 }, () => ({ x: 18 + r() * 72, y: 58 + r() * 34, d: r() * 7, t: 6 + r() * 6 }));
})();

/** bumpy canopy line made of overlapping circles sitting on a filled base */
function bumps(seed: number, width: number, baseY: number, minR: number, maxR: number) {
  const r = rng(seed);
  const out: { x: number; y: number; r: number }[] = [];
  for (let x = -40; x < width + 60; ) {
    const rad = minR + r() * (maxR - minR);
    out.push({ x, y: baseY - r() * rad * 0.85, r: rad });
    x += rad * (0.85 + r() * 0.55);
  }
  return out;
}

const FAR = bumps(3, 1600, 250, 34, 78);
const MID = bumps(11, 1600, 318, 30, 62);
const BUSH = bumps(5, 1600, 112, 26, 58);

function Pad({ cx, cy, rx, ry }: { cx: number; cy: number; rx: number; ry: number }) {
  return (
    <>
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} />
      <ellipse cx={cx - rx * 0.46} cy={cy - ry * 0.55} rx={rx * 0.42} ry={ry * 0.85} />
      <ellipse cx={cx + rx * 0.08} cy={cy - ry * 0.85} rx={rx * 0.5} ry={ry} />
      <ellipse cx={cx + rx * 0.55} cy={cy - ry * 0.42} rx={rx * 0.36} ry={ry * 0.75} />
    </>
  );
}

/** umbrella tree: forked trunk carrying flat layered canopies (base at 0,0, ~340 tall) */
function Acacia({ x, y, s = 1, fill, flip = false }: { x: number; y: number; s?: number; fill: string; flip?: boolean }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`} fill={fill}>
      <path d="M-18 6C-12-60-7-120-11-170C-30-208-70-228-98-244L-90-256C-58-242-24-224-3-196C0-232 14-264 40-292L52-284C32-258 21-226 19-190C40-206 76-216 112-218L114-205C78-200 42-186 23-160C19-110 20-50 28 6Z" />
      <Pad cx={-104} cy={-256} rx={92} ry={25} />
      <Pad cx={48} cy={-300} rx={118} ry={31} />
      <Pad cx={124} cy={-224} rx={82} ry={23} />
    </g>
  );
}

function Cloud({ className, fill }: { className: string; fill: string }) {
  return (
    <svg viewBox="0 0 240 70" className={className} aria-hidden>
      <g fill={fill}>
        <rect x="14" y="40" width="212" height="22" rx="11" />
        <ellipse cx="70" cy="40" rx="42" ry="20" />
        <ellipse cx="124" cy="30" rx="48" ry="26" />
        <ellipse cx="176" cy="42" rx="36" ry="17" />
      </g>
    </svg>
  );
}

function MenuScene({ paused = false, skin, bow, bare = false }: { paused?: boolean; skin?: HeadStyle; bow?: BowId; bare?: boolean }) {
  return (
    <div aria-hidden className={`m-vars m-scene ${paused ? 'm-paused' : ''}`}>
      <div className="m-rays" />

      {STARS.map((s, i) => (
        <span
          key={i}
          className="m-star"
          style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, animationDelay: `${s.d}s`, ['--o' as string]: s.o }}
        />
      ))}

      {/* ---------- full moon ---------- */}
      <div className="m-moon">
        <svg viewBox="0 0 200 200" className="h-full w-full">
          <defs>
            <radialGradient id="mm-moon" cx="42%" cy="38%" r="68%">
              <stop offset="0" stopColor="#f6f7e6" />
              <stop offset="0.62" stopColor="#dde3cf" />
              <stop offset="1" stopColor="#b3c0bf" />
            </radialGradient>
          </defs>
          <circle cx="100" cy="100" r="96" fill="url(#mm-moon)" />
          <g fill="#bcc7bd" opacity="0.75">
            <ellipse cx="66" cy="66" rx="24" ry="20" />
            <ellipse cx="128" cy="52" rx="13" ry="11" />
            <ellipse cx="140" cy="112" rx="26" ry="23" />
            <ellipse cx="78" cy="136" rx="17" ry="14" />
            <ellipse cx="42" cy="110" rx="9" ry="8" />
            <ellipse cx="112" cy="162" rx="11" ry="8" />
            <ellipse cx="166" cy="76" rx="7" ry="8" />
          </g>
          <g fill="#e9eddb" opacity="0.7">
            <ellipse cx="62" cy="62" rx="15" ry="12" />
            <ellipse cx="136" cy="107" rx="17" ry="14" />
            <ellipse cx="75" cy="133" rx="10" ry="8" />
          </g>
          <circle cx="100" cy="100" r="96" fill="none" stroke="#ffffff" strokeOpacity="0.35" strokeWidth="3" />
        </svg>
      </div>
      <Cloud className="m-cloud m-cloud-a" fill="#1a5fd3" />
      <Cloud className="m-cloud m-cloud-b" fill="#2069dc" />
      <Cloud className="m-cloud m-cloud-c" fill="#1857c9" />

      {/* ---------- distant forest ---------- */}
      <svg viewBox="0 0 1600 400" className="m-layer m-far">
        <g fill="#1556cb">
          {FAR.map((c, i) => <circle key={i} cx={c.x} cy={c.y} r={c.r} />)}
          <rect x="-40" y="240" width="1700" height="170" />
        </g>
        <Acacia x={470} y={300} s={0.62} fill="#1556cb" />
        <Acacia x={1010} y={300} s={0.7} fill="#1556cb" flip />
        <g fill="#0f47b4">
          {MID.map((c, i) => <circle key={i} cx={c.x} cy={c.y} r={c.r} />)}
          <rect x="-40" y="310" width="1700" height="100" />
        </g>
      </svg>
      <div className="m-haze" />

      {/* ---------- umbrella trees ---------- */}
      <svg viewBox="0 0 700 620" className="m-trees m-trees-l">
        <Acacia x={500} y={626} s={0.8} fill="#0e43ad" flip />
        <Acacia x={250} y={630} s={0.56} fill="#1049b6" />
      </svg>
      <svg viewBox="0 0 700 620" className="m-trees m-trees-r">
        <Acacia x={250} y={626} s={1.22} fill="#0e42aa" />
        <Acacia x={600} y={640} s={1.84} fill="#0a3594" flip />
      </svg>

      {/* ---------- foreground bushes ---------- */}
      <svg viewBox="0 0 1600 160" className="m-layer m-bush">
        <g fill="#072a7c">
          {BUSH.map((c, i) => <circle key={i} cx={c.x} cy={c.y} r={c.r} />)}
          <rect x="-40" y="104" width="1700" height="70" />
        </g>
        <g fill="#051f62">
          {BUSH.map((c, i) => <circle key={i} cx={c.x + 46} cy={c.y + 52} r={c.r * 0.9} />)}
        </g>
      </svg>

      {FLIES.map((f, i) => (
        <span key={i} className="m-fly" style={{ left: `${f.x}%`, top: `${f.y}%`, animationDelay: `-${f.d}s`, animationDuration: `${f.t}s` }} />
      ))}

      {!bare && (
        <>
      {/* ---------- right ledge ---------- */}
      <svg viewBox="0 0 220 150" className="m-ledge">
        <defs>
          <linearGradient id="mm-rock2" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#2f80d6" />
            <stop offset="1" stopColor="#11458f" />
          </linearGradient>
          <linearGradient id="mm-grass2" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#86e845" />
            <stop offset="1" stopColor="#39a82e" />
          </linearGradient>
        </defs>
        <path d="M34 62H230V160H92C80 132 54 104 34 62Z" fill="url(#mm-rock2)" />
        <path d="M92 160C96 128 120 110 150 104L176 160Z" fill="#092a66" opacity="0.6" />
        <path d="M18 60C24 44 60 38 110 38C150 38 200 40 230 42V80C218 88 206 86 200 76C190 90 172 90 164 76C154 90 136 90 128 76C118 90 100 90 92 76C82 90 64 88 58 76C46 86 22 80 18 60Z" fill="#2c8f2c" />
        <path d="M18 58C24 42 60 34 110 34C150 34 200 36 230 38V68C218 76 206 74 200 64C190 78 172 78 164 64C154 78 136 78 128 64C118 78 100 78 92 64C82 78 64 76 58 64C46 74 22 74 18 58Z" fill="url(#mm-grass2)" />
        <path d="M40 40l4-16 6 14zM78 35l6-18 5 17zM128 34l4-15 7 15zM176 36l5-17 6 17z" fill="#86e845" />
        <path d="M30 50C60 42 130 40 222 44" stroke="#c4ff7e" strokeWidth="3" strokeLinecap="round" fill="none" opacity="0.7" />
      </svg>

      {/* ---------- archer's cliff ---------- */}
      <svg viewBox="0 0 400 330" className="m-cliff">
        <defs>
          <linearGradient id="mm-rock" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#2f80d6" />
            <stop offset="1" stopColor="#11458f" />
          </linearGradient>
          <linearGradient id="mm-grass" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#8cec48" />
            <stop offset="1" stopColor="#3aaa2f" />
          </linearGradient>
        </defs>
        {/* rock */}
        <path d="M-10 226H322C330 250 312 268 292 282C272 298 256 314 246 340H-10Z" fill="url(#mm-rock)" />
        <path d="M-10 340V276C30 262 66 270 92 292C110 308 118 324 122 340Z" fill="#0b3478" opacity="0.6" />
        <path d="M246 340C240 310 212 286 176 280C204 268 250 266 292 282C272 298 256 314 246 340Z" fill="#082a66" opacity="0.55" />
        <path d="M150 262l26 8-16 18zM60 256l18 5-12 12z" fill="#2f7fd6" opacity="0.5" />
        {/* grass */}
        <path d="M-10 222C60 210 150 210 240 212C292 212 332 216 340 230C344 248 326 254 314 246C306 262 288 262 280 248C270 264 252 264 244 250C234 266 216 266 208 250C198 266 180 266 172 250C162 266 144 266 136 250C126 266 108 266 100 250C90 266 72 266 64 250C54 266 36 266 28 250C18 262 0 262-10 256Z" fill="#2a8c2c" />
        <path d="M-10 214C60 204 150 204 240 206C292 206 332 210 340 224C344 240 326 246 314 238C306 252 288 252 280 240C270 254 252 254 244 240C234 254 216 254 208 240C198 254 180 254 172 240C162 254 144 254 136 240C126 254 108 254 100 240C90 254 72 254 64 240C54 254 36 254 28 240C18 252 0 252-10 248Z" fill="url(#mm-grass)" />
        <path d="M14 208l5-18 6 17zM52 206l4-14 7 14zM92 205l6-20 5 19zM236 206l5-17 6 17zM274 207l4-14 7 14zM306 210l6-18 4 19z" fill="#8cec48" />
        <path d="M0 216C70 207 160 207 250 210C290 210 318 213 330 220" stroke="#cdff86" strokeWidth="3.5" strokeLinecap="round" fill="none" opacity="0.75" />
        <ellipse cx="150" cy="216" rx="62" ry="6" fill="#06240f" opacity="0.4" />
      </svg>

      {/* the real in-game archer, standing on the grass */}
      <LiveArcher className="m-archer-live" skin={skin ?? 'band'} bow={bow ?? 'thunder'} paused={paused} units={140} ox={0.25} oy={0.92} arrowLife={0.5} />

        </>
      )}

      <div className="m-vignette" />
    </div>
  );
}

export default memo(MenuScene);
