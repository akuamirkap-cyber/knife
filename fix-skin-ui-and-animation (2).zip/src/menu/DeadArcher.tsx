import { useEffect, useRef } from 'react';
import { V, add, canvasDpr, fromAngle, ik, v } from '../game/util';
import { BowId, Slab2, drawArrow, drawBow, impulse, makeStick, stepStick } from '../game/ragdoll/stick';
import type { Stick } from '../game/ragdoll/stick';
import { HeadStyle, makeHair, stepHair } from '../game/ragdoll/head';
import { drawSkinFigure } from '../SkinModal';

/* The real in-game archer on a transparent canvas, replaying his own defeat: he stands ready, gets hit,
   crumples with the same ragdoll physics as in a fight and ends up lying on the grass beside his bow
   and the arrows he planted. */

const STEP = 1 / 120;
const SLAB: Slab2[] = [{ x0: -500, x1: 500, top: 0, bot: 60 }];
const smooth01 = (x: number) => { const t = Math.max(0, Math.min(1, x)); return t * t * (3 - 2 * t); };

// The physics stays untouched; this render-only IK keeps the two hands apart and each arm fully connected.
function relaxedArms(k: Stick, weight: number): Stick {
  if (weight <= 0) return k;
  const p = k.p.map((q) => v(q.x, q.y));
  const root = p[1]; const hip = p[2];
  const dx = root.x - hip.x; const dy = root.y - hip.y;
  const bodyLength = Math.hypot(dx, dy) || 1;
  const axisX = dx / bodyLength; const axisY = dy / bodyLength;
  const downX = -axisY; const downY = axisX;
  const handNear = v(root.x - axisX * 27 + downX * 6, root.y - axisY * 27 + downY * 6);
  const handForward = v(root.x + axisX * 17 + downX * 16, root.y + axisY * 17 + downY * 16);

  const poseArm = (elbowIndex: number, handIndex: number, target: V, bendTarget: number, upper: number, forearm: number) => {
    const current = p[handIndex];
    const cx = current.x - root.x; const cy = current.y - root.y;
    const tx = target.x - root.x; const ty = target.y - root.y;
    const currentAngle = Math.atan2(cy, cx); const targetAngle = Math.atan2(ty, tx);
    const turn = Math.atan2(Math.sin(targetAngle - currentAngle), Math.cos(targetAngle - currentAngle));
    const angle = currentAngle + turn * weight;
    const minReach = Math.abs(upper - forearm) + 1.05;
    const maxReach = upper + forearm - 0.05;
    const currentReach = Math.max(minReach, Math.min(maxReach, Math.hypot(cx, cy)));
    const targetReach = Math.max(minReach, Math.min(maxReach, Math.hypot(tx, ty)));
    const reach = currentReach + (targetReach - currentReach) * weight;
    const hand = add(root, fromAngle(angle, reach));
    p[elbowIndex] = ik(root, hand, upper, forearm, bendTarget).mid;
    p[handIndex] = hand;
  };

  poseArm(3, 4, handNear, -1, k.L[6], k.L[7]);
  poseArm(5, 6, handForward, -1, k.L[8], k.L[9]);
  return { ...k, p };
}

interface Props {
  skin: HeadStyle;
  bow: BowId;
  /** seconds before the fatal hit lands */
  delay?: number;
  /** world units that fit in the canvas height */
  units?: number;
  ox?: number;
  oy?: number;
  className?: string;
}

export default function DeadArcher({ skin, bow, delay = 0.7, units = 84, ox = 0.5, oy = 0.96, className }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const live = useRef({ skin, bow, units, ox, oy });
  live.current = { skin, bow, units, ox, oy };

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const k = makeStick(v(0, 0), 1, 1, false, true);
    const hair = makeHair(live.current.skin, k);
    let t = 0; let fallTime = 0; let fallen = false;
    let acc = 0; let prev = 0; let raf = 0;
    const step = () => {
      t += STEP;
      if (!fallen) {
        k.base = v(0, 0); k.vigor = 1; k.muscle = Math.min(1, k.muscle + STEP * 1.1);
        k.aiming = Math.min(1, k.aiming + STEP * 2.2); k.aim = -0.2;
        if (t >= delay) {
          fallen = true;
          k.alive = false; k.muscle = 0; k.pull = 0; k.aiming = 0; k.hasBow = false; k.fade = 0.52; k.hurt = 1;
          impulse(k, 0, v(-117, -179)); impulse(k, 1, v(-94, -86)); impulse(k, 2, v(-55, -31));
        }
      }
      if (fallen) fallTime += STEP;
      k.lookAt = null;
      stepStick(k, SLAB);
      if (hair) stepHair(k, hair);
    };
    // Let his hair and stance settle before replaying the fall.
    for (let i = 0; i < 70; i++) {
      k.base = v(0, 0); k.vigor = 1; k.muscle = Math.min(1, k.muscle + STEP * 1.1);
      k.aiming = Math.min(1, k.aiming + STEP * 2.2); k.aim = -0.2; k.lookAt = null;
      stepStick(k, SLAB);
      if (hair) stepHair(k, hair);
    }

    const paint = (rt: number) => {
      const o = live.current;
      const r = canvas.getBoundingClientRect();
      const dpr = canvasDpr(r.width, r.height);
      const w = Math.max(8, r.width); const h = Math.max(8, r.height);
      const cw = Math.round(w * dpr); const ch = Math.round(h * dpr);
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const Z = h / o.units;
      ctx.translate(w * o.ox, h * o.oy);
      ctx.scale(Z, Z);
      ctx.lineCap = 'round';
      // the arrows he planted, one at each side
      drawArrow(ctx, v(-58, 3), Math.PI / 2 + 0.22, 1, true, o.bow, rt, false);
      drawArrow(ctx, v(44, 3), Math.PI / 2 - 0.2, 1, true, o.bow, rt, false);
      // his bow, dropped beside him once the blow lands
      if (fallen) drawBow(ctx, v(112, -5), -0.2, 1, null, 0, false, o.bow, rt);
      const figure = fallen ? relaxedArms(k, smooth01((fallTime - 0.08) / 0.46)) : k;
      drawSkinFigure(ctx, figure, o.skin, hair, rt, fallen ? null : o.bow);
    };

    let rt = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, prev ? (now - prev) / 1000 : 0.016);
      prev = now; rt += dt; acc += dt;
      let guard = 0;
      while (acc >= STEP && guard++ < 10) { step(); acc -= STEP; }
      if (guard >= 10) acc = 0;
      paint(rt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [delay]);

  return <canvas ref={ref} className={className} aria-hidden="true" />;
}
