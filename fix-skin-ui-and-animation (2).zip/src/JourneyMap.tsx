// "TO LEVEL X": a full-screen night-forest journey map (no boxed panel). One clean road runs the whole
// width of the screen; the next stretch forks into SAFE / DANGER lanes with a chest camp off to the side.
import { ReactNode, useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { RagWorld, RUi } from './game/ragdoll/game';
import { CFG } from './game/ragdoll/config';
import { encounterPlan, levelCounts, levelReward } from './game/ragdoll/formulas';
import { THEMES } from './game/ragdoll/scenery';
import { audioInit, snd } from './game/ragdoll/audio';
import { TreeArcher } from './SkillTreeArt';
import { Banner, prefersReducedMotion } from './RewardCards';
import MenuScene from './menu/MenuScene';
import { tx, useLang } from './i18n';
import './run-panels.css';

type W = () => RagWorld | undefined;
type Route = 'aman' | 'risiko' | 'peti';
type Pt = [number, number];
type Kind = 'camp' | 'won' | 'arena' | 'fort' | 'hostage' | 'boss' | 'dragon';
type IconName = 'swords' | 'castle' | 'chain' | 'skull' | 'flame' | 'tent' | 'trophy' | 'shield' | 'chest' | 'coin' | 'heart' | 'users' | 'bat' | 'crosshair' | 'check' | 'arrow' | 'map';

/* ---------------- icons: drawn twice (ink outline + colour) for the game's cartoon look ---------------- */
const ICON: Record<IconName, ReactNode> = {
  swords: <><path d="M14.5 17.5 3 6V3h3l11.5 11.5" /><path d="m13 19 6-6M16 16l4 4M19 21l2-2" /><path d="M14.5 6.5 18 3h3v3l-3.5 3.5" /><path d="m5 14 4 4M7 17l-3 3M3 19l2 2" /></>,
  castle: <><path d="M22 20v-9H2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2Z" /><path d="M18 11V4H6v7M15 22v-4a3 3 0 0 0-6 0v4M22 11V9M2 11V9M6 4V2M18 4V2M10 4V2M14 4V2" /></>,
  chain: <><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></>,
  skull: <><path d="M16 20a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20" /><path d="M8 20v2h8v-2" /><path d="M9 12h.01M15 12h.01" strokeWidth="3.4" /></>,
  flame: <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.07-2.14-.22-4.05 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.15.43-2.29 1-3a2.5 2.5 0 0 0 2.5 2.5z" />,
  tent: <path d="M3.5 21 14 3M20.5 21 10 3M15.5 21 12 15l-3.5 6M2 21h20" />,
  trophy: <><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6M18 9h1.5a2.5 2.5 0 0 0 0-5H18M4 22h16M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" /><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z" /></>,
  shield: <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />,
  chest: <><path d="M4 11h16v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z" /><path d="M4 11V9a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v2" /><path d="M10 11v3h4v-3M4 15h6M14 15h6" /></>,
  coin: <><circle cx="12" cy="12" r="9" /><path d="M12 7v10" /><path d="M15 9.5h-4a1.75 1.75 0 0 0 0 3.5h2a1.75 1.75 0 0 1 0 3.5H9" /></>,
  heart: <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
  bat: <path d="M12 9c-.8 0-1.4.8-1.8 1.8C9 9.7 6.8 8.9 3 9.6c1.3 1 1.9 2.7 1.6 4.7 1.4-.8 3.1-.6 4.4.9.6-1.1 1.7-1.7 3-1.7s2.4.6 3 1.7c1.3-1.5 3-1.7 4.4-.9-.3-2 .3-3.7 1.6-4.7-3.8-.7-6 .1-7.2 1.2C13.4 9.8 12.8 9 12 9z" />,
  crosshair: <><circle cx="12" cy="12" r="9" /><path d="M22 12h-4M6 12H2M12 6V2M12 22v-4" /></>,
  check: <path d="M20 6 9 17l-5-5" />,
  arrow: <path d="M5 12h14M12 5l7 7-7 7" />,
  map: <><path d="M14.1 6.03 9.9 4a1 1 0 0 0-.84 0L3.55 6.56A1 1 0 0 0 3 7.45v12.03a1 1 0 0 0 1.45.89l4.45-2.22a1 1 0 0 1 .89 0l4.31 2.15a1 1 0 0 0 .9 0l5.45-2.73a1 1 0 0 0 .55-.89V4.65a1 1 0 0 0-1.45-.89l-4.45 2.22a1 1 0 0 1-.89 0" /><path d="M15 5.76v15M9 3.24v15" /></>,
};
function Ico({ name, className = '', ink = true }: { name: IconName; className?: string; ink?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" strokeLinecap="round" strokeLinejoin="round" overflow="visible" aria-hidden="true">
      {ink && <g stroke="#0a1a52" strokeWidth="5.4">{ICON[name]}</g>}
      <g stroke="currentColor" strokeWidth={ink ? 2.5 : 2}>{ICON[name]}</g>
    </svg>
  );
}

/* ---------------- encounters ---------------- */
const getKinds = (): Record<Kind, { icon: IconName; label: string; title: string }> => ({
  camp: { icon: 'tent', label: tx('CAMP', 'KEMAH'), title: tx('START CAMP', 'KEMAH AWAL') },
  won: { icon: 'trophy', label: tx('BOSS SLAIN', 'BOS TUMBANG'), title: tx('BOSS DEFEATED', 'BOS TUMBANG') },
  arena: { icon: 'swords', label: 'ARENA', title: tx('ARCHER ARENA', 'ARENA PEMANAH') },
  fort: { icon: 'castle', label: tx('WOODEN FORT', 'ISTANA KAYU'), title: tx('WOODEN FORT', 'ISTANA KAYU') },
  hostage: { icon: 'chain', label: tx('HOSTAGE', 'TAWANAN'), title: tx('RESCUE HOSTAGE', 'SELAMATKAN TAWANAN') },
  boss: { icon: 'skull', label: tx('BIG BOSS', 'BOS BESAR'), title: tx('BIG BOSS', 'BOS BESAR') },
  dragon: { icon: 'flame', label: tx('RED DRAGON', 'NAGA MERAH'), title: tx('RED DRAGON', 'NAGA MERAH') },
});
/** one short tip, shown as a tooltip on the next-stop strip */
const getTips = (): Partial<Record<Kind, string>> => ({
  arena: tx(`Headshot = ${CFG.hitMult.head}× damage.`, `Headshot = damage ${CFG.hitMult.head}×.`),
  fort: tx('Aim for the foundation pegs and roof joints.', 'Bidik pasak pondasi dan sendi atap.'),
  hostage: tx('Cut the rope, not the captive.', 'Bidik talinya, bukan tawanan.'),
  boss: tx('Huge HP: aim for the head between swings.', 'HP besar: incar kepala di sela ayunan.'),
  dragon: tx(`Shoot its mouth while it charges fire: +${CFG.rewards.dragonMouth} gold.`, `Tembak mulut naga saat bersiap: +${CFG.rewards.dragonMouth} emas.`),
});
const kindOf = (level: number, first: boolean, chapter: number): Kind => {
  if (first) return chapter === 0 ? 'camp' : 'won';
  const p = encounterPlan(level);
  return p.dragon ? 'dragon' : p.boss ? 'boss' : p.fort ? 'fort' : p.hostage ? 'hostage' : 'arena';
};
const rangeOf = (level: number) => (level % 3 === 0 ? 2 : level % 3 === 2 ? 1.5 : 1);

/* ---------------- map geometry (real pixels, measured from the screen) ---------------- */
const f1 = (p: Pt) => `${p[0].toFixed(1)} ${p[1].toFixed(1)}`;
const sCurve = (a: Pt, b: Pt) => { const dx = b[0] - a[0]; return `M ${f1(a)} C ${a[0] + dx / 2} ${a[1]}, ${b[0] - dx / 2} ${b[1]}, ${f1(b)}`; };

interface Geo { pts: Pt[]; roads: Record<Route, { d: string; at: Pt; cap: Pt }>; junction: Pt }

/** stations run left to right on a gentle wave; the stretch you stand on gets extra room for its three options */
function layout(n: number, cur: number, W: number, H: number): Geo {
  const x0 = Math.max(54, W * 0.065); const x1 = W - Math.max(96, W * 0.1);
  const weights = Array.from({ length: n - 1 }, (_, i) => (i === cur ? 2.1 : 1));
  const sum = weights.reduce((a, b) => a + b, 0);
  const base = H * 0.5; const amp = H * 0.065;
  let x = x0;
  const pts: Pt[] = Array.from({ length: n }, (_, i) => {
    const p: Pt = [x, base + Math.sin(i * 1.5 + 0.6) * amp];
    if (i < n - 1) x += ((x1 - x0) * weights[i]) / sum;
    return p;
  });
  pts[cur + 1][1] = pts[cur][1]; // the fork is a clean lens: both ends level
  const a = pts[cur]; const b = pts[cur + 1]; const dx = b[0] - a[0];
  const up = Math.min(H * 0.25, 78); const down = Math.min(H * 0.24, 70);
  const m: Pt = [a[0] + dx * 0.5, a[1] - up];
  const s: Pt = [a[0] + dx * 0.5, a[1]];
  const c: Pt = [s[0], a[1] + down];
  const risky = `M ${f1(a)} C ${a[0] + dx * 0.3} ${a[1]}, ${m[0] - dx * 0.19} ${m[1]}, ${f1(m)} C ${m[0] + dx * 0.19} ${m[1]}, ${b[0] - dx * 0.3} ${b[1]}, ${f1(b)}`;
  const chest = `M ${f1(a)} L ${s[0] - 40} ${a[1]} C ${s[0] - 8} ${a[1]}, ${s[0]} ${a[1] + 14}, ${s[0]} ${a[1] + down * 0.5} L ${f1(c)}`;
  return {
    pts, junction: s,
    roads: {
      aman: { d: `M ${f1(a)} L ${f1(b)}`, at: [a[0] + dx * 0.75, a[1]], cap: [0, 1] },
      risiko: { d: risky, at: m, cap: [0, -1] },
      peti: { d: chest, at: c, cap: [0, 1] },
    },
  };
}
const fortress = (x: number, y: number, k: number) => {
  const p = (px: number, py: number) => `${(x + px * k).toFixed(1)} ${(y + py * k).toFixed(1)}`;
  const pts: [number, number][] = [[-74, 22], [-74, -26], [-62, -26], [-62, -36], [-54, -36], [-54, -26], [-47, -26], [-47, -36], [-39, -36], [-39, -26], [-30, -26], [-30, -50], [-21, -50], [-21, -60], [-13, -60], [-13, -50], [-6, -50], [-6, -60], [2, -60], [2, -50], [9, -50], [9, -60], [17, -60], [17, -50], [26, -50], [26, -26], [35, -26], [35, -36], [43, -36], [43, -26], [50, -26], [50, -36], [58, -36], [58, -26], [70, -26], [70, 22]];
  return `M ${pts.map(([px, py]) => p(px, py)).join(' L ')} Z`;
};

const ROUTE_ICON: Record<Route, IconName> = { aman: 'shield', risiko: 'skull', peti: 'chest' };

function Pips({ n, kind }: { n: number; kind: 'danger' | 'reward' }) {
  return <span className={`jr-pips ${kind}`}>{[0, 1, 2].map((i) => <i key={i} className={i < n ? 'on' : ''} />)}</span>;
}

function useBox(ref: React.RefObject<HTMLDivElement | null>) {
  const [box, setBox] = useState({ w: 960, h: 320 });
  useLayoutEffect(() => {
    const el = ref.current; if (!el) return;
    const fit = () => setBox({ w: Math.max(780, el.clientWidth), h: Math.max(180, el.clientHeight) });
    fit();
    const ro = new ResizeObserver(fit); ro.observe(el);
    return () => ro.disconnect();
  }, [ref]);
  return box;
}

export function RoutePanel({ ui, w }: { ui: RUi; w: W }) {
  useLang();
  const KIND = getKinds();
  const TIP = getTips();
  const r = ui.run; const R = CFG.route.risk; const every = CFG.bigBoss.every;
  const next = ui.level + 1;
  const chapter = Math.floor((next - 1) / every);
  const start = chapter * every;
  const cur = Math.max(0, Math.min(every - 1, ui.level - start));
  const themeIndex = Math.floor((next - 1) / 3) % THEMES.length;
  const theme = THEMES[themeIndex];

  const scroller = useRef<HTMLDivElement>(null);
  const { w: MW, h: MH } = useBox(scroller);
  const geo = layout(every + 1, cur, MW, MH);
  const { pts, roads } = geo;
  const nodes = pts.map((p, i) => {
    const level = start + i; const kind = kindOf(level, i === 0, chapter);
    const state = i < cur ? 'done' : i === cur ? 'here' : i === cur + 1 ? 'next' : 'todo';
    return { p, i, level, kind, state };
  });
  const target = nodes[cur + 1];
  const bossNode = nodes[nodes.length - 1];
  const toBoss = target.kind === 'boss' || target.kind === 'dragon';
  const bossIn = bossNode.level - next;
  const counts = levelCounts(next); const range = rangeOf(next);
  const disabled = (k: Route) => k === 'peti' && !r.canChest;

  const [sel, setSel] = useState<Route>('aman');
  const [hover, setHover] = useState<Route | null>(null);
  const [moving, setMoving] = useState<Route | null>(null);
  const [tok, setTok] = useState<Pt>(pts[cur]);
  const pathEls = useRef<Partial<Record<Route, SVGPathElement | null>>>({});
  const raf = useRef(0);
  const born = useRef(performance.now());
  useEffect(() => () => cancelAnimationFrame(raf.current), []);
  useEffect(() => { if (disabled(sel)) setSel('aman'); }, [r.canChest]); // eslint-disable-line react-hooks/exhaustive-deps
  // narrow screens: the map is wider than the view; start with the crossroads centred
  useLayoutEffect(() => {
    const el = scroller.current; if (!el || el.scrollWidth <= el.clientWidth + 2) return;
    el.scrollLeft = Math.max(0, (pts[cur][0] + pts[cur + 1][0]) / 2 - el.clientWidth / 2);
  }, [cur, MW]); // eslint-disable-line react-hooks/exhaustive-deps

  const select = (k: Route) => {
    if (moving) return;
    if (disabled(k)) { snd.deny(); return; }
    audioInit(); snd.tap(); setSel(k);
  };
  const go = (k: Route) => {
    if (moving) return;
    if (disabled(k)) { snd.deny(); return; }
    audioInit(); snd.open(); setMoving(k); setSel(k);
    const el = pathEls.current[k]; const total = el?.getTotalLength?.() ?? 0;
    const dur = prefersReducedMotion() ? 180 : k === 'peti' ? 1000 : 1150;
    const t0 = performance.now(); let step = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / dur); const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      if (el && total) { const q = el.getPointAtLength(total * e); setTok([q.x, q.y]); }
      const s = Math.floor(t * 5); if (s > step) { step = s; snd.tap(); }
      if (t < 1) { raf.current = requestAnimationFrame(tick); return; }
      w()?.chooseRoute(k);
    };
    raf.current = requestAnimationFrame(tick);
  };
  const latest = useRef({ select, go, sel }); latest.current = { select, go, sel };
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.repeat || e.ctrlKey || e.metaKey || e.altKey || performance.now() - born.current < 400) return;
      const k = ({ '1': 'aman', '2': 'risiko', '3': 'peti' } as Record<string, Route>)[e.key];
      if (k) { e.preventDefault(); latest.current.select(k); return; }
      if (e.key === 'Enter') { e.preventDefault(); latest.current.go(latest.current.sel); }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  const preview = moving ?? hover ?? sel;
  const order = (['aman', 'risiko', 'peti'] as Route[]).sort((a, b) => Number(a === preview) - Number(b === preview));
  const routes: { k: Route; name: string; desc: string; danger: number; stat: ReactNode }[] = [
    { k: 'aman', name: tx('SAFE ROAD', 'JALAN AMAN'), desc: tx('Standard foes. Steady path.', 'Musuh normal. Langkah stabil.'), danger: 1, stat: <span className="jr-gold font-game"><Ico name="coin" ink={false} />×1</span> },
    { k: 'risiko', name: tx('DANGER ROAD', 'JALAN BAHAYA'), desc: tx(`Foes +${Math.round((R.hp - 1) * 100)}% HP & damage. Gold ×${R.gold}.`, `Musuh +${Math.round((R.hp - 1) * 100)}% HP & damage. Emas ×${R.gold}.`), danger: 3, stat: <span className="jr-gold font-game"><Ico name="coin" ink={false} />×{R.gold}</span> },
    { k: 'peti', name: tx('CHEST CAMP', 'PETI HARTA'), desc: r.lastChest ? tx('Already opened.', 'Sudah dibuka.') : tx('1 card or full heal. No fight.', '1 kartu atau pulih penuh. Tanpa bertarung.'), danger: 0, stat: <span className={`jr-gold font-game ${r.canChest ? '' : 'short'}`}><Ico name="coin" ink={false} />{r.chestCost}</span> },
  ];
  const goTone = sel === 'peti' ? 'jm-go-green' : sel === 'risiko' || toBoss ? 'jm-go-red' : 'jm-go-orange';
  const goLabel = moving ? tx('TRAVELING…', 'BERJALAN…')
    : sel === 'peti' ? tx(`OPEN CHEST · ${r.chestCost}`, `BUKA PETI · ${r.chestCost}`)
    : toBoss ? tx(`FACE BOSS · LV ${next}`, `HADAPI BOS · LV ${next}`)
    : sel === 'risiko' ? tx(`DANGER ROAD · LV ${next}`, `JALAN BAHAYA · LV ${next}`) : tx(`GO TO LV ${next}`, `KE LV ${next}`);

  const hereLeft = moving && moving !== null;
  const tip = TIP[target.kind];

  return (
    <div className="jm-root g-dead-backdrop" role="dialog" aria-label={tx(`Toward level ${next}`, `Menuju level ${next}`)}>
      <MenuScene bare />
      <div className="jm-shade" aria-hidden="true" />

      <header className="jm-head">
        <span className="jm-chap font-game">
          <span className="jm-flag"><Ico name="map" /></span>
          <span><b>{tx(`CHAPTER ${chapter + 1}`, `BAB ${chapter + 1}`)}</b><small>{theme.name.toUpperCase()}</small></span>
        </span>
        <Banner tone={toBoss ? 'red' : 'blue'} className="jm-banner">{tx(`TO LEVEL ${next}`, `MENUJU LEVEL ${next}`)}{toBoss ? tx(' · BOSS!', ' · BOS!') : ''}</Banner>
        <span className="jm-chips">
          <span className="jm-chip gold font-game" aria-label={tx(`${ui.coins} gold`, `${ui.coins} emas`)}><Ico name="coin" ink={false} />{ui.coins}</span>
          <span className="jm-chip hp font-game" aria-label={tx(`HP ${ui.hp} of ${ui.maxHp}`, `HP ${ui.hp} dari ${ui.maxHp}`)}><Ico name="heart" ink={false} />{ui.hp}<small>/{ui.maxHp}</small></span>
        </span>
      </header>

      <div className="jm-map">
        <div className="jm-scroll" ref={scroller}>
          <div className="jm-canvas" style={{ width: MW, height: MH }} onMouseLeave={() => setHover(null)}>
            <svg className="jm-svg" width={MW} height={MH} viewBox={`0 0 ${MW} ${MH}`} aria-hidden="true">
              <defs>
                <radialGradient id="jm-boss"><stop offset="0" stopColor="#ff4a3a" stopOpacity=".6" /><stop offset="1" stopColor="#ff4a3a" stopOpacity="0" /></radialGradient>
                <radialGradient id="jm-dest"><stop offset="0" stopColor="#fff3a8" stopOpacity=".5" /><stop offset="1" stopColor="#fff3a8" stopOpacity="0" /></radialGradient>
              </defs>
              <circle cx={bossNode.p[0]} cy={bossNode.p[1] - 8} r="120" fill="url(#jm-boss)" className="jm-boss-glow" />
              <path d={fortress(bossNode.p[0], bossNode.p[1] + 18, 1.25)} className="jm-castle" />
              <path d={`M ${bossNode.p[0] + 70} ${bossNode.p[1] - 40} V ${bossNode.p[1] - 82} l 24 8 l -24 8`} className="jm-flag-svg" />
              {[-52, 52].map((dx) => <rect key={dx} x={bossNode.p[0] + dx - 5} y={bossNode.p[1] + 8} width="10" height="16" rx="4" className="jm-window" />)}
              {!toBoss && <circle cx={target.p[0]} cy={target.p[1]} r="74" fill="url(#jm-dest)" />}

              {pts.slice(0, -1).map((p, i) => {
                if (i === cur) return null;
                const d = sCurve(p, pts[i + 1]); const done = i < cur;
                return <g key={i}><path d={d} className={`jm-out ${done ? '' : 'dots'}`} /><path d={d} className={`jm-road ${done ? 'done' : 'todo'}`} /></g>;
              })}
              {order.map((k) => <path key={`o-${k}`} d={roads[k].d} className={`jm-out ${preview === k ? 'on' : 'dim'}`} />)}
              {order.map((k) => (
                <path key={k} d={roads[k].d} ref={(el) => { pathEls.current[k] = el; }} className={`jm-opt ${k} ${preview === k ? 'on' : ''} ${disabled(k) ? 'off' : ''}`} />
              ))}
              <path d={roads[preview].d} className="jm-flow" />
              <circle cx={geo.junction[0]} cy={geo.junction[1]} r="6.5" className="jm-junction" />
              {(['aman', 'risiko', 'peti'] as Route[]).map((k) => (
                <path key={`h-${k}`} d={roads[k].d} className="jm-hit" onMouseEnter={() => !moving && setHover(k)} onClick={() => select(k)} />
              ))}
            </svg>

            {nodes.map((n) => {
              const isBoss = n.kind === 'boss' || n.kind === 'dragon'; const here = n.state === 'here';
              return (
                <div key={n.i} className={`jn ${n.state} ${isBoss ? 'boss' : ''} ${here && hereLeft ? 'left' : ''}`} style={{ left: n.p[0], top: n.p[1] }}>
                  {here && <span className="jn-pin font-game">{tx('YOU ARE HERE', 'KAMU DI SINI')}</span>}
                  <span className="jn-core">
                    {here ? <span className="jn-archer"><TreeArcher /></span> : <Ico name={n.state === 'done' ? 'check' : KIND[n.kind].icon} />}
                  </span>
                  <span className="jn-label">
                    <small>{here && n.i > 0 ? tx('CLEARED', 'SELESAI') : n.i === 0 ? tx('START', 'AWAL') : `LV ${n.level}`}{n.state === 'next' ? ` · ${tx('NEXT', 'BERIKUTNYA')}` : ''}</small>
                    <b className="font-game">{here && n.i > 0 ? `LV ${n.level}` : KIND[n.kind].label}</b>
                  </span>
                </div>
              );
            })}

            {(['aman', 'risiko', 'peti'] as Route[]).map((k) => (
              <button
                key={k} type="button" disabled={disabled(k)} tabIndex={-1} title={routes.find((x) => x.k === k)?.desc}
                className={`jb ${k} ${preview === k ? 'on' : ''}`}
                style={{ left: roads[k].at[0], top: roads[k].at[1], visibility: moving ? 'hidden' : 'visible' }}
                onMouseEnter={() => !moving && setHover(k)} onClick={() => select(k)} onDoubleClick={() => go(k)} aria-label={tx(`Route ${k}`, `Rute ${k}`)}
              >
                <Ico name={ROUTE_ICON[k]} />
                <span className={`jb-cap font-game ${roads[k].cap[1] < 0 ? 'up' : 'down'}`}>{k === 'aman' ? tx('SAFE', 'AMAN') : k === 'risiko' ? tx('DANGER', 'BAHAYA') : tx('CHEST', 'PETI')}</span>
              </button>
            ))}
            {moving && <div className="jm-token" style={{ left: tok[0], top: tok[1] }}><span className="jm-token-ring"><TreeArcher /></span></div>}
          </div>
        </div>
      </div>

      <div className="jm-dock">
        <section className={`jm-next ${toBoss ? 'boss' : ''}`} aria-label={tx('Next destination', 'Tujuan berikutnya')} title={tip}>
          <span className="jm-next-ico"><Ico name={KIND[target.kind].icon} /></span>
          <span className="jm-next-name">
            <small className="font-game">{tx(`NEXT · LV ${next}`, `BERIKUTNYA · LV ${next}`)}</small>
            <b className="font-game">{KIND[target.kind].title}</b>
          </span>
          <span className="jm-stats">
            <span className="jm-stat font-game"><Ico name="users" ink={false} />{counts.foot}</span>
            {counts.bats > 0 && <span className="jm-stat font-game"><Ico name="bat" ink={false} />{counts.bats}</span>}
            {range > 1 && <span className="jm-stat warn font-game"><Ico name="crosshair" ink={false} />{range}×</span>}
            <span className="jm-stat gold font-game"><Ico name="coin" ink={false} />+{levelReward(next)}</span>
          </span>
          <span className="jm-boss-in font-game">{toBoss ? tx('BOSS!', 'BOS!') : tx(`BOSS IN ${bossIn}`, `BOS ${bossIn} LAGI`)}</span>
        </section>

        <div className="jm-routes" role="radiogroup" aria-label={tx('Choose route', 'Pilih rute')}>
          {routes.map(({ k, name, desc, danger, stat }, i) => (
            <button
              key={k} type="button" role="radio" aria-checked={sel === k} title={desc} disabled={disabled(k) || (!!moving && moving !== k)}
              className={`jr ${k}`}
              onClick={() => select(k)} onDoubleClick={() => go(k)} onMouseEnter={() => !moving && setHover(k)} onMouseLeave={() => setHover(null)}
            >
              <span className="jr-ico"><Ico name={ROUTE_ICON[k]} /></span>
              <span className="jr-txt">
                <b className="font-game">{name}</b>
                <span className="jr-meta">{stat}{k !== 'peti' && <span className="jr-risk"><em className="font-game">{tx('RISK', 'RISIKO')}</em><Pips n={danger} kind="danger" /></span>}</span>
              </span>
              <kbd className="jr-key font-game" aria-hidden="true">{i + 1}</kbd>
              {sel === k && <span className="jr-check"><Ico name="check" /></span>}
            </button>
          ))}
        </div>

        <button type="button" className={`jm-go font-game ${goTone}`} disabled={!!moving || disabled(sel)} onClick={() => go(sel)}>
          <span>{goLabel}</span><Ico name="arrow" />
        </button>
      </div>
    </div>
  );
}
