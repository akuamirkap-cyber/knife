// "GAME OVER": the title screen's night forest, a big logo, and our own archer lying on his grassy island.
import { ReactNode, useEffect, useState } from 'react';
import MenuScene from './menu/MenuScene';
import DeadArcher from './menu/DeadArcher';
import type { HeadStyle } from './game/ragdoll/head';
import type { BowId } from './game/ragdoll/stick';
import { audioInit, snd } from './game/ragdoll/audio';
import { tx, useLang } from './i18n';
import './gameover.css';

const NAVY = '#0a1a52';
const DEEP = '#050d38';

/** numbers that roll up to their value */
function useRoll(target: number, delay = 900, dur = 900) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let raf = 0; let t0 = 0;
    const id = window.setTimeout(() => {
      const tick = (now: number) => {
        if (!t0) t0 = now;
        const u = Math.min(1, (now - t0) / dur);
        setVal(Math.round(target * (1 - Math.pow(1 - u, 3))));
        if (u < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }, delay);
    return () => { window.clearTimeout(id); cancelAnimationFrame(raf); };
  }, [target, delay, dur]);
  return val;
}

function Arrow({ x, y, deg }: { x: number; y: number; deg: number }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${deg})`} strokeLinejoin="round" strokeLinecap="round">
      <path d="M0 0H128" stroke={NAVY} strokeWidth="13" />
      <path d="M0 0H128" stroke="#d99a4a" strokeWidth="6" />
      <path d="M2 -1.5H126" stroke="#ffd98c" strokeWidth="2" />
      <path d="M118-16L152 0L118 16L126 0Z" fill="#e6eef8" stroke={NAVY} strokeWidth="5" />
      <path d="M-4-4L-24-20H-2L16-4ZM-4 4L-24 20H-2L16 4Z" fill="#ff4a46" stroke={NAVY} strokeWidth="5" />
    </g>
  );
}

function GameOverLogo() {
  const top = { x: 92, y: 166, fontSize: 112, textLength: 376, lengthAdjust: 'spacingAndGlyphs' as const };
  const bot = { x: 56, y: 272, fontSize: 128, textLength: 450, lengthAdjust: 'spacingAndGlyphs' as const };
  const edge = { strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const };
  return (
    <svg viewBox="0 0 560 300" className="go-logo-svg" role="img" aria-label={tx('Game over', 'Permainan selesai')}>
      <defs>
        <linearGradient id="go-a" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" /><stop offset="0.52" stopColor="#ffffff" /><stop offset="0.56" stopColor="#d6ecff" /><stop offset="1" stopColor="#8fc8ff" />
        </linearGradient>
        <linearGradient id="go-b" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff27a" /><stop offset="0.46" stopColor="#ffc928" /><stop offset="0.52" stopColor="#ffa91c" /><stop offset="1" stopColor="#f56f0a" />
        </linearGradient>
        <linearGradient id="go-r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ff6a62" /><stop offset="1" stopColor="#c81e2e" /></linearGradient>
      </defs>
      <g className="go-logo-arrows"><Arrow x={214} y={104} deg={-147} /><Arrow x={346} y={104} deg={-33} /></g>
      {/* the red banner, torn at both ends */}
      <g stroke={NAVY} strokeWidth="7" strokeLinejoin="round">
        <path d="M26 96L214 74V136L26 154L58 125Z" fill="#a8182a" />
        <path d="M534 96L346 74V136L534 154L502 125Z" fill="#a8182a" />
        <path d="M46 84L226 66L238 128L58 146L82 113Z" fill="url(#go-r)" />
        <path d="M514 84L334 66L322 128L502 146L478 113Z" fill="url(#go-r)" />
        <path d="M226 66L238 128L214 136V74Z" fill="#8c1222" />
        <path d="M334 66L322 128L346 136V74Z" fill="#8c1222" />
      </g>
      <g transform="translate(280 52)"><g className="go-logo-skull">
        <path d="M0-36C-27-36-40-17-40 2C-40 15-33 24-25 29V42H25V29C33 24 40 15 40 2C40-17 27-36 0-36Z" fill="#fff" stroke={NAVY} strokeWidth="8" strokeLinejoin="round" />
        <path d="M-9 42V32M0 42V32M9 42V32" stroke={NAVY} strokeWidth="3.5" strokeLinecap="round" />
        <path d="M-21 -2l15 15M-6-2l-15 15M6-2l15 15M21-2L6 13" stroke={NAVY} strokeWidth="6.5" strokeLinecap="round" />
        <path d="M0 14l-5 9h10z" fill={NAVY} />
      </g></g>
      <g transform="rotate(-3 280 170)">
        <g transform="translate(0 11)" fill={DEEP} stroke={DEEP} strokeWidth="25" {...edge}><text {...top}>GAME</text><text {...bot}>OVER</text></g>
        <g fill={NAVY} stroke={NAVY} strokeWidth="21" {...edge}><text {...top}>GAME</text><text {...bot}>OVER</text></g>
        <text {...top} fill="url(#go-a)">GAME</text>
        <text {...bot} fill="url(#go-b)">OVER</text>
      </g>
    </svg>
  );
}

function GrassCap() {
  const n = 26; const W = 780; const step = (W - 24) / n;
  let d = `M0 8Q0 0 14 0H${W - 14}Q${W} 0 ${W} 8V26`;
  for (let i = 0; i < n; i++) { const cx = W - 12 - step * (i + 0.5); d += ` A${step / 2} ${step / 2} 0 0 1 ${cx - step / 2} 26`; }
  d += ' Z';
  return (
    <svg className="go-grass" viewBox="0 0 780 46" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id="go-g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#8cec48" /><stop offset="1" stopColor="#3aaa2f" /></linearGradient></defs>
      <path d={d} transform="translate(0 7)" fill="#2a8c2c" />
      <path d={d} fill="url(#go-g)" />
      <path d="M12 4H768" stroke="#cdff86" strokeOpacity=".8" strokeWidth="4" strokeLinecap="round" />
    </svg>
  );
}

const ico = { viewBox: '0 0 24 24', 'aria-hidden': true } as const;
const HomeIcon = () => (<svg {...ico}><path d="M12 3L2.5 11.5h3V21h5v-6h3v6h5v-9.5h3z" fill="#fff" stroke={NAVY} strokeWidth="1.6" strokeLinejoin="round" /></svg>);
const RetryIcon = () => (<svg {...ico}><path d="M12 4.5a7.5 7.5 0 1 0 7.4 8.8h-3.1A4.6 4.6 0 1 1 12 7.600v3.400l5.500-4.500L12 1.500z" fill="#fff" stroke={NAVY} strokeWidth="1.5" strokeLinejoin="round" /></svg>);
const TreeIcon = () => (
  <svg {...ico}>
    <g fill="none" stroke={NAVY} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 21V10.500M5 5.500v4l7 4 7-4v-4" /></g>
    <g fill="none" stroke="#ffd53e" strokeWidth="2.400" strokeLinecap="round" strokeLinejoin="round"><path d="M12 21V10.500M5 5.500v4l7 4 7-4v-4" /></g>
    <g fill="#ffe680" stroke={NAVY} strokeWidth="1.300"><circle cx="5" cy="4.500" r="2.900" /><circle cx="12" cy="7.500" r="2.900" /><circle cx="19" cy="4.500" r="2.900" /><circle cx="12" cy="20.500" r="2.600" /></g>
  </svg>
);
const Trophy = () => (
  <svg viewBox="0 0 48 48" aria-hidden>
    <path d="M13 9H5c0 9 3 14 9 15M35 9h8c0 9-3 14-9 15" fill="none" stroke={NAVY} strokeWidth="6" strokeLinecap="round" />
    <path d="M13 9H5c0 9 3 14 9 15M35 9h8c0 9-3 14-9 15" fill="none" stroke="#ffc83a" strokeWidth="2.600" strokeLinecap="round" />
    <path d="M12 5h24v11c0 8-5 13-12 13S12 24 12 16z" fill="#ffc83a" stroke={NAVY} strokeWidth="3" strokeLinejoin="round" />
    <path d="M16 8h5v14c-3-2-5-6-5-10z" fill="#fff3a0" />
    <path d="M21 29h6v6h-6z" fill="#e0920c" stroke={NAVY} strokeWidth="2.600" strokeLinejoin="round" />
    <path d="M13 36h22v7H13z" fill="#ffb02e" stroke={NAVY} strokeWidth="3" strokeLinejoin="round" />
  </svg>
);
const SkullIco = () => (
  <svg viewBox="0 0 48 48" aria-hidden>
    <path d="M24 5C14 5 8 12 8 20c0 5 2.500 8.500 6 10.500V40h20v-9.500c3.500-2 6-5.500 6-10.500C40 12 34 5 24 5z" fill="#eaf4ff" stroke={NAVY} strokeWidth="3.200" strokeLinejoin="round" />
    <path d="M15 18l7 7M22 18l-7 7M26 18l7 7M33 18l-7 7" stroke={NAVY} strokeWidth="3.200" strokeLinecap="round" />
    <path d="M19 40v-6M24 40v-6M29 40v-6" stroke={NAVY} strokeWidth="2.400" strokeLinecap="round" />
  </svg>
);
const CoinIco = () => (
  <svg viewBox="0 0 48 48" aria-hidden>
    <circle cx="24" cy="25" r="19" fill="#ffc83a" stroke={NAVY} strokeWidth="3.400" />
    <circle cx="24" cy="25" r="13" fill="none" stroke="#e0920c" strokeWidth="3" />
    <path d="M24 16v18M19 21h8a3.500 3.500 0 0 1 0 7H19" stroke="#b86a00" strokeWidth="3.400" strokeLinecap="round" fill="none" />
    <path d="M13 17c2-5 6-7 10-7" stroke="#fff6c4" strokeWidth="2.600" strokeLinecap="round" fill="none" />
  </svg>
);
const Ghost = () => (
  <svg viewBox="0 0 60 70" aria-hidden>
    <path d="M30 3C15 3 6 14 6 29v34l8-6 8 7 8-7 8 7 8-7 8 6V29C54 14 45 3 30 3z" fill="#fff" fillOpacity=".92" stroke="#cfe6ff" strokeWidth="2" strokeLinejoin="round" />
    <ellipse cx="21" cy="28" rx="4.200" ry="5.600" fill="#0a1a52" /><ellipse cx="39" cy="28" rx="4.200" ry="5.600" fill="#0a1a52" />
    <ellipse cx="30" cy="42" rx="4" ry="5" fill="#0a1a52" />
  </svg>
);

interface Props {
  level: number; kills: number; gold: number; meta: number; killedBy: string; daily?: string;
  skin: HeadStyle; bow: BowId; cards: ReactNode; unlocks?: string;
  onRetry: () => void; onMenu: () => void; onMeta: () => void;
}

export default function GameOverScreen({ level, kills, gold, meta, killedBy, daily, skin, bow, cards, unlocks, onRetry, onMenu, onMeta }: Props) {
  useLang();
  const nLevel = useRoll(level, 1000, 700);
  const nKills = useRoll(kills, 1100, 900);
  const nGold = useRoll(gold, 1200, 1100);
  const nMeta = useRoll(meta, 1500, 900);
  const press = (fn: () => void) => () => { audioInit(); snd.tap(); fn(); };
  return (
    <div className="go-root m-vars g-dead-backdrop">
      <MenuScene bare />
      <div className="go-shade" aria-hidden="true" />
      <div className="go-scroll">
        <div className="go-stack">
          <div className="go-logo"><GameOverLogo /></div>

          <div className="go-island">
            <DeadArcher className="go-archer" skin={skin} bow={bow} />
            <span className="go-ghost" aria-hidden="true"><Ghost /></span>
            <span className="go-smoke s1" aria-hidden="true" /><span className="go-smoke s2" aria-hidden="true" />
            <GrassCap />
            <div className="go-rock">
              <div className="go-plate font-game"><span>{tx('YOU LOST!', 'KAMU KALAH!')}</span></div>
              <div className="go-stats">
                <div className="go-stat"><i><Trophy /></i><span><small className="font-game">{tx('LEVEL', 'LEVEL')}</small><b className="font-game">LV.{nLevel}</b></span></div>
                <div className="go-stat"><i><SkullIco /></i><span><small className="font-game">{tx('KILLS', 'TUMBANG')}</small><b className="font-game">{nKills}</b></span></div>
                <div className="go-stat"><i><CoinIco /></i><span><small className="font-game">{tx('GOLD', 'EMAS')}</small><b className="font-game gold">+{nGold}</b></span></div>
              </div>
              <div className="go-extra">
                <span className="go-killer font-game"><SkullIco />{tx('KILLED BY', 'DIBUNUH OLEH')} <b>{killedBy}</b></span>
                {meta > 0 && <span className="go-meta font-game">+{nMeta} {tx('META COINS', 'KOIN META')}</span>}
                {daily && <span className="go-meta font-game cyan">{tx('DAILY', 'HARIAN')}: {daily}</span>}
              </div>
              {cards}
              {unlocks && <div className="go-unlock font-game">{tx('UNLOCKED', 'TERBUKA')}: {unlocks}</div>}
            </div>
          </div>

          <div className="go-btns">
            <button type="button" className="m-btn m-blue go-btn" onClick={press(onMenu)}><HomeIcon /><span>{tx('HOME', 'MENU')}</span></button>
            <button type="button" className="m-btn m-green go-btn go-retry g-sheen" onClick={press(onRetry)}><RetryIcon /><span>{tx('RETRY', 'ULANG')}</span></button>
            <button type="button" className="m-btn m-gold-btn go-btn" onClick={press(onMeta)}><TreeIcon /><span>{tx('SKILL TREE', 'SKILL TREE')}</span></button>
          </div>
        </div>
      </div>
    </div>
  );
}
