const shapes = {
  bow: <><path d="M10 4c16 4 24 14 24 20S26 40 10 44M10 4v40M7 7l25 34" /><path d="m27 34 7 1-1-7" /></>,
  helm: <><path d="M9 31V20a15 15 0 0 1 30 0v4H17v7h19" /><path d="M12 20h18M23 5l1-4 4 4M15 32v5m7-5v5m7-5v5" /></>,
  target: <><circle cx="24" cy="24" r="17" /><circle cx="24" cy="24" r="9" /><circle cx="24" cy="24" r="2" /><path d="m27 21 13-13m-7 0h7v7" /></>,
};

export type GameSymbolId = keyof typeof shapes;

export function GameSymbol({ kind, className = 'h-5 w-5' }: { kind: GameSymbolId; className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {shapes[kind]}
    </svg>
  );
}