import { WEAPON_MAP, type WeaponDef } from './weapons';
import { drawBullet, IS_LASER, type Bullet, type V } from './bullets';
import { drawGun } from './guns';

export type GameState = 'menu' | 'playing' | 'choice' | 'won' | 'lost';
export type Stage = 'normal' | 'bonus' | 'treasure';
export type TreasureFx = 'speed' | 'double' | 'mini' | 'big';

export interface HudInfo {
  state: GameState;
  time: number;
  progress: number;
  score: number;
  ammo: number;
  mag: number;
  reloading: boolean;
  reloadPct: number;
  weapon: string;
  stars: number;
  shots: number;
  hits: number;
  buffs: { dmg: number; mag: number; speed: number };
  choiceStar: { x: number; y: number } | null;
  aiming: boolean;
  stage: Stage;
  coinTotal: number;
  fxName: string | null;
}

export const GAME_W = 480;
export const GAME_H = 820;
const RCX = 240;
const RCY = 280;
const TAU = Math.PI * 2;
const TIME_LIMIT = 90;
const MUZZLE_Y = 585;
const ROCK_PAD = 224;
const ROCK_SCALE = 2;

interface Cell {
  ring: number;
  poly: V[];
  c: V;
  rMin: number;
  rMax: number;
  hp: number;
  maxHp: number;
  type: 'rock' | 'hard' | 'gold';
  alive: boolean;
  hue: number;
  sat: number;
  light: number;
  cracks: V[][];
  flash: number;
  sprite: HTMLCanvasElement;
  sx: number; sy: number; sw: number; sh: number;
}

interface Particle {
  kind: 'dust' | 'chip' | 'spark' | 'shell' | 'coin' | 'frag' | 'ring' | 'glint' | 'flame' | 'conf' | 'petal';
  x: number; y: number; vx: number; vy: number;
  life: number; max: number; size: number; color: string;
  rot: number; vr: number; poly?: V[]; g: number;
}

interface Beam { x1: number; y1: number; x2: number; y2: number; rgb: string; life: number; max: number; w: number }
interface FText { x: number; y: number; text: string; life: number; color: string; size: number }
interface Star { x: number; y: number; t: number }
interface Burn { cell: Cell; t: number; ticks: number; dmg: number; gap: number }

/* ---------------- Sound ---------------- */
class Sfx {
  ctx: AudioContext | null = null;
  noise: AudioBuffer | null = null;
  ensure() {
    if (!this.ctx) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      const len = Math.floor(this.ctx.sampleRate * 0.6);
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.noise = buf;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }
  burst(dur: number, freq: number, type: BiquadFilterType, vol: number, q = 1, delay = 0) {
    const c = this.ctx;
    if (!c || !this.noise) return;
    const t = c.currentTime + delay;
    const s = c.createBufferSource();
    s.buffer = this.noise;
    const f = c.createBiquadFilter();
    f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f).connect(g).connect(c.destination);
    s.start(t, Math.random() * 0.1);
    s.stop(t + dur);
  }
  tone(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', slide = 0, delay = 0) {
    const c = this.ctx;
    if (!c) return;
    const o = c.createOscillator();
    const g = c.createGain();
    const t = c.currentTime + delay;
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * (1 + slide)), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
  shotFx(k: string) {
    switch (k) {
      case 'thump': this.burst(0.11, 2200, 'lowpass', 0.35); this.tone(140, 0.08, 0.3, 'square', -0.6); break;
      case 'thud': this.tone(65, 0.18, 0.5, 'sine', -0.4); this.burst(0.09, 500, 'lowpass', 0.5); break;
      case 'zip': this.burst(0.08, 3200, 'highpass', 0.22); this.tone(950, 0.06, 0.15, 'sawtooth', -0.5); break;
      case 'crack': this.burst(0.18, 800, 'lowpass', 0.6); this.tone(200, 0.1, 0.2, 'sine', -0.4); break;
      case 'hiss': this.burst(0.3, 2600, 'bandpass', 0.2, 3); break;
      case 'bang': this.burst(0.3, 500, 'lowpass', 0.85); this.tone(70, 0.25, 0.55, 'sine', -0.4); break;
      case 'splat': this.burst(0.12, 900, 'bandpass', 0.4, 1); break;
      case 'whoosh': this.burst(0.18, 1300, 'highpass', 0.3); break;
      case 'pop': this.tone(520, 0.07, 0.3, 'sine', -0.4); this.burst(0.05, 1800, 'bandpass', 0.2, 2); break;
      case 'boing': this.tone(160, 0.22, 0.3, 'sine', 1.4); break;
      case 'quack': this.tone(480, 0.13, 0.32, 'sawtooth', -0.55); this.tone(360, 0.1, 0.2, 'sawtooth', -0.4, 0.08); break;
      case 'note': { const notes = [523, 587, 659, 784, 880]; this.tone(notes[Math.floor(Math.random() * 5)], 0.4, 0.2, 'triangle'); break; }
      case 'zap': this.tone(1400, 0.16, 0.24, 'sawtooth', -0.8); this.burst(0.1, 4200, 'highpass', 0.14); break;
      case 'chime': this.tone(1900, 0.25, 0.14); this.tone(2850, 0.2, 0.08); break;
      case 'boom': this.burst(0.55, 380, 'lowpass', 1); this.tone(48, 0.45, 0.55, 'sine', -0.4); this.burst(0.3, 1100, 'bandpass', 0.4, 1.5, 0.02); break;
    }
  }
  boom() { this.shotFx('boom'); }
  hit() { this.burst(0.05, 2800, 'bandpass', 0.22, 2); }
  crack() { this.burst(0.3, 600, 'lowpass', 0.55); this.tone(70, 0.2, 0.25, 'sine', -0.4); }
  ding() { this.tone(1900, 0.35, 0.08); this.tone(2850, 0.25, 0.05); }
  star() { this.tone(1600, 0.15, 0.15); this.tone(2400, 0.2, 0.12, 'sine', 0, 0.06); this.tone(3200, 0.3, 0.1, 'sine', 0, 0.12); }
  click() { this.tone(900, 0.04, 0.1, 'square'); this.tone(600, 0.05, 0.08, 'square', 0, 0.08); }
  reloadStart() {
    this.tone(500, 0.05, 0.2, 'square', -0.3);
    this.burst(0.16, 1400, 'bandpass', 0.35, 2, 0.05);
    this.tone(300, 0.08, 0.15, 'square', -0.5, 0.12);
  }
  reloadEnd() {
    for (let i = 0; i < 3; i++) this.tone(1300, 0.035, 0.16, 'square', -0.2, i * 0.06);
    this.burst(0.09, 260, 'lowpass', 0.6, 1, 0.18);
    this.tone(80, 0.16, 0.45, 'sine', -0.4, 0.18);
  }
  chime() { this.shotFx('chime'); }
  pop() { this.shotFx('pop'); }
  win() { [523, 659, 784, 1046, 1318].forEach((f, i) => this.tone(f, 0.5, 0.12, 'triangle', 0, i * 0.11)); }
  lose() { [392, 330, 262].forEach((f, i) => this.tone(f, 0.4, 0.12, 'triangle', 0, i * 0.18)); }
}

/* ---------------- Helpers ---------------- */
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
function pointInPoly(p: V, poly: V[]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x, yi = poly[i].y, xj = poly[j].x, yj = poly[j].y;
    if ((yi > p.y) !== (yj > p.y) && p.x < ((xj - xi) * (p.y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
const CONF_COLS = ['#ff5a8a', '#ffd23f', '#5ef2ff', '#9ae86a', '#c06eff', '#ff8a3c'];

function makeCellSprite(cell: Cell) {
  let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
  for (const p of cell.poly) {
    minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
    maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);
  }
  const pad = 6;
  const w = maxX - minX + pad * 2, h = maxY - minY + pad * 2;
  const cv = document.createElement('canvas');
  cv.width = Math.max(2, Math.ceil(w * 2));
  cv.height = Math.max(2, Math.ceil(h * 2));
  const c = cv.getContext('2d')!;
  c.scale(2, 2);
  c.translate(-minX + pad, -minY + pad);
  const path = () => {
    c.beginPath();
    cell.poly.forEach((p, i) => (i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)));
    c.closePath();
  };
  const { c: ctr, rMax } = cell;
  path();
  if (cell.type === 'gold') {
    // rare gem cell — icy cyan crystal (no yellow!)
    const g = c.createRadialGradient(ctr.x - 6, ctr.y - 6, 2, ctr.x, ctr.y, rMax * 1.15);
    g.addColorStop(0, 'hsl(182,90%,64%)');
    g.addColorStop(0.65, 'hsl(186,78%,44%)');
    g.addColorStop(1, 'hsl(190,72%,26%)');
    c.fillStyle = g;
    c.fill();
  } else if (cell.type === 'hard') {
    const g = c.createLinearGradient(ctr.x - rMax, ctr.y - rMax, ctr.x + rMax, ctr.y + rMax);
    g.addColorStop(0, `hsl(226,16%,${cell.light + 9}%)`);
    g.addColorStop(0.5, `hsl(224,13%,${cell.light}%)`);
    g.addColorStop(1, `hsl(228,18%,${cell.light - 9}%)`);
    c.fillStyle = g;
    c.fill();
  } else {
    const g = c.createRadialGradient(ctr.x - rMax * 0.3, ctr.y - rMax * 0.35, 2, ctr.x, ctr.y, rMax * 1.2);
    g.addColorStop(0, `hsl(${cell.hue},${cell.sat}%,${cell.light + 10}%)`);
    g.addColorStop(0.55, `hsl(${cell.hue},${cell.sat}%,${cell.light}%)`);
    g.addColorStop(1, `hsl(${cell.hue + 6},${cell.sat + 3}%,${cell.light - 11}%)`);
    c.fillStyle = g;
    c.fill();
    // soft bottom inner shadow for depth
    const g2 = c.createRadialGradient(ctr.x, ctr.y + rMax * 0.5, 2, ctr.x, ctr.y + rMax * 0.5, rMax * 1.1);
    g2.addColorStop(0, 'rgba(10,16,34,0)');
    g2.addColorStop(1, 'rgba(10,16,34,0.28)');
    c.fillStyle = g2;
    c.fill();
  }
  c.save();
  path(); c.clip();
  for (let i = 0; i < 9; i++) {
    const a = rand(0, TAU), r = rand(0, rMax * 0.85);
    c.fillStyle = `rgba(4,8,20,${rand(0.08, 0.22)})`;
    c.beginPath(); c.arc(ctr.x + Math.cos(a) * r, ctr.y + Math.sin(a) * r, rand(0.8, 2.4), 0, TAU); c.fill();
  }
  for (let i = 0; i < 4; i++) {
    const a = rand(0, TAU), r = rand(0, rMax * 0.8);
    c.fillStyle = 'rgba(220,235,255,0.12)';
    c.beginPath(); c.arc(ctr.x + Math.cos(a) * r, ctr.y + Math.sin(a) * r, rand(0.5, 1.3), 0, TAU); c.fill();
  }
  c.strokeStyle = 'rgba(8,14,30,0.16)';
  c.lineWidth = 1;
  for (let i = 0; i < 2; i++) {
    const p = cell.poly[Math.floor(Math.random() * cell.poly.length)];
    const q = cell.poly[Math.floor(Math.random() * cell.poly.length)];
    c.beginPath();
    c.moveTo(p.x, p.y);
    c.quadraticCurveTo(ctr.x + rand(-8, 8), ctr.y + rand(-8, 8), q.x, q.y);
    c.stroke();
  }
  if (cell.type === 'hard') {
    c.strokeStyle = 'rgba(190,210,235,0.22)';
    c.lineWidth = 1.2;
    for (let i = 0; i < 2; i++) {
      const p = cell.poly[Math.floor(Math.random() * cell.poly.length)];
      c.beginPath(); c.moveTo(ctr.x, ctr.y); c.lineTo(p.x, p.y); c.stroke();
    }
    for (let i = 0; i < 3; i++) {
      const a = rand(0, TAU), r = rand(0, rMax * 0.7);
      c.fillStyle = '#59626f';
      c.beginPath(); c.arc(ctr.x + Math.cos(a) * r, ctr.y + Math.sin(a) * r, 1.6, 0, TAU); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.5)';
      c.beginPath(); c.arc(ctr.x + Math.cos(a) * r - 0.5, ctr.y + Math.sin(a) * r - 0.5, 0.5, 0, TAU); c.fill();
    }
  }
  if (cell.type === 'gold') {
    for (let i = 0; i < 5; i++) {
      const a = rand(0, TAU), r = rand(0, rMax * 0.75);
      const gx = ctr.x + Math.cos(a) * r, gy = ctr.y + Math.sin(a) * r;
      // tiny cyan crystals
      c.fillStyle = 'rgba(190,255,255,0.95)';
      c.beginPath();
      c.moveTo(gx, gy - 2.6); c.lineTo(gx + 1.8, gy); c.lineTo(gx, gy + 2.6); c.lineTo(gx - 1.8, gy);
      c.closePath(); c.fill();
      c.strokeStyle = 'rgba(255,255,255,0.95)';
      c.lineWidth = 0.7;
      c.beginPath(); c.moveTo(gx - 2.8, gy); c.lineTo(gx + 2.8, gy); c.moveTo(gx, gy - 2.8); c.lineTo(gx, gy + 2.8); c.stroke();
    }
  }
  c.restore();
  path();
  c.strokeStyle = cell.type === 'gold' ? 'rgba(190,250,255,0.45)' : 'rgba(225,238,255,0.30)';
  c.lineWidth = 2.6;
  c.stroke();
  path();
  c.strokeStyle = 'rgba(4,8,18,0.8)';
  c.lineWidth = 1.1;
  c.stroke();
  cell.sprite = cv;
  cell.sx = minX - pad;
  cell.sy = minY - pad;
  cell.sw = w;
  cell.sh = h;
}

/* ---------------- Game ---------------- */
export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  onHud: (h: HudInfo) => void;
  sfx = new Sfx();
  cells: Cell[] = [];
  bullets: Bullet[] = [];
  particles: Particle[] = [];
  beams: Beam[] = [];
  texts: FText[] = [];
  burns: Burn[] = [];
  motes: { x: number; y: number; s: number; v: number }[] = [];
  rockCv: HTMLCanvasElement;
  rockCtx: CanvasRenderingContext2D;
  state: GameState = 'menu';
  weapon = 'ak';
  ammo = WEAPON_MAP.ak.mag;
  reloadT = 0;
  fireCd = 0;
  firing = false;
  prevFiring = false;
  holdT = 0;
  timeLeft = TIME_LIMIT;
  score = 0;
  shots = 0;
  hits = 0;
  shake = 0;
  rot = 0;
  rotSpeed = 1;
  targetSpeed = 1.2;
  phaseT = 2;
  recoil = 0;
  flash = 0;
  switchT = 0;
  winT = 0;
  t = 0;
  hudT = 0;
  stars = 0;
  totalCells = 0;
  raf = 0;
  last = 0;
  diamondPing = 0;
  // buffs
  buffs = { dmg: 1, mag: 1, speed: 1 };
  // star & aim
  star: Star | null = null;
  starT = 6;
  aim: { x: number; y: number; t: number } | null = null;
  // time effects
  timeScale = 1;
  warpT = 0;
  rockSlowT = 0;
  slipT = 0;
  // stage
  stage: Stage = 'normal';
  bonusDir = 1;
  coinTotal = 0;
  // treasure
  chestCoins: { dx: number; dy: number; ph: number }[] = [];
  chestShakeT = 0;
  item: { x: number; y: number; vx: number; eff: TreasureFx; t: number } | null = null;
  itemSpawnT = 0;
  treasureFx: TreasureFx | null = null;

  coinPop(n: number) {
    const cnt = Math.min(n, 5);
    for (let i = 0; i < cnt; i++) this.sfx.tone(rand(1400, 2400), 0.09, 0.11, 'triangle', 0, i * 0.05);
  }

  constructor(canvas: HTMLCanvasElement, onHud: (h: HudInfo) => void) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.onHud = onHud;
    this.rockCv = document.createElement('canvas');
    this.rockCv.width = ROCK_PAD * 2 * ROCK_SCALE;
    this.rockCv.height = ROCK_PAD * 2 * ROCK_SCALE;
    this.rockCtx = this.rockCv.getContext('2d')!;
    for (let i = 0; i < 40; i++) this.motes.push({ x: rand(0, GAME_W), y: rand(0, GAME_H), s: rand(0.5, 2), v: rand(5, 20) });
    this.resize();
    this.generateRock();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() { cancelAnimationFrame(this.raf); }
  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = GAME_W * dpr;
    this.canvas.height = GAME_H * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  generateRock() {
    const RINGS = [64, 90, 116, 142, 168, 196];
    const SECT = [8, 12, 16, 24, 32];
    const STEPS = 96;
    const seed = Math.random() * 1000;
    const h = (a: number, b: number, c = 0) => {
      const s = Math.sin(a * 127.1 + b * 311.7 + c * 74.7 + seed) * 43758.5453;
      return s - Math.floor(s);
    };
    const wrap = (k: number) => ((k % STEPS) + STEPS) % STEPS;
    const bp = (i: number, k: number): V => {
      k = wrap(k);
      const th = (k / STEPS) * TAU;
      let r = RINGS[i];
      if (i === 0) r += (h(i, k) - 0.5) * 3;
      else if (i === RINGS.length - 1) r += Math.sin(th * 3 + seed) * 9 + Math.sin(th * 7 + seed * 2) * 5 + (h(i, k) - 0.5) * 12;
      else r += (h(i, k) - 0.5) * 10;
      return { x: Math.cos(th) * r, y: Math.sin(th) * r };
    };
    const rm = (i: number, k: number): V => {
      k = wrap(k);
      const a = bp(i, k), b = bp(i + 1, k);
      const th = (k / STEPS) * TAU;
      const off = (h(i, k, 7) - 0.5) * 9;
      return { x: (a.x + b.x) / 2 - Math.sin(th) * off, y: (a.y + b.y) / 2 + Math.cos(th) * off };
    };
    this.cells = [];
    for (let i = 0; i < SECT.length; i++) {
      const n = SECT[i];
      const per = STEPS / n;
      for (let j = 0; j < n; j++) {
        const k0 = j * per, k1 = k0 + per;
        const poly: V[] = [];
        for (let k = k0; k <= k1; k++) poly.push(bp(i, k));
        poly.push(rm(i, k1));
        for (let k = k1; k >= k0; k--) poly.push(bp(i + 1, k));
        poly.push(rm(i, k0));
        let cx = 0, cy = 0, rMin = 1e9, rMax = 0;
        for (const p of poly) {
          cx += p.x; cy += p.y;
          const r = Math.hypot(p.x, p.y);
          rMin = Math.min(rMin, r); rMax = Math.max(rMax, r);
        }
        cx /= poly.length; cy /= poly.length;
        const roll = Math.random();
        let type: Cell['type'] = 'rock';
        if (i > 0 && i < 4 && roll < 0.13) type = 'hard';
        else if (roll > 0.92) type = 'gold';
        const baseHp = i === 0 ? 3 : i === 4 ? 2 : 2 + (Math.random() < 0.3 ? 1 : 0);
        const hp = type === 'hard' ? 6 : type === 'gold' ? 3 : baseHp;
        const cell: Cell = {
          ring: i, poly, c: { x: cx, y: cy }, rMin, rMax, hp, maxHp: hp, type, alive: true,
          hue: type === 'hard' ? 226 : type === 'gold' ? 186 : rand(205, 232),
          sat: type === 'hard' ? 14 : type === 'gold' ? 55 : rand(8, 16),
          light: type === 'hard' ? rand(27, 33) : type === 'gold' ? 46 : rand(42, 54) - i * 1.5,
          cracks: [], flash: 0,
          sprite: document.createElement('canvas'), sx: 0, sy: 0, sw: 1, sh: 1,
        };
        makeCellSprite(cell);
        this.cells.push(cell);
      }
    }
    this.totalCells = this.cells.length;
  }

  reset() {
    this.bullets = [];
    this.particles = [];
    this.beams = [];
    this.texts = [];
    this.burns = [];
    this.score = 0;
    this.shots = 0;
    this.hits = 0;
    this.coinTotal = 0;
    this.winT = 0;
    this.stars = 0;
    this.buffs = { dmg: 1, mag: 1, speed: 1 };
    this.star = null;
    this.starT = this.stage === 'treasure' ? 1e9 : 6;
    this.aim = null;
    this.warpT = 0;
    this.timeScale = 1;
    this.rockSlowT = 0;
    this.slipT = 0;
    this.treasureFx = null;
    this.item = null;
    this.chestShakeT = 0;
    if (this.stage === 'treasure') {
      this.cells = [];
      this.totalCells = 0;
      this.timeLeft = 10;
      this.itemSpawnT = rand(2.5, 4);
      // build natural coin pile (rows stacking up)
      this.chestCoins = [];
      for (let l = 0; l < 6; l++) {
        const count = 9 - l;
        for (let i = 0; i < count; i++) {
          this.chestCoins.push({
            dx: (i - (count - 1) / 2) * 13 + rand(-3, 3),
            dy: -14 - l * 8.5 + rand(-2, 2),
            ph: rand(0, TAU),
          });
        }
      }
      for (let i = 0; i < 14; i++) {
        this.chestCoins.push({ dx: rand(-42, 42), dy: rand(-62, -46), ph: rand(0, TAU) });
      }
    } else {
      this.generateRock();
      this.timeLeft = TIME_LIMIT;
      this.bonusDir = Math.random() < 0.5 ? -1 : 1;
    }
    this.ammo = Math.ceil(WEAPON_MAP[this.weapon].mag * this.buffs.mag);
    this.reloadT = 0;
    this.fireCd = 0;
    this.switchT = 0.4;
  }

  start(stage?: Stage) {
    this.sfx.ensure();
    if (stage) this.stage = stage;
    this.reset();
    this.state = 'playing';
    this.pushHud();
  }

  toMenu() {
    this.reset();
    this.state = 'menu';
    this.pushHud();
  }

  setWeapon(id: string) {
    if (this.weapon === id || !WEAPON_MAP[id]) return;
    this.sfx.ensure();
    this.weapon = id;
    this.ammo = Math.min(this.ammo + 99, WEAPON_MAP[id].mag * this.buffs.mag);
    this.reloadT = 0;
    this.fireCd = 0.25;
    this.switchT = 0.4;
    this.sfx.click();
    this.pushHud();
  }

  setFiring(f: boolean) {
    if (f) this.sfx.ensure();
    this.firing = f;
    if (!f) this.holdT = 0;
  }

  reload() {
    const d = WEAPON_MAP[this.weapon];
    const maxAmmo = Math.ceil(d.mag * this.buffs.mag);
    if (this.reloadT > 0 || this.ammo === maxAmmo || this.state !== 'playing') return;
    this.reloadT = d.reload;
    this.sfx.reloadStart();
  }

  def(): WeaponDef { return WEAPON_MAP[this.weapon]; }

  muzzlePos() {
    const off = this.switchT > 0 ? (this.switchT / 0.4) * 160 : 0;
    const relOff = this.reloadT > 0 ? 26 : 0;
    return { x: 240, y: MUZZLE_Y + this.recoil + off + relOff };
  }

  aimDir(m: V) {
    if (!this.aim) return 0;
    return Math.atan2(this.aim.x - m.x, -(this.aim.y - m.y));
  }

  spawnBullet(m: V, d: WeaponDef, a: number, size = 1, scl = 1) {
    const sp = d.speed * this.buffs.speed * (this.treasureFx === 'speed' ? 2 : 1);
    const trail =
      ['plasma', 'magnet', 'unicorn', 'ufo', 'galaxy', 'rainbow', 'meteor', 'gold'].includes(d.arch) ? 12 :
      d.arch === 'yoyo' || d.arch === 'harpoon' ? 0 : 0;
    const life =
      d.arch === 'flame' ? 0.45 :
      d.arch === 'rocket' || d.arch === 'bigrocket' ? 4 :
      d.arch === 'meteor' ? 5 :
      d.arch === 'plasma' || d.arch === 'magnet' || d.arch === 'unicorn' ? 3 :
      d.arch === 'yoyo' ? 2.2 : 2.5;
    this.bullets.push({
      x: m.x + Math.sin(a) * 16, y: m.y - Math.cos(a) * 16,
      vx: Math.sin(a) * sp, vy: -Math.cos(a) * sp,
      arch: d.arch, rgb: d.color,
      dmg: d.dmg * this.buffs.dmg * (this.treasureFx === 'big' ? 1.5 : 1),
      splash: d.splash, splashDmg: d.splashDmg * this.buffs.dmg,
      trail: [], maxTrail: trail,
      life, rot: rand(0, TAU), spinSpd: d.spin ?? 0,
      pierce: d.pierce ?? 0, bounce: d.bounce ?? 0, grav: d.grav ?? 0,
      homing: d.homing ?? 0, size, wobble: rand(0, TAU),
      fx: d.fx, ox: m.x, oy: m.y, scl,
    });
  }

  meteorRain() {
    for (let i = 0; i < 3; i++) {
      this.bullets.push({
        x: rand(60, 420), y: -20 - i * 40,
        vx: rand(-80, 80), vy: rand(380, 520),
        arch: 'meteor', rgb: '255,140,70',
        dmg: 2 * this.buffs.dmg, splash: 30, splashDmg: 1 * this.buffs.dmg,
        trail: [], maxTrail: 10, life: 5, rot: rand(0, TAU), spinSpd: 3,
        pierce: 0, bounce: 0, grav: 0.25, homing: 0, size: 1, wobble: rand(0, TAU), fx: 'none',
        ox: 0, oy: 0,
      });
    }
  }

  fire() {
    const d = this.def();
    const m = this.muzzlePos();
    const a = this.aimDir(m);
    if (this.ammo < 1) { this.reload(); return; }
    this.ammo -= 1;
    this.shots += d.pellets ?? 1;
    this.recoil = d.recoil;
    this.flash = d.fx === 'silence' ? 0.3 : 1;

    if (IS_LASER(d.arch)) {
      this.castLaser(m, a, d);
    } else {
      const fx = this.treasureFx;
      const scl = fx === 'mini' ? 0.5 : fx === 'big' ? 2 : 1;
      const n = (d.pellets ?? 1) * (fx === 'double' ? 2 : 1);
      for (let i = 0; i < n; i++) {
        const off = n > 1 ? (i - (n - 1) / 2) * 0.085 + rand(-0.02, 0.02) : 0;
        let size = 1;
        let dmgMult = 1;
        if (d.arch === 'charge') {
          size = 1 + 2 * Math.min(1, this.holdT / 1.2);
          dmgMult = 1 + 1.5 * Math.min(1, this.holdT / 1.2);
        }
        this.spawnBullet(m, d, a + off, size, scl);
        if (d.arch === 'charge') {
          const last = this.bullets[this.bullets.length - 1];
          if (last) last.dmg *= dmgMult;
        }
      }
    }

    // muzzle fx
    if (d.sfx === 'bang' || d.gun === 'cannon' || d.gun === 'bigcannon' || d.gun === 'rocketpod') {
      this.particles.push({
        kind: 'dust', x: m.x, y: m.y - 8, vx: 0, vy: -30, life: 0.35, max: 0.35, size: 26, color: 'rgba(255,170,90,', rot: 0, vr: 0, g: -60,
      });
    }
    if (d.arch === 'flame') {
      for (let i = 0; i < 3; i++) {
        this.particles.push({
          kind: 'flame', x: m.x + rand(-5, 5), y: m.y - rand(0, 14), vx: rand(-30, 30), vy: rand(40, 140),
          life: rand(0.15, 0.3), max: 0.3, size: rand(4, 9), color: `rgba(255,${120 + Math.floor(rand(0, 100))},40,`, rot: 0, vr: 0, g: -100,
        });
      }
    }
    if (d.gun !== 'wand' && d.gun !== 'bow' && d.gun !== 'slingshot' && d.gun !== 'crossbow' && d.arch !== 'flame' && d.arch !== 'confetti') {
      this.particles.push({
        kind: 'shell', x: m.x - 5, y: m.y + 60,
        vx: rand(-220, -120), vy: rand(-300, -180), life: 1.2, max: 1.2,
        size: 3, color: '#d9b04a', rot: rand(0, TAU), vr: rand(-20, 20), g: 900,
      });
    }
    if (d.fx === 'confetti') this.confettiBurst(m.x, m.y - 20, 10);
    if (d.fx === 'meteor') this.meteorRain();

    this.shake = Math.min(16, this.shake + d.shake);
    this.sfx.shotFx(d.sfx);
    if (d.arch === 'charge') this.holdT = 0;
    if (this.ammo <= 0) { this.reloadT = d.reload; this.sfx.reloadStart(); }
  }

  castLaser(m: V, a: number, d: WeaponDef) {
    if (this.stage === 'treasure') {
      let end: V = { x: m.x + Math.sin(a) * 780, y: m.y - Math.cos(a) * 780 };
      let hit = false;
      for (let dist = 20; dist < 780; dist += 5) {
        const px = m.x + Math.sin(a) * dist;
        const py = m.y - Math.cos(a) * dist;
        if (px > 158 && px < 322 && py > 258 && py < 402) {
          end = { x: px, y: py };
          this.onChestHit(px, py, d.dmg * this.buffs.dmg * (this.treasureFx === 'big' ? 1.5 : 1));
          hit = true;
          break;
        }
      }
      this.beams.push({ x1: m.x + Math.sin(a) * 14, y1: m.y - Math.cos(a) * 14, x2: end.x, y2: end.y, rgb: d.color, life: 0.18, max: 0.18, w: 5 });
      this.shake = Math.min(14, this.shake + (hit ? 5 : 2));
      return;
    }
    let px = m.x + Math.sin(a) * 20, py = m.y - Math.cos(a) * 20;
    let end: V = { x: m.x + Math.sin(a) * 750, y: m.y - Math.cos(a) * 750 };
    let hitsLeft = (d.pierce ?? 0) + 1;
    const mult = d.fx === 'doubleScore' ? 2 : 1;
    outer:
    for (let dist = 20; dist < 780; dist += 5) {
      px = m.x + Math.sin(a) * dist;
      py = m.y - Math.cos(a) * dist;
      for (const c of this.cells) {
        if (!c.alive) continue;
        const lp = this.toLocal(px, py);
        const r = Math.hypot(lp.x, lp.y);
        if (r > 215 || r < c.rMin - 1 || r > c.rMax + 1) continue;
        if (pointInPoly(lp, c.poly)) {
          end = { x: px, y: py };
          this.hits++;
          this.sfx.hit();
          this.damageCell(c, d.dmg * this.buffs.dmg, lp, mult);
          this.laserImpact(px, py, c, d);
          hitsLeft--;
          if (hitsLeft <= 0) break outer;
          break;
        }
      }
    }
    this.beams.push({ x1: m.x + Math.sin(a) * 14, y1: m.y - Math.cos(a) * 14, x2: end.x, y2: end.y, rgb: d.color, life: 0.18, max: 0.18, w: d.arch === 'laser' ? 5 : 3 });
    this.shake = Math.min(14, this.shake + 4);
  }

  laserImpact(x: number, y: number, c: Cell, d: WeaponDef) {
    for (let i = 0; i < 8; i++) {
      this.particles.push({
        kind: 'spark', x, y, vx: rand(-200, 200), vy: rand(20, 240),
        life: rand(0.15, 0.3), max: 0.3, size: 2, color: `rgb(${d.color})`, rot: 0, vr: 0, g: 0,
      });
    }
    this.particles.push({
      kind: 'chip', x, y, vx: rand(-100, 100), vy: rand(60, 200),
      life: 0.5, max: 0.5, size: 2.5, color: `hsl(${c.hue},${c.sat}%,${c.light + 10}%)`, rot: 0, vr: 0, g: 800,
    });
  }

  toLocal(x: number, y: number): V {
    const dx = x - RCX, dy = y - RCY;
    const c = Math.cos(-this.rot), s = Math.sin(-this.rot);
    return { x: dx * c - dy * s, y: dx * s + dy * c };
  }
  toWorld(p: V): V {
    const c = Math.cos(this.rot), s = Math.sin(this.rot);
    return { x: RCX + p.x * c - p.y * s, y: RCY + p.x * s + p.y * c };
  }

  addCrack(cell: Cell, p: V) {
    if (cell.cracks.length > 10) return;
    const n = 2 + Math.floor(Math.random() * 2);
    for (let i = 0; i < n; i++) {
      const line: V[] = [{ ...p }];
      let a = rand(0, TAU);
      let cur = { ...p };
      const segs = 3 + Math.floor(Math.random() * 2);
      for (let s = 0; s < segs; s++) {
        a += rand(-0.7, 0.7);
        const len = rand(5, 11);
        cur = { x: cur.x + Math.cos(a) * len, y: cur.y + Math.sin(a) * len };
        line.push(cur);
      }
      cell.cracks.push(line);
    }
  }

  damageCell(cell: Cell, dmg: number, local: V, mult = 1) {
    if (!cell.alive) return;
    cell.hp -= dmg;
    cell.flash = 1;
    this.addCrack(cell, local);
    if (cell.hp <= 0) this.breakCell(cell, mult);
  }

  addBurn(cell: Cell, ticks: number, dmg: number, gap: number) {
    for (let i = 0; i < ticks; i++) this.burns.push({ cell, t: (i + 1) * gap, ticks: 1, dmg, gap });
  }

  confettiBurst(x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      this.particles.push({
        kind: 'conf', x, y,
        vx: rand(-200, 200), vy: rand(-320, -60),
        life: rand(0.8, 1.6), max: 1.6, size: rand(3, 5),
        color: CONF_COLS[Math.floor(Math.random() * CONF_COLS.length)],
        rot: rand(0, TAU), vr: rand(-14, 14), g: 500,
      });
    }
  }

  petalRain(n: number) {
    for (let i = 0; i < n; i++) {
      this.particles.push({
        kind: 'petal', x: rand(20, GAME_W - 20), y: rand(-60, 10),
        vx: rand(-40, 40), vy: rand(60, 140),
        life: rand(1.5, 3), max: 3, size: rand(4, 7), color: '#ffb8d0',
        rot: rand(0, TAU), vr: rand(-3, 3), g: 30,
      });
    }
  }

  explosion(x: number, y: number, radius: number, dmg: number) {
    this.sfx.boom();
    this.shake = Math.min(20, this.shake + 13);
    this.particles.push({ kind: 'ring', x, y, vx: 0, vy: 0, life: 0.4, max: 0.4, size: radius * 1.2, color: 'rgba(255,230,180,0.9)', rot: 0, vr: 0, g: 0 });
    this.particles.push({ kind: 'dust', x, y, vx: 0, vy: 0, life: 0.18, max: 0.18, size: radius, color: 'rgba(255,220,150,', rot: 0, vr: 0, g: 0 });
    for (let i = 0; i < 16; i++) {
      const a = rand(0, TAU), sp = rand(120, 420);
      this.particles.push({
        kind: 'flame', x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life: rand(0.25, 0.5), max: 0.5, size: rand(6, 14), color: `rgba(255,${130 + Math.floor(rand(0, 120))},50,`, rot: 0, vr: 0, g: -80,
      });
    }
    for (let i = 0; i < 10; i++) {
      const a = rand(0, TAU), sp = rand(40, 160);
      this.particles.push({
        kind: 'dust', x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life: rand(0.8, 1.4), max: 1.4, size: rand(10, 20), color: 'rgba(120,110,110,', rot: 0, vr: 0, g: -10,
      });
    }
    for (const c of this.cells) {
      if (!c.alive) continue;
      const wc = this.toWorld(c.c);
      if (Math.hypot(wc.x - x, wc.y - y) < radius + 14) this.damageCell(c, dmg, this.toLocal(wc.x, wc.y));
    }
  }

  fireworkBurst(x: number, y: number, color: string) {
    const base = parseInt(color, 10) % 360;
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * TAU + rand(-0.1, 0.1);
      const sp = rand(140, 320);
      this.particles.push({
        kind: 'conf', x, y,
        vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life: rand(0.7, 1.4), max: 1.4, size: rand(2.5, 4),
        color: `hsl(${(base + i * 14) % 360},90%,65%)`,
        rot: a, vr: rand(-6, 6), g: 260,
      });
    }
  }

  breakCell(cell: Cell, mult = 1) {
    cell.alive = false;
    const wc = this.toWorld(cell.c);
    const out = { x: wc.x - RCX, y: wc.y - RCY };
    const ol = Math.hypot(out.x, out.y) || 1;
    out.x /= ol; out.y /= ol;
    const tan = { x: -out.y * this.rotSpeed * ol, y: out.x * this.rotSpeed * ol };
    const col = (dl: number) => `hsl(${cell.hue},${cell.sat}%,${cell.light + dl}%)`;
    const nFrag = 4 + Math.floor(Math.random() * 3);
    for (let i = 0; i < nFrag; i++) {
      const vtx = cell.poly[Math.floor(Math.random() * cell.poly.length)];
      const f = rand(0.1, 0.6);
      const lp = { x: cell.c.x + (vtx.x - cell.c.x) * f, y: cell.c.y + (vtx.y - cell.c.y) * f };
      const wp = this.toWorld(lp);
      const sz = rand(5, 13);
      const pts = 5 + Math.floor(Math.random() * 3);
      const poly: V[] = [];
      for (let k = 0; k < pts; k++) {
        const a = (k / pts) * TAU + rand(-0.3, 0.3);
        const r = sz * rand(0.55, 1);
        poly.push({ x: Math.cos(a) * r, y: Math.sin(a) * r });
      }
      const sp = rand(120, 360);
      this.particles.push({
        kind: 'frag', x: wp.x, y: wp.y,
        vx: out.x * sp + tan.x * 0.6 + rand(-60, 60), vy: out.y * sp + tan.y * 0.6 + rand(-120, 30),
        life: rand(1.2, 2), max: 2, size: sz, color: col(rand(-6, 6)), rot: rand(0, TAU), vr: rand(-10, 10), poly, g: 1100,
      });
    }
    for (let i = 0; i < 10; i++) {
      this.particles.push({
        kind: 'chip', x: wc.x + rand(-8, 8), y: wc.y + rand(-8, 8),
        vx: out.x * rand(80, 300) + rand(-100, 100), vy: out.y * rand(80, 300) + rand(-150, 50),
        life: rand(0.6, 1.2), max: 1.2, size: rand(1.5, 3.5), color: col(rand(-10, 10)), rot: 0, vr: 0, g: 900,
      });
    }
    for (let i = 0; i < 8; i++) {
      this.particles.push({
        kind: 'dust', x: wc.x + rand(-14, 14), y: wc.y + rand(-14, 14),
        vx: out.x * rand(20, 80) + rand(-30, 30), vy: out.y * rand(20, 80) + rand(-30, 30),
        life: rand(0.6, 1.2), max: 1.2, size: rand(8, 18), color: 'rgba(150,170,205,', rot: 0, vr: 0, g: -15,
      });
    }
    let pts = 10;
    if (cell.type === 'hard') pts = 30;
    if (cell.type === 'gold') {
      pts = 60;
      for (let i = 0; i < 8; i++) {
        this.particles.push({
          kind: 'coin', x: wc.x, y: wc.y, vx: rand(-160, 160), vy: rand(-380, -160),
          life: 1.4, max: 1.4, size: rand(3, 5), color: '#ffd23f', rot: rand(0, TAU), vr: rand(-15, 15), g: 900,
        });
      }
    }
    // bonus stage: coins drop from every side, evenly
    if (this.stage === 'bonus') {
      const cn = 2 + Math.floor(Math.random() * 3);
      this.coinTotal += cn;
      for (let i = 0; i < cn; i++) {
        this.particles.push({
          kind: 'coin', x: wc.x + rand(-10, 10), y: wc.y + rand(-10, 10),
          vx: out.x * rand(120, 260) + rand(-80, 80), vy: out.y * rand(120, 260) + rand(-180, -60),
          life: 1.5, max: 1.5, size: rand(3, 5), color: '#ffd23f', rot: rand(0, TAU), vr: rand(-16, 16), g: 900,
        });
      }
      this.coinPop(cn);
    }
    pts *= mult;
    this.texts.push({ x: wc.x, y: wc.y, text: cell.type === 'gold' ? `+${pts} GEM!` : `+${pts}`, life: 0.8, color: cell.type === 'gold' ? '#7df9ff' : '#e8f2ff', size: cell.type === 'gold' ? 22 : 15 });
    this.score += pts;
    this.shake = Math.min(16, this.shake + 3);
    this.sfx.crack();

    if (this.cells.every((c) => !c.alive) && this.state === 'playing') this.win();
  }

  win() {
    this.state = 'won';
    this.winT = 0;
    if (this.stage === 'treasure') {
      this.stars = this.coinTotal > 120 ? 3 : this.coinTotal > 60 ? 2 : 1;
      this.texts.push({ x: RCX, y: 220, text: '💰 HARTA KARUN SELESAI!', life: 2.2, color: '#ffd23f', size: 28 });
      if (this.coinTotal > 100) this.confettiBurst(RCX, 260, 40);
    } else {
      const used = TIME_LIMIT - this.timeLeft;
      this.stars = used < 35 ? 3 : used < 60 ? 2 : 1;
      this.score += Math.round(this.timeLeft) * 20;
      this.texts.push({ x: RCX, y: RCY - 110, text: 'DIAMOND BERSIH!', life: 2.2, color: '#7df9ff', size: 30 });
    }
    this.firing = false;
    this.bullets = [];
    this.sfx.win();
    this.pushHud();
  }

  lose() {
    this.state = 'lost';
    this.firing = false;
    this.sfx.lose();
    this.pushHud();
  }

  /* ----- star ----- */
  spawnStar() {
    for (let i = 0; i < 24; i++) {
      const x = rand(50, GAME_W - 50), y = rand(60, 200);
      if (Math.hypot(x - RCX, y - RCY) > 245) { this.star = { x, y, t: 12 }; return; }
    }
    this.star = { x: 70, y: 90, t: 12 };
  }

  triggerStar() {
    if (!this.star || this.state !== 'playing') return;
    this.state = 'choice';
    this.sfx.star();
    this.pushHud();
  }

  pickStar(k: 0 | 1 | 2) {
    if (this.state !== 'choice' || !this.star) return;
    if (k === 0) this.buffs.speed = Math.min(8, this.buffs.speed * 2);
    if (k === 1) {
      this.buffs.mag = Math.min(8, this.buffs.mag * 2);
      this.ammo = Math.ceil(WEAPON_MAP[this.weapon].mag * this.buffs.mag);
    }
    if (k === 2) this.buffs.dmg = Math.min(8, this.buffs.dmg * 2);
    this.aim = { x: this.star.x, y: this.star.y, t: 6 };
    this.texts.push({
      x: this.star.x, y: this.star.y,
      text: k === 0 ? 'PELURU 2×!' : k === 1 ? 'AMUNISI 2×!' : 'DAYA 2×!',
      life: 1.6, color: '#ffd23f', size: 24,
    });
    this.confettiBurst(this.star.x, this.star.y, 16);
    this.star = null;
    this.starT = rand(13, 20);
    this.state = 'playing';
    this.sfx.chime();
    this.pushHud();
  }

  pointerTap(gx: number, gy: number) {
    if (this.star && this.state === 'playing' && Math.hypot(gx - this.star.x, gy - this.star.y) < 30) {
      this.triggerStar();
      return;
    }
    if (this.stage === 'treasure' && this.item && this.state === 'playing' && Math.hypot(gx - this.item.x, gy - this.item.y) < 38) {
      this.applyItemFx(this.item);
    }
  }

  onChestHit(x: number, y: number, dmg: number) {
    this.hits++;
    // bigger damage = more coins per hit (Obliterator → 4-5 coin dll)
    const n = clamp(Math.round(dmg * 0.55), 1, 9);
    this.coinTotal += n;
    this.score += n * 10;
    this.chestShakeT = 0.3;
    for (let i = 0; i < n; i++) {
      this.particles.push({
        kind: 'coin',
        x: 240 + rand(-45, 45), y: 340 + rand(-38, -8),
        vx: rand(-190, 190), vy: rand(-440, -200),
        life: rand(1.3, 1.8), max: 1.8, size: rand(4, 6),
        color: '#ffd23f', rot: rand(0, TAU), vr: rand(-14, 14), g: 950,
      });
    }
    this.particles.push({
      kind: 'ring', x, y, vx: 0, vy: 0, life: 0.22, max: 0.22, size: 30,
      color: 'rgba(255,215,90,0.9)', rot: 0, vr: 0, g: 0,
    });
    for (let i = 0; i < 6; i++) {
      this.particles.push({
        kind: 'glint', x: x + rand(-14, 14), y: y + rand(-14, 14),
        vx: rand(-160, 160), vy: rand(-120, 60),
        life: rand(0.25, 0.5), max: 0.5, size: rand(2, 4), color: '#fff3c0', rot: 0, vr: 0, g: 300,
      });
    }
    const label = n >= 6 ? `+${n} JACKPOT!` : `+${n}`;
    this.texts.push({ x, y: y - 16, text: label, life: 0.8, color: '#ffd23f', size: n >= 6 ? 24 : 17 });
    this.coinPop(n);
  }

  applyItemFx(item: { x: number; y: number; eff: TreasureFx }) {
    this.treasureFx = item.eff;
    this.item = null;
    const name = { speed: '⚡ SPEED 2×!', double: '✌️ DOUBLE SHOT!', mini: '🔻 MINI • CEKATAN CEPAT!', big: '🔺 PELURU 2×!' }[item.eff];
    this.texts.push({ x: clamp(item.x, 90, GAME_W - 90), y: item.y, text: name, life: 1.6, color: '#8df0ff', size: 22 });
    this.confettiBurst(item.x, item.y, 18);
    this.sfx.star();
    this.pushHud();
  }

  hitBullet(b: Bullet): boolean {
    // treasure: bonus item & chest
    if (this.stage === 'treasure') {
      if (this.item && Math.hypot(b.x - this.item.x, b.y - this.item.y) < 32) {
        this.applyItemFx(this.item);
        return true;
      }
      if (b.x > 158 && b.x < 322 && b.y > 258 && b.y < 402) {
        this.onChestHit(b.x, b.y, b.dmg);
        return true;
      }
      return false;
    }
    // star first
    if (this.star && this.state === 'playing' && Math.hypot(b.x - this.star.x, b.y - this.star.y) < 18) {
      this.bullets.splice(this.bullets.indexOf(b), 1);
      this.triggerStar();
      return true;
    }
    const lp = this.toLocal(b.x, b.y);
    const r = Math.hypot(lp.x, lp.y);
    if (r > 215) return false;
    for (const c of this.cells) {
      if (!c.alive || r < c.rMin - 1 || r > c.rMax + 1) continue;
      if (pointInPoly(lp, c.poly)) {
        this.hits++;
        this.sfx.hit();
        const mult = b.fx === 'doubleScore' ? 2 : 1;
        if (b.arch === 'rocket' || b.arch === 'bigrocket' || b.arch === 'oblit' || b.arch === 'blackhole') {
          this.explosion(b.x, b.y, b.splash, b.dmg);
        } else {
          this.damageCell(c, b.dmg, lp, mult);
          if (b.splash > 0) {
            for (const o of this.cells) {
              if (o === c || !o.alive) continue;
              const d = Math.hypot(o.c.x - lp.x, o.c.y - lp.y);
              if (d < b.splash) this.damageCell(o, b.splashDmg, { x: o.c.x + (lp.x - o.c.x) * 0.4, y: o.c.y + (lp.y - o.c.y) * 0.4 });
            }
          }
        }
        // impact fx
        const col = `hsl(${c.hue},${c.sat}%,${c.light + 10}%)`;
        for (let i = 0; i < 5; i++) {
          this.particles.push({
            kind: 'chip', x: b.x, y: b.y, vx: rand(-180, 180), vy: rand(60, 260),
            life: rand(0.4, 0.8), max: 0.8, size: rand(1.5, 3), color: col, rot: 0, vr: 0, g: 800,
          });
        }
        this.particles.push({
          kind: 'dust', x: b.x, y: b.y + 4, vx: rand(-20, 20), vy: rand(20, 60),
          life: 0.5, max: 0.5, size: 12, color: 'rgba(160,180,215,', rot: 0, vr: 0, g: 0,
        });
        if (!['rocket', 'bigrocket', 'oblit', 'blackhole'].includes(b.arch)) {
          this.particles.push({
            kind: 'ring', x: b.x, y: b.y, vx: 0, vy: 0, life: 0.18, max: 0.18, size: 16,
            color: `rgba(${b.rgb},0.7)`, rot: 0, vr: 0, g: 0,
          });
        }
        switch (b.fx) {
          case 'coins':
            for (let i = 0; i < 3; i++) this.particles.push({
              kind: 'coin', x: b.x, y: b.y, vx: rand(-140, 140), vy: rand(-320, -140),
              life: 1.2, max: 1.2, size: rand(2.5, 4), color: '#ffd23f', rot: rand(0, TAU), vr: rand(-12, 12), g: 900,
            });
            this.score += 15;
            this.texts.push({ x: b.x, y: b.y - 10, text: '+15', life: 0.7, color: '#ffd23f', size: 14 });
            break;
          case 'slow': this.rockSlowT = 3; break;
          case 'warp': this.warpT = 0.9; break;
          case 'burn': this.addBurn(c, 3, 0.5, 0.35); break;
          case 'corrode': this.addBurn(c, 4, 0.75, 0.3); break;
          case 'confetti': this.confettiBurst(b.x, b.y, 18); this.score += 10; break;
          case 'note': this.sfx.shotFx('note'); break;
          case 'quack': this.sfx.shotFx('quack'); this.texts.push({ x: b.x, y: b.y - 14, text: 'KWEK!', life: 0.8, color: '#ffe89a', size: 16 }); break;
          case 'slip': this.slipT = 1.5; this.texts.push({ x: b.x, y: b.y - 14, text: 'GLISS!', life: 0.8, color: '#fff06a', size: 16 }); break;
          case 'petals': this.petalRain(12); break;
          case 'teleport': {
            const alive = this.cells.filter((cc) => cc.alive);
            if (alive.length) {
              const target = alive[Math.floor(Math.random() * alive.length)];
              const tp = this.toWorld(target.c);
              this.beams.push({ x1: b.x, y1: b.y, x2: tp.x, y2: tp.y, rgb: b.rgb, life: 0.25, max: 0.25, w: 3 });
              this.damageCell(target, b.dmg, this.toLocal(tp.x, tp.y), mult);
            }
            break;
          }
          case 'suck':
            for (let i = 0; i < 5; i++) this.particles.push({
              kind: 'coin', x: b.x + rand(-30, 30), y: b.y + rand(-30, 30), vx: rand(-60, 60), vy: rand(-200, -80),
              life: 1, max: 1, size: rand(2, 3.5), color: '#ffd23f', rot: rand(0, TAU), vr: 10, g: 700,
            });
            this.score += 20;
            break;
          case 'blast': this.explosion(b.x, b.y, 60, 1.5 * this.buffs.dmg); break;
          case 'silence': break;
        }
        if (b.arch === 'firework') { this.fireworkBurst(b.x, b.y, b.rgb); this.sfx.shotFx('bang'); }
        if (b.arch === 'bubble') {
          this.particles.push({ kind: 'ring', x: b.x, y: b.y, vx: 0, vy: 0, life: 0.25, max: 0.25, size: 18, color: 'rgba(170,220,255,0.8)', rot: 0, vr: 0, g: 0 });
        }
        if (b.arch === 'rainbow' || b.arch === 'unicorn') this.petalRain(3);
        if (b.pierce > 0) {
          b.pierce--;
          b.dmg *= 0.6;
          this.particles.push({ kind: 'ring', x: b.x, y: b.y, vx: 0, vy: 0, life: 0.15, max: 0.15, size: 14, color: `rgba(${b.rgb},0.8)`, rot: 0, vr: 0, g: 0 });
          return false; // continue flying
        }
        return true;
      }
    }
    if (r < 54) {
      this.diamondPing = 1;
      this.sfx.ding();
      for (let i = 0; i < 8; i++) {
        this.particles.push({
          kind: 'glint', x: b.x, y: b.y, vx: rand(-200, 200), vy: rand(-50, 250),
          life: rand(0.3, 0.6), max: 0.6, size: rand(2, 4), color: '#bff8ff', rot: 0, vr: 0, g: 300,
        });
      }
      return true;
    }
    return false;
  }

  pushHud() {
    const d = WEAPON_MAP[this.weapon];
    const alive = this.cells.filter((c) => c.alive).length;
    this.onHud({
      state: this.state,
      time: this.timeLeft,
      progress: 1 - alive / Math.max(1, this.totalCells),
      score: this.score,
      ammo: this.ammo,
      mag: Math.ceil(d.mag * this.buffs.mag),
      reloading: this.reloadT > 0,
      reloadPct: this.reloadT > 0 ? 1 - this.reloadT / d.reload : 0,
      weapon: this.weapon,
      stars: this.stars,
      shots: this.shots,
      hits: this.hits,
      buffs: { ...this.buffs },
      choiceStar: this.state === 'choice' && this.star ? { x: this.star.x, y: this.star.y } : null,
      aiming: !!this.aim,
      stage: this.stage,
      coinTotal: this.coinTotal,
      fxName: this.treasureFx ? { speed: '⚡ SPEED 2×', double: '✌️ DOUBLE SHOT', mini: '🔻 MINI • CEPAT', big: '🔺 PELURU 2×' }[this.treasureFx] : null,
    });
  }

  loop = (now: number) => {
    const dt = Math.min(0.033, (now - this.last) / 1000);
    this.last = now;
    this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  };

  update(dt: number) {
    this.t += dt;
    const d = this.def();

    // time warp (sniper/chrono slow-mo)
    this.warpT = Math.max(0, this.warpT - dt);
    const targetScale = this.warpT > 0 ? 0.3 : 1;
    this.timeScale += (targetScale - this.timeScale) * Math.min(1, dt * 12);
    const dtw = dt * this.timeScale;

    // rock rotation
    if (this.stage === 'normal') {
      this.phaseT -= dtw;
      if (this.phaseT <= 0) {
        this.phaseT = rand(1.4, 3.6);
        const cur = Math.sign(this.targetSpeed) || 1;
        const dir = Math.random() < 0.38 ? -cur : cur;
        this.targetSpeed = dir * rand(0.7, 2.8);
        if (Math.random() < 0.12) this.targetSpeed = dir * 0.2;
      }
    } else if (this.stage === 'bonus') {
      this.targetSpeed = this.bonusDir * 0.9; // nyaman, satu arah saja
    }
    let spd = this.targetSpeed;
    if (this.rockSlowT > 0) { this.rockSlowT -= dt; spd *= 0.35; }
    if (this.slipT > 0) { this.slipT -= dt; spd *= -1; }
    const tgt = this.state === 'won' ? 0.4 : spd;
    this.rotSpeed += (tgt - this.rotSpeed) * Math.min(1, dtw * 2.2);
    this.rot += this.rotSpeed * dtw;

    if (this.switchT > 0) this.switchT = Math.max(0, this.switchT - dt);
    this.recoil += (0 - this.recoil) * Math.min(1, dt * 14);
    this.flash = Math.max(0, this.flash - dt * 14);
    this.shake = Math.max(0, this.shake - dt * 40);
    this.diamondPing = Math.max(0, this.diamondPing - dt * 3);
    if (this.aim) { this.aim.t -= dt; if (this.aim.t <= 0) this.aim = null; }

    const playing = this.state === 'playing';

    if (playing) {
      this.timeLeft -= dtw;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        if (this.stage === 'treasure') this.win();
        else this.lose();
      }
      // treasure: floating bonus item (only ONE per stage)
      if (this.stage === 'treasure') {
        this.chestShakeT = Math.max(0, this.chestShakeT - dt);
        if (!this.item) {
          this.itemSpawnT -= dt;
          if (this.itemSpawnT <= 0) {
            const fromLeft = Math.random() < 0.5;
            const effs: TreasureFx[] = ['speed', 'double', 'mini', 'big'];
            this.item = {
              x: fromLeft ? -50 : GAME_W + 50,
              y: rand(130, 240),
              vx: (fromLeft ? 1 : -1) * rand(55, 85),
              eff: effs[Math.floor(Math.random() * effs.length)],
              t: 0,
            };
          }
        } else {
          this.item.x += this.item.vx * dt;
          this.item.t += dt;
          if (this.item.x < -70 || this.item.x > GAME_W + 70) this.item = null;
        }
        // ambient sparkle on the coin pile
        if (Math.random() < 0.35 && this.chestCoins.length) {
          const c = this.chestCoins[Math.floor(Math.random() * this.chestCoins.length)];
          this.particles.push({
            kind: 'glint', x: 240 + c.dx, y: 340 + c.dy, vx: 0, vy: -14,
            life: 0.5, max: 0.5, size: rand(1.5, 3), color: '#fff8d0', rot: 0, vr: 0, g: 0,
          });
        }
      }
      // star spawn
      if (!this.star) {
        this.starT -= dt;
        if (this.starT <= 0) this.spawnStar();
      } else if (this.star) {
        this.star.t -= dt;
        if (this.star.t <= 0) this.star = null;
      }
      if (this.reloadT > 0) {
        this.reloadT -= dtw;
        if (this.reloadT <= 0) { this.reloadT = 0; this.ammo = Math.ceil(d.mag * this.buffs.mag); this.sfx.reloadEnd(); }
      }
      const rateMul = this.treasureFx === 'mini' ? 0.62 : 1;
      this.fireCd -= dtw;
      if (this.firing && this.fireCd <= 0 && this.reloadT <= 0 && this.switchT <= 0.05) {
        if (d.arch === 'charge') {
          if (this.holdT < 1.0) {
            this.holdT += dtw;
          } else {
            this.fire();
            this.fireCd = d.rate * rateMul;
          }
        } else {
          this.fire();
          this.fireCd = d.rate * rateMul;
        }
      }
      if (!this.firing && this.prevFiring && d.arch === 'charge' && this.holdT >= 0.15) {
        this.fire();
        this.fireCd = d.rate * rateMul;
      }
      this.prevFiring = this.firing;
      // burns
      for (let i = this.burns.length - 1; i >= 0; i--) {
        const bn = this.burns[i];
        bn.t -= dtw;
        if (bn.t <= 0) {
          if (bn.cell.alive) {
            this.damageCell(bn.cell, bn.dmg, bn.cell.c);
            for (let s = 0; s < 3; s++) this.particles.push({
              kind: 'flame', x: this.toWorld(bn.cell.c).x + rand(-8, 8), y: this.toWorld(bn.cell.c).y + rand(-8, 8),
              vx: rand(-20, 20), vy: rand(-60, -20), life: 0.4, max: 0.4, size: rand(4, 8),
              color: `rgba(255,${120 + Math.floor(rand(0, 100))},40,`, rot: 0, vr: 0, g: -80,
            });
          }
          this.burns.splice(i, 1);
        }
      }
    }

    if (this.state === 'won') {
      this.winT += dt;
      if (Math.random() < 0.5) {
        const a = rand(0, TAU), r = rand(40, 120);
        this.particles.push({
          kind: 'glint', x: RCX + Math.cos(a) * r, y: RCY + Math.sin(a) * r, vx: 0, vy: -20,
          life: 0.8, max: 0.8, size: rand(2, 5), color: '#ffffff', rot: 0, vr: 0, g: 0,
        });
      }
    }

    // bullets (frozen during choice)
    if (this.state !== 'choice') {
      for (let i = this.bullets.length - 1; i >= 0; i--) {
        const b = this.bullets[i];
        b.life -= dtw;
        if (b.life <= 0) {
          if (b.arch === 'rocket' || b.arch === 'bigrocket') this.explosion(b.x, b.y, b.splash, b.dmg);
          this.bullets.splice(i, 1);
          continue;
        }
        if (b.homing > 0) {
          let tx = RCX, ty = RCY - 200;
          let best = 1e9;
          for (const c of this.cells) {
            if (!c.alive) continue;
            const wc = this.toWorld(c.c);
            const dd = (wc.x - b.x) ** 2 + (wc.y - b.y) ** 2;
            if (dd < best) { best = dd; tx = wc.x; ty = wc.y; }
          }
          const cur = Math.atan2(b.vy, b.vx);
          const want = Math.atan2(ty - b.y, tx - b.x);
          let diff = want - cur;
          while (diff > Math.PI) diff -= TAU;
          while (diff < -Math.PI) diff += TAU;
          const na = cur + clamp(diff, -b.homing * dtw, b.homing * dtw);
          const sp = Math.hypot(b.vx, b.vy);
          b.vx = Math.cos(na) * sp;
          b.vy = Math.sin(na) * sp;
        }
        if (b.grav > 0) b.vy += 900 * b.grav * dtw;
        if (b.spinSpd) b.rot += b.spinSpd * dtw;
        // wall bounce
        if (b.bounce > 0 && (b.x < 10 || b.x > GAME_W - 10)) {
          b.x = clamp(b.x, 10, GAME_W - 10);
          b.vx *= -1;
          b.bounce--;
          this.particles.push({ kind: 'ring', x: b.x, y: b.y, vx: 0, vy: 0, life: 0.15, max: 0.15, size: 12, color: `rgba(${b.rgb},0.7)`, rot: 0, vr: 0, g: 0 });
          this.sfx.pop();
        } else if (b.bounce < 0) {
          this.bullets.splice(i, 1);
          continue;
        }
        const dist = Math.hypot(b.vx, b.vy) * dtw;
        const steps = Math.max(1, Math.ceil(dist / 4));
        let dead = false;
        for (let s = 0; s < steps; s++) {
          b.x += (b.vx * dtw) / steps;
          b.y += (b.vy * dtw) / steps;
          if (this.hitBullet(b)) { dead = true; break; }
        }
        if (dead) { this.bullets.splice(i, 1); continue; }
        if (b.y < -40 || b.y > GAME_H + 40 || b.x < -40 || b.x > GAME_W + 40) { this.bullets.splice(i, 1); continue; }
        if (b.maxTrail > 0) {
          b.trail.push({ x: b.x, y: b.y });
          if (b.trail.length > b.maxTrail) b.trail.shift();
        }
        // rocket / meteor smoke
        if ((b.arch === 'rocket' || b.arch === 'bigrocket' || b.arch === 'meteor') && Math.random() < 0.6) {
          const a = Math.atan2(b.vy, b.vx);
          this.particles.push({
            kind: 'dust', x: b.x - Math.cos(a) * 14, y: b.y - Math.sin(a) * 14,
            vx: rand(-25, 25), vy: rand(-25, 25), life: rand(0.5, 0.9), max: 0.9, size: rand(4, 8),
            color: b.arch === 'meteor' ? 'rgba(255,140,60,' : 'rgba(210,205,210,', rot: 0, vr: 0, g: -20,
          });
          if (Math.random() < 0.5) {
            this.particles.push({
              kind: 'flame', x: b.x - Math.cos(a) * 12, y: b.y - Math.sin(a) * 12,
              vx: rand(-20, 20), vy: rand(-20, 20), life: 0.18, max: 0.18, size: rand(4, 8),
              color: `rgba(255,${140 + Math.floor(rand(0, 90))},60,`, rot: 0, vr: 0, g: 0,
            });
          }
        }
      }
    }

    for (const c of this.cells) if (c.flash > 0) c.flash = Math.max(0, c.flash - dt * 8);
    for (let i = this.beams.length - 1; i >= 0; i--) {
      this.beams[i].life -= dt;
      if (this.beams[i].life <= 0) this.beams.splice(i, 1);
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) { this.particles.splice(i, 1); continue; }
      p.vy += p.g * dt;
      if (p.kind === 'dust' || p.kind === 'flame' || p.kind === 'conf' || p.kind === 'petal') { p.vx *= 0.97; p.vy *= 0.97; }
      if (p.kind === 'petal') p.x += Math.sin(this.t * 3 + p.rot) * 40 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      if ((p.kind === 'frag' || p.kind === 'chip' || p.kind === 'shell' || p.kind === 'coin') && p.y > GAME_H - 10) {
        p.y = GAME_H - 10;
        p.vy *= -0.35;
        p.vx *= 0.6;
        p.vr *= 0.6;
      }
    }
    if (this.particles.length > 600) this.particles.splice(0, this.particles.length - 600);

    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= 40 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
    for (const m of this.motes) {
      m.y += m.v * dt;
      if (m.y > GAME_H) { m.y = -5; m.x = rand(0, GAME_W); }
    }

    this.hudT -= dt;
    if (this.hudT <= 0) { this.hudT = 0.08; this.pushHud(); }
  }

  renderRock(progress: number) {
    const rc = this.rockCtx;
    rc.setTransform(ROCK_SCALE, 0, 0, ROCK_SCALE, ROCK_PAD * ROCK_SCALE, ROCK_PAD * ROCK_SCALE);
    rc.clearRect(-ROCK_PAD, -ROCK_PAD, ROCK_PAD * 2, ROCK_PAD * 2);
    rc.globalCompositeOperation = 'source-over';
    for (const c of this.cells) {
      if (!c.alive) continue;
      rc.drawImage(c.sprite, c.sx, c.sy, c.sw, c.sh);
    }
    for (const c of this.cells) {
      if (!c.alive) continue;
      if (c.cracks.length || c.flash > 0) {
        rc.save();
        rc.beginPath();
        c.poly.forEach((p, i) => (i ? rc.lineTo(p.x, p.y) : rc.moveTo(p.x, p.y)));
        rc.closePath();
        rc.clip();
        rc.lineCap = 'round';
        for (const line of c.cracks) {
          rc.strokeStyle = 'rgba(2,5,14,0.9)';
          rc.lineWidth = 2.2;
          rc.beginPath();
          rc.moveTo(line[0].x, line[0].y);
          for (let k = 1; k < line.length; k++) rc.lineTo(line[k].x, line[k].y);
          rc.stroke();
          rc.strokeStyle = 'rgba(225,240,255,0.28)';
          rc.lineWidth = 1;
          rc.beginPath();
          rc.moveTo(line[0].x + 1, line[0].y + 1.2);
          for (let k = 1; k < line.length; k++) rc.lineTo(line[k].x + 1, line[k].y + 1.2);
          rc.stroke();
        }
        if (c.flash > 0) {
          rc.fillStyle = `rgba(255,255,255,${c.flash * 0.45})`;
          rc.fill();
        }
        rc.restore();
      }
    }
    rc.globalCompositeOperation = 'source-atop';
    let g = rc.createRadialGradient(-150, -150, 20, -150, -150, 540);
    g.addColorStop(0, 'rgba(216,232,255,0.34)');
    g.addColorStop(0.55, 'rgba(216,232,255,0.06)');
    g.addColorStop(1, 'rgba(216,232,255,0)');
    rc.fillStyle = g;
    rc.fillRect(-ROCK_PAD, -ROCK_PAD, ROCK_PAD * 2, ROCK_PAD * 2);
    g = rc.createRadialGradient(150, 170, 30, 150, 170, 560);
    g.addColorStop(0, 'rgba(6,9,26,0)');
    g.addColorStop(0.6, 'rgba(6,9,26,0.30)');
    g.addColorStop(1, 'rgba(6,9,26,0.52)');
    rc.fillStyle = g;
    rc.fillRect(-ROCK_PAD, -ROCK_PAD, ROCK_PAD * 2, ROCK_PAD * 2);
    g = rc.createRadialGradient(0, 0, 10, 0, 0, 175);
    g.addColorStop(0, `rgba(140,240,255,${0.12 + progress * 0.3})`);
    g.addColorStop(1, 'rgba(140,240,255,0)');
    rc.fillStyle = g;
    rc.fillRect(-ROCK_PAD, -ROCK_PAD, ROCK_PAD * 2, ROCK_PAD * 2);
    g = rc.createRadialGradient(0, 0, 150, 0, 0, 224);
    g.addColorStop(0, 'rgba(220,238,255,0)');
    g.addColorStop(0.75, 'rgba(220,238,255,0.16)');
    g.addColorStop(1, 'rgba(220,238,255,0)');
    rc.fillStyle = g;
    rc.fillRect(-ROCK_PAD, -ROCK_PAD, ROCK_PAD * 2, ROCK_PAD * 2);
    rc.globalCompositeOperation = 'source-over';
  }

  drawChest() {
    const ctx = this.ctx;
    const shx = this.chestShakeT > 0 ? Math.sin(this.t * 55) * 4 * this.chestShakeT : 0;
    const shy = this.chestShakeT > 0 ? Math.cos(this.t * 47) * 2.5 * this.chestShakeT : 0;
    ctx.save();
    ctx.translate(240 + shx, 340 + shy);
    // golden glow
    ctx.globalCompositeOperation = 'lighter';
    const gl = ctx.createRadialGradient(0, -30, 10, 0, -30, 150);
    gl.addColorStop(0, `rgba(255,215,110,${0.3 + this.chestShakeT * 0.5})`);
    gl.addColorStop(1, 'rgba(255,215,110,0)');
    ctx.fillStyle = gl;
    ctx.beginPath(); ctx.arc(0, -30, 150, 0, TAU); ctx.fill();
    // light rays
    ctx.save();
    ctx.rotate(this.t * 0.3);
    ctx.fillStyle = 'rgba(255,225,140,0.05)';
    for (let i = 0; i < 8; i++) {
      ctx.rotate(TAU / 8);
      ctx.beginPath(); ctx.moveTo(0, -20); ctx.lineTo(-14, -220); ctx.lineTo(14, -220); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    ctx.globalCompositeOperation = 'source-over';

    // open lid (tilted back)
    ctx.save();
    ctx.translate(0, -44);
    ctx.rotate(-0.5);
    ctx.fillStyle = '#6a4423';
    ctx.fillRect(-64, -46, 128, 46);
    ctx.fillStyle = '#553517';
    ctx.fillRect(-64, -8, 128, 8);
    ctx.strokeStyle = '#3d2712'; ctx.lineWidth = 2;
    ctx.strokeRect(-64, -46, 128, 46);
    ctx.fillStyle = '#4a4f57';
    ctx.fillRect(-64, -46, 10, 46); ctx.fillRect(54, -46, 10, 46);
    ctx.restore();

    // interior back wall
    ctx.fillStyle = '#3a2410';
    ctx.fillRect(-62, -44, 124, 40);

    // COIN PILE — naturally stacked, blinking sparkle
    for (const c of this.chestCoins) {
      const cx = c.dx, cy = c.dy;
      ctx.fillStyle = '#e8a820';
      ctx.beginPath(); ctx.ellipse(cx, cy + 2, 8.5, 5.5, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ffd23f';
      ctx.beginPath(); ctx.ellipse(cx, cy, 8.5, 5.5, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(cx, cy, 8.5, 5.5, 0, 0, TAU); ctx.stroke();
      ctx.strokeStyle = 'rgba(120,80,10,0.5)';
      ctx.beginPath(); ctx.ellipse(cx, cy, 4.5, 2.8, 0, 0, TAU); ctx.stroke();
      // blinking shine
      const sh = Math.sin(this.t * 2.6 + c.ph);
      if (sh > 0.6) {
        const a = (sh - 0.6) / 0.4;
        ctx.fillStyle = `rgba(255,255,240,${a * 0.9})`;
        ctx.beginPath(); ctx.ellipse(cx - 3, cy - 1.5, 2.6, 1.4, -0.5, 0, TAU); ctx.fill();
      }
    }

    // front of chest
    ctx.fillStyle = '#8a5a30';
    ctx.fillRect(-64, -18, 128, 52);
    ctx.fillStyle = '#7a4c26';
    ctx.fillRect(-64, -18, 128, 8);
    ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-21, -18); ctx.lineTo(-21, 34);
    ctx.moveTo(21, -18); ctx.lineTo(21, 34);
    ctx.stroke();
    ctx.fillStyle = '#4a4f57';
    ctx.fillRect(-64, -18, 12, 52); ctx.fillRect(52, -18, 12, 52);
    // lock
    ctx.fillStyle = '#ffd23f';
    ctx.beginPath(); ctx.arc(0, 4, 8, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 4, 8, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#3a2410';
    ctx.fillRect(-2, 1, 4, 8);
    // spilled coins at base
    const spill = [[-72, 26], [66, 28], [-80, 4], [78, 2]];
    for (const [sx, sy] of spill) {
      ctx.fillStyle = '#ffd23f';
      ctx.beginPath(); ctx.ellipse(sx, sy, 7, 4.5, 0.3, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(sx, sy, 7, 4.5, 0.3, 0, TAU); ctx.stroke();
    }
    // floating sparkle crosses
    for (let i = 0; i < 4; i++) {
      const a = this.t * 1.4 + i * 1.9;
      const px = Math.cos(a * 1.3) * 55, py = -40 + Math.sin(a) * 24;
      const sa = 0.3 + (Math.sin(this.t * 5 + i * 2) + 1) / 2 * 0.7;
      ctx.strokeStyle = `rgba(255,245,200,${sa})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(px - 5, py); ctx.lineTo(px + 5, py);
      ctx.moveTo(px, py - 5); ctx.lineTo(px, py + 5);
      ctx.stroke();
    }
    ctx.restore();
  }

  drawItem() {
    if (!this.item) return;
    const ctx = this.ctx;
    const it = this.item;
    const bob = Math.sin(this.t * 2.2 + it.t) * 9;
    const y = it.y + bob;
    const labels: Record<TreasureFx, [string, string]> = {
      speed: ['⚡', 'SPEED 2×'],
      double: ['✌️', 'DOUBLE SHOT'],
      mini: ['🔻', 'MINI • CEPAT'],
      big: ['🔺', 'PELURU 2×'],
    };
    const [emo, label] = labels[it.eff];
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const gl = ctx.createRadialGradient(it.x, y, 4, it.x, y, 55);
    gl.addColorStop(0, 'rgba(140,240,255,0.55)');
    gl.addColorStop(1, 'rgba(140,240,255,0)');
    ctx.fillStyle = gl;
    ctx.beginPath(); ctx.arc(it.x, y, 55, 0, TAU); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    const pulse = 1 + Math.sin(this.t * 6) * 0.06;
    ctx.save();
    ctx.translate(it.x, y);
    ctx.scale(pulse, pulse);
    ctx.fillStyle = 'rgba(10,30,44,0.92)';
    ctx.strokeStyle = '#8df0ff';
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.roundRect(-70, -20, 140, 40, 20); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(141,240,255,0.15)';
    ctx.beginPath(); ctx.roundRect(-66, -16, 132, 14, 10); ctx.fill();
    ctx.font = '20px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText(emo, -44, 7);
    ctx.font = '900 14px system-ui';
    ctx.fillStyle = '#d9f8ff';
    ctx.fillText(label, 12, 5);
    ctx.restore();
    ctx.font = '700 10px system-ui';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(200,250,255,0.9)';
    ctx.fillText('TEMBAK ATAU TEKAN!', it.x, y + 34);
    ctx.restore();
  }

  drawStar() {
    if (!this.star) return;
    const s = this.star;
    const ctx = this.ctx;
    const bob = Math.sin(this.t * 2.4) * 5;
    const y = s.y + bob;
    const blink = s.t < 3 ? (Math.sin(this.t * 12) > 0 ? 1 : 0.3) : 1;
    ctx.save();
    ctx.globalAlpha = blink;
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(s.x, y, 2, s.x, y, 42);
    g.addColorStop(0, 'rgba(255,220,120,0.9)');
    g.addColorStop(1, 'rgba(255,180,60,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(s.x, y, 42, 0, TAU); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    const R = 16 + Math.sin(this.t * 4) * 2;
    ctx.fillStyle = '#ffd23f';
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const rr = i % 2 === 0 ? R : R * 0.45;
      const a = this.t * 0.8 + (i / 10) * TAU - Math.PI / 2;
      const px = s.x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#fff0b0';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.beginPath(); ctx.arc(s.x, y, 4, 0, TAU); ctx.fill();
    // hint ring
    ctx.strokeStyle = `rgba(255,210,80,${0.4 + Math.sin(this.t * 5) * 0.25})`;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(s.x, y, 26 + Math.sin(this.t * 5) * 3, 0, TAU); ctx.stroke();
    ctx.font = '900 13px system-ui';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fff0b0';
    ctx.fillText('TEMBAK!', s.x, y - 34);
    // sparkles
    for (let i = 0; i < 3; i++) {
      const a = this.t * 2 + i * 2.1;
      const px = s.x + Math.cos(a) * 24, py = y + Math.sin(a) * 24;
      ctx.fillStyle = `rgba(255,240,180,${0.5 + Math.sin(this.t * 8 + i) * 0.4})`;
      ctx.beginPath(); ctx.arc(px, py, 1.5, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }

  render() {
    const ctx = this.ctx;
    const d = this.def();
    ctx.save();
    const bg = ctx.createLinearGradient(0, 0, 0, GAME_H);
    bg.addColorStop(0, '#1a1330');
    bg.addColorStop(0.55, '#0e1424');
    bg.addColorStop(1, '#07090f');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, GAME_W, GAME_H);

    if (this.shake > 0) ctx.translate(rand(-1, 1) * this.shake * 0.6, rand(-1, 1) * this.shake * 0.6);

    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    for (let x = 0; x <= GAME_W; x += 40) ctx.lineTo(x, 30 + Math.sin(x * 0.05) * 18 + (x % 80 === 0 ? 20 : 0));
    ctx.lineTo(GAME_W, 0); ctx.closePath(); ctx.fill();

    for (const m of this.motes) {
      ctx.fillStyle = `rgba(200,190,255,${0.15 + m.s * 0.1})`;
      ctx.fillRect(m.x, m.y, m.s, m.s);
    }

    const alive = this.cells.reduce((n, c) => n + (c.alive ? 1 : 0), 0);
    const progress = 1 - alive / Math.max(1, this.totalCells);
    const isTreasure = this.stage === 'treasure';
    const spotColor = isTreasure ? '255,205,110' : '90,200,255';
    const sp = ctx.createRadialGradient(RCX, 320, 20, RCX, 320, 320);
    sp.addColorStop(0, `rgba(${spotColor},${isTreasure ? 0.16 : 0.08 + progress * 0.25})`);
    sp.addColorStop(1, `rgba(${spotColor},0)`);
    ctx.fillStyle = sp;
    ctx.fillRect(0, 0, GAME_W, GAME_H);

    if (this.state === 'won') {
      ctx.save();
      ctx.translate(RCX, RCY);
      ctx.rotate(this.t * 0.4);
      const a = Math.min(1, this.winT);
      for (let i = 0; i < 12; i++) {
        ctx.rotate(TAU / 12);
        ctx.fillStyle = `rgba(150,240,255,${0.08 * a})`;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-30, -420); ctx.lineTo(30, -420); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }

    if (isTreasure) {
      this.drawChest();
    } else {
      const glowR = 90 + progress * 40 + (this.state === 'won' ? 40 + Math.sin(this.t * 4) * 10 : 0);
      const dg = ctx.createRadialGradient(RCX, RCY, 10, RCX, RCY, glowR);
      dg.addColorStop(0, `rgba(160,245,255,${0.35 + this.diamondPing * 0.4})`);
      dg.addColorStop(1, 'rgba(160,245,255,0)');
      ctx.fillStyle = dg;
      ctx.beginPath(); ctx.arc(RCX, RCY, glowR, 0, TAU); ctx.fill();

      const ds = this.state === 'won' ? 1 + Math.min(1, this.winT * 1.5) * 0.45 + Math.sin(this.t * 3) * 0.03 : 1 + this.diamondPing * 0.05;
      drawDiamond(ctx, this.t, ds);

      this.renderRock(progress);
      ctx.save();
      ctx.translate(RCX, RCY);
      ctx.rotate(this.rot);
      ctx.drawImage(this.rockCv, -ROCK_PAD, -ROCK_PAD, ROCK_PAD * 2, ROCK_PAD * 2);
      ctx.restore();
    }

    // aim line
    if (this.aim && this.state !== 'menu') {
      const m = this.muzzlePos();
      const a = this.aimDir(m);
      ctx.strokeStyle = 'rgba(255,210,80,0.35)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 8]);
      ctx.beginPath();
      ctx.moveTo(m.x + Math.sin(a) * 20, m.y - Math.cos(a) * 20);
      ctx.lineTo(m.x + Math.sin(a) * 600, m.y - Math.cos(a) * 600);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // bullets
    for (const b of this.bullets) {
      drawBullet(ctx, b, this.t);
      // rope for harpoon / yoyo
      if ((b.arch === 'harpoon' || b.arch === 'yoyo') && b.ox !== undefined && b.oy !== undefined) {
        ctx.strokeStyle = b.arch === 'harpoon' ? 'rgba(150,180,200,0.5)' : 'rgba(255,110,60,0.6)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(b.ox, b.oy);
        const mx = (b.ox + b.x) / 2 + 14, my = (b.oy + b.y) / 2 + 10;
        ctx.quadraticCurveTo(mx, my, b.x, b.y);
        ctx.stroke();
      }
    }

    // beams
    for (const bm of this.beams) {
      const a = bm.life / bm.max;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (const [lw, la] of [[bm.w * 3.4, 0.2 * a], [bm.w * 1.6, 0.5 * a], [bm.w * 0.7, 0.95 * a]] as const) {
        ctx.strokeStyle = `rgba(${bm.rgb},${la})`;
        ctx.lineWidth = lw;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(bm.x1, bm.y1); ctx.lineTo(bm.x2, bm.y2); ctx.stroke();
      }
      ctx.restore();
    }

    // particles
    for (const p of this.particles) {
      const a = Math.min(1, (p.life / p.max) * 1.5);
      switch (p.kind) {
        case 'frag':
          ctx.save();
          ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.globalAlpha = a;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          p.poly!.forEach((v, k) => (k ? ctx.lineTo(v.x, v.y) : ctx.moveTo(v.x, v.y)));
          ctx.closePath(); ctx.fill();
          ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 1; ctx.stroke();
          ctx.restore();
          break;
        case 'chip':
          ctx.globalAlpha = a;
          ctx.fillStyle = p.color;
          ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
          ctx.globalAlpha = 1;
          break;
        case 'dust': {
          const k = 1 - p.life / p.max;
          ctx.fillStyle = `${p.color}${0.35 * (1 - k)})`;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.6 + k), 0, TAU); ctx.fill();
          break;
        }
        case 'flame': {
          const k = 1 - p.life / p.max;
          ctx.fillStyle = `${p.color}${0.9 * (1 - k)})`;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 - k * 0.5), 0, TAU); ctx.fill();
          break;
        }
        case 'spark':
          ctx.strokeStyle = p.color; ctx.globalAlpha = a; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03); ctx.stroke();
          ctx.globalAlpha = 1;
          break;
        case 'glint':
          ctx.globalAlpha = a;
          ctx.fillStyle = p.color;
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(Math.PI / 4);
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          ctx.restore();
          ctx.globalAlpha = 1;
          break;
        case 'shell':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = a;
          ctx.fillStyle = p.color; ctx.fillRect(-p.size, -p.size * 2.2, p.size * 2, p.size * 4.4);
          ctx.fillStyle = '#8a6a22'; ctx.fillRect(-p.size, p.size * 1.6, p.size * 2, p.size * 0.8);
          ctx.restore();
          break;
        case 'coin':
          ctx.save(); ctx.translate(p.x, p.y); ctx.globalAlpha = a;
          ctx.scale(Math.abs(Math.cos(p.rot)) + 0.2, 1);
          ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(0, 0, p.size, 0, TAU); ctx.fill();
          ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1; ctx.stroke();
          ctx.restore();
          break;
        case 'conf':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = a;
          ctx.fillStyle = p.color; ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
          ctx.restore();
          break;
        case 'petal':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot + Math.sin(this.t * 3 + p.rot) * 0.5); ctx.globalAlpha = a * 0.9;
          ctx.fillStyle = p.color;
          ctx.beginPath(); ctx.ellipse(0, 0, p.size * 0.4, p.size, 0, 0, TAU); ctx.fill();
          ctx.restore();
          break;
        case 'ring': {
          const k = 1 - p.life / p.max;
          ctx.strokeStyle = p.color.startsWith('rgba') ? p.color.replace(/[\d.]+\)$/, `${0.8 * (1 - k)})`) : p.color;
          ctx.globalAlpha = p.color.startsWith('rgba') ? 1 : 0.8 * (1 - k);
          ctx.lineWidth = 4 * (1 - k) + 1;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.3 + k), 0, TAU); ctx.stroke();
          ctx.globalAlpha = 1;
          break;
        }
      }
    }
    ctx.globalAlpha = 1;

    // floating bonus item (treasure)
    if (this.stage === 'treasure') this.drawItem();

    // gun
    const m = this.muzzlePos();
    const a = this.aimDir(m);
    const relK = this.reloadT > 0 ? 1 - this.reloadT / d.reload : 0;
    const tilt = this.reloadT > 0 ? Math.sin(relK * Math.PI) * 0.16 : 0;
    const magDrop = this.reloadT > 0 ? (relK < 0.5 ? relK * 2 * 60 : (1 - relK) * 2 * 60) : 0;
    ctx.save();
    ctx.translate(m.x, m.y);
    ctx.rotate(a + tilt);
    drawGun(ctx, d, 0, 0, 1, this.flash, magDrop);
    ctx.restore();
    // charge indicator
    if (d.arch === 'charge' && this.holdT > 0.05 && this.state !== 'menu') {
      const k = Math.min(1, this.holdT);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const cg = ctx.createRadialGradient(m.x, m.y - 16, 0, m.x, m.y - 16, 14 + k * 20);
      cg.addColorStop(0, `rgba(255,240,160,${0.35 + k * 0.5})`);
      cg.addColorStop(1, 'rgba(255,200,60,0)');
      ctx.fillStyle = cg;
      ctx.beginPath(); ctx.arc(m.x, m.y - 16, 14 + k * 20, 0, TAU); ctx.fill();
      ctx.restore();
    }

    // star
    this.drawStar();

    // floating texts
    ctx.textAlign = 'center';
    for (const t of this.texts) {
      ctx.globalAlpha = Math.min(1, t.life * 2);
      ctx.font = `900 ${t.size}px system-ui, sans-serif`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(0,0,0,0.7)';
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;

    const vg = ctx.createRadialGradient(GAME_W / 2, GAME_H / 2, GAME_H * 0.3, GAME_W / 2, GAME_H / 2, GAME_H * 0.75);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = vg;
    ctx.fillRect(-20, -20, GAME_W + 40, GAME_H + 40);

    // slow-mo overlay
    if (this.timeScale < 0.9) {
      ctx.fillStyle = `rgba(120,180,255,${(1 - this.timeScale) * 0.12})`;
      ctx.fillRect(0, 0, GAME_W, GAME_H);
    }

    ctx.restore();
  }
}

/* diamond */
function drawDiamond(ctx: CanvasRenderingContext2D, t: number, scale: number) {
  ctx.save();
  ctx.translate(RCX, RCY);
  ctx.scale(scale, scale);
  const G = [-52, -26, 0, 26, 52].map((x) => ({ x, y: -6 }));
  const T = [-27, -9, 9, 27].map((x) => ({ x, y: -28 }));
  const P = { x: 0, y: 50 };
  const strip = [G[0], T[0], G[1], T[1], G[2], T[2], G[3], T[3], G[4]];
  const crownL = [78, 92, 70, 88, 64, 84, 72, 90, 76];
  for (let i = 0; i < strip.length - 2; i++) {
    const a = strip[i], bb = strip[i + 1], c = strip[i + 2];
    const l = crownL[i] + Math.sin(t * 2 + i) * 6;
    ctx.fillStyle = `hsl(${190 + i * 3},90%,${l}%)`;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(bb.x, bb.y); ctx.lineTo(c.x, c.y); ctx.closePath(); ctx.fill();
  }
  ctx.fillStyle = `hsl(195,100%,${90 + Math.sin(t * 3) * 5}%)`;
  ctx.beginPath(); ctx.moveTo(T[0].x, T[0].y); ctx.lineTo(T[3].x, T[3].y); ctx.lineTo(T[2].x, -20); ctx.lineTo(T[1].x, -20); ctx.closePath(); ctx.fill();
  const pavL = [55, 72, 48, 66];
  for (let i = 0; i < 4; i++) {
    const a = G[i], bb = G[i + 1];
    const mid = { x: (a.x + bb.x) / 2 * 0.5, y: 22 };
    const l = pavL[i] + Math.sin(t * 2.4 + i * 1.7) * 7;
    ctx.fillStyle = `hsl(${200 + i * 4},85%,${l}%)`;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(bb.x, bb.y); ctx.lineTo(mid.x, mid.y); ctx.closePath(); ctx.fill();
    ctx.fillStyle = `hsl(${205 + i * 4},85%,${l - 12}%)`;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mid.x, mid.y); ctx.lineTo(P.x, P.y); ctx.closePath(); ctx.fill();
    ctx.fillStyle = `hsl(${195 + i * 4},85%,${l + 8}%)`;
    ctx.beginPath(); ctx.moveTo(bb.x, bb.y); ctx.lineTo(mid.x, mid.y); ctx.lineTo(P.x, P.y); ctx.closePath(); ctx.fill();
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.75)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(T[0].x, T[0].y); ctx.lineTo(T[3].x, T[3].y); ctx.lineTo(G[4].x, G[4].y); ctx.lineTo(P.x, P.y); ctx.lineTo(G[0].x, G[0].y); ctx.closePath();
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(G[0].x, G[0].y); ctx.lineTo(G[4].x, G[4].y); ctx.stroke();
  const sp2 = (Math.sin(t * 2.2) + 1) / 2;
  const sx = -20 + Math.sin(t * 0.7) * 10, sy = -18;
  ctx.fillStyle = `rgba(255,255,255,${0.4 + sp2 * 0.6})`;
  const s = 6 + sp2 * 8;
  ctx.beginPath();
  ctx.moveTo(sx, sy - s); ctx.lineTo(sx + s * 0.18, sy - s * 0.18); ctx.lineTo(sx + s, sy); ctx.lineTo(sx + s * 0.18, sy + s * 0.18);
  ctx.lineTo(sx, sy + s); ctx.lineTo(sx - s * 0.18, sy + s * 0.18); ctx.lineTo(sx - s, sy); ctx.lineTo(sx - s * 0.18, sy - s * 0.18);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}
