export type Tier = 0 | 1 | 2 | 3;

export type GunTpl =
  | 'pistol' | 'rifle' | 'double' | 'shotgun' | 'bow' | 'slingshot' | 'crossbow'
  | 'cannon' | 'tube' | 'wand' | 'launcher' | 'drum' | 'bigcannon' | 'blade' | 'rocketpod' | 'cross'
  | 'pump' | 'smg' | 'revolver' | 'sniper' | 'gatling' | 'staff' | 'cannonwood' | 'mace';

export type Arch =
  | 'tracer' | 'bullet' | 'nail' | 'bolt' | 'dart' | 'pebble' | 'pellet' | 'water' | 'snowball'
  | 'honey' | 'coconut' | 'pencil' | 'sandal' | 'paint' | 'plasma' | 'laser' | 'fish' | 'rocket'
  | 'sniperbolt' | 'flame' | 'disc' | 'bubble' | 'bamboom' | 'banana' | 'harpoon' | 'chicken'
  | 'confetti' | 'seed' | 'pizza' | 'angklung' | 'ink' | 'yoyo' | 'petal' | 'acid' | 'spark'
  | 'gem' | 'pixel' | 'shuriken' | 'cricket' | 'electro' | 'bigrocket' | 'minibolt' | 'rail'
  | 'magnet' | 'cannonball' | 'card' | 'sonic' | 'shard' | 'bee' | 'keris' | 'tornado'
  | 'firework' | 'anchor' | 'shark' | 'coin' | 'iceshard' | 'gold' | 'blackhole' | 'portal'
  | 'chrono' | 'rainbow' | 'meteor' | 'diamond' | 'storm' | 'holy' | 'unicorn' | 'oblit' | 'galaxy'
  | 'crystal' | 'charge' | 'ufo';

export type Fx =
  | 'none' | 'coins' | 'slow' | 'warp' | 'burn' | 'blast' | 'confetti' | 'note' | 'quack'
  | 'slip' | 'meteor' | 'petals' | 'teleport' | 'corrode' | 'silence' | 'doubleScore' | 'suck';

export type SfxKind =
  | 'thump' | 'thud' | 'zip' | 'crack' | 'hiss' | 'bang' | 'splat' | 'whoosh' | 'pop'
  | 'boing' | 'quack' | 'note' | 'zap' | 'chime' | 'boom';

export interface WeaponDef {
  id: string;
  name: string;
  emoji: string;
  tier: Tier;
  perk: string;
  dmg: number;
  splash: number;
  splashDmg: number;
  rate: number;
  mag: number;
  reload: number;
  speed: number;
  shake: number;
  recoil: number;
  arch: Arch;
  color: string; // rgb string
  sfx: SfxKind;
  gun: GunTpl;
  g1: string; // body color
  g2: string; // accent color
  extra?: 'scope' | 'drum' | 'coil' | 'fins' | 'bamboo' | 'gold' | 'wings' | 'tank';
  pellets?: number;
  homing?: number;
  pierce?: number;
  bounce?: number;
  grav?: number;
  spin?: number;
  fx?: Fx;
}

const w = (d: Partial<WeaponDef> & Pick<WeaponDef, 'id' | 'name' | 'emoji' | 'tier' | 'perk' | 'arch' | 'gun' | 'g1' | 'g2' | 'color' | 'sfx'>): WeaponDef => ({
  dmg: 1, splash: 0, splashDmg: 0, rate: 0.4, mag: 12, reload: 1.3, speed: 1300,
  shake: 2, recoil: 12, fx: 'none',
  ...d,
} as WeaponDef);

export const WEAPON_DEFS: WeaponDef[] = [
  // ============ ⚪ UMUM ============
  w({ id: 'pistol', name: 'Pistol', emoji: '🔫', tier: 0, perk: 'SEIMBANG', arch: 'bullet', gun: 'pistol', g1: '#2a2e35', g2: '#565e6b', color: '255,200,120', sfx: 'thud', rate: 0.45, speed: 1400 }),
  w({ id: 'ak', name: 'AK-47', emoji: '🪖', tier: 0, perk: 'AUTO-FIRE', arch: 'tracer', gun: 'rifle', g1: '#4a3a26', g2: '#2c3139', color: '255,190,90', sfx: 'thump', rate: 0.12, mag: 30, speed: 1600 }),
  w({ id: 'nail', name: 'Nail Gun', emoji: '🔩', tier: 0, perk: 'TIPIS & AUTO', arch: 'nail', gun: 'smg', g1: '#3a4048', g2: '#d07020', color: '220,230,240', sfx: 'zip', rate: 0.1, mag: 40, speed: 2000 }),
  w({ id: 'crossbow', name: 'Crossbow', emoji: '🏹', tier: 0, perk: 'PRESISI', arch: 'bolt', gun: 'crossbow', g1: '#6b4a2b', g2: '#c9a24a', color: '210,170,100', sfx: 'crack', rate: 0.8, mag: 6, speed: 1250, dmg: 2 }),
  w({ id: 'ketapel', name: 'Ketapel', emoji: '🪨', tier: 0, perk: 'KHAS NUSANTARA', arch: 'pebble', gun: 'slingshot', g1: '#8a5a30', g2: '#e8d5b0', color: '180,150,120', sfx: 'whoosh', rate: 0.5, mag: 24, speed: 950, grav: 0.25 }),
  w({ id: 'sumpit', name: 'Sumpit Dayak', emoji: '🎋', tier: 0, perk: 'SENYAP & TIPIS', arch: 'dart', gun: 'bow', g1: '#2f4a35', g2: '#9fd8a8', color: '150,230,150', sfx: 'hiss', rate: 0.9, mag: 8, speed: 1150, dmg: 2, fx: 'silence' }),
  w({ id: 'shotgun', name: 'Shotgun', emoji: '💥', tier: 0, perk: 'TIGA SEKALIGUS', arch: 'pellet', gun: 'shotgun', g1: '#5a4128', g2: '#2c3139', color: '255,140,66', sfx: 'bang', rate: 0.55, mag: 6, speed: 1300, pellets: 3, shake: 6, recoil: 24 }),
  w({ id: 'soaker', name: 'Super Soaker', emoji: '💦', tier: 0, perk: 'BASAH', arch: 'water', gun: 'tube', g1: '#2a6fd0', g2: '#7fd8ff', color: '90,180,255', sfx: 'splat', rate: 0.3, mag: 20, speed: 1150, grav: 0.15 }),
  w({ id: 'snow', name: 'Snowball Cannon', emoji: '⛄', tier: 0, perk: 'MANUSIA SALJU', arch: 'snowball', gun: 'cannon', g1: '#3a4654', g2: '#cfe8ff', color: '240,248,255', sfx: 'splat', rate: 0.5, mag: 15, speed: 1050, grav: 0.2 }),
  w({ id: 'honey', name: 'Honey Blaster', emoji: '🍯', tier: 0, perk: 'LENGKET', arch: 'honey', gun: 'tube', g1: '#a06a20', g2: '#ffd870', color: '255,190,60', sfx: 'splat', rate: 0.35, mag: 15, speed: 1200, grav: 0.1 }),
  w({ id: 'coconut', name: 'Meriam Kelapa', emoji: '🥥', tier: 0, perk: 'KELAPA MUDA', arch: 'coconut', gun: 'launcher', g1: '#6b4a2b', g2: '#c98a4a', color: '150,100,60', sfx: 'thud', rate: 0.7, mag: 10, speed: 1050, grav: 0.5, dmg: 2, shake: 4 }),
  w({ id: 'pencil', name: 'Pencil Gun', emoji: '✏️', tier: 0, perk: 'PENGHAPUS', arch: 'pencil', gun: 'wand', g1: '#3a3a44', g2: '#ffd24a', color: '255,215,80', sfx: 'zip', rate: 0.4, mag: 20, speed: 1350 }),
  w({ id: 'sandal', name: 'Sandal Jepit', emoji: '🩴', tier: 0, perk: 'PLAK!', arch: 'sandal', gun: 'launcher', g1: '#7a3030', g2: '#ffb080', color: '255,120,80', sfx: 'boing', rate: 0.5, mag: 12, speed: 1250, grav: 0.4, spin: 8, dmg: 2 }),
  w({ id: 'paintball', name: 'Paintball Gun', emoji: '🎨', tier: 0, perk: 'WARNA SAMPAI', arch: 'paint', gun: 'tube', g1: '#37424e', g2: '#ff5a8a', color: '255,90,140', sfx: 'pop', rate: 0.45, mag: 12, speed: 1350, grav: 0.1 }),

  // ============ 🔵 LANGKA ============
  w({ id: 'plasma', name: 'Plasma Gun', emoji: '🟢', tier: 1, perk: '2× POIN', arch: 'plasma', gun: 'tube', g1: '#12343a', g2: '#5ef2ff', color: '94,242,255', sfx: 'zap', rate: 0.3, mag: 12, speed: 950, homing: 1.7, dmg: 2, fx: 'doubleScore', extra: 'coil' }),
  w({ id: 'laser', name: 'Laser Beam', emoji: '🔴', tier: 1, perk: 'INSTAN', arch: 'laser', gun: 'tube', g1: '#3a1520', g2: '#ff5060', color: '255,80,90', sfx: 'zap', rate: 0.5, mag: 10, dmg: 2, extra: 'coil' }),
  w({ id: 'fish', name: 'Fish Gun', emoji: '🐟', tier: 1, perk: 'IKAN HOKI', arch: 'fish', gun: 'tube', g1: '#1f4a5a', g2: '#7fd8ff', color: '120,200,255', sfx: 'splat', rate: 0.5, mag: 8, speed: 1150, dmg: 2, spin: 6, extra: 'fins' }),
  w({ id: 'rpg', name: 'RPG-7', emoji: '🚀', tier: 1, perk: 'LEDAKAN 2×', arch: 'rocket', gun: 'rocketpod', g1: '#2e3a2c', g2: '#6a8a4a', color: '255,170,90', sfx: 'bang', rate: 1.5, mag: 4, speed: 620, homing: 2.4, dmg: 5, splash: 55, splashDmg: 3, shake: 10, recoil: 30 }),
  w({ id: 'awp', name: 'Sniper AWP', emoji: '🎯', tier: 1, perk: 'SLOW-MO SCOPE', arch: 'sniperbolt', gun: 'sniper', g1: '#1f2830', g2: '#4a6a7a', color: '235,245,255', sfx: 'crack', rate: 1.1, mag: 5, speed: 5000, dmg: 6, shake: 9, recoil: 26, fx: 'warp' }),
  w({ id: 'flame', name: 'Flamethrower', emoji: '🔥', tier: 1, perk: 'MEMBAKAR', arch: 'flame', gun: 'tube', g1: '#4a2410', g2: '#ff8a30', color: '255,150,50', sfx: 'hiss', rate: 0.05, mag: 40, speed: 720, dmg: 0.4, fx: 'burn', extra: 'tank' }),
  w({ id: 'disc', name: 'Disc Gun', emoji: '🥏', tier: 1, perk: 'CAKRAM PANTUL', arch: 'disc', gun: 'wand', g1: '#4a2a4a', g2: '#ff6e6e', color: '255,110,110', sfx: 'whoosh', rate: 0.7, mag: 10, speed: 1050, bounce: 3 }),
  w({ id: 'bubble', name: 'Bubble Gun', emoji: '🫧', tier: 1, perk: 'PERISAI AIR', arch: 'bubble', gun: 'wand', g1: '#2a4a5a', g2: '#bfe8ff', color: '170,220,255', sfx: 'pop', rate: 0.5, mag: 12, speed: 1050, grav: 0.05 }),
  w({ id: 'bamboo', name: 'Meriam Bambu', emoji: '🎍', tier: 1, perk: 'DUARR LEBARAN', arch: 'bamboom', gun: 'tube', g1: '#6a7a30', g2: '#d8e8a0', color: '190,150,80', sfx: 'crack', rate: 1.3, mag: 6, speed: 750, dmg: 4, splash: 40, splashDmg: 2, fx: 'confetti', extra: 'bamboo', shake: 8 }),
  w({ id: 'banana', name: 'Banana Gun', emoji: '🍌', tier: 1, perk: 'TERPELESET', arch: 'banana', gun: 'tube', g1: '#8a7a20', g2: '#fff06a', color: '255,220,60', sfx: 'whoosh', rate: 0.6, mag: 12, speed: 1150, grav: 0.3, spin: 5, fx: 'slip' }),
  w({ id: 'harpoon', name: 'Harpoon Gun', emoji: '🔱', tier: 1, perk: 'TALI PENARIK', arch: 'harpoon', gun: 'rifle', g1: '#2a3a4a', g2: '#8ab8d8', color: '180,200,220', sfx: 'whoosh', rate: 1.0, mag: 6, speed: 1450, dmg: 3, pierce: 2 }),
  w({ id: 'chicken', name: 'Rubber Chicken', emoji: '🐔', tier: 1, perk: 'KWEK!', arch: 'chicken', gun: 'launcher', g1: '#7a5a20', g2: '#ffe89a', color: '255,225,120', sfx: 'quack', rate: 0.6, mag: 10, speed: 1250, grav: 0.2, spin: 4, fx: 'quack' }),
  w({ id: 'confetti', name: 'Confetti Cannon', emoji: '🎉', tier: 1, perk: 'PESTA COMBO', arch: 'confetti', gun: 'tube', g1: '#5a2a6a', g2: '#ff8ad8', color: '255,138,216', sfx: 'pop', rate: 0.6, mag: 8, speed: 1050, grav: 0.2, fx: 'confetti' }),
  w({ id: 'seed', name: 'Seed Gun', emoji: '🌱', tier: 1, perk: 'TANAM KOIN', arch: 'seed', gun: 'wand', g1: '#3a5a2a', g2: '#9ae86a', color: '140,220,100', sfx: 'pop', rate: 0.7, mag: 10, speed: 1150, grav: 0.1, fx: 'coins' }),
  w({ id: 'pizza', name: 'Pizza Launcher', emoji: '🍕', tier: 1, perk: 'IRISAN KOIN', arch: 'pizza', gun: 'launcher', g1: '#7a4a20', g2: '#ffd890', color: '255,170,60', sfx: 'thud', rate: 0.6, mag: 8, speed: 1050, grav: 0.5, spin: 4, dmg: 2 }),
  w({ id: 'angklung', name: 'Angklung', emoji: '🎶', tier: 1, perk: 'NADA COMBO', arch: 'angklung', gun: 'staff', g1: '#8a6a30', g2: '#e8d5a0', color: '210,170,90', sfx: 'note', rate: 0.5, mag: 12, speed: 1250, extra: 'bamboo' }),
  w({ id: 'ink', name: 'Tinta Gurita', emoji: '🐙', tier: 1, perk: 'SEMBUR TINTA', arch: 'ink', gun: 'tube', g1: '#3a2a5a', g2: '#b08aff', color: '110,80,170', sfx: 'splat', rate: 0.4, mag: 14, speed: 1250, grav: 0.05 }),
  w({ id: 'yoyo', name: 'Yoyo Shooter', emoji: '🪀', tier: 1, perk: 'TALI AJAIB', arch: 'yoyo', gun: 'wand', g1: '#5a3a2a', g2: '#ff6e3c', color: '255,110,60', sfx: 'boing', rate: 0.45, mag: 12, speed: 1450, grav: 0.6 }),
  w({ id: 'sakura', name: 'Sakura Blossom', emoji: '🌸', tier: 1, perk: 'HUJAN SAKURA', arch: 'petal', gun: 'wand', g1: '#5a2a3a', g2: '#ffb0d0', color: '255,170,200', sfx: 'whoosh', rate: 0.35, mag: 20, speed: 950, fx: 'petals' }),
  w({ id: 'acid', name: 'Acid Spitter', emoji: '🧪', tier: 1, perk: 'KOROSI', arch: 'acid', gun: 'tube', g1: '#3a4a1a', g2: '#a8e83c', color: '150,230,60', sfx: 'splat', rate: 0.4, mag: 12, speed: 1150, grav: 0.1, fx: 'corrode' }),
  w({ id: 'wand', name: 'Magic Wand', emoji: '🪄', tier: 1, perk: 'SIM SALABIM', arch: 'spark', gun: 'mace', g1: '#3a2a4a', g2: '#ffe066', color: '255,230,120', sfx: 'chime', rate: 0.5, mag: 10, speed: 1250, dmg: 2 }),
  w({ id: 'ruby', name: 'Ruby Revolver', emoji: '♦️', tier: 1, perk: 'LUCKY SIX', arch: 'gem', gun: 'revolver', g1: '#3a1a20', g2: '#ff465a', color: '255,70,90', sfx: 'chime', rate: 0.4, mag: 6, speed: 1500, dmg: 2 }),
  w({ id: 'bit8', name: '8-Bit Retro Gun', emoji: '👾', tier: 1, perk: 'RETRO ARCADE', arch: 'pixel', gun: 'smg', g1: '#22302a', g2: '#78ff8c', color: '120,255,140', sfx: 'zip', rate: 0.3, mag: 16, speed: 1800 }),
  w({ id: 'kunai', name: 'Kunai Shuriken', emoji: '🗡️', tier: 1, perk: 'NINJA CEPAT', arch: 'shuriken', gun: 'blade', g1: '#2a2a34', g2: '#c0c8d8', color: '200,210,230', sfx: 'zip', rate: 0.35, mag: 10, speed: 1550, dmg: 2, spin: 14 }),

  // ============ 🟣 EPIC ============
  w({ id: 'cricket', name: 'Noisy Cricket', emoji: '🦗', tier: 2, perk: 'MINI MONSTER', arch: 'cricket', gun: 'wand', g1: '#4a4a2a', g2: '#c8c04a', color: '190,150,90', sfx: 'pop', rate: 0.4, mag: 12, speed: 1150, grav: 0.2, bounce: 2 }),
  w({ id: 'electro', name: 'Electro Gun', emoji: '⚡', tier: 2, perk: 'COMBO+', arch: 'electro', gun: 'tube', g1: '#1a2a4a', g2: '#a0dcff', color: '160,220,255', sfx: 'zap', rate: 0.4, mag: 12, speed: 1650, dmg: 2, extra: 'coil' }),
  w({ id: 'bazooka', name: 'Bazooka', emoji: '💣', tier: 2, perk: '3× POIN', arch: 'bigrocket', gun: 'rocketpod', g1: '#2a2a2e', g2: '#7a8a4a', color: '255,120,60', sfx: 'bang', rate: 1.6, mag: 3, speed: 600, homing: 2.2, dmg: 6, splash: 60, splashDmg: 3, fx: 'doubleScore', shake: 12, recoil: 34 }),
  w({ id: 'minigun', name: 'Minigun', emoji: '🌀', tier: 2, perk: 'SPIN-UP', arch: 'minibolt', gun: 'gatling', g1: '#2e3238', g2: '#8a9099', color: '255,210,110', sfx: 'thump', rate: 0.06, mag: 100, speed: 2200, reload: 2.5, shake: 4, recoil: 14 }),
  w({ id: 'rail', name: 'Railgun', emoji: '🧲', tier: 2, perk: 'TEMBUS', arch: 'rail', gun: 'tube', g1: '#1e2a3a', g2: '#96e6ff', color: '150,230,255', sfx: 'zap', rate: 0.9, mag: 6, speed: 4500, dmg: 3, pierce: 3, extra: 'coil', shake: 8 }),
  w({ id: 'magnet', name: 'Magnet Gun', emoji: '🧲', tier: 2, perk: 'TARIK & TOLAK', arch: 'magnet', gun: 'mace', g1: '#2a1a3a', g2: '#c882ff', color: '200,130,255', sfx: 'zap', rate: 0.5, mag: 12, speed: 850, homing: 3, dmg: 2 }),
  w({ id: 'shrink', name: 'Shrink Ray', emoji: '🔬', tier: 2, perk: 'MENGECILKAN', arch: 'laser', gun: 'wand', g1: '#3a1a3a', g2: '#ff8cdc', color: '255,140,220', sfx: 'zap', rate: 0.6, mag: 8, dmg: 2 }),
  w({ id: 'grow', name: 'Grow Ray', emoji: '🔭', tier: 2, perk: 'MEMBESARKAN', arch: 'laser', gun: 'tube', g1: '#3a2a1a', g2: '#ffdc78', color: '255,220,120', sfx: 'zap', rate: 0.6, mag: 8, dmg: 2, extra: 'scope' }),
  w({ id: 'pirate', name: 'Meriam Bajak Laut', emoji: '🏴‍☠️', tier: 2, perk: 'PENGHANCUR', arch: 'cannonball', gun: 'cannonwood', g1: '#3a2a1a', g2: '#8a7a5a', color: '150,150,160', sfx: 'bang', rate: 1.0, mag: 6, speed: 950, grav: 0.4, dmg: 4, shake: 8 }),
  w({ id: 'card', name: 'Card Gun', emoji: '🃏', tier: 2, perk: 'JACKPOT AS', arch: 'card', gun: 'revolver', g1: '#2a2a34', g2: '#ff5060', color: '255,240,220', sfx: 'whoosh', rate: 0.7, mag: 8, speed: 1150, dmg: 2, spin: 3 }),
  w({ id: 'sonic', name: 'Sonic Blaster', emoji: '🔊', tier: 2, perk: 'GELOMBANG SUARA', arch: 'sonic', gun: 'tube', g1: '#1a2a3a', g2: '#aac8ff', color: '170,200,255', sfx: 'whoosh', rate: 0.8, mag: 8, speed: 950, splash: 30, splashDmg: 1 }),
  w({ id: 'mirror', name: 'Mirror Gun', emoji: '🪞', tier: 2, perk: 'MEMANTUL', arch: 'shard', gun: 'tube', g1: '#2a3038', g2: '#e6f2ff', color: '230,240,255', sfx: 'chime', rate: 0.5, mag: 8, speed: 1650, dmg: 2, bounce: 3, pierce: 1 }),
  w({ id: 'bee', name: 'Bee Rifle', emoji: '🐝', tier: 2, perk: 'SENGAT RATU', arch: 'bee', gun: 'smg', g1: '#4a401a', g2: '#ffd21e', color: '255,200,60', sfx: 'hiss', rate: 0.25, mag: 30, speed: 950, homing: 1.2, reload: 1.6 }),
  w({ id: 'keris', name: 'Keris Sakti', emoji: '🗡️', tier: 2, perk: 'TEMBUS GAIB', arch: 'keris', gun: 'blade', g1: '#3a2a10', g2: '#dcb878', color: '220,190,120', sfx: 'whoosh', rate: 0.6, mag: 8, speed: 1550, dmg: 3, pierce: 2, extra: 'gold' }),
  w({ id: 'tornado', name: 'Tornado Gun', emoji: '🌪️', tier: 2, perk: 'PUSARAN', arch: 'tornado', gun: 'staff', g1: '#2a3038', g2: '#c8d4e8', color: '200,210,230', sfx: 'whoosh', rate: 0.8, mag: 8, speed: 850, dmg: 2, splash: 26, splashDmg: 1 }),
  w({ id: 'firework', name: 'Firework Launcher', emoji: '🎆', tier: 2, perk: 'KEMBANG API', arch: 'firework', gun: 'launcher', g1: '#2a1a3a', g2: '#ff78c8', color: '255,120,200', sfx: 'bang', rate: 0.8, mag: 6, speed: 850, dmg: 2, fx: 'confetti' }),
  w({ id: 'anchor', name: 'Anchor Cannon', emoji: '⚓', tier: 2, perk: 'JANGKAR KAPAL', arch: 'anchor', gun: 'bigcannon', g1: '#2e3238', g2: '#6a7280', color: '150,160,175', sfx: 'thud', rate: 1.4, mag: 5, speed: 850, grav: 0.6, dmg: 6, shake: 9, recoil: 30 }),
  w({ id: 'shark', name: 'Shark Launcher', emoji: '🦈', tier: 2, perk: 'GIGITAN HIU', arch: 'shark', gun: 'rocketpod', g1: '#22303a', g2: '#8ab0c8', color: '140,170,200', sfx: 'splat', rate: 0.8, mag: 8, speed: 1350, dmg: 3 }),
  w({ id: 'emerald', name: 'Emerald Laser', emoji: '💚', tier: 2, perk: 'KILAU ZAMRUD', arch: 'laser', gun: 'tube', g1: '#123422', g2: '#3ce68c', color: '60,230,140', sfx: 'zap', rate: 0.5, mag: 10, dmg: 3, extra: 'coil' }),
  w({ id: 'sapphire', name: 'Sapphire Shotgun', emoji: '💙', tier: 2, perk: 'BEKU SAFIR', arch: 'iceshard', gun: 'pump', g1: '#1a2a4a', g2: '#78b4ff', color: '120,180,255', sfx: 'chime', rate: 0.7, mag: 9, speed: 1250, pellets: 3, fx: 'slow', shake: 6, recoil: 22 }),
  w({ id: 'crystal', name: 'Crystal Cannon', emoji: '🔮', tier: 2, perk: 'PECAH KRISTAL', arch: 'crystal', gun: 'mace', g1: '#2a1a3a', g2: '#dc8cff', color: '220,140,255', sfx: 'chime', rate: 0.5, mag: 10, speed: 1450, dmg: 2 }),
  w({ id: 'charge', name: 'Charge Blaster', emoji: '🔋', tier: 2, perk: 'TAHAN = CHARGE', arch: 'charge', gun: 'tube', g1: '#2a2a1a', g2: '#ffdc5a', color: '255,220,90', sfx: 'zap', rate: 1.0, mag: 6, speed: 1550, dmg: 2 }),
  w({ id: 'ufo', name: 'UFO Ray', emoji: '🛸', tier: 2, perk: 'CULIK', arch: 'ufo', gun: 'wand', g1: '#2a2a34', g2: '#c8a0ff', color: '200,160,255', sfx: 'zap', rate: 0.7, mag: 8, speed: 1050, dmg: 2, fx: 'teleport' }),
  w({ id: 'coingu', name: 'Coin Gun', emoji: '🪙', tier: 2, perk: 'PABRIK KOIN', arch: 'coin', gun: 'drum', g1: '#4a3a1a', g2: '#ffd23f', color: '255,205,80', sfx: 'chime', rate: 0.35, mag: 14, speed: 1450, spin: 10, fx: 'coins' }),

  // ============ 🟡 LEGENDARIS ============
  w({ id: 'freeze', name: 'Freeze Ray', emoji: '❄️', tier: 3, perk: 'BEKUKAN', arch: 'iceshard', gun: 'tube', g1: '#1a3a4a', g2: '#aaf4ff', color: '170,230,255', sfx: 'chime', rate: 0.5, mag: 10, speed: 1350, dmg: 2, fx: 'slow', extra: 'coil' }),
  w({ id: 'golden', name: 'Golden Gun', emoji: '🌟', tier: 3, perk: '3× KOIN', arch: 'gold', gun: 'sniper', g1: '#4a3a10', g2: '#ffd74f', color: '255,215,80', sfx: 'chime', rate: 0.4, mag: 10, speed: 1650, dmg: 2, fx: 'coins', extra: 'gold' }),
  w({ id: 'blackhole', name: 'Black Hole', emoji: '🕳️', tier: 3, perk: 'SEDOT KOIN', arch: 'blackhole', gun: 'bigcannon', g1: '#12101a', g2: '#8c50ff', color: '140,80,255', sfx: 'boom', rate: 1.2, mag: 5, speed: 850, dmg: 5, splash: 45, splashDmg: 2, fx: 'suck', shake: 8 }),
  w({ id: 'portal', name: 'Portal Gun', emoji: '🌌', tier: 3, perk: 'TELEPORT', arch: 'portal', gun: 'wand', g1: '#123430', g2: '#50f0dc', color: '80,240,220', sfx: 'zap', rate: 0.9, mag: 6, speed: 1150, dmg: 3, fx: 'teleport' }),
  w({ id: 'chrono', name: 'Chrono Gun', emoji: '⏱️', tier: 3, perk: 'STOP WAKTU', arch: 'chrono', gun: 'revolver', g1: '#2a2a34', g2: '#f0f0ff', color: '240,240,255', sfx: 'chime', rate: 0.8, mag: 8, speed: 1250, dmg: 2, fx: 'warp' }),
  w({ id: 'rainbow', name: 'Rainbow Gun', emoji: '🌈', tier: 3, perk: 'PELANGI', arch: 'rainbow', gun: 'tube', g1: '#3a2a4a', g2: '#ff8ad8', color: '255,255,255', sfx: 'chime', rate: 0.4, mag: 12, speed: 1250, dmg: 2 }),
  w({ id: 'meteor', name: 'Meteor Launcher', emoji: '☄️', tier: 3, perk: 'HUJAN METEOR', arch: 'meteor', gun: 'rocketpod', g1: '#3a2218', g2: '#ff8c46', color: '255,140,70', sfx: 'bang', rate: 0.9, mag: 6, speed: 1050, grav: 0.2, dmg: 3, splash: 34, splashDmg: 1, fx: 'meteor', shake: 6 }),
  w({ id: 'diamond', name: 'Diamond Gun', emoji: '💎', tier: 3, perk: 'BERLIAN', arch: 'diamond', gun: 'mace', g1: '#1a2a3a', g2: '#c8fbff', color: '200,250,255', sfx: 'chime', rate: 0.55, mag: 8, speed: 1550, dmg: 4, extra: 'gold' }),
  w({ id: 'moonbeam', name: 'Moonbeam', emoji: '🌙', tier: 3, perk: 'CAHAYA BULAN', arch: 'laser', gun: 'staff', g1: '#2a2a3a', g2: '#e6ebff', color: '226,232,255', sfx: 'chime', rate: 0.7, mag: 8, dmg: 2 }),
  w({ id: 'storm', name: 'Storm Caller', emoji: '🌩️', tier: 3, perk: 'BADAI PETIR', arch: 'storm', gun: 'bigcannon', g1: '#1a2233', g2: '#b4dcff', color: '180,220,255', sfx: 'zap', rate: 1.0, mag: 6, speed: 1900, dmg: 4, splash: 30, splashDmg: 1, shake: 7 }),
  w({ id: 'holy', name: 'Holy Light Gun', emoji: '😇', tier: 3, perk: 'CAHAYA SUCI', arch: 'holy', gun: 'cross', g1: '#3a3426', g2: '#fff5c8', color: '255,245,200', sfx: 'chime', rate: 1.1, mag: 6, speed: 1350, dmg: 4, extra: 'gold' }),
  w({ id: 'unicorn', name: 'Rainbow Unicorn', emoji: '🦄', tier: 3, perk: 'SIHIR ACAK', arch: 'unicorn', gun: 'staff', g1: '#3a2a3a', g2: '#ffa8dc', color: '255,200,240', sfx: 'chime', rate: 0.5, mag: 10, speed: 1050, homing: 1.4, dmg: 2, fx: 'petals', extra: 'wings' }),
  w({ id: 'oblit', name: 'Obliterator 9000', emoji: '☢️', tier: 3, perk: 'PEMUSNAH', arch: 'oblit', gun: 'bigcannon', g1: '#241214', g2: '#ff3c3c', color: '255,60,60', sfx: 'boom', rate: 1.8, mag: 3, speed: 700, dmg: 8, splash: 70, splashDmg: 4, fx: 'blast', shake: 14, recoil: 40, reload: 2.5 }),
  w({ id: 'wars', name: 'Wars Blaster', emoji: '🌌', tier: 3, perk: 'LASER GALAXY', arch: 'galaxy', gun: 'gatling', g1: '#221a33', g2: '#c878ff', color: '200,120,255', sfx: 'zap', rate: 0.35, mag: 12, speed: 2100, dmg: 3, extra: 'fins' }),
];

export const WEAPON_MAP: Record<string, WeaponDef> = Object.fromEntries(WEAPON_DEFS.map((d) => [d.id, d]));

export const TIER_INFO = [
  { name: 'UMUM', emoji: '⚪', color: '#c8cdd6' },
  { name: 'LANGKA', emoji: '🔵', color: '#5aa8ff' },
  { name: 'EPIC', emoji: '🟣', color: '#c06eff' },
  { name: 'LEGENDARIS', emoji: '🟡', color: '#ffd23f' },
];
