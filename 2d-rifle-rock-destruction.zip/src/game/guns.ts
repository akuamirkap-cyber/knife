import type { WeaponDef } from './weapons';

function hexRgb(hex: string): string {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath(); ctx.roundRect(x, y, w, h, r);
}

// deterministic per-weapon variation
function makeSeed(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return (n: number) => {
    const x = Math.sin(h * 12.9898 + n * 78.233) * 43758.5453;
    return x - Math.floor(x);
  };
}

function flashStar(ctx: CanvasRenderingContext2D, s: number, flash: number, rgb: string, style: string) {
  ctx.save();
  const g = ctx.createRadialGradient(0, -s * 0.4, 0, 0, -s * 0.4, s * 1.5);
  g.addColorStop(0, `rgba(${rgb},${0.95 * flash})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(0, -s * 0.4, s * 1.5, 0, Math.PI * 2); ctx.fill();
  if (style === 'ring') {
    ctx.strokeStyle = `rgba(${rgb},${flash})`; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(0, -s * 0.5, s * 0.6, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = `rgba(255,255,255,${flash})`;
    ctx.beginPath(); ctx.arc(0, -s * 0.5, s * 0.28, 0, Math.PI * 2); ctx.fill();
  } else if (style === 'beam') {
    ctx.fillStyle = `rgba(255,255,255,${flash})`;
    ctx.beginPath(); ctx.ellipse(0, -s * 0.7, s * 0.12, s * 0.9, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `rgba(${rgb},${flash})`; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, -s * 0.4, s * 0.75, 0, Math.PI * 2); ctx.stroke();
  } else {
    ctx.fillStyle = `rgba(255,246,220,${flash})`;
    ctx.beginPath();
    ctx.moveTo(0, -s * 1.9);
    ctx.lineTo(s * 0.25, -s * 0.5); ctx.lineTo(s * 0.85, -s * 0.75);
    ctx.lineTo(s * 0.3, -s * 0.1); ctx.lineTo(0, 0);
    ctx.lineTo(-s * 0.3, -s * 0.1); ctx.lineTo(-s * 0.85, -s * 0.75);
    ctx.lineTo(-s * 0.25, -s * 0.5);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = `rgba(255,255,255,${flash})`;
    ctx.beginPath(); ctx.ellipse(0, -s * 0.45, s * 0.13, s * 0.48, 0, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

export function drawGun(
  ctx: CanvasRenderingContext2D, d: WeaponDef,
  x: number, y: number, side: number, flash: number, magDrop: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(side, 1);
  const g1 = d.g1, g2 = d.g2, g2r = hexRgb(g2);
  const sr = makeSeed(d.id);
  const hi = 'rgba(255,255,255,0.16)';
  const dark = 'rgba(0,0,0,0.4)';
  ctx.lineJoin = 'round';
  const ringStyle = ['plasma', 'magnet', 'ufo', 'portal', 'blackhole', 'freeze', 'holy', 'sonic', 'rainbow', 'unicorn'].includes(d.arch);
  const beamStyle = ['laser', 'rail', 'moonbeam', 'storm'].includes(d.arch);

  const stock = (y0: number, len: number, col: string) => {
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.moveTo(-9, y0); ctx.lineTo(9, y0); ctx.lineTo(17, y0 + len); ctx.lineTo(-10, y0 + len);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#14171c'; ctx.fillRect(-10, y0 + len - 5, 27, 9);
    ctx.fillStyle = hi; ctx.fillRect(-9, y0 + 2, 2, len - 4);
  };
  const grip = (y0: number, col: string) => {
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.moveTo(8, y0); ctx.lineTo(30, y0 + 8);
    ctx.quadraticCurveTo(36, y0 + 14, 32, y0 + 22);
    ctx.lineTo(8, y0 + 14);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = dark; ctx.lineWidth = 1;
    for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(13 + i * 5, y0 + 4 + i * 2); ctx.lineTo(11 + i * 5, y0 + 12 + i * 2); ctx.stroke(); }
  };

  switch (d.gun) {
    case 'rifle': {
      const b = d.extra === 'scope' ? 100 : 52 + sr(1) * 22;
      if (flash > 0) flashStar(ctx, d.extra === 'scope' ? 44 : 26, flash, g2r, beamStyle ? 'beam' : 'star');
      ctx.fillStyle = '#16191e'; rr(ctx, -5.5, 0, 11, 16, 2); ctx.fill();
      ctx.fillStyle = '#4b525e'; ctx.fillRect(-5.5, 5, 11, 2); ctx.fillRect(-5.5, 10, 11, 2);
      ctx.fillStyle = g1; ctx.fillRect(-3.2, 16, 6.4, b);
      ctx.fillStyle = hi; ctx.fillRect(-3.2, 16, 1.5, b);
      const hg = 16 + b - 10, hgEnd = hg + 56, recEnd = hgEnd + 56;
      ctx.fillStyle = d.extra === 'gold' ? g2 : g1; rr(ctx, -10, hg, 20, 56, 4); ctx.fill();
      if (d.extra === 'gold') { ctx.fillStyle = 'rgba(255,255,255,0.35)'; for (let i = 0; i < 3; i++) ctx.fillRect(-7, hg + 10 + i * 14, 14, 2); }
      else {
        const vents = 3 + Math.floor(sr(2) * 3);
        ctx.fillStyle = '#1b1f25';
        for (let i = 0; i < vents; i++) { rr(ctx, -6, hg + 7 + i * (50 / vents), 12, 4, 2); ctx.fill(); }
      }
      ctx.save(); ctx.translate(magDrop * 0.6, magDrop);
      ctx.globalAlpha = magDrop > 0 ? Math.max(0, 1 - magDrop / 60) : 1;
      ctx.fillStyle = '#1e2228';
      ctx.beginPath();
      ctx.moveTo(10, hgEnd + 6); ctx.quadraticCurveTo(30, hgEnd + 2, 46, hgEnd - 10);
      ctx.lineTo(48, hgEnd + 10); ctx.quadraticCurveTo(32, hgEnd + 24, 10, hgEnd + 28);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.restore();
      ctx.fillStyle = g1; rr(ctx, -12, hgEnd, 24, 56, 4); ctx.fill();
      ctx.fillStyle = '#c9a24a'; ctx.fillRect(-3, hgEnd + 14, 4, 10);
      ctx.fillStyle = hi; ctx.fillRect(-12, hgEnd + 3, 2, 50);
      ctx.strokeStyle = '#16191e'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(14, recEnd - 18, 8, -Math.PI / 2, Math.PI / 2); ctx.stroke();
      grip(recEnd - 8, d.extra === 'gold' ? g2 : '#25292f');
      stock(recEnd, 62 + sr(3) * 16, d.extra === 'gold' ? g2 : g1);
      if (d.extra === 'scope') {
        ctx.fillStyle = '#20242b'; rr(ctx, -30, hgEnd - 36, 14, 96, 5); ctx.fill();
        ctx.fillStyle = g2; ctx.fillRect(-31, hgEnd - 43, 16, 3); ctx.fillRect(-31, hgEnd + 48, 16, 3);
        ctx.fillStyle = hi; ctx.fillRect(-30, hgEnd - 34, 2, 92);
      } else {
        ctx.fillStyle = '#22262d'; rr(ctx, -26, hgEnd + 4, 12, 28, 3); ctx.fill();
        ctx.fillStyle = 'rgba(255,60,60,0.9)'; ctx.fillRect(-25, hgEnd + 3, 10, 2.5);
        ctx.fillStyle = hi; ctx.fillRect(-26, hgEnd + 6, 2, 24);
      }
      break;
    }
    case 'pistol': {
      const bl2 = 10 + sr(1) * 8;
      if (flash > 0) flashStar(ctx, 20, flash, g2r, 'star');
      ctx.fillStyle = '#16191e'; rr(ctx, -4.5, 0, 9, bl2, 2); ctx.fill();
      ctx.fillStyle = g1; rr(ctx, -7, bl2 - 2, 14, 36, 3); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-7, bl2, 1.5, 32);
      ctx.fillStyle = g2; ctx.fillRect(-7, bl2 + 20, 14, 3);
      const gy = bl2 + 30;
      ctx.strokeStyle = '#16191e'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(9, gy + 4, 7, -Math.PI / 2, Math.PI / 2); ctx.stroke();
      grip(gy, g2);
      ctx.fillStyle = 'rgba(255,60,60,0.9)'; ctx.fillRect(-2, 2, 4, 2);
      break;
    }
    case 'shotgun': {
      const bl3 = 38 + sr(1) * 12;
      if (flash > 0) flashStar(ctx, 40, flash, g2r, 'star');
      ctx.fillStyle = '#16191e'; rr(ctx, -7, 0, 14, 12, 3); ctx.fill();
      ctx.fillStyle = g1; ctx.fillRect(-8, 12, 7, bl3);
      ctx.fillRect(1, 12, 7, bl3);
      ctx.fillStyle = hi; ctx.fillRect(-8, 12, 1.5, bl3);
      const hg = 12 + bl3;
      ctx.fillStyle = g2; rr(ctx, -6, hg, 12, 18, 3); ctx.fill();
      ctx.fillStyle = '#1b1f25'; for (let i = 0; i < 2; i++) ctx.fillRect(-4, hg + 5 + i * 6, 8, 2);
      ctx.fillStyle = g1; rr(ctx, -10, hg + 16, 20, 48, 4); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-10, hg + 18, 2, 44);
      grip(hg + 56, g2);
      stock(hg + 62, 62, g2);
      ctx.fillStyle = '#16191e'; rr(ctx, -14, 22, 6, 26, 2); ctx.fill();
      break;
    }
    case 'pump': {
      const bl4 = 34 + sr(1) * 14;
      if (flash > 0) flashStar(ctx, 38, flash, g2r, 'star');
      ctx.fillStyle = '#16191e'; rr(ctx, -8, 0, 16, 12, 3); ctx.fill();
      ctx.fillStyle = g1;
      ctx.fillRect(-9, 12, 7, bl4); ctx.fillRect(2, 12, 7, bl4);
      // ribbed pump forend
      ctx.fillStyle = '#20242b'; rr(ctx, -11, 12 + bl4, 22, 22, 4); ctx.fill();
      ctx.fillStyle = g2;
      for (let i = 0; i < 4; i++) ctx.fillRect(-8, 15 + bl4 + i * 5, 16, 2);
      const hg = 34 + bl4 + 22;
      ctx.fillStyle = g1; rr(ctx, -10, hg, 20, 44, 4); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-10, hg + 2, 2, 40);
      ctx.fillStyle = g2; ctx.fillRect(-10, hg + 20, 20, 3);
      grip(hg + 42, '#25292f');
      stock(hg + 46, 58, g1);
      ctx.fillStyle = '#22262d'; rr(ctx, -27, hg + 2, 13, 24, 3); ctx.fill();
      ctx.fillStyle = 'rgba(120,220,255,0.9)'; ctx.fillRect(-26, hg + 4, 11, 2);
      break;
    }
    case 'smg': {
      const bl5 = 18 + sr(1) * 10;
      if (flash > 0) flashStar(ctx, 22, flash, g2r, 'star');
      ctx.fillStyle = '#16191e'; rr(ctx, -6, 0, 12, bl5, 2); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(-6, bl5 - 4, 12, 3);
      ctx.fillStyle = g1; rr(ctx, -9, bl5 - 2, 18, 52, 5); ctx.fill();
      // box mag
      ctx.save(); ctx.translate(magDrop * 0.6, magDrop);
      ctx.globalAlpha = magDrop > 0 ? Math.max(0, 1 - magDrop / 60) : 1;
      ctx.fillStyle = '#1a1e24';
      rr(ctx, 8, bl5 + 24, 10, 26, 2); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(8, bl5 + 44, 10, 3);
      ctx.restore();
      // rail
      ctx.fillStyle = '#101318';
      for (let i = 0; i < 4; i++) ctx.fillRect(-4, bl5 + 4 + i * 9, 8, 4);
      ctx.fillStyle = hi; ctx.fillRect(-9, bl5, 1.5, 48);
      // short stock
      ctx.fillStyle = g2;
      ctx.beginPath();
      ctx.moveTo(-8, bl5 + 50); ctx.lineTo(8, bl5 + 50); ctx.lineTo(12, bl5 + 78); ctx.lineTo(-8, bl5 + 78);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(-4, bl5 + 58, 10, 14);
      ctx.fillStyle = 'rgba(255,60,60,0.9)'; ctx.fillRect(-2, 2, 4, 2);
      break;
    }
    case 'revolver': {
      if (flash > 0) flashStar(ctx, 24, flash, g2r, 'star');
      // fat barrel
      ctx.fillStyle = g1; rr(ctx, -6.5, 0, 13, 26, 3); ctx.fill();
      ctx.fillStyle = '#14171c';
      ctx.beginPath(); ctx.ellipse(0, 4, 5.5, 4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-6.5, 8, 1.5, 18);
      // cylinder with chambers
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.ellipse(0, 38, 11, 10, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#1a1e24';
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        ctx.beginPath(); ctx.arc(Math.cos(a) * 6.5, 38 + Math.sin(a) * 5.5, 1.8, 0, Math.PI * 2); ctx.fill();
      }
      // grip
      ctx.fillStyle = g1;
      ctx.beginPath();
      ctx.moveTo(6, 46); ctx.lineTo(24, 52); ctx.quadraticCurveTo(28, 58, 24, 66); ctx.lineTo(6, 58);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#14171c'; ctx.fillRect(6, 44, 20, 5);
      ctx.fillStyle = g2; ctx.fillRect(10, 52, 3, 10);
      break;
    }
    case 'sniper': {
      const bl6 = 130 + sr(1) * 30;
      if (flash > 0) flashStar(ctx, 48, flash, g2r, 'beam');
      ctx.fillStyle = '#16191e'; rr(ctx, -6, 0, 12, 14, 2); ctx.fill();
      // muzzle brake
      ctx.fillStyle = g2; rr(ctx, -7, 0, 14, 6, 2); ctx.fill();
      // very long slim barrel
      ctx.fillStyle = g1; ctx.fillRect(-2.5, 14, 5, bl6);
      ctx.fillStyle = hi; ctx.fillRect(-2.5, 14, 1.2, bl6);
      // front post
      ctx.fillStyle = '#14171c'; ctx.fillRect(-8, 14 + bl6 - 14, 16, 4);
      const hg = 14 + bl6 - 10;
      // handguard slim
      ctx.fillStyle = d.extra === 'gold' ? g2 : g1; rr(ctx, -8, hg, 16, 54, 4); ctx.fill();
      if (d.extra === 'gold') { ctx.fillStyle = 'rgba(255,255,255,0.35)'; for (let i = 0; i < 3; i++) ctx.fillRect(-6, hg + 12 + i * 12, 12, 2); }
      else { ctx.fillStyle = '#101318'; for (let i = 0; i < 4; i++) ctx.fillRect(-5, hg + 8 + i * 11, 10, 4); }
      const hgEnd = hg + 54, recEnd = hgEnd + 50;
      ctx.fillStyle = g1; rr(ctx, -10, hgEnd, 20, 50, 4); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-10, hgEnd + 2, 1.5, 46);
      // big scope
      ctx.fillStyle = '#20242b'; rr(ctx, -32, hgEnd - 44, 16, 110, 6); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(-33, hgEnd - 52, 18, 4); ctx.fillRect(-33, hgEnd + 52, 18, 4);
      ctx.fillStyle = 'rgba(140,220,255,0.5)'; ctx.fillRect(-30, hgEnd + 40, 12, 6);
      ctx.fillStyle = hi; ctx.fillRect(-32, hgEnd - 42, 2, 106);
      grip(recEnd - 4, '#25292f');
      stock(recEnd, 74, g1);
      // bipod
      ctx.strokeStyle = '#16191e'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-6, 14 + bl6 - 20); ctx.lineTo(-14, 14 + bl6 - 6); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(6, 14 + bl6 - 20); ctx.lineTo(14, 14 + bl6 - 6); ctx.stroke();
      break;
    }
    case 'gatling': {
      const bl7 = 30 + sr(1) * 14;
      if (flash > 0) flashStar(ctx, 30, flash, g2r, 'star');
      // three barrels
      for (const [ox, len] of [[-5, bl7], [0, bl7 + 8], [5, bl7]] as const) {
        ctx.fillStyle = g1;
        ctx.fillRect(ox - 2.2, 0, 4.4, len);
        ctx.fillStyle = '#14171c';
        ctx.fillRect(ox - 2.2, 0, 4.4, 5);
      }
      // drum
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(14, 52, 15, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#14171c';
      ctx.beginPath(); ctx.arc(14, 52, 9, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(14, 52, 12, 0.4, 1.8); ctx.stroke();
      // mount
      ctx.fillStyle = g1; rr(ctx, -10, bl7 + 8, 20, 44, 5); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(-10, bl7 + 20, 20, 4);
      ctx.fillStyle = hi; ctx.fillRect(-10, bl7 + 10, 1.5, 40);
      // grip + stock
      grip(bl7 + 50, g2);
      ctx.strokeStyle = g1; ctx.lineWidth = 10; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, bl7 + 64); ctx.lineTo(-6, bl7 + 130); ctx.stroke();
      break;
    }
    case 'tube': {
      const tl = 74 + sr(1) * 22;
      if (flash > 0) flashStar(ctx, 28, flash, g2r, ringStyle ? 'ring' : beamStyle ? 'beam' : 'star');
      ctx.fillStyle = '#16191e'; rr(ctx, -7, 0, 14, 14, 3); ctx.fill();
      ctx.fillStyle = g1; rr(ctx, -9, 12, 18, tl, 5); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-9, 14, 2, tl - 4);
      const rings = 2 + Math.floor(sr(2) * 3);
      for (let i = 0; i < rings; i++) { ctx.fillStyle = g2; ctx.fillRect(-9, 24 + i * ((tl - 30) / rings), 18, 4); }
      if (d.extra === 'coil') {
        ctx.strokeStyle = g2; ctx.lineWidth = 2;
        for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.ellipse(0, 20 + i * (tl / 5), 11, 3.5, 0, 0, Math.PI * 2); ctx.stroke(); }
      }
      if (d.extra === 'bamboo') {
        ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5;
        for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-9, 20 + i * (tl / 4)); ctx.lineTo(9, 22 + i * (tl / 4)); ctx.stroke(); }
        ctx.fillStyle = g2; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(0, 20 + i * (tl / 4), 1.5, 0, Math.PI * 2); ctx.fill(); }
      }
      if (d.extra === 'fins') {
        ctx.fillStyle = g2;
        ctx.beginPath(); ctx.moveTo(-9, 16); ctx.lineTo(-16, 30); ctx.lineTo(-9, 30); ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.moveTo(9, 16); ctx.lineTo(16, 30); ctx.lineTo(9, 30); ctx.closePath(); ctx.fill();
      }
      if (d.extra === 'tank') {
        ctx.fillStyle = '#5a5f68'; rr(ctx, 10, 30, 16, 34, 6); ctx.fill();
        ctx.fillStyle = g2; ctx.fillRect(13, 34, 10, 4);
        ctx.strokeStyle = g2; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(10, 40); ctx.lineTo(0, 34); ctx.stroke();
      }
      if (d.extra === 'scope') {
        ctx.fillStyle = '#20242b'; rr(ctx, -30, 30, 12, 60, 4); ctx.fill();
        ctx.fillStyle = g2; ctx.fillRect(-30, 26, 12, 5);
      }
      ctx.fillStyle = g2; rr(ctx, -12, 12 + tl, 24, 20, 4); ctx.fill();
      grip(12 + tl + 18, g2);
      stock(14 + tl, 62, g1);
      break;
    }
    case 'wand': {
      const wl = 150 + sr(1) * 40;
      if (flash > 0) flashStar(ctx, 24, flash, g2r, ringStyle ? 'ring' : 'star');
      const grad = ctx.createLinearGradient(0, 10, 0, 190);
      grad.addColorStop(0, g2);
      grad.addColorStop(0.25, g1);
      grad.addColorStop(1, g1);
      ctx.fillStyle = grad;
      rr(ctx, -3.5, 8, 7, wl, 3); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fillRect(-3.5, 8, 1.5, wl - 2);
      // wrapped texture
      ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(-3.5, 30 + i * 24); ctx.lineTo(3.5, 33 + i * 24); ctx.stroke(); }
      // orb tip
      const orb = ctx.createRadialGradient(0, 4, 0, 0, 4, 8);
      orb.addColorStop(0, '#ffffff');
      orb.addColorStop(0.5, g2);
      orb.addColorStop(1, 'rgba(0,0,0,0.4)');
      ctx.fillStyle = orb;
      ctx.beginPath(); ctx.arc(0, 4, 7, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = g2; ctx.lineWidth = 1.5;
      const orbRings = 2 + Math.floor(sr(2) * 3);
      for (let i = 0; i < orbRings; i++) { ctx.beginPath(); ctx.arc(0, 4, 10 + i * 4, i * 2, i * 2 + 1.8); ctx.stroke(); }
      // handle
      ctx.fillStyle = g1; rr(ctx, -6, wl - 4, 12, 40, 5); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(-6, wl + 4, 12, 4); ctx.fillRect(-6, wl + 20, 12, 4);
      if (d.extra === 'gold') { ctx.strokeStyle = g2; ctx.lineWidth = 2; ctx.strokeRect(-6, wl - 4, 12, 40); }
      if (d.extra === 'wings') {
        ctx.fillStyle = 'rgba(255,180,230,0.85)';
        ctx.beginPath(); ctx.ellipse(-11, 20, 7, 16, 0.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(11, 20, 7, 16, -0.5, 0, Math.PI * 2); ctx.fill();
      }
      break;
    }
    case 'bow': {
      const bw2 = 20 + sr(1) * 14;
      if (flash > 0) flashStar(ctx, 20, flash, g2r, 'star');
      ctx.strokeStyle = g1; ctx.lineWidth = 7; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(14, 210); ctx.quadraticCurveTo(-bw2 - 12, 100, 14, -10); ctx.stroke();
      ctx.strokeStyle = g2; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(14, 210); ctx.quadraticCurveTo(-bw2 - 12, 100, 14, -10); ctx.stroke();
      // binding wraps
      ctx.strokeStyle = g2; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(11, -4); ctx.lineTo(17, -8); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(11, 204); ctx.lineTo(17, 208); ctx.stroke();
      ctx.strokeStyle = 'rgba(240,240,220,0.8)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(14, -10); ctx.lineTo(2, 100); ctx.lineTo(14, 210); ctx.stroke();
      ctx.strokeStyle = g2; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(2, 100); ctx.lineTo(-16, 100); ctx.stroke();
      break;
    }
    case 'slingshot': {
      const sa = 10 + sr(1) * 12;
      if (flash > 0) flashStar(ctx, 22, flash, g2r, 'star');
      ctx.strokeStyle = g1; ctx.lineWidth = 10; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-18, 58 - sa); ctx.lineTo(0, 130); ctx.lineTo(18, 58 - sa); ctx.stroke();
      ctx.strokeStyle = g1; ctx.lineWidth = 12;
      ctx.beginPath(); ctx.moveTo(0, 130); ctx.lineTo(0, 200); ctx.stroke();
      // carved grip
      ctx.strokeStyle = g2; ctx.lineWidth = 3;
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-5, 145 + i * 10); ctx.lineTo(5, 148 + i * 10); ctx.stroke(); }
      ctx.strokeStyle = g2; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-18, 56 - sa); ctx.lineTo(2, 18); ctx.lineTo(18, 56 - sa); ctx.stroke();
      ctx.fillStyle = g2; rr(ctx, -8, 12, 16, 12, 5); ctx.fill();
      break;
    }
    case 'crossbow': {
      const cbw = 26 + sr(1) * 12;
      if (flash > 0) flashStar(ctx, 22, flash, g2r, 'star');
      ctx.fillStyle = g1; rr(ctx, -3, 4, 6, 170, 3); ctx.fill();
      ctx.strokeStyle = g1; ctx.lineWidth = 9; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-cbw, 96); ctx.quadraticCurveTo(0, 38, cbw, 96); ctx.stroke();
      ctx.strokeStyle = g2; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(-cbw, 96); ctx.lineTo(2, 62); ctx.lineTo(cbw, 96); ctx.stroke();
      // string anchor notch
      ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(-cbw, 96, 4, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(cbw, 96, 4, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = g2; rr(ctx, -12, 40, 24, 18, 4); ctx.fill();
      ctx.fillStyle = '#101318'; ctx.fillRect(-8, 46, 16, 4);
      ctx.fillStyle = hi; ctx.fillRect(-3, 4, 1.5, 170);
      break;
    }
    case 'cannon': {
      const cr = 17 + sr(1) * 6;
      if (flash > 0) flashStar(ctx, 44, flash, g2r, 'star');
      ctx.fillStyle = g1;
      ctx.beginPath(); ctx.ellipse(0, 40, cr + 3, cr + 7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.ellipse(0, 12, cr - 6, 8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#14171c';
      ctx.beginPath(); ctx.ellipse(0, 6, cr - 7, 7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hi;
      ctx.beginPath(); ctx.ellipse(-cr * 0.35, 32, 4, 12, 0.3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = g2;
      for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; ctx.beginPath(); ctx.arc(Math.cos(a) * (cr), 40 + Math.sin(a) * (cr + 4), 3, 0, Math.PI * 2); ctx.fill(); }
      ctx.strokeStyle = g1; ctx.lineWidth = 14; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, 60); ctx.lineTo(0, 150); ctx.stroke();
      ctx.fillStyle = g2; ctx.fillRect(-14, 150, 28, 14);
      break;
    }
    case 'cannonwood': {
      if (flash > 0) flashStar(ctx, 48, flash, g2r, 'star');
      // wooden staves
      ctx.fillStyle = g1; rr(ctx, -18, 0, 36, 58, 8); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5;
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(-18 + 9 + i * 9, 2); ctx.lineTo(-18 + 9 + i * 9, 56); ctx.stroke(); }
      // iron bands
      ctx.fillStyle = '#4a4f57';
      ctx.fillRect(-19, 8, 38, 6); ctx.fillRect(-19, 30, 38, 6); ctx.fillRect(-19, 50, 38, 6);
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(-19, 9, 38, 2); ctx.fillRect(-19, 31, 38, 2);
      ctx.fillStyle = '#14171c';
      ctx.beginPath(); ctx.ellipse(0, 4, 15, 8, 0, 0, Math.PI * 2); ctx.fill();
      // wooden barrel body
      ctx.fillStyle = g1; ctx.fillRect(-14, 56, 28, 78);
      ctx.fillStyle = '#4a4f57'; ctx.fillRect(-15, 78, 30, 5); ctx.fillRect(-15, 112, 30, 5);
      // skull decal
      ctx.fillStyle = 'rgba(240,240,230,0.85)';
      ctx.beginPath(); ctx.arc(0, 96, 8, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(-6, 96, 12, 7);
      ctx.fillStyle = '#20242b';
      ctx.beginPath(); ctx.arc(-3, 94, 2, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(3, 94, 2, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(-17, 132, 34, 14);
      ctx.fillStyle = g2; ctx.fillRect(-17, 132, 34, 4);
      break;
    }
    case 'bigcannon': {
      const bwc = 15 + sr(1) * 4;
      if (flash > 0) flashStar(ctx, 56, flash, g2r, 'star');
      ctx.fillStyle = g1; rr(ctx, -bwc, 0, bwc * 2, 60, 8); ctx.fill();
      ctx.fillStyle = g2; rr(ctx, -bwc, 0, bwc * 2, 10, 4); ctx.fill();
      ctx.fillStyle = '#14171c'; ctx.beginPath(); ctx.ellipse(0, 4, bwc - 1, 8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-bwc, 14, 3, 44);
      ctx.fillStyle = g1; ctx.fillRect(-bwc + 3, 56, (bwc - 3) * 2, 80);
      ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-bwc + 3, 80); ctx.lineTo(bwc - 3, 80); ctx.moveTo(-bwc + 3, 110); ctx.lineTo(bwc - 3, 110); ctx.stroke();
      ctx.fillStyle = g2; ctx.fillRect(-bwc - 1, 134, (bwc + 1) * 2, 14);
      if (d.extra === 'gold') {
        ctx.strokeStyle = g2; ctx.lineWidth = 2;
        ctx.strokeRect(-bwc, 0, bwc * 2, 60);
      }
      break;
    }
    case 'launcher': {
      const lh = 62 + sr(1) * 16;
      if (flash > 0) flashStar(ctx, 34, flash, g2r, 'star');
      ctx.fillStyle = g1; rr(ctx, -10, 0, 20, 50, 5); ctx.fill();
      ctx.fillStyle = g2; rr(ctx, -10, 0, 20, 8, 3); ctx.fill();
      ctx.fillStyle = '#14171c'; ctx.beginPath(); ctx.ellipse(0, 4, 9, 5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = g1; rr(ctx, -14, 48, 28, lh, 6); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-14, 52, 2.5, lh - 8);
      ctx.fillStyle = g2; ctx.fillRect(-14, 70, 28, 5);
      ctx.fillStyle = '#101318';
      ctx.fillRect(-14, 48, 28, 10);
      ctx.fillStyle = g2; ctx.fillRect(-14, 49, 28, 2);
      ctx.strokeStyle = g1; ctx.lineWidth = 9; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(10, 48 + lh); ctx.lineTo(16, 48 + lh + 60); ctx.stroke();
      ctx.fillStyle = g2; rr(ctx, 8, 44 + lh, 16, 30, 5); ctx.fill();
      break;
    }
    case 'drum': {
      const dl = 22 + sr(1) * 10;
      if (flash > 0) flashStar(ctx, 26, flash, g2r, 'star');
      ctx.fillStyle = g1; rr(ctx, -9, 0, 18, dl, 4); ctx.fill();
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(12, dl + 28, 17, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#14171c';
      ctx.beginPath(); ctx.arc(12, dl + 28, 11, 0, Math.PI * 2); ctx.fill();
      // spinning drum lines
      ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(12, dl + 28, 14, 0.4, 1.6); ctx.stroke();
      ctx.beginPath(); ctx.arc(12, dl + 28, 8, 2.2, 3.4); ctx.stroke();
      ctx.fillStyle = g1; rr(ctx, -8, dl + 2, 16, 60, 4); ctx.fill();
      ctx.fillStyle = hi; ctx.fillRect(-8, dl + 6, 2, 52);
      grip(dl + 58, g2);
      ctx.strokeStyle = g1; ctx.lineWidth = 8; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(4, dl + 86); ctx.lineTo(-2, dl + 146); ctx.stroke();
      break;
    }
    case 'blade': {
      const blen = 110 + sr(1) * 26;
      if (flash > 0) flashStar(ctx, 22, flash, g2r, beamStyle ? 'beam' : 'star');
      const grad = ctx.createLinearGradient(-6, 0, 6, 0);
      grad.addColorStop(0, '#e8eef6');
      grad.addColorStop(0.5, '#9aa8bc');
      grad.addColorStop(1, '#6a7890');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(-6, 0); ctx.lineTo(6, 0);
      ctx.quadraticCurveTo(4, blen * 0.65, -1, blen * 0.94);
      ctx.quadraticCurveTo(-8, blen * 0.55, -6, 0);
      ctx.closePath(); ctx.fill();
      if (d.extra === 'gold') {
        ctx.strokeStyle = g2; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(-3, 6); ctx.quadraticCurveTo(-5, blen * 0.55, -1.5, blen * 0.88); ctx.stroke();
      }
      const gy = blen * 0.94;
      ctx.fillStyle = d.extra === 'gold' ? g2 : '#22262d'; rr(ctx, -12, gy - 2, 24, 10, 3); ctx.fill();
      if (d.extra === 'gold') {
        ctx.fillStyle = '#fff0b0';
        ctx.beginPath(); ctx.arc(0, gy + 3, 2.5, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = g1; rr(ctx, -4, gy + 8, 8, 44, 3); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(-4, gy + 14, 8, 3); ctx.fillRect(-4, gy + 30, 8, 3);
      break;
    }
    case 'rocketpod': {
      const rp = 72 + sr(1) * 18;
      if (flash > 0) flashStar(ctx, 46, flash, g2r, 'star');
      ctx.fillStyle = g1; rr(ctx, -16, 0, 32, rp, 10); ctx.fill();
      ctx.fillStyle = '#14171c';
      ctx.beginPath(); ctx.ellipse(0, 6, 14, 8, 0, 0, Math.PI * 2); ctx.fill();
      // periscope window
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(0, 24, 9, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2a3038';
      ctx.beginPath(); ctx.arc(0, 24, 6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = g2;
      for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2; ctx.fillRect(Math.cos(a) * 7 - 1, 24 + Math.sin(a) * 7 - 1, 2.5, 2.5); }
      ctx.fillStyle = hi; ctx.fillRect(-16, 10, 3, rp - 16);
      // ammo bumps
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(-8, 44 + i * 12, 4, 0, Math.PI * 2); ctx.fill(); }
      grip(rp - 8, g2);
      ctx.strokeStyle = g1; ctx.lineWidth = 10; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-8, rp + 16); ctx.lineTo(-14, rp + 86); ctx.stroke();
      break;
    }
    case 'staff': {
      const sl = 160 + sr(1) * 30;
      if (flash > 0) flashStar(ctx, 26, flash, g2r, ringStyle ? 'ring' : 'star');
      // long pole
      ctx.fillStyle = g1; rr(ctx, -3, 10, 6, sl, 3); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.fillRect(-3, 10, 1.2, sl - 4);
      // wraps
      ctx.strokeStyle = g2; ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-4, 40 + i * 30); ctx.lineTo(4, 44 + i * 30); ctx.stroke(); }
      // gem nodes
      for (const ny of [50, 120]) {
        ctx.fillStyle = g2;
        ctx.save(); ctx.translate(0, ny); ctx.rotate(Math.PI / 4);
        ctx.fillRect(-4, -4, 8, 8);
        ctx.restore();
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillRect(-1, ny - 1, 2, 2);
      }
      // top crystal cluster
      ctx.save();
      ctx.translate(0, 6);
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.moveTo(0, -16); ctx.lineTo(6, 0); ctx.lineTo(0, 8); ctx.lineTo(-6, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.beginPath(); ctx.moveTo(0, -16); ctx.lineTo(6, 0); ctx.lineTo(0, -2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = g1;
      ctx.beginPath(); ctx.moveTo(-8, -8); ctx.lineTo(-4, -18); ctx.lineTo(-2, -4); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(8, -8); ctx.lineTo(4, -18); ctx.lineTo(2, -4); ctx.closePath(); ctx.fill();
      ctx.restore();
      if (d.extra === 'bamboo') {
        ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5;
        for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(-3, 26 + i * 28); ctx.lineTo(3, 28 + i * 28); ctx.stroke(); }
      }
      break;
    }
    case 'mace': {
      if (flash > 0) flashStar(ctx, 30, flash, g2r, ringStyle ? 'ring' : 'star');
      // shaft
      ctx.fillStyle = g1; rr(ctx, -3.5, 24, 7, 150, 3); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.fillRect(-3.5, 26, 1.2, 146);
      // orb head
      const orbG = ctx.createRadialGradient(-5, 2, 2, 0, 8, 18);
      orbG.addColorStop(0, '#ffffff');
      orbG.addColorStop(0.4, g2);
      orbG.addColorStop(1, '#1a1a22');
      ctx.fillStyle = orbG;
      ctx.beginPath(); ctx.arc(0, 8, 16, 0, Math.PI * 2); ctx.fill();
      // spikes
      ctx.fillStyle = d.extra === 'gold' ? g2 : '#5a5f68';
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
        ctx.save();
        ctx.translate(Math.cos(a) * 15, 8 + Math.sin(a) * 15);
        ctx.rotate(a);
        ctx.beginPath(); ctx.moveTo(0, -3); ctx.lineTo(6, 0); ctx.lineTo(0, 3); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
      // band
      ctx.fillStyle = g1; rr(ctx, -8, 22, 16, 8, 3); ctx.fill();
      ctx.fillStyle = g2; ctx.fillRect(-8, 24, 16, 2);
      // grip wrap
      ctx.strokeStyle = g2; ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.moveTo(-4, 60 + i * 18); ctx.lineTo(4, 64 + i * 18); ctx.stroke(); }
      ctx.fillStyle = g1; rr(ctx, -6, 170, 12, 30, 5); ctx.fill();
      break;
    }
    case 'cross': {
      if (flash > 0) flashStar(ctx, 30, flash, g2r, 'ring');
      ctx.strokeStyle = g1; ctx.lineWidth = 10; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, 12); ctx.lineTo(0, 190); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-26, 60); ctx.lineTo(26, 60); ctx.stroke();
      ctx.strokeStyle = g2; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, 12); ctx.lineTo(0, 190); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-26, 60); ctx.lineTo(26, 60); ctx.stroke();
      // gold trim tips
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(0, 190, 5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(-26, 60, 4, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(26, 60, 4, 0, Math.PI * 2); ctx.fill();
      const orb = ctx.createRadialGradient(0, 8, 0, 0, 8, 12);
      orb.addColorStop(0, '#fff');
      orb.addColorStop(0.5, g2);
      orb.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = orb;
      ctx.beginPath(); ctx.arc(0, 8, 12, 0, Math.PI * 2); ctx.fill();
      break;
    }
  }
  ctx.restore();
}
