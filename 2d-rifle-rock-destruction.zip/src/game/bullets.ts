export type V = { x: number; y: number };

export interface Bullet {
  x: number; y: number; vx: number; vy: number;
  arch: string; rgb: string;
  dmg: number; splash: number; splashDmg: number;
  trail: V[]; maxTrail: number;
  life: number;
  rot: number; spinSpd: number;
  pierce: number; bounce: number; grav: number;
  homing: number;
  size: number;
  wobble: number;
  fx?: string;
  ox?: number;
  oy?: number;
  scl?: number;
}

export const IS_LASER = (arch: string) => arch === 'laser';

const TAU = Math.PI * 2;
function rand2(a: number, b: number) { return a + Math.random() * (b - a); }

function glow(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, rgb: string, a: number) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, `rgba(${rgb},${a})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
}

function starShape(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, n: number, inner: number, rot: number) {
  ctx.beginPath();
  for (let i = 0; i < n * 2; i++) {
    const rr = i % 2 === 0 ? r : r * inner;
    const a = rot + (i / (n * 2)) * TAU;
    const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.closePath();
}

function trailDraw(ctx: CanvasRenderingContext2D, b: Bullet, rgb: string | ((i: number) => string), w1: number, a1: number, w2?: number, a2?: number) {
  if (b.trail.length < 2) return;
  const passes: [number, number][] = w2 ? [[w1, a1], [w2, a2!]] : [[w1, a1]];
  for (const [lw, la] of passes) {
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.lineWidth = lw;
    if (typeof rgb === 'string') {
      ctx.strokeStyle = `rgba(${rgb},${la})`;
      ctx.beginPath();
      b.trail.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    } else {
      for (let i = 0; i < b.trail.length - 1; i++) {
        ctx.strokeStyle = rgb(i);
        ctx.beginPath(); ctx.moveTo(b.trail[i].x, b.trail[i].y); ctx.lineTo(b.trail[i + 1].x, b.trail[i + 1].y); ctx.stroke();
      }
      ctx.strokeStyle = rgb(b.trail.length);
      ctx.beginPath(); ctx.moveTo(b.trail[b.trail.length - 1].x, b.trail[b.trail.length - 1].y); ctx.lineTo(b.x, b.y); ctx.stroke();
    }
  }
}

export function drawBullet(ctx: CanvasRenderingContext2D, b: Bullet, t: number) {
  const [r, g, bl] = b.rgb.split(',').map(Number);
  const vel = Math.hypot(b.vx, b.vy) || 1;
  const ux = b.vx / vel, uy = b.vy / vel;
  const px = -uy, py = ux; // perpendicular
  const ang = Math.atan2(b.vy, b.vx);
  ctx.save();
  if (b.scl && b.scl !== 1) {
    ctx.translate(b.x, b.y);
    ctx.scale(b.scl, b.scl);
    ctx.translate(-b.x, -b.y);
  }
  ctx.globalCompositeOperation = 'lighter';
  const A = b.arch;

  if (A === 'tracer') {
    // slanted bolt streak + chevrons
    const g2 = ctx.createLinearGradient(b.x, b.y, b.x + ux * 34, b.y + uy * 34);
    g2.addColorStop(0, `rgba(${b.rgb},0.95)`);
    g2.addColorStop(1, `rgba(${b.rgb},0)`);
    ctx.strokeStyle = g2; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 34, b.y + uy * 34); ctx.stroke();
    ctx.strokeStyle = `rgba(255,240,200,0.8)`; ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      const d = 8 + i * 10;
      ctx.beginPath();
      ctx.moveTo(b.x + ux * d + px * 4, b.y + uy * d + py * 4);
      ctx.lineTo(b.x + ux * (d + 5), b.y + uy * (d + 5));
      ctx.lineTo(b.x + ux * d - px * 4, b.y + uy * d - py * 4);
      ctx.stroke();
    }
    glow(ctx, b.x, b.y, 10, b.rgb, 0.8);
    ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 14, b.y + uy * 14); ctx.stroke();
  } else if (A === 'minibolt') {
    // twin parallel slim bolts
    for (const s of [-3.2, 3.2]) {
      const g2 = ctx.createLinearGradient(b.x + px * s, b.y + py * s, b.x + px * s + ux * 24, b.y + py * s + uy * 24);
      g2.addColorStop(0, `rgba(${b.rgb},0.9)`);
      g2.addColorStop(1, `rgba(${b.rgb},0)`);
      ctx.strokeStyle = g2; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(b.x + px * s, b.y + py * s); ctx.lineTo(b.x + px * s + ux * 24, b.y + py * s + uy * 24); ctx.stroke();
    }
    glow(ctx, b.x, b.y, 8, b.rgb, 0.7);
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(b.x, b.y, 1.8, 0, TAU); ctx.fill();
  } else if (A === 'nail') {
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 20, b.y + uy * 20); ctx.stroke();
    ctx.strokeStyle = `rgba(${b.rgb},0.5)`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(b.x + px * 3, b.y + py * 3); ctx.lineTo(b.x + px * 3 + ux * 14, b.y + py * 3 + uy * 14); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(b.x - px * 3, b.y - py * 3); ctx.lineTo(b.x - px * 3 + ux * 14, b.y - py * 3 + uy * 14); ctx.stroke();
    glow(ctx, b.x, b.y, 6, b.rgb, 0.6);
  } else if (A === 'gold') {
    const g2 = ctx.createLinearGradient(b.x, b.y, b.x + ux * 36, b.y + uy * 36);
    g2.addColorStop(0, 'rgba(255,235,150,0.95)');
    g2.addColorStop(1, 'rgba(255,190,60,0)');
    ctx.strokeStyle = g2; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 36, b.y + uy * 36); ctx.stroke();
    glow(ctx, b.x, b.y, 12, b.rgb, 0.8);
    ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 16, b.y + uy * 16); ctx.stroke();
    for (let i = 0; i < 3; i++) {
      const a = t * 6 + i * 2.1;
      ctx.fillStyle = `rgba(255,240,180,${0.5 + Math.sin(t * 10 + i) * 0.4})`;
      starShape(ctx, b.x + ux * 12 + Math.cos(a) * 8, b.y + uy * 12 + Math.sin(a) * 8, 3, 4, 0.35, t * 3);
      ctx.fill();
    }
  } else if (A === 'rail') {
    const jit = Math.sin(t * 90) * 1.5;
    for (const [lw, la, col] of [[14, 0.18, b.rgb], [7, 0.5, b.rgb], [3, 1, '255,255,255']] as const) {
      ctx.strokeStyle = `rgba(${col},${la})`;
      ctx.lineWidth = lw; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + jit * (lw > 6 ? 1.4 : 0.3), b.y + uy * 70); ctx.stroke();
    }
    glow(ctx, b.x, b.y, 13, b.rgb, 0.9);
    // hex charges along trail
    for (let i = 0; i < 3; i++) {
      const d = 18 + i * 16;
      ctx.strokeStyle = `rgba(${b.rgb},${0.6 - i * 0.15})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let k = 0; k <= 6; k++) {
        const a = (k / 6) * TAU;
        const hx = b.x + ux * d + Math.cos(a) * 4, hy = b.y + uy * d + Math.sin(a) * 4;
        k ? ctx.lineTo(hx, hy) : ctx.moveTo(hx, hy);
      }
      ctx.closePath(); ctx.stroke();
    }
  } else if (A === 'storm') {
    const jit = Math.sin(t * 90) * 1.5;
    for (const [lw, la, col] of [[24, 0.14, b.rgb], [12, 0.4, b.rgb], [4, 1, '255,255,255']] as const) {
      ctx.strokeStyle = `rgba(${col},${la})`;
      ctx.lineWidth = lw; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + jit * (lw > 6 ? 1.4 : 0.3), b.y + uy * 84); ctx.stroke();
    }
    glow(ctx, b.x, b.y, 20, b.rgb, 0.95);
    ctx.strokeStyle = 'rgba(240,250,255,0.9)';
    ctx.lineWidth = 2;
    // double lightning
    for (const s of [-1, 1]) {
      ctx.beginPath();
      let cx2 = b.x + s * 5, cy2 = b.y + 6;
      ctx.moveTo(cx2, cy2);
      for (let sgm = 0; sgm < 5; sgm++) {
        cx2 += rand2(-8, 8) + s * 1;
        cy2 += uy * rand2(10, 18);
        ctx.lineTo(cx2, cy2);
      }
      ctx.stroke();
    }
  } else if (A === 'sniperbolt') {
    const g2 = ctx.createLinearGradient(b.x, b.y, b.x + ux * 100, b.y + uy * 100);
    g2.addColorStop(0, 'rgba(255,255,255,0.95)');
    g2.addColorStop(0.4, `rgba(${b.rgb},0.6)`);
    g2.addColorStop(1, `rgba(${b.rgb},0)`);
    for (const [lw, la] of [[14, 0.1], [6, 0.3], [2.5, 0.95]] as const) {
      ctx.strokeStyle = `rgba(${la > 0.5 ? '255,255,255' : b.rgb},${la})`;
      ctx.lineWidth = lw; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 100, b.y + uy * 100); ctx.stroke();
    }
    // reticle rings
    for (let i = 0; i < 2; i++) {
      const d = 30 + ((t * 500 + i * 40) % 80);
      ctx.strokeStyle = `rgba(${b.rgb},${0.5 * (1 - d / 110)})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(b.x + ux * d, b.y + uy * d, 8 + d * 0.2, 0, TAU); ctx.stroke();
    }
    glow(ctx, b.x, b.y, 16, b.rgb, 0.9);
  } else if (A === 'galaxy') {
    trailDraw(ctx, b, (i: number) => `hsl(${(260 + t * 300 + i * 14) % 360},90%,70%)`, 6, 0.25, 2.5, 0.7);
    glow(ctx, b.x, b.y, 13, b.rgb, 0.9);
    ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = 2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + ux * 18, b.y + uy * 18); ctx.stroke();
    for (let i = 0; i < 4; i++) {
      const a = t * 4 + i * 1.7;
      const rad = 9 + Math.sin(t * 3 + i) * 4;
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillRect(b.x + Math.cos(a) * rad - 1, b.y + Math.sin(a) * rad - 1, 2, 2);
    }
  } else if (A === 'rainbow') {
    trailDraw(ctx, b, (i: number) => `hsl(${(t * 400 + i * 30) % 360},95%,65%)`, 7, 0.3, 3, 0.8);
    const h = (t * 500) % 360;
    glow(ctx, b.x, b.y, 15, '255,255,255', 0.35);
    ctx.fillStyle = `hsl(${h},95%,70%)`;
    ctx.beginPath(); ctx.arc(b.x, b.y, 5.5, 0, TAU); ctx.fill();
    ctx.strokeStyle = `hsl(${(h + 120) % 360},95%,70%)`;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(b.x, b.y, 8, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.beginPath(); ctx.arc(b.x - 1.5, b.y - 1.5, 2, 0, TAU); ctx.fill();
  } else if (A === 'plasma') {
    trailDraw(ctx, b, b.rgb, 9, 0.18, 4, 0.5);
    const pulse = 1 + Math.sin(t * 22) * 0.18;
    glow(ctx, b.x, b.y, 17 * pulse, b.rgb, 0.85);
    // torus rings
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = `rgba(${b.rgb},${0.8 - i * 0.2})`;
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(b.x, b.y, 10 * pulse, 4 * pulse, t * 3 + i * 1.05, 0, TAU); ctx.stroke();
    }
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(b.x, b.y, 4 * pulse, 0, TAU); ctx.fill();
    // orbiting sparks
    for (let i = 0; i < 2; i++) {
      const a = t * 8 + i * Math.PI;
      ctx.fillStyle = `rgba(${b.rgb},0.9)`;
      ctx.beginPath(); ctx.arc(b.x + Math.cos(a) * 13, b.y + Math.sin(a) * 13, 2, 0, TAU); ctx.fill();
    }
  } else if (A === 'magnet') {
    trailDraw(ctx, b, b.rgb, 6, 0.2, 3, 0.5);
    glow(ctx, b.x, b.y, 16, b.rgb, 0.7);
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(t * 4);
    // horseshoe magnet
    ctx.strokeStyle = '#c882ff'; ctx.lineWidth = 6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(0, 0, 7, Math.PI * 0.1, Math.PI * 0.9); ctx.stroke();
    ctx.fillStyle = '#ff5a6a';
    ctx.fillRect(-9.5, -2, 5, 7);
    ctx.fillRect(4.5, -2, 5, 7);
    // field arcs
    ctx.strokeStyle = `rgba(${b.rgb},0.7)`; ctx.lineWidth = 1.5;
    for (let i = 0; i < 2; i++) {
      ctx.beginPath(); ctx.arc(0, 0, 12 + i * 4, t * 6 + i * Math.PI, t * 6 + i * Math.PI + 1.2); ctx.stroke();
    }
    ctx.restore();
  } else if (A === 'unicorn') {
    trailDraw(ctx, b, (i: number) => `hsl(${(t * 300 + i * 40) % 360},90%,80%)`, 5, 0.35, 2, 0.7);
    glow(ctx, b.x, b.y, 15, '255,200,240', 0.8);
    // rainbow halo
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = `hsla(${(t * 200 + i * 100) % 360},90%,70%,0.8)`;
      ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.arc(b.x, b.y, 9 + i * 3, t * 5 + i, t * 5 + i + 2.2); ctx.stroke();
    }
    // mini unicorn head
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.ellipse(0, 0, 5, 4, 0, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-4, -2); ctx.lineTo(-8, -1); ctx.lineTo(-4, 2); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-5, -3); ctx.lineTo(-9, -7); ctx.stroke();
    ctx.fillStyle = '#ff8ad8';
    ctx.beginPath(); ctx.arc(1.5, 0.5, 1, 0, TAU); ctx.fill();
    ctx.restore();
  } else if (A === 'ufo') {
    glow(ctx, b.x, b.y, 20, b.rgb, 0.7);
    // beam cone
    const bg2 = ctx.createLinearGradient(b.x, b.y, b.x, b.y + 26);
    bg2.addColorStop(0, `rgba(${b.rgb},0.5)`);
    bg2.addColorStop(1, `rgba(${b.rgb},0)`);
    ctx.fillStyle = bg2;
    ctx.beginPath(); ctx.moveTo(b.x - 4, b.y + 4); ctx.lineTo(b.x + 4, b.y + 4); ctx.lineTo(b.x + 10, b.y + 26); ctx.lineTo(b.x - 10, b.y + 26); ctx.closePath(); ctx.fill();
    // saucer
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.fillStyle = '#b8c4d8';
    ctx.beginPath(); ctx.ellipse(0, 0, 12, 4.5, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#8df0ff';
    ctx.beginPath(); ctx.ellipse(0, -3, 6, 4, 0, Math.PI, 0); ctx.fill();
    for (let i = 0; i < 3; i++) {
      const on = Math.sin(t * 10 + i * 2) > 0;
      ctx.fillStyle = on ? '#ffd23f' : '#5a6470';
      ctx.beginPath(); ctx.arc(-6 + i * 6, 1, 1.4, 0, TAU); ctx.fill();
    }
    ctx.restore();
  } else if (A === 'bubble') {
    ctx.strokeStyle = `hsla(${(t * 200) % 360},70%,80%,0.9)`; ctx.lineWidth = 2;
    ctx.fillStyle = `rgba(${b.rgb},0.15)`;
    ctx.beginPath(); ctx.arc(b.x, b.y, 7, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = `hsla(${(t * 200 + 140) % 360},70%,80%,0.6)`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(b.x, b.y, 8.5, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(b.x - 2, b.y - 2, 3.5, Math.PI * 0.9, Math.PI * 1.6); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.beginPath(); ctx.arc(b.x + 2, b.y + 2.5, 1, 0, TAU); ctx.fill();
  } else if (A === 'blackhole') {
    glow(ctx, b.x, b.y, 24, b.rgb, 0.7);
    ctx.fillStyle = '#050308';
    ctx.beginPath(); ctx.arc(b.x, b.y, 8, 0, TAU); ctx.fill();
    // accretion disc
    for (let i = 0; i < 2; i++) {
      ctx.strokeStyle = `rgba(${b.rgb},${0.9 - i * 0.3})`; ctx.lineWidth = 3 - i;
      ctx.beginPath(); ctx.ellipse(b.x, b.y, 14 - i * 2, 5, t * 3 + i * 1.4, 0, TAU); ctx.stroke();
    }
    // falling matter streaks
    for (let i = 0; i < 4; i++) {
      const a = t * 5 + i * 1.57;
      ctx.strokeStyle = `rgba(${b.rgb},0.6)`; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(b.x + Math.cos(a) * 18, b.y + Math.sin(a) * 18);
      ctx.quadraticCurveTo(b.x + Math.cos(a + 0.5) * 12, b.y + Math.sin(a + 0.5) * 12, b.x + Math.cos(a + 1) * 8, b.y + Math.sin(a + 1) * 8);
      ctx.stroke();
    }
  } else if (A === 'portal') {
    glow(ctx, b.x, b.y, 18, b.rgb, 0.7);
    ctx.strokeStyle = `rgba(${b.rgb},0.9)`;
    for (let i = 0; i < 3; i++) {
      ctx.lineWidth = 2.5 - i * 0.5;
      ctx.beginPath(); ctx.arc(b.x, b.y, 6 + i * 4, t * 5 + i * 2, t * 5 + i * 2 + 2.4); ctx.stroke();
    }
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(b.x, b.y, 2.5, 0, TAU); ctx.fill();
  } else if (A === 'oblit') {
    glow(ctx, b.x, b.y, 32, b.rgb, 0.9);
    // shockwave pulse
    const sk = (t * 2) % 1;
    ctx.strokeStyle = `rgba(${b.rgb},${0.5 * (1 - sk)})`; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(b.x, b.y, 16 + sk * 18, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#1a0505';
    ctx.beginPath(); ctx.arc(b.x, b.y, 10, 0, TAU); ctx.fill();
    starShape(ctx, b.x, b.y, 19, 8, 0.5, t * 2);
    ctx.fillStyle = `rgba(${b.rgb},0.95)`; ctx.fill();
    ctx.fillStyle = `rgba(255,${120 + Math.sin(t * 20) * 60},80,0.95)`;
    ctx.beginPath(); ctx.arc(b.x, b.y, 5, 0, TAU); ctx.fill();
  } else if (A === 'charge') {
    const s = b.size;
    glow(ctx, b.x, b.y, 16 * s, b.rgb, 0.85);
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    ctx.beginPath(); ctx.arc(b.x, b.y, 4 * s, 0, TAU); ctx.fill();
    ctx.strokeStyle = `rgba(${b.rgb},0.8)`; ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath(); ctx.arc(b.x, b.y, 7 * s + i * 4 * s, t * 8 + i, t * 8 + i + 1.6); ctx.stroke();
    }
    for (let i = 0; i < 3; i++) {
      const a = t * 10 + i * 2.09;
      ctx.fillStyle = `rgba(${b.rgb},0.9)`;
      ctx.beginPath(); ctx.arc(b.x + Math.cos(a) * 12 * s, b.y + Math.sin(a) * 12 * s, 1.8, 0, TAU); ctx.fill();
    }
  } else if (A === 'holy') {
    glow(ctx, b.x, b.y, 28, b.rgb, 0.9);
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(Math.sin(t * 2) * 0.15);
    ctx.fillStyle = 'rgba(255,255,240,0.95)';
    ctx.fillRect(-2.5, -12, 5, 24);
    ctx.fillRect(-12, -2.5, 24, 5);
    ctx.restore();
    const s = (Math.sin(t * 6) + 1) / 2;
    ctx.strokeStyle = `rgba(255,245,200,${0.4 + s * 0.5})`; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(b.x, b.y, 15 + s * 4, 0, TAU); ctx.stroke();
    // halo rays
    for (let i = 0; i < 8; i++) {
      const a = t + (i / 8) * TAU;
      ctx.strokeStyle = `rgba(255,245,200,${0.3 + s * 0.3})`; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(b.x + Math.cos(a) * 17, b.y + Math.sin(a) * 17);
      ctx.lineTo(b.x + Math.cos(a) * 22, b.y + Math.sin(a) * 22);
      ctx.stroke();
    }
  } else if (A === 'chrono') {
    glow(ctx, b.x, b.y, 17, b.rgb, 0.7);
    ctx.fillStyle = 'rgba(245,245,255,0.95)';
    ctx.beginPath(); ctx.arc(b.x, b.y, 8.5, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#334'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(b.x, b.y, 8.5, 0, TAU); ctx.stroke();
    // tick marks
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * TAU;
      ctx.strokeStyle = '#667'; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(b.x + Math.cos(a) * 6.5, b.y + Math.sin(a) * 6.5);
      ctx.lineTo(b.x + Math.cos(a) * 8, b.y + Math.sin(a) * 8);
      ctx.stroke();
    }
    ctx.strokeStyle = '#2255ff'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + Math.cos(t * 12) * 6, b.y + Math.sin(t * 12) * 6); ctx.stroke();
    ctx.strokeStyle = '#ff3344'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + Math.cos(t * 3) * 4, b.y + Math.sin(t * 3) * 4); ctx.stroke();
  } else if (A === 'spark') {
    trailDraw(ctx, b, b.rgb, 3, 0.4);
    glow(ctx, b.x, b.y, 14, b.rgb, 0.8);
    starShape(ctx, b.x, b.y, 9 + Math.sin(t * 10) * 2, 4, 0.35, b.rot);
    ctx.fillStyle = `rgba(${b.rgb},0.95)`; ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(b.x, b.y, 2.5, 0, TAU); ctx.fill();
    for (let i = 0; i < 3; i++) {
      const a = t * 7 + i * 2.09;
      ctx.fillStyle = `rgba(${b.rgb},0.8)`;
      ctx.beginPath(); ctx.arc(b.x + Math.cos(a) * 12, b.y + Math.sin(a) * 12, 1.6, 0, TAU); ctx.fill();
    }
  } else if (A === 'pixel') {
    const s = 5;
    // stepped 8-bit trail
    for (let i = 3; i >= 1; i--) {
      ctx.fillStyle = `rgba(${b.rgb},${0.35 - i * 0.08})`;
      const d = i * 10;
      ctx.fillRect(b.x + ux * d - s / 2, b.y + uy * d - s / 2, s, s);
    }
    ctx.fillStyle = `rgba(${b.rgb},0.95)`;
    ctx.fillRect(b.x - s, b.y - s, s * 2, s * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(b.x - s + 1.5, b.y - s + 1.5, s - 3, s - 3);
  } else if (A === 'confetti') {
    const cols = ['#ff5a8a', '#ffd23f', '#5ef2ff', '#9ae86a', '#c06eff', '#ff8a3c'];
    for (let i = 0; i < 6; i++) {
      ctx.save();
      ctx.translate(b.x + Math.sin(b.rot * 2 + i * 1.3) * 7, b.y + Math.cos(b.rot * 1.7 + i) * 7);
      ctx.rotate(b.rot * 1.5 + i);
      ctx.fillStyle = cols[i % cols.length];
      ctx.fillRect(-3, -1.5, 6, 3);
      ctx.restore();
    }
    glow(ctx, b.x, b.y, 10, '255,255,255', 0.25);
  } else if (A === 'flame') {
    const k = b.life / 0.45;
    const s = (8 + 8 * k) * (1 + Math.sin(t * 40 + b.wobble) * 0.2);
    const g2 = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, s);
    g2.addColorStop(0, `rgba(255,240,170,${0.9 * k})`);
    g2.addColorStop(0.5, `rgba(255,${120 + Math.floor(k * 80)},40,${0.7 * k})`);
    g2.addColorStop(1, 'rgba(255,60,20,0)');
    ctx.fillStyle = g2;
    ctx.beginPath(); ctx.arc(b.x, b.y, s, 0, TAU); ctx.fill();
  } else if (A === 'sonic') {
    for (let i = 0; i < 3; i++) {
      const rr = 4 + ((t * 60 + i * 8) % 24);
      ctx.strokeStyle = `rgba(${b.rgb},${1 - rr / 26})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(b.x, b.y, rr, 0, TAU); ctx.stroke();
    }
    glow(ctx, b.x, b.y, 10, b.rgb, 0.7);
    // side wave ticks
    for (let i = 0; i < 2; i++) {
      const a = t * 10 + i * Math.PI;
      ctx.strokeStyle = `rgba(${b.rgb},0.5)`; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(b.x, b.y, 14, a, a + 0.8); ctx.stroke();
    }
  } else if (A === 'tornado') {
    for (let i = 0; i < 4; i++) {
      const off = i * 8;
      const w = 4 + i * 2.5;
      ctx.strokeStyle = `rgba(${b.rgb},${0.8 - i * 0.15})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(b.x + Math.sin(t * 14 + i) * 3, b.y + off, w, 0.3, TAU - 2 + t * 10);
      ctx.stroke();
    }
    glow(ctx, b.x, b.y, 13, '255,255,255', 0.4);
  } else if (A === 'meteor') {
    trailDraw(ctx, b, (i: number) => `rgba(255,${140 - i * 8},40,${0.55 - i * 0.02})`, 9, 0.4, 4, 0.7);
    glow(ctx, b.x, b.y, 17, '255,150,60', 0.85);
    ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.rot);
    ctx.fillStyle = '#6a4a3a';
    ctx.beginPath(); ctx.arc(0, 0, 7, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(40,25,20,0.6)';
    ctx.beginPath(); ctx.arc(2, -2, 2, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(-2.5, 2, 1.5, 0, TAU); ctx.fill();
    ctx.fillStyle = `rgba(255,140,50,${0.6 + Math.sin(t * 15) * 0.3})`;
    ctx.beginPath(); ctx.arc(-2, -2, 4, 0, TAU); ctx.fill();
    ctx.restore();
    // embers
    for (let i = 0; i < 3; i++) {
      const a = t * 6 + i * 2.1;
      ctx.fillStyle = `rgba(255,${140 + i * 20},50,0.7)`;
      ctx.beginPath(); ctx.arc(b.x - ux * 12 + Math.cos(a) * 4, b.y - uy * 12 + Math.sin(a) * 4, 1.5, 0, TAU); ctx.fill();
    }
  } else {
    // ---- solid projectiles, normal composite ----
    ctx.restore();
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(A === 'pellet' || A === 'water' || A === 'snowball' || A === 'honey' || A === 'acid' || A === 'ink' || A === 'bolt' || A === 'dart' ? ang + Math.PI / 2 : b.rot);
    switch (A) {
      case 'bolt':
        ctx.fillStyle = '#a87840'; ctx.fillRect(-1.5, -14, 3, 26);
        ctx.fillStyle = '#d8e2ec';
        ctx.beginPath(); ctx.moveTo(0, -20); ctx.lineTo(-3.5, -12); ctx.lineTo(3.5, -12); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#c03a3a'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(-4, 10); ctx.lineTo(0, 4); ctx.lineTo(4, 10); ctx.stroke();
        break;
      case 'dart':
        ctx.fillStyle = '#3a8a4a'; ctx.fillRect(-1.2, -12, 2.4, 24);
        ctx.fillStyle = '#c8f0c8';
        ctx.beginPath(); ctx.moveTo(0, -16); ctx.lineTo(-2.5, -10); ctx.lineTo(2.5, -10); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(240,255,240,0.9)'; ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.moveTo(-4, 10); ctx.lineTo(0, 4); ctx.lineTo(4, 10); ctx.stroke();
        break;
      case 'pebble':
        ctx.fillStyle = '#a89a86'; ctx.beginPath(); ctx.arc(0, 0, 5, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.arc(1.5, 1, 1.5, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.beginPath(); ctx.arc(-1.5, -1.5, 1, 0, TAU); ctx.fill();
        break;
      case 'bullet':
        // brass bullet
        ctx.fillStyle = '#d8b04a';
        ctx.beginPath();
        ctx.moveTo(-2.6, 8); ctx.lineTo(-2.6, -2); ctx.quadraticCurveTo(0, -9, 2.6, -2); ctx.lineTo(2.6, 8);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#8a6a20'; ctx.fillRect(-3, 6, 6, 2.5);
        ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(-2, -4, 1.2, 10);
        break;
      case 'pellet':
        ctx.fillStyle = `rgb(${r},${g},${bl})`; ctx.beginPath(); ctx.arc(0, 0, 5, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.beginPath(); ctx.arc(-1.5, -1.5, 1.6, 0, TAU); ctx.fill();
        starShape(ctx, 0, 0, 8, 4, 0.25, t * 5);
        ctx.strokeStyle = `rgba(${r},${g},${bl},0.5)`; ctx.lineWidth = 1; ctx.stroke();
        break;
      case 'water':
        ctx.fillStyle = `rgba(${r},${g},${bl},0.9)`;
        ctx.beginPath(); ctx.moveTo(0, -9); ctx.quadraticCurveTo(6, 0, 0, 6); ctx.quadraticCurveTo(-6, 0, 0, -9); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.beginPath(); ctx.arc(-1.5, -1, 1.5, 0, TAU); ctx.fill();
        ctx.fillStyle = `rgba(${r},${g},${bl},0.5)`;
        ctx.beginPath(); ctx.arc(3, 9, 1.3, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(-2.5, 11, 1, 0, TAU); ctx.fill();
        break;
      case 'snowball':
        ctx.fillStyle = '#f4f9ff';
        ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(3, 3, 4, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(-3, 2.5, 3.5, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(160,190,230,0.6)';
        ctx.beginPath(); ctx.arc(2, 2.5, 1.2, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        for (let i = 0; i < 2; i++) {
          const a = t * 4 + i * 2.5;
          ctx.beginPath(); ctx.arc(Math.cos(a) * 7, Math.sin(a) * 7, 0.8, 0, TAU); ctx.fill();
        }
        break;
      case 'honey':
        ctx.fillStyle = `rgba(${r},${g},${bl},0.95)`;
        ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(0, 8, 2, 3.5 + Math.sin(t * 6) * 1, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.arc(-2, -2, 1.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(120,70,10,0.5)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(0, 0, 4, 0.5, 2); ctx.stroke();
        break;
      case 'coconut':
        ctx.fillStyle = '#7a5230'; ctx.beginPath(); ctx.arc(0, 0, 8, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(60,38,18,0.5)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(0, 0, 6.5, 0.4, 2.2); ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, 5, -2, -0.4); ctx.stroke();
        ctx.fillStyle = '#4a2e14';
        ctx.beginPath(); ctx.arc(-2, -2, 1.4, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(2.5, -0.5, 1.4, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(-0.5, 2.5, 1.4, 0, TAU); ctx.fill();
        break;
      case 'pencil':
        ctx.rotate(ang + Math.PI / 2);
        ctx.fillStyle = '#ffd24a'; ctx.fillRect(-2.5, -8, 5, 12);
        ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.fillRect(0, -8, 2.5, 12);
        ctx.fillStyle = '#f5d3a0'; ctx.beginPath(); ctx.moveTo(-2.5, -8); ctx.lineTo(0, -13); ctx.lineTo(2.5, -8); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#333'; ctx.beginPath(); ctx.moveTo(-1, -11.3); ctx.lineTo(0, -13); ctx.lineTo(1, -11.3); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#ff8a8a'; ctx.fillRect(-2.5, 4, 5, 3.5);
        ctx.fillStyle = '#b8b8c0'; ctx.fillRect(-2.5, 6, 5, 1.5);
        break;
      case 'sandal':
        ctx.fillStyle = '#e8503a';
        ctx.beginPath(); ctx.ellipse(0, 2, 7, 10, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.beginPath(); ctx.ellipse(0, 2, 4.5, 7, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#ffd0b0'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, -3); ctx.lineTo(-5, 5); ctx.moveTo(0, -3); ctx.lineTo(5, 5); ctx.stroke();
        break;
      case 'paint':
        ctx.fillStyle = `rgb(${r},${g},${bl})`; ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.beginPath(); ctx.arc(-2, -2, 2, 0, TAU); ctx.fill();
        for (let i = 0; i < 3; i++) {
          const a = b.rot + i * 2.1;
          ctx.fillStyle = `rgba(${r},${g},${bl},0.6)`;
          ctx.beginPath(); ctx.arc(Math.cos(a) * 8, Math.sin(a) * 8, 1.5, 0, TAU); ctx.fill();
        }
        break;
      case 'fish': {
        const wag = Math.sin(t * 14) * 0.3;
        ctx.fillStyle = '#5aa8e0';
        ctx.beginPath(); ctx.ellipse(0, 0, 8, 5, 0, 0, TAU); ctx.fill();
        ctx.save();
        ctx.translate(7, 0); ctx.rotate(wag);
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(5, -4); ctx.lineTo(5, 4); ctx.closePath();
        ctx.fillStyle = '#3d8ac0'; ctx.fill();
        ctx.restore();
        ctx.fillStyle = '#3d8ac0';
        ctx.beginPath(); ctx.moveTo(-2, -4); ctx.lineTo(1, -8); ctx.lineTo(3, -4); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.beginPath(); ctx.ellipse(-1, 1.5, 4, 1.5, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-4, -1, 1.8, 0, TAU); ctx.fill();
        ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(-4.3, -1, 0.9, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(120,190,240,0.6)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(-1, 0, 3, -0.8, 0.8); ctx.stroke();
        break;
      }
      case 'rocket': case 'bigrocket': {
        const sc = A === 'bigrocket' ? 1.4 : 1;
        ctx.rotate(ang + Math.PI / 2);
        const fl = (6 + Math.random() * 7) * sc;
        const fg2 = ctx.createLinearGradient(0, 8 * sc, 0, 8 * sc + fl * 2);
        fg2.addColorStop(0, 'rgba(255,230,140,0.95)');
        fg2.addColorStop(0.5, 'rgba(255,140,50,0.8)');
        fg2.addColorStop(1, 'rgba(255,80,30,0)');
        ctx.fillStyle = fg2;
        ctx.beginPath(); ctx.moveTo(-3 * sc, 8 * sc); ctx.quadraticCurveTo(0, 8 * sc + fl * 2, 3 * sc, 8 * sc); ctx.closePath(); ctx.fill();
        ctx.fillStyle = A === 'bigrocket' ? '#5a6470' : '#8a93a0';
        ctx.fillRect(-3.5 * sc, -9 * sc, 7 * sc, 17 * sc);
        ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillRect(-3.5 * sc, -9 * sc, 2, 17 * sc);
        if (A === 'bigrocket') {
          ctx.fillStyle = '#ff7a3d'; ctx.fillRect(-3.5 * sc, -2 * sc, 7 * sc, 3);
          ctx.fillStyle = '#ffd870';
          ctx.beginPath(); ctx.arc(0, 3 * sc, 2, 0, TAU); ctx.fill();
        }
        ctx.fillStyle = '#ff7a3d';
        ctx.beginPath(); ctx.moveTo(-3.5 * sc, -9 * sc); ctx.lineTo(0, -14 * sc); ctx.lineTo(3.5 * sc, -9 * sc); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#4a525c';
        ctx.beginPath(); ctx.moveTo(-3.5 * sc, 5 * sc); ctx.lineTo(-7 * sc, 9 * sc); ctx.lineTo(-3.5 * sc, 8 * sc); ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.moveTo(3.5 * sc, 5 * sc); ctx.lineTo(7 * sc, 9 * sc); ctx.lineTo(3.5 * sc, 8 * sc); ctx.closePath(); ctx.fill();
        break;
      }
      case 'banana':
        ctx.fillStyle = '#ffe93c';
        ctx.beginPath(); ctx.arc(0, -3, 8, 0.15 * Math.PI, 0.85 * Math.PI); ctx.arc(0, 3, 8, 0.85 * Math.PI, 0.15 * Math.PI, true); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(180,140,20,0.5)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(0, 0, 8, 0.35 * Math.PI, 0.65 * Math.PI); ctx.stroke();
        ctx.fillStyle = '#8a6a20'; ctx.fillRect(-1.5, -10.5, 3, 3);
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath(); ctx.arc(-3, 5, 1, 0, TAU); ctx.fill();
        break;
      case 'harpoon':
        ctx.rotate(ang + Math.PI / 2);
        ctx.strokeStyle = '#9ab8cc'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(0, 12); ctx.lineTo(0, -6); ctx.stroke();
        ctx.fillStyle = '#d8e8f4';
        ctx.beginPath(); ctx.moveTo(0, -15); ctx.lineTo(-4.5, -5); ctx.lineTo(4.5, -5); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#9ab8cc'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-4.5, -6); ctx.lineTo(-7, -3);
        ctx.moveTo(4.5, -6); ctx.lineTo(7, -3);
        ctx.moveTo(-3.5, 2); ctx.lineTo(3.5, 2);
        ctx.stroke();
        break;
      case 'chicken': {
        const flap = Math.sin(t * 24) * 0.7;
        // tail feathers
        for (let i = -1; i <= 1; i++) {
          ctx.strokeStyle = i === 0 ? '#ffd23f' : '#f5b83d'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(0, 8); ctx.quadraticCurveTo(i * 4, 12, i * 6, 13); ctx.stroke();
        }
        ctx.fillStyle = '#ffe066';
        ctx.beginPath(); ctx.ellipse(0, 0, 8, 10, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff2a8';
        ctx.beginPath(); ctx.ellipse(0, 2, 5, 6, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#ffd23f';
        ctx.save(); ctx.translate(-7, -2); ctx.rotate(-0.6 - flap); ctx.beginPath(); ctx.ellipse(-4, 0, 5, 3, 0, 0, TAU); ctx.fill(); ctx.restore();
        ctx.save(); ctx.translate(7, -2); ctx.rotate(0.6 + flap); ctx.beginPath(); ctx.ellipse(4, 0, 5, 3, 0, 0, TAU); ctx.fill(); ctx.restore();
        ctx.fillStyle = '#ffe066'; ctx.beginPath(); ctx.arc(0, -9, 4.5, 0, TAU); ctx.fill();
        ctx.fillStyle = '#ff8c2a'; ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(6, -8.5); ctx.lineTo(0, -7); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(2, -10, 0.9, 0, TAU); ctx.fill();
        break;
      }
      case 'seed':
        ctx.fillStyle = '#7ac850'; ctx.beginPath(); ctx.ellipse(0, 1, 5, 6.5, 0.3, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.beginPath(); ctx.arc(-1.5, -1, 1.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#3a8a20'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(0, -5); ctx.quadraticCurveTo(2, -9, 5, -10); ctx.stroke();
        ctx.fillStyle = '#5ad03a';
        ctx.beginPath(); ctx.ellipse(5.5, -10.5, 2.5, 1.4, 0.5, 0, TAU); ctx.fill();
        break;
      case 'pizza':
        ctx.fillStyle = '#f5c04a';
        ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(9, 8); ctx.lineTo(-9, 8); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#ffd878'; ctx.fillRect(-8, 6, 16, 3);
        ctx.fillStyle = 'rgba(255,230,140,0.8)';
        ctx.beginPath(); ctx.moveTo(-2, 9); ctx.quadraticCurveTo(-1, 13, -2.5, 14); ctx.stroke();
        ctx.fillStyle = '#d84a30';
        ctx.beginPath(); ctx.arc(-2, 0, 1.8, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(3, 3, 1.8, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(0, -4, 1.8, 0, TAU); ctx.fill();
        break;
      case 'angklung':
        ctx.rotate(ang + Math.PI / 2);
        ctx.fillStyle = '#c8a050'; ctx.fillRect(-3.5, -11, 7, 22);
        ctx.strokeStyle = '#8a6a30'; ctx.lineWidth = 1;
        ctx.strokeRect(-3.5, -11, 7, 22);
        ctx.fillStyle = '#5a4420';
        ctx.beginPath(); ctx.arc(0, -3, 2, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(0, 4, 2, 0, TAU); ctx.fill();
        // sound waves
        const wa = (t * 4) % 1;
        ctx.strokeStyle = `rgba(255,240,180,${0.7 * (1 - wa)})`; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(0, -13, 4 + wa * 6, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
        break;
      case 'ink': {
        const w2 = 1 + Math.sin(t * 10) * 0.15;
        ctx.fillStyle = `rgba(${r},${g},${bl},0.95)`;
        ctx.beginPath(); ctx.arc(0, 0, 6 * w2, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(5, 4, 3, 0, TAU); ctx.fill();
        // tentacle curls
        ctx.strokeStyle = `rgba(${r},${g},${bl},0.9)`; ctx.lineWidth = 2; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(-4, 5); ctx.quadraticCurveTo(-8, 8, -6, 12); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(4, 6); ctx.quadraticCurveTo(7, 10, 4, 12); ctx.stroke();
        break;
      }
      case 'yoyo':
        ctx.fillStyle = `rgb(${r},${g},${bl})`; ctx.beginPath(); ctx.arc(0, 0, 6.5, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(0, 0, 3, 0, TAU); ctx.fill();
        ctx.fillStyle = `rgb(${r},${g},${bl})`; ctx.beginPath(); ctx.arc(0, 0, 1.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(0, 0, 4.8, t * 6, t * 6 + 2); ctx.stroke();
        break;
      case 'petal':
        for (let i = 0; i < 5; i++) {
          ctx.save();
          ctx.rotate((i / 5) * TAU + b.rot * 0.3);
          ctx.fillStyle = i === 0 ? '#ffd0e0' : `rgba(${r},${g},${bl},0.95)`;
          ctx.beginPath(); ctx.ellipse(0, -4.5, 2.6, 4.5, 0, 0, TAU); ctx.fill();
          ctx.restore();
        }
        ctx.fillStyle = '#fff0a0';
        ctx.beginPath(); ctx.arc(0, 0, 1.8, 0, TAU); ctx.fill();
        break;
      case 'acid':
        ctx.fillStyle = `rgba(${r},${g},${bl},0.9)`;
        ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(0, 8, 1.8, 3 + Math.sin(t * 8) * 1, 0, 0, TAU); ctx.fill();
        // rising bubbles
        for (let i = 0; i < 3; i++) {
          const by = -((t * 20 + i * 9) % 18);
          ctx.fillStyle = `rgba(220,255,160,${0.8 - by / 25})`;
          ctx.beginPath(); ctx.arc(Math.sin(by + i * 2) * 4, by - 2, 1 + (i % 2) * 0.5, 0, TAU); ctx.fill();
        }
        ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.arc(-1.8, -1.8, 1.4, 0, TAU); ctx.fill();
        break;
      case 'shuriken':
        ctx.fillStyle = '#d8e0ec';
        starShape(ctx, 0, 0, 10, 4, 0.3, 0);
        ctx.fill();
        ctx.strokeStyle = 'rgba(120,130,150,0.8)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = '#333a44'; ctx.beginPath(); ctx.arc(0, 0, 2.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(200,215,235,0.4)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(-14, 0); ctx.moveTo(9, 0); ctx.lineTo(14, 0); ctx.stroke();
        break;
      case 'cricket': {
        const wing = Math.sin(t * 40);
        ctx.fillStyle = 'rgba(200,190,150,0.35)';
        ctx.beginPath(); ctx.ellipse(-5, -3, 6, 3, -0.4 + wing * 0.2, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(5, -3, 6, 3, 0.4 - wing * 0.2, 0, TAU); ctx.fill();
        ctx.fillStyle = '#a08040';
        ctx.beginPath(); ctx.ellipse(0, 0, 5, 7, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#6a5020'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-4, -3); ctx.lineTo(-9, -6); ctx.moveTo(4, -3); ctx.lineTo(9, -6);
        ctx.moveTo(-4, 4); ctx.lineTo(-8, 8); ctx.moveTo(4, 4); ctx.lineTo(8, 8);
        ctx.stroke();
        ctx.strokeStyle = '#4a3818'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(-1, -7); ctx.lineTo(-3, -11); ctx.moveTo(1, -7); ctx.lineTo(3, -11); ctx.stroke();
        ctx.fillStyle = '#332a10';
        ctx.beginPath(); ctx.arc(-1.5, -5, 0.8, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(1.5, -5, 0.8, 0, TAU); ctx.fill();
        break;
      }
      case 'card':
        ctx.scale(Math.cos(b.rot * 2) * 0.7 + 0.3, 1);
        ctx.fillStyle = '#fff'; ctx.fillRect(-6, -8, 12, 16);
        ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 1.2; ctx.strokeRect(-5, -7, 10, 14);
        ctx.fillStyle = '#e03040'; ctx.font = 'bold 9px system-ui'; ctx.textAlign = 'center';
        ctx.fillText('A', 0, 4);
        ctx.beginPath(); ctx.moveTo(0, -5); ctx.lineTo(3, -2); ctx.lineTo(0, 1); ctx.lineTo(-3, -2); ctx.closePath(); ctx.fill();
        break;
      case 'shard':
        ctx.fillStyle = `rgba(${r},${g},${bl},0.95)`;
        ctx.beginPath(); ctx.moveTo(0, -11); ctx.lineTo(4, 0); ctx.lineTo(0, 11); ctx.lineTo(-4, 0); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.8)';
        ctx.beginPath(); ctx.moveTo(0, -11); ctx.lineTo(4, 0); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
        // rainbow refraction
        for (let i = 0; i < 3; i++) {
          ctx.strokeStyle = `hsla(${(t * 200 + i * 120) % 360},90%,70%,0.5)`;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(6 + i * 2, 8 + i * 2); ctx.stroke();
        }
        break;
      case 'bee': {
        const w = Math.sin(t * 60) * 0.9;
        ctx.fillStyle = 'rgba(255,255,255,0.75)';
        ctx.beginPath(); ctx.ellipse(-4, -5, 4, 2.5, -0.5 - w * 0.4, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(4, -5, 4, 2.5, 0.5 + w * 0.4, 0, TAU); ctx.fill();
        ctx.fillStyle = '#ffd21e'; ctx.beginPath(); ctx.ellipse(0, 0, 5.5, 4, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#222';
        ctx.fillRect(-5, -1.5, 10, 2);
        ctx.beginPath(); ctx.arc(0, 4.5, 1, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#222'; ctx.lineWidth = 0.8;
        ctx.beginPath(); ctx.moveTo(1, 4.5); ctx.lineTo(2.5, 7); ctx.stroke();
        break;
      }
      case 'keris':
        ctx.rotate(ang + Math.PI / 2);
        ctx.fillStyle = '#e8d0a0';
        ctx.beginPath();
        ctx.moveTo(0, -14); ctx.quadraticCurveTo(4, -6, 0, 0); ctx.quadraticCurveTo(-4, 6, 0, 10);
        ctx.lineTo(0, 14); ctx.lineTo(1.5, 10); ctx.lineTo(1.5, -12);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = `rgba(255,220,140,${0.4 + Math.sin(t * 8) * 0.3})`; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0.5, -13); ctx.quadraticCurveTo(3.5, -6, 0.5, 0); ctx.quadraticCurveTo(-3.5, 6, 0.5, 12); ctx.stroke();
        ctx.fillStyle = '#8a6a20'; ctx.fillRect(-2, 10, 4, 4);
        break;
      case 'firework':
        ctx.rotate(ang + Math.PI / 2);
        ctx.fillStyle = '#e04a8a'; ctx.fillRect(-2.5, -8, 5, 14);
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(0, -9, 2.5 + Math.random() * 1.5, 0, TAU); ctx.fill();
        ctx.fillStyle = `rgba(255,220,120,${Math.random()})`;
        ctx.beginPath(); ctx.arc(rand2(-2, 2), -13, 1.2, 0, TAU); ctx.fill();
        break;
      case 'anchor':
        ctx.strokeStyle = '#8a95a5'; ctx.fillStyle = '#8a95a5';
        ctx.beginPath(); ctx.arc(0, -13, 3, 0, TAU); ctx.lineWidth = 2; ctx.stroke();
        ctx.fillRect(-1.5, -11, 3, 20);
        ctx.beginPath(); ctx.arc(0, 9, 7, 0.1 * Math.PI, 0.9 * Math.PI); ctx.lineWidth = 3.5; ctx.stroke();
        ctx.fillRect(-5, -6, 10, 2.5);
        ctx.fillStyle = '#6a7280';
        ctx.beginPath(); ctx.arc(-6.5, 9, 1.5, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(6.5, 9, 1.5, 0, TAU); ctx.fill();
        break;
      case 'shark':
        ctx.fillStyle = '#8aa8c0';
        ctx.beginPath(); ctx.ellipse(0, 0, 11, 5, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#c8d8e8'; ctx.beginPath(); ctx.ellipse(0, 2.5, 9, 2.5, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#6a8aa4';
        ctx.beginPath(); ctx.moveTo(-2, -4); ctx.lineTo(1, -10); ctx.lineTo(4, -4); ctx.closePath(); ctx.fill();
        const tw = Math.sin(t * 8) * 1.5;
        ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(14, -4 + tw); ctx.lineTo(14, 4 - tw); ctx.closePath(); ctx.fill();
        const jaw = Math.sin(t * 10) * 2;
        ctx.fillStyle = '#4a6a84';
        ctx.beginPath(); ctx.moveTo(-11, 1); ctx.lineTo(-5, 2 + jaw); ctx.lineTo(-11, 4.5); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#fff';
        for (let i = 0; i < 3; i++) {
          ctx.beginPath(); ctx.moveTo(-10 + i * 1.8, 1.4); ctx.lineTo(-9.2 + i * 1.8, 2.4 + jaw * 0.5); ctx.lineTo(-8.4 + i * 1.8, 1.4); ctx.closePath(); ctx.fill();
        }
        ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(-6, -1.5, 0.9, 0, TAU); ctx.fill();
        break;
      case 'disc':
        ctx.fillStyle = `rgb(${r},${g},${bl})`;
        ctx.beginPath(); ctx.ellipse(0, 0, 9, 5.5, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.ellipse(0, 0, 9, 5.5, 0, 0, TAU); ctx.stroke();
        ctx.strokeStyle = `rgba(255,255,255,${0.4 + Math.sin(t * 12) * 0.3})`; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(0, 0, 6, 3.5, 0, t * 8, t * 8 + 1.5); ctx.stroke();
        break;
      default:
        ctx.fillStyle = `rgb(${r},${g},${bl})`;
        ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.beginPath(); ctx.arc(-1.5, -1.5, 2, 0, TAU); ctx.fill();
    }
  }
  ctx.restore();
  ctx.restore();
}
