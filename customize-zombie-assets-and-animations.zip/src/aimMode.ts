/**
 * Global aim arbitration for shoot mode.
 * 'zombie' = the crosshair punches straight through the squad and hits whatever
 * zombie body part sits under the cursor (the squad is only shot as a fallback
 * when no zombie is behind it). 'squad' = the classic behaviour.
 */
export const aim: { mode: 'zombie' | 'squad' } = { mode: 'zombie' };
