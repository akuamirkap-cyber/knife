import { useCallback, useMemo, useRef, useState } from 'react';
import hordePlate from './images/horde-plate.jpg';
import { aim } from './aimMode';
import {
  Activity,
  ArrowDownToLine,
  Box,
  Camera,
  Check,
  ChevronRight,
  Crosshair,
  Download,
  Eye,
  Flame,
  Footprints,
  Grid,
  Heart,
  HeartPulse,
  Layers,
  PenTool,
  RotateCcw,
  RotateCw,
  Shirt,
  Shuffle,
  Skull,
  SlidersHorizontal,
  Smile,
  User,
  Users,
  Volume2,
  VolumeX,
  Wand2,
} from 'lucide-react';
import {
  HitFeedbackEvent,
  SceneViewport,
  SceneViewportHandle,
} from './components/SceneViewport';
import {
  ALL_SKIN_IDS,
  AnimMode,
  CameraPreset,
  CharacterHealthSummary,
  CharacterLoadout,
  DEFAULT_SQUAD_LOADOUTS,
  FACE_META_MAP,
  FaceId,
  FACES_META,
  HitTargetGroup,
  HitZone,
  MeshStats,
  OPEN_FACE_HEADS,
  PART_SLOT_LABELS,
  PartSlot,
  SKIN_META_MAP,
  SkinId,
  SKINS_META,
  StudioBgMode,
  ViewSelection,
} from './models/types';

const PART_ORDER: PartSlot[] = ['head', 'face', 'torso', 'pants', 'shoes'];
const PLAYABLE_FACES: FaceId[] = ['grin', 'smirk', 'fierce', 'cool', 'neutral'];

function getPartOptionLabel(skinId: SkinId, part: Exclude<PartSlot, 'face'>): string {
  const meta = SKIN_META_MAP[skinId];
  switch (part) {
    case 'head':
      return meta.headLabel;
    case 'torso':
      return meta.torsoLabel;
    case 'pants':
      return meta.pantsLabel;
    case 'shoes':
      return meta.shoesLabel;
  }
}

function formatHitZoneID(zone: HitZone): string {
  switch (zone) {
    case 'head':
      return 'KEPALA';
    case 'chest':
      return 'DADA';
    case 'leftArm':
      return 'TANGAN KIRI';
    case 'rightArm':
      return 'TANGAN KANAN';
    case 'leftLeg':
      return 'KAKI KIRI';
    case 'rightLeg':
      return 'KAKI KANAN';
  }
}

function isLoadoutModified(loadout: CharacterLoadout, slotIndex: number): boolean {
  const def = DEFAULT_SQUAD_LOADOUTS[slotIndex];
  return (
    loadout.head !== def.head ||
    loadout.face !== def.face ||
    loadout.torso !== def.torso ||
    loadout.pants !== def.pants ||
    loadout.shoes !== def.shoes
  );
}

function formatSelectionLabel(sel: ViewSelection): string {
  if (sel === 'squad9') return 'Jejer 9 (All)';
  if (sel === 'wave1') return 'Set 1 (1–4)';
  if (sel === 'wave2') return 'Set 2 (5–9)';
  return `Slot 0${sel + 1}`;
}

export function App() {
  const viewportRef = useRef<SceneViewportHandle | null>(null);

  const [loadouts, setLoadouts] = useState<CharacterLoadout[]>(() =>
    DEFAULT_SQUAD_LOADOUTS.map((l) => ({ ...l }))
  );
  const [selection, setSelection] = useState<ViewSelection>('squad9');
  const [activeSlot, setActiveSlot] = useState<number>(8);
  const [activePart, setActivePart] = useState<PartSlot>('head');
  const [customizerOpen, setCustomizerOpen] = useState<boolean>(false);

  const [animMode, setAnimMode] = useState<AnimMode>('idle');
  const [parkourEnabled, setParkourEnabled] = useState<boolean>(true);
  const [zombieHordeEnabled, setZombieHordeEnabled] = useState<boolean>(true);
  const [shootMode, setShootMode] = useState<boolean>(true);
  const [shootAll, setShootAll] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [healthList, setHealthList] = useState<CharacterHealthSummary[]>(() =>
    Array.from({ length: 9 }, () => ({
      hp: 3,
      maxHp: 3,
      lastHitZone: null,
      knockedOut: false,
    }))
  );

  const [bgMode, setBgMode] = useState<StudioBgMode>('dark');
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('front');
  const [cameraPresetTick, setCameraPresetTick] = useState(0);
  const [showOutlines, setShowOutlines] = useState(true);
  const [wireframe, setWireframe] = useState(false);
  const [turntable, setTurntable] = useState(false);
  const [includeExportOutlines, setIncludeExportOutlines] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [started, setStarted] = useState(false);
  const [aimMode, setAimMode] = useState<'zombie' | 'squad'>('zombie');
  const [toast, setToast] = useState<string | null>(null);
  const [stats, setStats] = useState<MeshStats>({
    triangles: 0,
    vertices: 0,
    meshes: 0,
    materials: 0,
  });

  const activeLoadout = loadouts[activeSlot];
  const activeHealth = healthList[activeSlot] ?? {
    hp: 3,
    maxHp: 3,
    lastHitZone: null,
    knockedOut: false,
  };
  const baseSlotMeta = SKINS_META[activeSlot];
  const activeHeadShowsFace = OPEN_FACE_HEADS.includes(activeLoadout.head);

  const anyModified = useMemo(
    () => loadouts.some((l, idx) => isLoadoutModified(l, idx)),
    [loadouts]
  );

  const anyDamagedOrKO = useMemo(
    () => healthList.some((h) => h.hp < h.maxHp),
    [healthList]
  );

  const koCount = useMemo(
    () => healthList.filter((h) => h.knockedOut).length,
    [healthList]
  );

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => {
      setToast((prev) => (prev === msg ? null : prev));
    }, 2400);
  }, []);

  const handleSelectPreset = (preset: CameraPreset) => {
    setCameraPreset(preset);
    setCameraPresetTick((t) => t + 1);
  };

  const handlePickCharacterPart = useCallback(
    (slotIndex: number, partSlot: PartSlot) => {
      setActiveSlot(slotIndex);
      setActivePart(partSlot);
      setCustomizerOpen(true);
      const slotName = SKINS_META[slotIndex].name;
      const partName = PART_SLOT_LABELS[partSlot].title.split(' ')[0];
      showToast(`Dipilih: ${slotName} (${partName})`);
    },
    [showToast]
  );

  const handleHitEvent = useCallback(
    (ev: HitFeedbackEvent) => {
      setActiveSlot(ev.slotIndex);
      const name = SKINS_META[ev.slotIndex].shortName;
      const zLabel = formatHitZoneID(ev.zone);
      if (ev.isFatal) {
        showToast(`💥 ${name} KENA ${zLabel} — TERPENTAL K.O.! (HP 0/3)`);
      } else {
        showToast(`🎯 ${name} kena ${zLabel} — Masih Hidup! (HP ${ev.hpRemaining}/3)`);
      }
    },
    [showToast]
  );

  const handleShootButton = (group: HitTargetGroup) => {
    if (!viewportRef.current) return;
    if (shootAll && typeof selection !== 'number') {
      viewportRef.current.shootTarget('all', group);
    } else {
      const targetIdx = typeof selection === 'number' ? selection : activeSlot;
      viewportRef.current.shootTarget(targetIdx, group);
    }
  };

  const handleRevive = () => {
    if (!viewportRef.current) return;
    viewportRef.current.reviveTarget('all');
    showToast('Semua prajurit bangkit penuh! (HP 3/3)');
  };

  const handleSpawnBoxes = () => {
    if (animMode !== 'chase') setAnimMode('chase');
    if (!parkourEnabled) setParkourEnabled(true);
    window.setTimeout(() => {
      viewportRef.current?.spawnObstacleWave();
    }, 30);
    showToast('📦 Obstacle Box meluncur acak — siap Speed Vault!');
  };

  const handleDockSelect = (next: ViewSelection) => {
    setSelection(next);
    if (typeof next === 'number') {
      setActiveSlot(next);
    } else if (next === 'wave1' && activeSlot >= 4) {
      setActiveSlot(0);
    } else if (next === 'wave2' && activeSlot < 4) {
      setActiveSlot(4);
    }
    setCameraPreset('front');
    setCameraPresetTick((t) => t + 1);
  };

  const handleSwapPart = (part: Exclude<PartSlot, 'face'>, skinId: SkinId) => {
    setLoadouts((prev) =>
      prev.map((item, idx) =>
        idx === activeSlot ? { ...item, [part]: skinId } : item
      )
    );
  };

  const handleSwapFace = (faceId: FaceId) => {
    setLoadouts((prev) =>
      prev.map((item, idx) =>
        idx === activeSlot ? { ...item, face: faceId } : item
      )
    );
  };

  const handleApplyFullPresetToSlot = (skinId: SkinId) => {
    const defFace =
      DEFAULT_SQUAD_LOADOUTS.find((d) => d.head === skinId)?.face ?? 'grin';
    setLoadouts((prev) =>
      prev.map((item, idx) =>
        idx === activeSlot
          ? { head: skinId, face: defFace, torso: skinId, pants: skinId, shoes: skinId }
          : item
      )
    );
    showToast(`Slot 0${activeSlot + 1} set ke ${SKIN_META_MAP[skinId].name}`);
  };

  const handleRandomizeActiveSlot = () => {
    const pickSkin = () => ALL_SKIN_IDS[Math.floor(Math.random() * ALL_SKIN_IDS.length)];
    const pickFace = () => PLAYABLE_FACES[Math.floor(Math.random() * PLAYABLE_FACES.length)];
    const next: CharacterLoadout = {
      head: pickSkin(),
      face: pickFace(),
      torso: pickSkin(),
      pants: pickSkin(),
      shoes: pickSkin(),
    };
    setLoadouts((prev) => prev.map((item, idx) => (idx === activeSlot ? next : item)));
    showToast(`Mix & match acak untuk Slot 0${activeSlot + 1}!`);
  };

  const handleResetActiveSlot = () => {
    const def = DEFAULT_SQUAD_LOADOUTS[activeSlot];
    setLoadouts((prev) => prev.map((item, idx) => (idx === activeSlot ? { ...def } : item)));
    showToast(`Slot 0${activeSlot + 1} di-reset ke skin asli`);
  };

  const handleResetAllSlots = () => {
    setLoadouts(DEFAULT_SQUAD_LOADOUTS.map((l) => ({ ...l })));
    showToast('Semua 9 skin di-reset ke setelan original');
  };

  const handleExportGLB = async () => {
    if (!viewportRef.current || exporting) return;
    setExporting(true);
    try {
      await viewportRef.current.exportGLB(includeExportOutlines);
      showToast(`Exported ${formatSelectionLabel(selection)} (.GLB)`);
    } catch (err) {
      console.error(err);
      showToast('Export GLB gagal, coba lagi');
    } finally {
      setExporting(false);
    }
  };

  const handleExportOBJ = () => {
    if (!viewportRef.current) return;
    viewportRef.current.exportOBJ(includeExportOutlines);
    showToast(`Exported ${formatSelectionLabel(selection)} (.OBJ)`);
  };

  const handleCapturePNG = (transparent: boolean) => {
    if (!viewportRef.current) return;
    viewportRef.current.capturePNG(transparent);
    showToast(transparent ? 'Saved PNG Transparan (Alpha)' : 'Saved Studio PNG Render');
  };

  const partIcon = (part: PartSlot) => {
    switch (part) {
      case 'head':
        return <User className="w-3.5 h-3.5" />;
      case 'face':
        return <Smile className="w-3.5 h-3.5" />;
      case 'torso':
        return <Shirt className="w-3.5 h-3.5" />;
      case 'pants':
        return <Layers className="w-3.5 h-3.5" />;
      case 'shoes':
        return <Footprints className="w-3.5 h-3.5" />;
    }
  };

  const partShortName = (part: PartSlot) => {
    switch (part) {
      case 'head':
        return 'Kepala';
      case 'face':
        return 'Wajah';
      case 'torso':
        return 'Baju';
      case 'pants':
        return 'Celana';
      case 'shoes':
        return 'Sepatu';
    }
  };

  const getChosenAccent = (part: PartSlot): string => {
    if (part === 'face') return FACE_META_MAP[activeLoadout.face].accentHex;
    return SKIN_META_MAP[activeLoadout[part]].accentHex;
  };

  const getChosenShortName = (part: PartSlot): string => {
    if (part === 'face') return FACE_META_MAP[activeLoadout.face].shortName;
    return SKIN_META_MAP[activeLoadout[part]].shortName;
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#1a1410]">
      {/* CABINET BEZEL — hazard strip framing the screen like an arcade marquee */}
      <div className="hazard-stripes pointer-events-none fixed inset-x-0 top-0 z-40 h-1.5" />
      <div className="hazard-stripes pointer-events-none fixed inset-x-0 bottom-0 z-40 h-1.5" />

      {/* FULL-BLEED 3D STUDIO VIEWPORT */}
      <SceneViewport
        ref={viewportRef}
        loadouts={loadouts}
        selection={selection}
        activeSlotIndex={activeSlot}
        highlightActiveSlot={customizerOpen}
        shootMode={shootMode}
        parkourEnabled={parkourEnabled}
        zombieHordeEnabled={zombieHordeEnabled}
        soundEnabled={soundEnabled}
        bgMode={bgMode}
        cameraPreset={cameraPreset}
        cameraPresetTick={cameraPresetTick}
        animMode={animMode}
        showOutlines={showOutlines}
        wireframe={wireframe}
        turntable={turntable}
        onPickCharacterPart={handlePickCharacterPart}
        onHitEvent={handleHitEvent}
        onHealthChange={setHealthList}
        onStatsChange={setStats}
      />

      {/* TOP FLOATING STUDIO HUD */}
      <header className="pointer-events-none fixed top-0 inset-x-0 z-20 flex flex-col gap-2 p-3 sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="pointer-events-auto flex items-stretch overflow-hidden studio-glass rounded-xl shadow-xl">
            <div className="hazard-stripes w-2.5 shrink-0" />
            <div className="flex items-center gap-3 px-3.5 py-2">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-hazard/45 bg-hazard/15 text-hazard">
                <Crosshair className="w-4 h-4" />
              </div>
              <div className="leading-tight">
                <div className="flex items-baseline gap-2">
                  <h1 className="plate-title text-lg sm:text-xl text-plate">
                    Sword of the Sea
                  </h1>
                  <span className="stencil hidden text-hazard sm:inline">
                    City Zombie Range
                  </span>
                </div>
                <p className="font-mono text-[11px] text-plate/60">
                  {shootMode
                    ? 'MODE TEMBAK · Klik prajurit (3× = K.O.) · Tembak zombie · Kepala = HEADSHOT'
                    : `${stats.triangles.toLocaleString()} tris · 100 City Zombie Horde · 8 Squad · Mix & Match`}
                </p>
              </div>
            </div>
          </div>

          <div className="pointer-events-auto flex items-center gap-1.5 flex-wrap">
            {/* ANIMATION MODE BAR */}
            <div className="studio-glass rounded-xl p-1 flex items-center gap-1 shadow-xl">
              {(
                [
                  { id: 'idle', label: 'Pose', icon: <User className="w-3.5 h-3.5" /> },
                  { id: 'walk', label: 'Jalan', icon: <Activity className="w-3.5 h-3.5" /> },
                  { id: 'chase', label: 'Lari Kejar', icon: <Flame className="w-3.5 h-3.5" /> },
                  { id: 'crouch', label: 'Jongkok', icon: <ArrowDownToLine className="w-3.5 h-3.5" /> },
                ] as { id: AnimMode; label: string; icon: React.ReactNode }[]
              ).map((m) => {
                const active = animMode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => setAnimMode(m.id)}
                    className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition ${
                      active
                        ? m.id === 'chase'
                          ? 'bg-orange-500 text-stone-950 shadow'
                          : 'bg-amber-400 text-stone-950 shadow'
                        : 'text-stone-200 hover:bg-white/8'
                    }`}
                  >
                    {m.icon}
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>

            {/* PARKOUR SPEED VAULT OBSTACLE CONTROLS */}
            <div className="studio-glass rounded-xl p-1 flex items-center gap-1 shadow-xl">
              <button
                onClick={() => {
                  setParkourEnabled((v) => {
                    const next = !v;
                    if (next && animMode !== 'chase') setAnimMode('chase');
                    return next;
                  });
                }}
                title="Aktifkan/Matikan Obstacle Box Acak (Speed Vault)"
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition ${
                  parkourEnabled && animMode === 'chase'
                    ? 'bg-emerald-400 text-stone-950 shadow'
                    : 'text-stone-200 hover:bg-white/8'
                }`}
              >
                <Box className="w-3.5 h-3.5" />
                <span>Parkour Box</span>
              </button>
              <button
                onClick={handleSpawnBoxes}
                title="Luncurkan Obstacle Box Acak Sekarang!"
                className="rounded-lg bg-amber-500/25 hover:bg-amber-500/45 text-amber-200 border border-amber-400/35 px-2 py-1.5 text-[11px] font-bold transition"
              >
                +Box
              </button>
            </div>

            {/* WORLD WAR Z ZOMBIE HORDE TOGGLE */}
            <button
              onClick={() => {
                setZombieHordeEnabled((v) => {
                  const next = !v;
                  showToast(next ? '🧟 100 City Zombie Horde mendekat!' : 'Zombie Horde disembunyikan');
                  return next;
                });
              }}
              title="Aktifkan/Matikan 100 City Zombie Horde yang mengejar dari belakang"
              className={`flex items-center gap-1.5 rounded-xl font-bold text-xs px-3 py-2.5 shadow-lg transition ${
                zombieHordeEnabled
                  ? 'bg-lime-400 hover:bg-lime-300 text-stone-950 shadow-lime-950/40'
                  : 'studio-glass text-lime-200 border-lime-400/35 hover:bg-lime-500/20'
              }`}
            >
              <Skull className="w-3.5 h-3.5" />
              <span>Horde (100)</span>
            </button>

            {/* MODE TEMBAK (SHOOT) TOGGLE */}
            <button
              onClick={() => {
                setShootMode((v) => {
                  const next = !v;
                  if (next) setCustomizerOpen(false);
                  return next;
                });
              }}
              className={`flex items-center gap-1.5 rounded-xl font-bold text-xs px-3.5 py-2.5 shadow-lg transition ${
                shootMode
                  ? 'bg-red-500 hover:bg-red-400 text-white shadow-red-950/50 ring-1 ring-red-300/60'
                  : 'studio-glass text-red-300 border-red-400/35 hover:bg-red-500/20'
              }`}
            >
              <Crosshair className="w-3.5 h-3.5" />
              <span>{shootMode ? 'Tembak ON' : 'Mode Tembak'}</span>
            </button>

            <div className="studio-glass rounded-xl p-1 flex items-center gap-1 shadow-xl">
              <button
                onClick={() => setShowOutlines((v) => !v)}
                title="Toggle Cel Ink Outlines"
                className={`flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition ${
                  showOutlines
                    ? 'bg-amber-500/25 text-amber-200 border border-amber-400/35'
                    : 'text-stone-300 hover:bg-white/5 border border-transparent'
                }`}
              >
                <PenTool className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setWireframe((v) => !v)}
                title="Toggle Wireframe"
                className={`flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition ${
                  wireframe
                    ? 'bg-amber-500/25 text-amber-200 border border-amber-400/35'
                    : 'text-stone-300 hover:bg-white/5 border border-transparent'
                }`}
              >
                <Grid className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setTurntable((v) => !v)}
                title="360° Turntable"
                className={`flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium transition ${
                  turntable
                    ? 'bg-amber-500/25 text-amber-200 border border-amber-400/35'
                    : 'text-stone-300 hover:bg-white/5 border border-transparent'
                }`}
              >
                <RotateCw className={`w-3.5 h-3.5 ${turntable ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={() => viewportRef.current?.resetCamera()}
                title="Reset Camera"
                className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-medium text-stone-300 hover:bg-white/10 transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={() => {
                setCustomizerOpen((v) => {
                  const next = !v;
                  if (next) setShootMode(false);
                  return next;
                });
              }}
              className={`flex items-center gap-1.5 rounded-xl font-semibold text-xs px-3 py-2.5 shadow-lg transition ${
                customizerOpen
                  ? 'bg-amber-500 text-stone-950 shadow-amber-950/35'
                  : 'studio-glass text-amber-200 border-amber-400/35 hover:bg-amber-500/20'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Ganti Skin</span>
            </button>

            <button
              onClick={handleExportGLB}
              disabled={exporting}
              className="studio-glass flex items-center gap-1.5 rounded-xl px-3 py-2.5 text-xs font-medium text-stone-100 hover:bg-white/10 transition shadow-xl disabled:opacity-60"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{exporting ? 'Exporting...' : '.GLB'}</span>
            </button>
          </div>
        </div>

        {/* FLOATING 3-HP HIT-ZONE SHOOTING & ACTING CONTROL BAR */}
        {shootMode && (
          <div className="pointer-events-auto self-center studio-glass rounded-2xl px-2.5 py-1.5 flex flex-wrap items-center justify-center gap-1.5 shadow-2xl border border-red-400/30">
            {/* Live HP Status for Selected Target */}
            <div className="flex items-center gap-2 px-2 py-1 rounded-xl bg-black/35 border border-white/8">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: baseSlotMeta.accentHex }}
              />
              <span className="text-[11px] font-bold text-stone-100 whitespace-nowrap">
                {shootAll && typeof selection !== 'number'
                  ? `Semua (${koCount} K.O.)`
                  : `${baseSlotMeta.index} ${baseSlotMeta.shortName}`}
              </span>
              {!(shootAll && typeof selection !== 'number') && (
                <div className="flex items-center gap-0.5 ml-0.5">
                  {activeHealth.knockedOut ? (
                    <span className="inline-flex items-center gap-1 rounded bg-red-500/25 px-1.5 py-0.5 text-[10px] font-mono font-bold text-red-300 border border-red-400/40">
                      <Skull className="w-3 h-3" />
                      K.O. 0/3
                    </span>
                  ) : (
                    <>
                      {[0, 1, 2].map((hIdx) => (
                        <Heart
                          key={hIdx}
                          className={`w-3.5 h-3.5 transition ${
                            hIdx < activeHealth.hp
                              ? 'fill-red-500 text-red-400'
                              : 'text-stone-600'
                          }`}
                        />
                      ))}
                      <span className="ml-1 text-[10px] font-mono text-stone-300">
                        {activeHealth.hp}/3
                      </span>
                    </>
                  )}
                </div>
              )}
            </div>

            <div className="w-px h-5 bg-white/12 hidden sm:block" />

            {/* AIM ARBITRATION — zombie aiming punches through the squad */}
            <button
              onClick={() =>
                setAimMode((m) => {
                  const next = m === 'zombie' ? 'squad' : 'zombie';
                  aim.mode = next;
                  showToast(
                    next === 'zombie'
                      ? 'Bidik ZOMBIE — tembus squad, kena part yang diklik'
                      : 'Bidik SQUAD — prajurit jadi target utama'
                  );
                  return next;
                })
              }
              title="Saat bidang menimpa squad DAN zombie sekaligus, siapa yang kena tembak"
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-bold transition ${
                aimMode === 'zombie'
                  ? 'bg-hazard text-night shadow'
                  : 'studio-glass text-amber-200 border border-amber-400/35 hover:bg-amber-500/20'
              }`}
            >
              <Crosshair className="w-3.5 h-3.5" />
              <span className="whitespace-nowrap">
                {aimMode === 'zombie' ? 'Bidik Zombie' : 'Bidik Squad'}
              </span>
            </button>

            {/* 4 Direct Body-Zone Shot Buttons */}
            {(
              [
                { id: 'head', label: 'Kepala' },
                { id: 'chest', label: 'Dada' },
                { id: 'arm', label: 'Tangan' },
                { id: 'leg', label: 'Kaki' },
              ] as { id: HitTargetGroup; label: string }[]
            ).map((btn) => (
              <button
                key={btn.id}
                onClick={() => handleShootButton(btn.id)}
                className="flex items-center gap-1 rounded-xl bg-red-500/20 hover:bg-red-500 active:scale-95 text-red-100 hover:text-white border border-red-400/40 px-2.5 py-1.5 text-xs font-semibold transition"
              >
                <Crosshair className="w-3 h-3" />
                <span>{btn.label}</span>
              </button>
            ))}

            {typeof selection !== 'number' && (
              <button
                onClick={() => setShootAll((v) => !v)}
                className={`rounded-xl px-2.5 py-1.5 text-[11px] font-semibold border transition ${
                  shootAll
                    ? 'bg-amber-500 text-stone-950 border-amber-300'
                    : 'bg-white/[0.06] text-stone-200 border-white/12 hover:bg-white/12'
                }`}
              >
                {shootAll ? 'Target: Semua' : 'Target: 1 Orang'}
              </button>
            )}

            <button
              onClick={handleRevive}
              className={`flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-semibold border transition ${
                anyDamagedOrKO
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-stone-950 border-emerald-300 shadow'
                  : 'bg-white/[0.06] hover:bg-white/12 text-stone-300 border-white/10'
              }`}
            >
              <HeartPulse className="w-3.5 h-3.5" />
              <span>Bangun / Revive</span>
            </button>

            <button
              onClick={() => setSoundEnabled((v) => !v)}
              title={soundEnabled ? 'Matikan Suara Tembakan' : 'Aktifkan Suara Tembakan'}
              className="rounded-xl p-1.5 bg-white/[0.06] hover:bg-white/14 text-stone-200 border border-white/10 transition"
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 text-stone-500" />}
            </button>
          </div>
        )}
      </header>

      {/* RIGHT MODULAR 9-SKIN & 5-FACE MIX & MATCH CUSTOMIZER DRAWER */}
      <aside
        className={`fixed top-16 sm:top-[68px] right-3 sm:right-4 bottom-24 z-20 w-[356px] max-w-[calc(100vw-24px)] studio-glass rounded-2xl shadow-2xl transition-all duration-300 flex flex-col overflow-hidden ${
          customizerOpen
            ? 'translate-x-0 opacity-100 pointer-events-auto'
            : 'translate-x-[115%] opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest text-amber-300/90">
              <SlidersHorizontal className="w-3 h-3" />
              <span>9-SKIN · 5-WAJAH MIXER</span>
            </div>
            <h2 className="text-sm font-bold text-stone-100 truncate">
              Slot 0{activeSlot + 1} · {baseSlotMeta.name}
            </h2>
          </div>
          <button
            onClick={() => setCustomizerOpen(false)}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-white/10 transition"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3.5">
          {/* Step 1: Select Character Slot (1–9) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">
                1. Pilih Karakter (Slot 1–9)
              </span>
              <button
                onClick={() =>
                  handleDockSelect(selection === activeSlot ? 'squad9' : activeSlot)
                }
                className="text-[10px] font-semibold text-amber-300 hover:text-amber-200 underline underline-offset-2"
              >
                {selection === activeSlot ? 'Lihat Jejer 9' : 'Zoom Solo 360°'}
              </button>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {SKINS_META.map((skin, idx) => {
                const isEditing = activeSlot === idx;
                const modified = isLoadoutModified(loadouts[idx], idx);
                return (
                  <button
                    key={skin.id}
                    onClick={() => {
                      setActiveSlot(idx);
                      if (typeof selection === 'number') setSelection(idx);
                    }}
                    className={`relative rounded-xl py-1.5 px-1.5 flex items-center gap-1.5 border transition ${
                      isEditing
                        ? 'bg-amber-500/20 border-amber-400/65 text-white shadow-inner'
                        : 'bg-white/[0.03] border-white/8 text-stone-300 hover:bg-white/[0.08]'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0 ring-2 ring-black/30"
                      style={{ backgroundColor: skin.accentHex }}
                    />
                    <span className="text-[10px] font-semibold truncate">
                      {skin.index} {skin.shortName.split(' ')[0]}
                    </span>
                    {modified && (
                      <span
                        title="Custom Mix"
                        className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-amber-400"
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Choose Body Part Category */}
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-stone-400 mb-1.5">
              2. Pilih Bagian Tubuh
            </div>
            <div className="grid grid-cols-5 gap-1 rounded-xl bg-black/35 p-1 border border-white/8">
              {PART_ORDER.map((part) => {
                const active = activePart === part;
                return (
                  <button
                    key={part}
                    onClick={() => setActivePart(part)}
                    className={`flex flex-col items-center gap-1 rounded-lg py-1.5 px-0.5 text-[9.5px] font-medium transition ${
                      active
                        ? 'bg-amber-500 text-stone-950 font-bold shadow'
                        : 'text-stone-300 hover:bg-white/8 hover:text-white'
                    }`}
                  >
                    {partIcon(part)}
                    <span>{partShortName(part)}</span>
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${active ? 'ring-1 ring-black/40' : ''}`}
                      style={{ backgroundColor: getChosenAccent(part) }}
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 3: Pick Face Variation OR Skin Part */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-300/90">
                3. {PART_SLOT_LABELS[activePart].title}
              </span>
              <span className="text-[10px] text-stone-400">
                {getChosenShortName(activePart)}
              </span>
            </div>

            {activePart === 'face' ? (
              <div className="space-y-2">
                {!activeHeadShowsFace && (
                  <div className="rounded-xl bg-amber-500/12 border border-amber-400/30 p-2.5 text-[11px] text-amber-200/95 space-y-1.5">
                    <div>
                      Kepala <strong>{SKIN_META_MAP[activeLoadout.head].name}</strong> tertutup topeng/helm penuh. Ganti ke kepala terbuka untuk melihat wajah:
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {OPEN_FACE_HEADS.map((hid) => (
                        <button
                          key={hid}
                          onClick={() => handleSwapPart('head', hid)}
                          className="rounded-lg bg-amber-500/25 hover:bg-amber-500/40 px-2 py-1 text-[10px] font-semibold text-amber-100 border border-amber-400/40 transition"
                        >
                          Pakai {SKIN_META_MAP[hid].shortName}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-1.5">
                  {FACES_META.map((face) => {
                    const selected = activeLoadout.face === face.id;
                    return (
                      <button
                        key={face.id}
                        onClick={() => handleSwapFace(face.id)}
                        className={`w-full flex items-center justify-between gap-2.5 rounded-xl px-2.5 py-2 border text-left transition ${
                          selected
                            ? 'bg-amber-500/20 border-amber-400/65 text-white shadow-md'
                            : 'bg-white/[0.03] border-white/8 text-stone-200 hover:bg-white/[0.08] hover:border-white/15'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className="w-3 h-3 rounded-full shrink-0 border border-white/25 shadow"
                            style={{ backgroundColor: face.accentHex }}
                          />
                          <div className="min-w-0">
                            <div className="text-xs font-semibold truncate flex items-center gap-1.5">
                              <span className="font-mono text-[10px] opacity-65">{face.index}</span>
                              <span>{face.name}</span>
                            </div>
                            <div className="text-[10px] text-stone-400 leading-snug">
                              {face.detail}
                            </div>
                          </div>
                        </div>
                        {selected ? (
                          <span className="flex items-center justify-center w-5 h-5 rounded-full bg-amber-400 text-stone-950 shrink-0">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono text-stone-500 shrink-0">
                            Pakai
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="space-y-1.5">
                {SKINS_META.map((option) => {
                  const selected = activeLoadout[activePart] === option.id;
                  return (
                    <button
                      key={option.id}
                      onClick={() => handleSwapPart(activePart, option.id)}
                      className={`w-full flex items-center justify-between gap-2.5 rounded-xl px-2.5 py-2 border text-left transition ${
                        selected
                          ? 'bg-amber-500/20 border-amber-400/65 text-white shadow-md'
                          : 'bg-white/[0.03] border-white/8 text-stone-200 hover:bg-white/[0.08] hover:border-white/15'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="w-3 h-3 rounded-full shrink-0 border border-white/25 shadow"
                          style={{ backgroundColor: option.accentHex }}
                        />
                        <div className="min-w-0">
                          <div className="text-xs font-semibold truncate flex items-center gap-1.5">
                            <span className="font-mono text-[10px] opacity-60">{option.index}</span>
                            <span>{option.name}</span>
                          </div>
                          <div className="text-[10px] text-stone-400 truncate">
                            {getPartOptionLabel(option.id, activePart)}
                          </div>
                        </div>
                      </div>
                      {selected ? (
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-amber-400 text-stone-950 shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono text-stone-500 shrink-0">
                          Pakai
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Active Build Summary & Quick Actions */}
          <div className="rounded-xl bg-black/30 border border-white/8 p-2.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">
                Kombinasi Slot 0{activeSlot + 1}
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={handleRandomizeActiveSlot}
                  className="flex items-center gap-1 rounded-md bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 px-2 py-1 text-[10px] font-semibold border border-amber-400/30 transition"
                >
                  <Shuffle className="w-3 h-3" />
                  <span>Acak</span>
                </button>
                <button
                  onClick={handleResetActiveSlot}
                  className="flex items-center gap-1 rounded-md bg-white/8 hover:bg-white/14 text-stone-200 px-2 py-1 text-[10px] font-medium transition"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Asli</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1">
              {PART_ORDER.map((part) => (
                <button
                  key={part}
                  onClick={() => setActivePart(part)}
                  className={`flex items-center gap-1.5 rounded-lg px-2 py-1 text-left border transition ${
                    activePart === part
                      ? 'bg-white/10 border-amber-400/40'
                      : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.06]'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: getChosenAccent(part) }}
                  />
                  <div className="min-w-0 leading-tight">
                    <div className="text-[8.5px] text-stone-400 uppercase font-mono">
                      {partShortName(part)}
                    </div>
                    <div className="text-[10px] font-semibold text-stone-100 truncate">
                      {getChosenShortName(part)}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="pt-1 space-y-1">
              <div className="text-[9px] font-mono text-stone-400 uppercase">Set Full Skin:</div>
              <div className="grid grid-cols-3 gap-1">
                {SKINS_META.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleApplyFullPresetToSlot(s.id)}
                    title={`Set full ${s.name}`}
                    className="rounded px-1.5 py-0.5 text-[9px] font-medium bg-white/[0.05] hover:bg-white/15 text-stone-300 border border-white/8 truncate transition"
                  >
                    {s.index} {s.shortName.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {anyModified && (
              <button
                onClick={handleResetAllSlots}
                className="w-full rounded-lg bg-white/[0.05] hover:bg-white/10 text-stone-300 text-[10px] font-medium py-1.5 border border-white/8 transition"
              >
                Reset Semua 9 Karakter ke Original
              </button>
            )}
          </div>

          {/* Studio Backdrop Switcher */}
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-stone-400 mb-1.5">
              Studio Backdrop
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {(
                [
                  { id: 'terracotta', label: 'Ref' },
                  { id: 'dark', label: 'Dark' },
                  { id: 'clay', label: 'Clay' },
                  { id: 'transparent', label: 'Alpha' },
                ] as { id: StudioBgMode; label: string }[]
              ).map((bg) => (
                <button
                  key={bg.id}
                  onClick={() => setBgMode(bg.id)}
                  className={`rounded-lg py-1.5 text-[11px] font-medium border transition ${
                    bgMode === bg.id
                      ? 'bg-amber-500/25 border-amber-400/45 text-amber-200'
                      : 'bg-white/[0.03] border-white/8 text-stone-300 hover:bg-white/[0.07]'
                  }`}
                >
                  {bg.label}
                </button>
              ))}
            </div>
          </div>

          {/* Export Suite */}
          <div className="pt-2 border-t border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">
                Export ({formatSelectionLabel(selection)})
              </span>
              <span className="text-[10px] font-mono text-stone-400">
                {stats.triangles.toLocaleString()} tris
              </span>
            </div>

            <label className="flex items-center gap-2 text-xs text-stone-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={includeExportOutlines}
                onChange={(e) => setIncludeExportOutlines(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <span>Sertakan Cel Outline Hull (.GLB/.OBJ)</span>
            </label>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={handleExportGLB}
                disabled={exporting}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-xs py-2 transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>.GLB 3D</span>
              </button>
              <button
                onClick={handleExportOBJ}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-stone-100 font-medium text-xs py-2 border border-white/12 transition"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>.OBJ Mesh</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => handleCapturePNG(false)}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-white/[0.06] hover:bg-white/12 text-stone-200 text-xs py-1.5 border border-white/8 transition"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>PNG Studio</span>
              </button>
              <button
                onClick={() => handleCapturePNG(true)}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-white/[0.06] hover:bg-white/12 text-stone-200 text-xs py-1.5 border border-white/8 transition"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>PNG Alpha</span>
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* BOTTOM FLOATING 9-SKIN SELECTOR & CAMERA DOCK */}
      <footer className="pointer-events-none fixed bottom-3 sm:bottom-4 inset-x-0 z-20 flex flex-col items-center gap-2 px-3">
        <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-1.5">
          <div className="studio-glass-subtle rounded-full px-1.5 py-1 flex items-center gap-1 shadow-lg">
            {(
              [
                { id: 'squad9', label: 'Jejer 9' },
                { id: 'wave1', label: 'Set 1 (1–4)' },
                { id: 'wave2', label: 'Set 2 (5–9)' },
              ] as { id: ViewSelection; label: string }[]
            ).map((vw) => (
              <button
                key={String(vw.id)}
                onClick={() => handleDockSelect(vw.id)}
                className={`rounded-full px-2.5 py-1 text-[11px] font-medium transition ${
                  selection === vw.id
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'text-stone-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {vw.label}
              </button>
            ))}
          </div>

          <div className="studio-glass-subtle rounded-full px-1.5 py-1 flex items-center gap-1 shadow-lg">
            {(
              [
                { id: 'front', label: 'Front' },
                { id: 'threeQuarter', label: '3/4 Hero' },
                { id: 'mini', label: 'Miniatur' },
                { id: 'back', label: 'Back 360°' },
                { id: 'closeup', label: 'Head Close-Up' },
              ] as { id: CameraPreset; label: string }[]
            ).map((cam) => (
              <button
                key={cam.id}
                onClick={() => handleSelectPreset(cam.id)}
                className={`rounded-full px-2.5 py-1 text-[11px] font-medium transition ${
                  cameraPreset === cam.id
                    ? 'bg-stone-100 text-stone-950 font-semibold'
                    : 'text-stone-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {cam.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main 9-Slot Selector Bar (with live HP / K.O. status indicators!) */}
        <div className="pointer-events-auto studio-glass rounded-2xl p-1.5 flex items-center gap-1 max-w-full overflow-x-auto shadow-2xl">
          <button
            onClick={() => handleDockSelect('squad9')}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-semibold whitespace-nowrap transition ${
              selection === 'squad9'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-200 hover:bg-white/10'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>All 9</span>
          </button>

          <div className="w-px h-5 bg-white/12 mx-0.5 shrink-0" />

          {SKINS_META.map((skin, idx) => {
            const focused = selection === idx;
            const modified = isLoadoutModified(loadouts[idx], idx);
            const h = healthList[idx];
            return (
              <button
                key={skin.id}
                onClick={() => {
                  handleDockSelect(idx);
                  if (!shootMode) setCustomizerOpen(true);
                }}
                className={`relative flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-medium whitespace-nowrap transition ${
                  focused
                    ? 'bg-white/18 text-white ring-1 ring-amber-400/60 shadow-md'
                    : h?.knockedOut
                      ? 'bg-red-950/40 text-stone-400 hover:bg-red-950/60 border border-red-500/25'
                      : 'text-stone-300 hover:bg-white/8 hover:text-white'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full shrink-0 border border-black/30"
                  style={{ backgroundColor: h?.knockedOut ? '#ef4444' : skin.accentHex }}
                />
                <span className="font-mono text-[10px] opacity-60">{skin.index}</span>
                <span>{skin.shortName}</span>
                {h?.knockedOut ? (
                  <span className="rounded bg-red-500/30 px-1 py-0.5 text-[8.5px] font-mono text-red-200 border border-red-400/40">
                    K.O.
                  </span>
                ) : h && h.hp < h.maxHp ? (
                  <span className="rounded bg-orange-500/25 px-1 py-0.5 text-[8.5px] font-mono text-orange-200 border border-orange-400/35">
                    {h.hp}/3
                  </span>
                ) : modified ? (
                  <span className="rounded bg-amber-400/25 px-1 py-0.5 text-[8.5px] font-mono text-amber-300 border border-amber-400/35">
                    MIX
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>
      </footer>

      {/* ================================================================ */}
      {/* START PLATE — arcade marquee over the generated key art         */}
      {/* ================================================================ */}
      {!started && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-night">
          <img
            src={hordePlate}
            alt=""
            className="absolute inset-0 h-full w-full object-cover object-right"
            onError={(ev) => {
              (ev.currentTarget as HTMLImageElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#0d1020_0%,rgba(13,16,32,0.93)_46%,rgba(13,16,32,0.28)_100%)]" />
          <div className="absolute inset-0 bg-[linear-gradient(to_top,rgba(13,16,32,0.92)_0%,rgba(13,16,32,0)_45%,rgba(13,16,32,0.65)_100%)]" />
          <div className="scanlines pointer-events-none absolute inset-0 opacity-40" />

          <div className="relative flex h-full max-w-[44rem] flex-col justify-center gap-5 overflow-y-auto px-7 py-9 sm:px-14">
            <div className="flex items-center gap-3">
              <span className="hazard-stripes h-3 w-28 shrink-0 rounded-sm" />
              <span className="stencil text-hazard">
                Polygon · 100 City Zombies · 8 Squad di balik blok
              </span>
            </div>

            <h2 className="plate-title text-[19vw] leading-[0.82] text-plate sm:text-[10vw]">
              City
              <br />
              <span className="text-hazard">Zombies</span>
            </h2>

            <div className="max-w-lg border-l-2 border-blood pl-4">
              <p className="text-sm leading-relaxed text-plate/75 sm:text-base">
                Wajah zombie dibuat <strong className="text-plate">tidak serem</strong>:
                hanya <strong className="text-undead">mata putih</strong> polos tanpa
                pupil. Rambut dan bentuk wajahnya <em>macam-macam</em> — mohawk, panjang,
                bowl cut, botak, sampai topi lebar — dengan warna kulit teal dan baju
                kuning hazmat, ungu, putih, serta teal persis seperti referensinya.
              </p>
              <p className="mt-2 text-sm leading-relaxed text-plate/60">
                Semua part badan bisa ditembak — kepala, badan, lengan, kaki. Sekali kena:
                kilatan putih, semburan darah, kepingan daging beterbangan, lengan/kaki
                copot, lalu tubuhnya <strong className="text-plate">ragdoll</strong> terpelanting,
                terguling, dan jatuh tersebar di aspal.{" "}
                <strong className="text-blood">Headshot</strong> membuat kepala terlepas dan
                berputar ke udara.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => {
                  setStarted(true);
                  setShootMode(true);
                  setZombieHordeEnabled(true);
                }}
                className="group relative overflow-hidden rounded-sm bg-hazard px-9 py-4 shadow-[0_10px_0_rgba(0,0,0,0.35)] transition active:translate-y-1 active:shadow-[0_4px_0_rgba(0,0,0,0.35)]"
              >
                <span className="plate-title text-2xl text-night">Mulai Tembak</span>
              </button>
              <span className="stencil text-plate/45">
                Klik = tembak · Bidikan menembus squad · Geser = kamera
              </span>
            </div>

            <p className="stencil max-w-md text-plate/45">
              Basis: stylized-polygon-skin-assets · POLYGON City Zombies pack
            </p>
          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed bottom-28 sm:bottom-[118px] left-1/2 -translate-x-1/2 z-30 studio-glass rounded-full px-4 py-2 text-xs font-semibold text-amber-100 border border-amber-400/40 shadow-2xl flex items-center gap-2 whitespace-nowrap">
          <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
}

export default App;
