import * as THREE from 'three';
import { makeStylizedMesh, StylizedMeshOptions } from './materials';

export interface LoftRing {
  y: number;
  rx: number;
  rz: number;
  ox?: number;
  oz?: number;
  shape?: (angle: number) => { rxMul?: number; rzMul?: number; dzAdd?: number; dyAdd?: number };
}

export interface FootAnchors {
  leftPos: THREE.Vector3;
  rightPos: THREE.Vector3;
  leftRotY: number;
  rightRotY: number;
  /** True for tailored dress trousers where pants drape lower over shoe collar */
  drapesLow?: boolean;
}

/**
 * Builds a crisp faceted low-poly loft geometry from ordered cross-section rings.
 * Angle 0 points straight along +Z (front center), ensuring symmetrical planar face/body ridges.
 */
export function createLoftGeometry(
  rings: LoftRing[],
  radialSegments = 10,
  capBottom = true,
  capTop = true
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const minY = rings[0].y;
  const maxY = rings[rings.length - 1].y;
  const spanY = Math.max(0.0001, maxY - minY);

  const ringCols = radialSegments + 1;

  for (let r = 0; r < rings.length; r++) {
    const ring = rings[r];
    const vCoord = (ring.y - minY) / spanY;
    const ox = ring.ox ?? 0;
    const oz = ring.oz ?? 0;

    for (let s = 0; s <= radialSegments; s++) {
      const uCoord = s / radialSegments;
      const angle = (s % radialSegments) * ((Math.PI * 2) / radialSegments);
      let rx = ring.rx;
      let rz = ring.rz;
      let dzAdd = 0;
      let dyAdd = 0;
      if (ring.shape) {
        const mod = ring.shape(angle);
        if (mod.rxMul !== undefined) rx *= mod.rxMul;
        if (mod.rzMul !== undefined) rz *= mod.rzMul;
        if (mod.dzAdd !== undefined) dzAdd = mod.dzAdd;
        if (mod.dyAdd !== undefined) dyAdd = mod.dyAdd;
      }

      const x = ox + Math.sin(angle) * rx;
      const z = oz + Math.cos(angle) * rz + dzAdd;
      positions.push(x, ring.y + dyAdd, z);
      uvs.push(uCoord, vCoord);
    }
  }

  for (let r = 0; r < rings.length - 1; r++) {
    for (let s = 0; s < radialSegments; s++) {
      const a = r * ringCols + s;
      const b = a + 1;
      const c = (r + 1) * ringCols + s;
      const d = c + 1;

      indices.push(a, b, d);
      indices.push(a, d, c);
    }
  }

  if (capBottom) {
    const ring = rings[0];
    const centerIdx = positions.length / 3;
    positions.push(ring.ox ?? 0, ring.y, ring.oz ?? 0);
    uvs.push(0.5, 0);
    for (let s = 0; s < radialSegments; s++) {
      indices.push(centerIdx, s + 1, s);
    }
  }

  if (capTop) {
    const lastRow = (rings.length - 1) * ringCols;
    const ring = rings[rings.length - 1];
    const centerIdx = positions.length / 3;
    positions.push(ring.ox ?? 0, ring.y, ring.oz ?? 0);
    uvs.push(0.5, 1);
    for (let s = 0; s < radialSegments; s++) {
      indices.push(centerIdx, lastRow + s, lastRow + s + 1);
    }
  }

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geom.setIndex(indices);
  geom.computeVertexNormals();
  return geom;
}

/**
 * Creates a faceted beveled rectangular block (for armor plates, pouches, buckles, receivers).
 */
export function createBeveledBoxGeometry(
  width: number,
  height: number,
  depth: number,
  bevel = 0.008
): THREE.BufferGeometry {
  const b = Math.min(bevel, width * 0.28, height * 0.28, depth * 0.28);
  const hw = width / 2;
  const hh = height / 2;

  const shape = new THREE.Shape();
  shape.moveTo(-hw + b, -hh);
  shape.lineTo(hw - b, -hh);
  shape.lineTo(hw, -hh + b);
  shape.lineTo(hw, hh - b);
  shape.lineTo(hw - b, hh);
  shape.lineTo(-hw + b, hh);
  shape.lineTo(-hw, hh - b);
  shape.lineTo(-hw, -hh + b);
  shape.closePath();

  const extrude = new THREE.ExtrudeGeometry(shape, {
    depth: Math.max(0.002, depth - b * 2),
    bevelEnabled: true,
    bevelThickness: b,
    bevelSize: b,
    bevelSegments: 1,
    curveSegments: 1,
  });
  extrude.center();
  return extrude;
}

/**
 * Master sculpted low-poly stylized human head matching Image 3 close-up:
 * - Clean tall oval silhouette with sleek tapered jawline and chin
 * - Prominent smooth vertical center ridge along forehead/nose/chin creating the iconic
 *   two-plane bright/shadow split seen on Boonie and Gold Mask
 * - Zero flat boxy walls!
 */
export function createStylizedHeadGeometry(opts?: {
  scale?: number;
  slimX?: number;
  noseRidge?: number;
}): THREE.BufferGeometry {
  const s = opts?.scale ?? 1.0;
  const sx = opts?.slimX ?? 1.0;
  const ridge = opts?.noseRidge ?? 0.018;

  const faceShape = (ridgeMul: number, cheekFlat = 0) => (angle: number) => {
    const front = Math.cos(angle); // +1 center nose, -1 occiput
    const side = Math.abs(Math.sin(angle));
    let dzAdd = 0;
    let rxMul = 1;
    // Crisp central vertical nose-bridge / chin-point ridge at angle = 0
    if (front > 0.62) {
      dzAdd += ridge * ridgeMul * Math.pow((front - 0.62) / 0.38, 1.35);
    }
    // Slight angular cheek plane taper
    if (front > 0.1 && side > 0.5) {
      rxMul -= cheekFlat * 0.055;
    }
    // Slight natural skull back curve
    if (front < -0.5) {
      dzAdd -= 0.004 * s;
    }
    return { rxMul, dzAdd };
  };

  const rings: LoftRing[] = [
    { y: -0.128 * s, rx: 0.030 * s * sx, rz: 0.036 * s, oz: 0.024 * s, shape: faceShape(0.65, 1.0) }, // Pointed rounded chin tip
    { y: -0.100 * s, rx: 0.058 * s * sx, rz: 0.072 * s, oz: 0.018 * s, shape: faceShape(0.85, 0.9) }, // Chin / lower jaw
    { y: -0.052 * s, rx: 0.082 * s * sx, rz: 0.098 * s, oz: 0.010 * s, shape: faceShape(1.05, 0.7) }, // Jawline angle
    { y: 0.005 * s, rx: 0.090 * s * sx, rz: 0.106 * s, oz: 0.006 * s, shape: faceShape(1.20, 0.4) },  // Cheekbone & nose plane
    { y: 0.062 * s, rx: 0.091 * s * sx, rz: 0.110 * s, oz: 0.000 * s, shape: faceShape(0.75, 0.15) }, // Brow & temple
    { y: 0.110 * s, rx: 0.082 * s * sx, rz: 0.102 * s, oz: -0.006 * s, shape: faceShape(0.35, 0) },   // Upper forehead
    { y: 0.142 * s, rx: 0.056 * s * sx, rz: 0.070 * s, oz: -0.008 * s },                              // Crown bevel
    { y: 0.156 * s, rx: 0.022 * s * sx, rz: 0.028 * s, oz: -0.008 * s },                              // Top cap
  ];

  return createLoftGeometry(rings, 10, true, true);
}

/**
 * Sleek, non-boxy stylized combat boot OR Oxford dress shoe grounded cleanly at y = 0.
 * Completely eliminates the clunky wide rectangular sole slabs!
 */
export function createStylizedBoot(opts: {
  upperMat: THREE.Material;
  lowerMat: THREE.Material;
  soleMat: THREE.Material;
  height?: number;
  dressShoe?: boolean;
  outline?: number;
}): THREE.Group {
  const group = new THREE.Group();
  const outline = opts.outline ?? 0.0044;

  // Tapered foot shape helper: narrower sculpted toe front (+Z), rounded snug heel (-Z)
  const footShape = (toeNarrow: number) => (angle: number) => {
    const front = Math.cos(angle);
    return {
      rxMul: front > 0 ? 1.0 - toeNarrow * front : 0.88,
    };
  };

  if (opts.dressShoe) {
    // Sleek tailored Oxford dress shoe (Golden Enforcer) — flush slim sole, tapered pointed toe
    const soleRings: LoftRing[] = [
      { y: 0.0, rx: 0.044, rz: 0.118, oz: 0.048, shape: footShape(0.32) },
      { y: 0.018, rx: 0.045, rz: 0.118, oz: 0.048, shape: footShape(0.32) },
    ];
    const sole = makeStylizedMesh(createLoftGeometry(soleRings, 10), opts.soleMat, {
      outline: outline * 0.78,
    });
    group.add(sole);

    // Sculpted upper dress oxford vamp + sleek toe slope
    const upperRings: LoftRing[] = [
      { y: 0.016, rx: 0.044, rz: 0.116, oz: 0.047, shape: footShape(0.34) },
      { y: 0.044, rx: 0.042, rz: 0.102, oz: 0.036, shape: footShape(0.36) },
      { y: 0.072, rx: 0.039, rz: 0.068, oz: 0.006, shape: footShape(0.18) },
      { y: 0.095, rx: 0.038, rz: 0.048, oz: -0.008 },
    ];
    const upper = makeStylizedMesh(createLoftGeometry(upperRings, 10), opts.lowerMat, {
      outline,
    });
    group.add(upper);

    return group;
  }

  // Sleek tapered tactical combat boot (Boonie / Venom / Reaper) — flush contoured sole!
  const h = opts.height ?? 0.22;

  const soleRings: LoftRing[] = [
    { y: 0.0, rx: 0.052, rz: 0.120, oz: 0.044, shape: footShape(0.24) },
    { y: 0.026, rx: 0.053, rz: 0.121, oz: 0.044, shape: footShape(0.24) },
  ];
  const sole = makeStylizedMesh(createLoftGeometry(soleRings, 10), opts.soleMat, {
    outline: outline * 0.85,
  });
  group.add(sole);

  // Sculpted lower boot vamp & rounded-faceted toe box
  const vampRings: LoftRing[] = [
    { y: 0.024, rx: 0.051, rz: 0.118, oz: 0.042, shape: footShape(0.26) },
    { y: 0.062, rx: 0.049, rz: 0.104, oz: 0.032, shape: footShape(0.28) },
    { y: 0.098, rx: 0.047, rz: 0.068, oz: 0.002, shape: footShape(0.12) },
  ];
  const vamp = makeStylizedMesh(createLoftGeometry(vampRings, 10), opts.lowerMat, {
    outline,
  });
  group.add(vamp);

  // Tapered athletic boot ankle & calf shaft
  const shaftRings: LoftRing[] = [
    { y: 0.088, rx: 0.047, rz: 0.056, oz: -0.006 },
    { y: h * 0.65, rx: 0.052, rz: 0.060, oz: -0.005 },
    { y: h, rx: 0.058, rz: 0.064, oz: -0.004 },
  ];
  const shaft = makeStylizedMesh(createLoftGeometry(shaftRings, 10), opts.upperMat, {
    outline,
  });
  group.add(shaft);

  return group;
}

/**
 * Builds an articulated sleek low-poly limb segment oriented precisely from `from` to `to`.
 * Uses 10-sided smooth-faceted cross-sections with zero robotic boxy seams.
 */
export function buildLimbBetween(
  from: THREE.Vector3,
  to: THREE.Vector3,
  rStartX: number,
  rStartZ: number,
  rMidX: number,
  rMidZ: number,
  rEndX: number,
  rEndZ: number,
  material: THREE.Material,
  radialSegments = 10,
  opts: StylizedMeshOptions = {}
): THREE.Group {
  const dir = new THREE.Vector3().subVectors(to, from);
  const len = dir.length();
  const holder = new THREE.Group();
  holder.position.copy(from);

  const up = new THREE.Vector3(0, 1, 0);
  const quat = new THREE.Quaternion().setFromUnitVectors(up, dir.clone().normalize());
  holder.quaternion.copy(quat);

  const rings: LoftRing[] = [
    { y: -0.014, rx: rStartX * 0.88, rz: rStartZ * 0.88 },
    { y: len * 0.06, rx: rStartX, rz: rStartZ },
    { y: len * 0.48, rx: rMidX, rz: rMidZ },
    { y: len * 0.92, rx: rEndX, rz: rEndZ },
    { y: len + 0.014, rx: rEndX * 0.88, rz: rEndZ * 0.88 },
  ];

  const mesh = makeStylizedMesh(createLoftGeometry(rings, radialSegments), material, {
    outline: opts.outline ?? 0.0048,
    edgeThreshold: opts.edgeThreshold ?? 0,
    subtleEdges: opts.subtleEdges,
    name: opts.name,
  });
  holder.add(mesh);
  return holder;
}

/**
 * Smooth rounded-faceted deltoid shoulder cap (replaces spiky icosahedron balls!).
 */
export function createShoulderCap(
  position: THREE.Vector3,
  material: THREE.Material,
  radius = 0.072,
  outline = 0.0044
): THREE.Mesh {
  const geom = new THREE.SphereGeometry(radius, 10, 7);
  geom.scale(0.95, 1.06, 0.95);
  const mesh = makeStylizedMesh(geom, material, { outline, edgeThreshold: 0 });
  mesh.position.copy(position);
  return mesh;
}

/**
 * Smooth elbow fold cap (replaces jagged dodecahedrons).
 */
export function createElbowCap(
  position: THREE.Vector3,
  material: THREE.Material,
  radius = 0.056,
  outline = 0.0042
): THREE.Mesh {
  const geom = new THREE.SphereGeometry(radius, 8, 6);
  const mesh = makeStylizedMesh(geom, material, { outline, edgeThreshold: 0 });
  mesh.position.copy(position);
  return mesh;
}

/**
 * Smooth spherical wrist connector cap so hands NEVER detach or expose gaps at any joint bend.
 */
export function createWristCap(
  position: THREE.Vector3,
  material: THREE.Material,
  radius = 0.043,
  outline = 0.0036
): THREE.Mesh {
  const geom = new THREE.SphereGeometry(radius, 8, 6);
  const mesh = makeStylizedMesh(geom, material, { outline, edgeThreshold: 0 });
  mesh.position.copy(position);
  return mesh;
}

/**
 * Helper: builds a sleek tapered low-poly finger/thumb phalanx extending from local y = 0 down to y = -length
 * with rounded knuckle joint at top and rounded fingertip dome when `isTip = true`.
 */
function createPhalanxGeometry(
  length: number,
  rBase: number,
  rTip: number,
  isTip = false
): THREE.BufferGeometry {
  const rings: LoftRing[] = [
    { y: rBase * 0.55, rx: rBase * 0.72, rz: rBase * 0.72 },
    { y: 0.0, rx: rBase, rz: rBase * 0.95 },
    { y: -length * 0.55, rx: (rBase + rTip) * 0.50, rz: (rBase + rTip) * 0.47 },
    { y: -length * (isTip ? 0.84 : 1.0), rx: rTip, rz: rTip * 0.90 },
  ];
  if (isTip) {
    rings.push({ y: -length * 1.03, rx: rTip * 0.42, rz: rTip * 0.36 });
  } else {
    rings.push({ y: -length - rTip * 0.45, rx: rTip * 0.68, rz: rTip * 0.65 });
  }
  // Loft rings must be ascending in Y so outward winding normals point cleanly out!
  rings.reverse();
  return createLoftGeometry(rings, 6, true, true);
}

/**
 * Anatomically sculpted stylized low-poly hand anchored cleanly at local wrist pivot (0, 0, 0).
 * True human left/right coordinate convention:
 *  - Fingers extend along -Y
 *  - Palm flexion interior = +Z (fingers curl into +Z)
 *  - Back of hand / knuckles = -Z
 *  - Thumb (radial side) = +s * X (s = +1 for left hand, s = -1 for right hand)
 *  - Pinky (ulnar side)  = -s * X
 * Features flat-beveled trapezoidal palm, muscular thenar thumb pad, 4 individual 2-segment
 * articulated fingers (Index, Middle, Ring, Pinky), opposable 2-segment thumb, and proper
 * fingerless tactical glove support when `fingerMaterial` is provided!
 */
export function createStylizedHand(
  material: THREE.Material,
  side: 'left' | 'right',
  pose: 'fist' | 'relaxed' | 'grip' | 'hip' | 'silat' = 'fist',
  outline = 0.0038,
  fingerMaterial?: THREE.Material,
  handScale = 1.54
): THREE.Group {
  const g = new THREE.Group();
  const s = side === 'left' ? 1 : -1;
  const k = handScale; // ~1.54x linear (~2.3x visual hand area!) proportional to athletic forearms!
  const fMat = fingerMaterial ?? material;
  const isFingerless = fingerMaterial !== undefined && fingerMaterial !== material;
  const digitOutline = Math.min(0.0024, outline * 0.56);

  // 1. Bold Heroic Flat-Beveled Trapezoidal Palm (smoothly matches forearm wrist -> bold wide palm!)
  const palmShape = (thenarStr: number, flatBack = 0.86) => (angle: number) => {
    const front = Math.cos(angle);
    const thumbSide = Math.sin(angle) * s;
    let dzAdd = 0;
    let rzMul = flatBack;
    if (thenarStr > 0 && front > 0.15 && thumbSide > 0.15) {
      dzAdd += thenarStr * front * thumbSide;
    }
    if (front > 0.65 && Math.abs(thumbSide) < 0.45) {
      rzMul *= 0.88;
    }
    return { rzMul, dzAdd };
  };

  const palmRings: LoftRing[] = [
    { y: -0.062 * k, rx: 0.0365 * k, rz: 0.0175 * k, shape: palmShape(0.0025 * k, 0.90) },
    { y: -0.042 * k, rx: 0.0378 * k, rz: 0.0195 * k, shape: palmShape(0.0085 * k, 0.92) },
    { y: -0.018 * k, rx: 0.0330 * k, rz: 0.0200 * k, shape: palmShape(0.0100 * k, 0.94) },
    // Wrist base smoothly anchored to natural forearm radius (~0.041) so zero bulge!
    { y: 0.004 * k, rx: 0.040, rz: 0.031 },
    { y: 0.016 * k, rx: 0.035, rz: 0.028 },
  ];
  const palm = makeStylizedMesh(createLoftGeometry(palmRings, 10, true, true), material, {
    outline: outline * 0.86,
    edgeThreshold: 0,
  });
  g.add(palm);

  // Raised tactical knuckle guard bar on back of hand (-Z) for fingerless tactical gloves
  if (isFingerless) {
    const knuckleGuard = makeStylizedMesh(
      createBeveledBoxGeometry(0.068 * k, 0.016 * k, 0.012 * k, 0.004 * k),
      material,
      { outline: digitOutline }
    );
    knuckleGuard.position.set(0, -0.054 * k, -0.014 * k);
    g.add(knuckleGuard);
  }

  // 2. FOUR INDIVIDUAL ARTICULATED 2-SEGMENT FINGERS (Index, Middle, Ring, Pinky)
  interface FingerSpec {
    x: number;
    y: number;
    len1: number;
    len2: number;
    rBase: number;
    rTip: number;
    curl1: number;
    curl2: number;
    spreadZ: number;
  }

  const baseSpecs = [
    { x: s * 0.0258 * k, y: -0.059 * k, len1: 0.033 * k, len2: 0.027 * k, rBase: 0.0080 * k, rTip: 0.0060 * k },
    { x: s * 0.0088 * k, y: -0.061 * k, len1: 0.037 * k, len2: 0.030 * k, rBase: 0.0082 * k, rTip: 0.0062 * k },
    { x: s * -0.0085 * k, y: -0.060 * k, len1: 0.034 * k, len2: 0.027 * k, rBase: 0.0078 * k, rTip: 0.0058 * k },
    { x: s * -0.0248 * k, y: -0.056 * k, len1: 0.027 * k, len2: 0.022 * k, rBase: 0.0070 * k, rTip: 0.0052 * k },
  ];

  const poseKinematics: Record<
    'fist' | 'relaxed' | 'grip' | 'hip' | 'silat',
    { curl1: number[]; curl2: number[]; spread: number[] }
  > = {
    fist: {
      curl1: [1.52, 1.56, 1.58, 1.60],
      curl2: [1.62, 1.65, 1.65, 1.62],
      spread: [-0.03, 0.0, 0.02, 0.04],
    },
    grip: {
      curl1: [0.76, 1.08, 1.14, 1.18],
      curl2: [0.88, 1.24, 1.28, 1.30],
      spread: [0.05, 0.0, -0.03, -0.07],
    },
    relaxed: {
      curl1: [0.22, 0.30, 0.38, 0.46],
      curl2: [0.28, 0.36, 0.44, 0.52],
      spread: [0.06, 0.01, -0.04, -0.10],
    },
    hip: {
      curl1: [0.06, 0.08, 0.10, 0.12],
      curl2: [0.08, 0.10, 0.12, 0.14],
      spread: [0.12, 0.03, -0.06, -0.15],
    },
    silat: {
      // Iconic Pencak Silat martial-arts guard hand: alert open-curved parry/strike fingers!
      curl1: [0.16, 0.22, 0.30, 0.40],
      curl2: [0.24, 0.28, 0.34, 0.44],
      spread: [0.10, 0.02, -0.04, -0.10],
    },
  };

  const kin = poseKinematics[pose];
  const fingers: FingerSpec[] = baseSpecs.map((b, i) => ({
    ...b,
    curl1: kin.curl1[i],
    curl2: kin.curl2[i],
    spreadZ: s * kin.spread[i],
  }));

  for (const f of fingers) {
    const proxGroup = new THREE.Group();
    proxGroup.position.set(f.x, f.y, 0.001 * k);
    proxGroup.rotation.order = 'ZXY';
    proxGroup.rotation.z = f.spreadZ;
    proxGroup.rotation.x = -f.curl1;

    if (isFingerless) {
      const gloveStub = makeStylizedMesh(
        createPhalanxGeometry(f.len1 * 0.42, f.rBase * 1.08, f.rBase * 1.02, false),
        material,
        { outline: digitOutline }
      );
      proxGroup.add(gloveStub);

      const bareProx = makeStylizedMesh(
        createPhalanxGeometry(f.len1 * 0.65, f.rBase * 0.94, f.rTip * 1.08, false),
        fMat,
        { outline: digitOutline }
      );
      bareProx.position.y = -f.len1 * 0.35;
      proxGroup.add(bareProx);
    } else {
      const proxMesh = makeStylizedMesh(
        createPhalanxGeometry(f.len1, f.rBase, f.rTip * 1.12, false),
        fMat,
        { outline: digitOutline }
      );
      proxGroup.add(proxMesh);
    }

    const distGroup = new THREE.Group();
    distGroup.position.set(0, -f.len1, 0);
    distGroup.rotation.x = -f.curl2;

    const distMesh = makeStylizedMesh(
      createPhalanxGeometry(f.len2, f.rTip * 1.08, f.rTip * 0.82, true),
      fMat,
      { outline: digitOutline }
    );
    distGroup.add(distMesh);

    proxGroup.add(distGroup);
    g.add(proxGroup);
  }

  // 3. ANATOMICALLY SCULPTED 2-SEGMENT OPPOSABLE THUMB (Radial +s * X side!)
  const thumbRoot = new THREE.Group();
  thumbRoot.position.set(s * 0.032 * k, -0.026 * k, 0.008 * k);
  thumbRoot.rotation.order = 'YXZ';

  const thumbDist = new THREE.Group();
  thumbDist.position.set(0, -0.030 * k, 0);

  if (pose === 'fist') {
    thumbRoot.rotation.x = -0.96;
    thumbRoot.rotation.z = s * 0.22;
    thumbRoot.rotation.y = s * -0.45;
    thumbDist.rotation.z = -s * 0.85;
    thumbDist.rotation.x = -0.42;
  } else if (pose === 'grip') {
    thumbRoot.rotation.x = -0.78;
    thumbRoot.rotation.z = s * 0.44;
    thumbRoot.rotation.y = s * -0.35;
    thumbDist.rotation.z = -s * 0.42;
    thumbDist.rotation.x = -0.34;
  } else if (pose === 'hip' || pose === 'silat') {
    thumbRoot.rotation.x = pose === 'silat' ? -0.36 : -0.14;
    thumbRoot.rotation.z = s * (pose === 'silat' ? 0.54 : 0.70);
    thumbRoot.rotation.y = s * -0.22;
    thumbDist.rotation.z = -s * 0.18;
    thumbDist.rotation.x = -0.12;
  } else {
    thumbRoot.rotation.x = -0.34;
    thumbRoot.rotation.z = s * 0.46;
    thumbRoot.rotation.y = s * -0.25;
    thumbDist.rotation.z = -s * 0.20;
    thumbDist.rotation.x = -0.18;
  }

  thumbRoot.add(
    makeStylizedMesh(
      createPhalanxGeometry(0.030 * k, 0.0098 * k, 0.0084 * k, false),
      isFingerless ? material : fMat,
      { outline: digitOutline }
    )
  );
  thumbDist.add(
    makeStylizedMesh(createPhalanxGeometry(0.025 * k, 0.0084 * k, 0.0066 * k, true), fMat, {
      outline: digitOutline,
    })
  );

  thumbRoot.add(thumbDist);
  g.add(thumbRoot);

  return g;
}

/**
 * Sleek Low-Top Black Athletic Sport Sneaker (for Skin 09 Silat Striker — clearly a running/sport shoe, NOT a boot!).
 * Grounded cleanly at local y = 0.
 */
export function createAthleticSportShoe(opts: {
  upperMat: THREE.Material;
  soleMat: THREE.Material;
  accentMat: THREE.Material;
  outline?: number;
}): THREE.Group {
  const g = new THREE.Group();
  const ol = opts.outline ?? 0.0040;

  const footShape = (toeNarrow: number) => (angle: number) => {
    const front = Math.cos(angle);
    return {
      rxMul: front > 0 ? 1.0 - toeNarrow * front : 0.88,
    };
  };

  // Sculpted cushioned athletic running midsole (thicker springy heel tapering sleekly toward toe!)
  const midsoleShape = (angle: number) => {
    const front = Math.cos(angle);
    return {
      rxMul: front > 0 ? 1.0 - 0.24 * front : 0.92,
      dyAdd: front > 0.55 ? 0.006 * (front - 0.55) : front < -0.3 ? 0.008 * (-front - 0.3) : 0,
    };
  };
  const midsoleRings: LoftRing[] = [
    { y: 0.0, rx: 0.049, rz: 0.122, oz: 0.046, shape: footShape(0.24) },
    { y: 0.028, rx: 0.052, rz: 0.125, oz: 0.046, shape: midsoleShape },
  ];
  g.add(makeStylizedMesh(createLoftGeometry(midsoleRings, 12), opts.soleMat, { outline: ol * 0.85 }));

  // Sleek low-top athletic mesh upper + curved toe cap
  const upperRings: LoftRing[] = [
    { y: 0.026, rx: 0.048, rz: 0.119, oz: 0.044, shape: footShape(0.28) },
    { y: 0.058, rx: 0.046, rz: 0.102, oz: 0.032, shape: footShape(0.32) },
    { y: 0.088, rx: 0.043, rz: 0.068, oz: 0.002, shape: footShape(0.16) },
    { y: 0.104, rx: 0.041, rz: 0.054, oz: -0.008 }, // Low padded sport collar below ankle!
  ];
  g.add(makeStylizedMesh(createLoftGeometry(upperRings, 12), opts.upperMat, { outline: ol }));

  // Padded sport tongue rising slightly at front instep
  const tongue = makeStylizedMesh(
    createBeveledBoxGeometry(0.046, 0.054, 0.020, 0.006),
    opts.upperMat,
    { outline: ol * 0.72 }
  );
  tongue.position.set(0, 0.092, 0.048);
  tongue.rotation.x = -0.52;
  g.add(tongue);

  // Sporty grey/slate athletic laces + side aerodynamic stripe accents!
  for (let i = 0; i < 3; i++) {
    const lace = makeStylizedMesh(
      createBeveledBoxGeometry(0.044, 0.007, 0.010, 0.002),
      opts.accentMat,
      { outline: 0 }
    );
    lace.position.set(0, 0.078 - i * 0.011, 0.058 + i * 0.020);
    lace.rotation.x = 0.40;
    g.add(lace);
  }

  for (const s of [-1, 1]) {
    const stripe = makeStylizedMesh(
      createBeveledBoxGeometry(0.008, 0.014, 0.088, 0.002),
      opts.accentMat,
      { outline: 0 }
    );
    stripe.position.set(s * 0.047, 0.052, 0.040);
    stripe.rotation.x = 0.14;
    g.add(stripe);
  }

  // Molded heel stabilizer tab at back of running shoe
  const heelTab = makeStylizedMesh(
    createBeveledBoxGeometry(0.050, 0.040, 0.020, 0.006),
    opts.accentMat,
    { outline: ol * 0.65 }
  );
  heelTab.position.set(0, 0.054, -0.060);
  g.add(heelTab);

  return g;
}

/**
 * Builds a sleek open-front curved jacket shell wrapping smoothly around a torso (from front-right
 * lapel around the back to front-left lapel), completely eliminating boxy flat front flaps!
 */
export function createOpenJacketShellGeometry(opts: {
  rings: { y: number; rx: number; rz: number; openHalfAngle: number }[];
  thickness: number;
  segs?: number;
}): THREE.BufferGeometry {
  const { rings, thickness } = opts;
  const segs = opts.segs ?? 14;
  const ringCols = segs + 1;

  const verts: number[] = [];
  const idx: number[] = [];

  // Push outer vertices then inner vertices for each ring
  for (let r = 0; r < rings.length; r++) {
    const ring = rings[r];
    const startAng = ring.openHalfAngle; // angle 0 = +Z front center, wrap clockwise around back
    const span = Math.PI * 2 - ring.openHalfAngle * 2;
    for (let s = 0; s <= segs; s++) {
      const ang = startAng + (s / segs) * span;
      const sx = Math.sin(ang);
      const cz = Math.cos(ang);
      verts.push(sx * ring.rx, ring.y, cz * ring.rz);
    }
  }
  const innerOffset = rings.length * ringCols;
  for (let r = 0; r < rings.length; r++) {
    const ring = rings[r];
    const startAng = ring.openHalfAngle;
    const span = Math.PI * 2 - ring.openHalfAngle * 2;
    for (let s = 0; s <= segs; s++) {
      const ang = startAng + (s / segs) * span;
      const sx = Math.sin(ang);
      const cz = Math.cos(ang);
      verts.push(
        sx * Math.max(0.01, ring.rx - thickness),
        ring.y,
        cz * Math.max(0.01, ring.rz - thickness)
      );
    }
  }

  for (let r = 0; r < rings.length - 1; r++) {
    for (let s = 0; s < segs; s++) {
      // Outer skin
      const a = r * ringCols + s;
      const b = a + 1;
      const c = (r + 1) * ringCols + s;
      const d = c + 1;
      idx.push(a, b, d, a, d, c);

      // Inner skin (reversed winding)
      const ia = innerOffset + a;
      const ib = innerOffset + b;
      const ic = innerOffset + c;
      const id = innerOffset + d;
      idx.push(ia, id, ib, ia, ic, id);
    }
  }

  // Front-left & front-right lapel edge caps
  for (let r = 0; r < rings.length - 1; r++) {
    const o0 = r * ringCols;
    const o1 = (r + 1) * ringCols;
    const i0 = innerOffset + o0;
    const i1 = innerOffset + o1;
    idx.push(o0, o1, i1, o0, i1, i0);

    const ro0 = r * ringCols + segs;
    const ro1 = (r + 1) * ringCols + segs;
    const ri0 = innerOffset + ro0;
    const ri1 = innerOffset + ro1;
    idx.push(ro0, ri1, ro1, ro0, ri0, ri1);
  }

  // Bottom & top hem edge rims
  const lastR = (rings.length - 1) * ringCols;
  for (let s = 0; s < segs; s++) {
    // Bottom rim
    idx.push(s, innerOffset + s + 1, s + 1);
    idx.push(s, innerOffset + s, innerOffset + s + 1);
    // Top rim
    idx.push(lastR + s, lastR + s + 1, innerOffset + lastR + s + 1);
    idx.push(lastR + s, innerOffset + lastR + s + 1, innerOffset + lastR + s);
  }

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  geom.setIndex(idx);
  geom.computeVertexNormals();
  return geom;
}

/**
 * Hard-shell molded stylized tactical knee pad (rounded hexagonal armor shell + snug straps).
 */
export function createTacticalKneePad(
  padMat: THREE.Material,
  strapMat: THREE.Material,
  outline = 0.0042
): THREE.Group {
  const g = new THREE.Group();

  const strap = makeStylizedMesh(
    new THREE.CylinderGeometry(0.078, 0.076, 0.060, 10),
    strapMat,
    { outline: outline * 0.78, edgeThreshold: 0 }
  );
  g.add(strap);

  const capOuter = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: -0.064, rx: 0.044, rz: 0.022 },
        { y: -0.030, rx: 0.064, rz: 0.036 },
        { y: 0.030, rx: 0.064, rz: 0.036 },
        { y: 0.064, rx: 0.044, rz: 0.020 },
      ],
      8
    ),
    padMat,
    { outline, edgeThreshold: 0 }
  );
  capOuter.position.set(0, 0, 0.068);
  g.add(capOuter);

  const capInner = makeStylizedMesh(
    createBeveledBoxGeometry(0.080, 0.082, 0.018, 0.008),
    padMat,
    { outline: outline * 0.72, edgeThreshold: 0 }
  );
  capInner.position.set(0, 0, 0.092);
  g.add(capInner);

  return g;
}

/**
 * Crisp tactical magazine / utility pouch with optional top flap or protruding magazine.
 */
export function createTacticalPouch(opts: {
  width: number;
  height: number;
  depth: number;
  pouchMat: THREE.Material;
  flap?: boolean;
  flapMat?: THREE.Material;
  magMat?: THREE.Material;
  magHeight?: number;
  outline?: number;
}): THREE.Group {
  const g = new THREE.Group();
  const outline = opts.outline ?? 0.0036;

  const body = makeStylizedMesh(
    createBeveledBoxGeometry(opts.width, opts.height, opts.depth, 0.005),
    opts.pouchMat,
    { outline, edgeThreshold: 40, subtleEdges: true }
  );
  g.add(body);

  if (opts.flap) {
    const flap = makeStylizedMesh(
      createBeveledBoxGeometry(opts.width * 1.03, opts.height * 0.42, opts.depth * 1.07, 0.004),
      opts.flapMat ?? opts.pouchMat,
      { outline: outline * 0.85, edgeThreshold: 40, subtleEdges: true }
    );
    flap.position.set(0, opts.height * 0.30, 0.004);
    g.add(flap);
  }

  if (opts.magMat) {
    const mh = opts.magHeight ?? 0.094;
    const mag = makeStylizedMesh(
      createBeveledBoxGeometry(opts.width * 0.78, mh, opts.depth * 0.64, 0.003),
      opts.magMat,
      { outline: outline * 0.88, edgeThreshold: 38, subtleEdges: true }
    );
    mag.position.set(-0.004, opts.height * 0.42 + mh * 0.36, -0.001);
    mag.rotation.z = 0.09;
    g.add(mag);
  }

  return g;
}

/**
 * Athletic V-tapered stylized torso with NATURAL SLOPING TRAPEZIUS SHOULDERS
 * (completely fixes the boxy/Minecraft-like upper shoulders from Image 2!).
 */
export function createTorsoGeometry(opts?: {
  waistRx?: number;
  waistRz?: number;
  chestRx?: number;
  chestRz?: number;
  shoulderRx?: number;
  height?: number;
  yStart?: number;
}): THREE.BufferGeometry {
  const y0 = opts?.yStart ?? 0.97;
  const h = opts?.height ?? 0.54;
  const waistRx = opts?.waistRx ?? 0.158;
  const waistRz = opts?.waistRz ?? 0.106;
  const chestRx = opts?.chestRx ?? 0.204;
  const chestRz = opts?.chestRz ?? 0.124;
  const shoulderRx = opts?.shoulderRx ?? 0.214;

  const chestShape = (angle: number) => {
    const front = Math.cos(angle);
    return {
      rzMul: Math.abs(front) > 0.65 ? 0.93 : 1.0,
    };
  };

  // Notice the smooth anatomical shoulder slope from y0+h*0.74 -> y0+h*0.91 -> neck base y0+h!
  const rings: LoftRing[] = [
    { y: y0, rx: waistRx * 1.03, rz: waistRz * 1.01, shape: chestShape },
    { y: y0 + h * 0.20, rx: waistRx * 0.98, rz: waistRz * 0.98, shape: chestShape },
    { y: y0 + h * 0.50, rx: chestRx * 0.94, rz: chestRz * 0.96, shape: chestShape },
    { y: y0 + h * 0.75, rx: shoulderRx, rz: chestRz * 0.98, shape: chestShape },
    { y: y0 + h * 0.87, rx: shoulderRx * 0.78, rz: chestRz * 0.84, shape: chestShape },
    { y: y0 + h * 0.95, rx: 0.108, rz: 0.092 },
    { y: y0 + h, rx: 0.076, rz: 0.076 },
  ];

  return createLoftGeometry(rings, 10, true, true);
}
