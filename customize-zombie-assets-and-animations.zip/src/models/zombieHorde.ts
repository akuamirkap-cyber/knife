import * as THREE from 'three';
import {
  buildSmoothOutlineGeometry,
  createMat,
  getOutlineMaterial,
} from './materials';
import {
  createBeveledBoxGeometry,
  createLoftGeometry,
  createStylizedHeadGeometry,
  LoftRing,
} from './common';
import { AnimMode } from './types';

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let cachedZombieFaceTex: THREE.CanvasTexture | null = null;
let cachedZombieEyeTex: THREE.CanvasTexture | null = null;
let cachedTornClothTex: THREE.CanvasTexture | null = null;
let cachedTornPantsTex: THREE.CanvasTexture | null = null;

/**
 * Stylized low-poly POLYGON "City Zombie" face texture — deliberately NOT horror.
 * Plain blank WHITE eyes (no pupils, no sunken sockets), a small neutral closed mouth,
 * a soft nose shadow and a few light blood flecks, matching the reference pack art.
 * The base stays neutral pale so `InstancedMesh.setColorAt` tints every zombie's skin.
 */
export function getZombieFaceTexture(): THREE.CanvasTexture {
  if (cachedZombieFaceTex) return cachedZombieFaceTex;
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Neutral pale base (multiplied per-instance by undead skin color!)
  ctx.fillStyle = '#e8ece6';
  ctx.fillRect(0, 0, size, size);

  // Front of the face straddles the u seam (features drawn at x=0 and x=512)
  const drawFrontFeature = (drawFn: (ox: number) => void) => {
    drawFn(0);
    drawFn(size);
  };

  drawFrontFeature((ox) => {
    const ey = 254;

    // 1. Very soft brow-ridge shading so the face still reads without any scary socket
    ctx.fillStyle = 'rgba(64, 78, 76, 0.15)';
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.ellipse(ox + s * 38, ey - 13, 31, 23, s * 0.12, 0, Math.PI * 2);
      ctx.fill();
    }

    // 2. Eye beds. The actual WHITE comes from the emissive eye map (getZombieEyeTexture),
    //    because per-instance skin tint would wash plain white eyes straight back to teal.
    for (const s of [-1, 1]) {
      const ex = ox + s * 38;
      ctx.fillStyle = 'rgba(56, 72, 70, 0.32)';
      ctx.beginPath();
      ctx.ellipse(ex, ey, 24, 18, s * 0.12, 0, Math.PI * 2);
      ctx.fill();
    }

    // 3. Tiny soft nose shadow (never a dark hollow nostril)
    ctx.fillStyle = 'rgba(70, 84, 82, 0.32)';
    ctx.beginPath();
    ctx.ellipse(ox, 306, 9, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // 4. Small closed neutral mouth — flat and calm, NEVER a gaping fanged jaw
    ctx.strokeStyle = 'rgba(98, 68, 68, 0.85)';
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(ox - 24, 374);
    ctx.quadraticCurveTo(ox, 382, ox + 24, 374);
    ctx.stroke();

    // 5. A few light blood flecks on the cheek + one thin drip (reference-pack splatter, still tame)
    ctx.fillStyle = 'rgba(158, 28, 32, 0.72)';
    const flecks: [number, number, number, number][] = [
      [54, 316, 7, 5],
      [66, 334, 4, 3],
      [-58, 344, 6, 4],
      [-46, 360, 3.5, 3],
    ];
    for (const [fx, fy, fw, fh] of flecks) {
      ctx.beginPath();
      ctx.ellipse(ox + fx, fy, fw, fh, 0.4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(158, 28, 32, 0.6)';
    ctx.fillRect(ox + 15, 386, 5, 24);
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = 4;
  cachedZombieFaceTex = tex;
  return tex;
}

/**
 * Emissive-only eye map: pure black except two plain WHITE almond eyes.
 * Deliberately kept off `map` — `InstancedMesh.setColorAt` tints the diffuse map by the
 * zombie's teal skin, but `emissiveMap` is never instance-tinted, so the eyes stay white.
 */
export function getZombieEyeTexture(): THREE.CanvasTexture {
  if (cachedZombieEyeTex) return cachedZombieEyeTex;
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, size, size);

  const drawFrontFeature = (drawFn: (ox: number) => void) => {
    drawFn(0);
    drawFn(size);
  };

  drawFrontFeature((ox) => {
    for (const s of [-1, 1]) {
      const ex = ox + s * 38;
      const ey = 254;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(ex, ey, 21, 15, s * 0.12, 0, Math.PI * 2);
      ctx.fill();
      // gentle halo so the white has a soft edge rather than a hard cut
      ctx.strokeStyle = 'rgba(255,255,255,0.4)';
      ctx.lineWidth = 7;
      ctx.stroke();
    }
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = 4;
  cachedZombieEyeTex = tex;
  return tex;
}

/**
 * Torn, shredded, blood-and-grime stained cloth texture for zombie shirts/jackets/suits!
 * Bright neutral base lets `InstancedMesh.setColorAt` give every zombie a unique vivid costume color
 * while jagged rips, frayed tears, and dark stains stand out unmistakably!
 */
function getTornClothTexture(): THREE.CanvasTexture {
  if (cachedTornClothTex) return cachedTornClothTex;
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(42119);

  // Clean light-neutral fabric base
  ctx.fillStyle = '#e6e6e4';
  ctx.fillRect(0, 0, size, size);

  // Dirty weathered fabric patches & folds
  for (let i = 0; i < 24; i++) {
    ctx.fillStyle = i % 2 === 0 ? 'rgba(65, 58, 50, 0.24)' : 'rgba(255,255,255,0.14)';
    ctx.fillRect(rand() * size, rand() * size, 32 + rand() * 88, 48 + rand() * 110);
  }

  // Jagged horizontal & diagonal rips revealing dark shadow & frayed fabric edges!
  for (let i = 0; i < 11; i++) {
    const cx = 30 + rand() * (size - 60);
    const cy = 60 + rand() * (size - 120);
    const rw = 46 + rand() * 68;
    const rh = 16 + rand() * 24;

    ctx.fillStyle = '#2d2321';
    ctx.beginPath();
    ctx.moveTo(cx - rw * 0.5, cy);
    ctx.lineTo(cx - rw * 0.2, cy - rh * 0.55);
    ctx.lineTo(cx + rw * 0.15, cy - rh * 0.3);
    ctx.lineTo(cx + rw * 0.5, cy + rh * 0.1);
    ctx.lineTo(cx + rw * 0.18, cy + rh * 0.6);
    ctx.lineTo(cx - rw * 0.25, cy + rh * 0.4);
    ctx.closePath();
    ctx.fill();

    // Frayed bright cloth threads spanning across rip!
    ctx.strokeStyle = '#d4cec6';
    ctx.lineWidth = 3;
    for (let k = -2; k <= 2; k++) {
      ctx.beginPath();
      ctx.moveTo(cx - rw * 0.35, cy + k * 4);
      ctx.lineTo(cx + rw * 0.35, cy + k * 3 + 2);
      ctx.stroke();
    }
  }

  // Vivid fresh blood splatters on front chest & torn bottom hem (reference-pack red!)
  for (let i = 0; i < 16; i++) {
    ctx.fillStyle = i % 3 === 0 ? 'rgba(176, 26, 32, 0.72)' : 'rgba(120, 20, 24, 0.6)';
    const x = rand() * size;
    const y = 80 + rand() * (size - 100);
    ctx.beginPath();
    ctx.ellipse(x, y, 12 + rand() * 26, 16 + rand() * 32, rand() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  // Sprayed blood droplets flicked off the splatter hits
  for (let i = 0; i < 40; i++) {
    ctx.fillStyle = 'rgba(176, 26, 32, 0.66)';
    const x = rand() * size;
    const y = 70 + rand() * (size - 90);
    ctx.beginPath();
    ctx.ellipse(x, y, 2 + rand() * 5, 2 + rand() * 7, rand() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  // Dark shredded jagged shadow along lower garment hem (y near 450..512)
  ctx.fillStyle = '#332926';
  ctx.beginPath();
  ctx.moveTo(0, 512);
  for (let x = 0; x <= size; x += 24) {
    const jag = 468 + ((x * 37) % 38);
    ctx.lineTo(x, jag);
  }
  ctx.lineTo(size, 512);
  ctx.closePath();
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  cachedTornClothTex = tex;
  return tex;
}

/**
 * Resident-Evil-style bullet hole: torn dark puncture, frayed cloth rim, blood specks.
 * Lives on a transparent canvas and is punched through the shared costume material.
 */
let cachedHoleTex: THREE.CanvasTexture | null = null;
function getBulletHoleTexture(): THREE.CanvasTexture {
  if (cachedHoleTex) return cachedHoleTex;
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(778291);
  const cx = size / 2;
  const cy = size / 2;
  ctx.clearRect(0, 0, size, size);

  const ragged = (points: number, base: number, jitter: number, fill: string) => {
    ctx.beginPath();
    for (let i = 0; i <= points; i++) {
      const a = (i / points) * Math.PI * 2;
      const r = base + (rand() - 0.5) * jitter;
      const x = cx + Math.cos(a) * r;
      const y = cy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  };

  ragged(18, 44, 18, 'rgba(206, 196, 182, 0.8)'); // pale frayed threads
  ragged(15, 33, 15, 'rgba(66, 56, 52, 0.95)'); // torn dark edge
  ragged(12, 20, 12, '#0a090c'); // the puncture itself

  // Blood welling out around the tear
  ctx.fillStyle = 'rgba(148, 20, 24, 0.72)';
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.ellipse(
      cx + (rand() - 0.5) * 58,
      cy + (rand() - 0.5) * 58,
      3 + rand() * 6,
      3 + rand() * 7,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  cachedHoleTex = tex;
  return tex;
}

/**
 * Torn distressed zombie trousers texture with ragged knee holes & grime.
 */
function getTornPantsTexture(): THREE.CanvasTexture {
  if (cachedTornPantsTex) return cachedTornPantsTex;
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(88317);

  ctx.fillStyle = '#dfdfdc';
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 14; i++) {
    ctx.fillStyle = 'rgba(55, 48, 42, 0.28)';
    ctx.fillRect(rand() * size, rand() * size, 24 + rand() * 52, 40 + rand() * 90);
  }
  // Ragged knee tear rips
  for (let i = 0; i < 5; i++) {
    const x = 20 + rand() * (size - 40);
    const y = 55 + rand() * (size - 110);
    ctx.fillStyle = '#322624';
    ctx.fillRect(x, y, 36 + rand() * 34, 14 + rand() * 14);
    ctx.strokeStyle = '#d0cbc4';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + 2, y + 6);
    ctx.lineTo(x + 32, y + 6);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  cachedTornPantsTex = tex;
  return tex;
}

/**
 * Merges an array of non-indexed or indexed BufferGeometries (position + normal + uv)
 * into a single static BufferGeometry so each costume archetype stays 1 draw call!
 */
function mergeSimpleGeometries(geoms: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const nonIndexed = geoms.map((g) => (g.index ? g.toNonIndexed() : g.clone()));
  let totalVerts = 0;
  for (const g of nonIndexed) {
    totalVerts += g.getAttribute('position').count;
  }

  const posArr = new Float32Array(totalVerts * 3);
  const uvArr = new Float32Array(totalVerts * 2);

  let vOffset = 0;
  for (const g of nonIndexed) {
    const p = g.getAttribute('position') as THREE.BufferAttribute;
    const uv = g.getAttribute('uv') as THREE.BufferAttribute | undefined;
    for (let i = 0; i < p.count; i++) {
      posArr[(vOffset + i) * 3] = p.getX(i);
      posArr[(vOffset + i) * 3 + 1] = p.getY(i);
      posArr[(vOffset + i) * 3 + 2] = p.getZ(i);
      if (uv) {
        uvArr[(vOffset + i) * 2] = uv.getX(i);
        uvArr[(vOffset + i) * 2 + 1] = uv.getY(i);
      }
    }
    vOffset += p.count;
    g.dispose();
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uvArr, 2));
  out.computeVertexNormals();
  return out;
}

/**
 * Builds 4 distinctly sculpted TORN & TATTERED zombie costume torso geometries (centered around local y=0..0.52):
 *  0: Torn Office Commuter Suit (ripped blazer lapels + jagged trailing tails + crooked tie!)
 *  1: Shredded Street Hoodie (saw-tooth torn bottom hem + bunched ragged hood collar + torn shoulder!)
 *  2: Tattered Tactical / Security Vest (broken chest plates + asymmetrical ripped pockets + dangling strap!)
 *  3: Ripped Sleeveless / Torn Civilian Tee (jagged diagonal hem tear + dangling torn cloth strips!)
 */
function createZombieTorsoArchetype(archetype: 0 | 1 | 2 | 3): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];

  // Saw-tooth jagged torn bottom edge helper!
  const jaggedHem = (seedShift: number, amp = 0.036) => (angle: number) => ({
    dyAdd: Math.sin(angle * 4 + seedShift) * amp + Math.cos(angle * 3 - seedShift) * (amp * 0.55),
  });

  if (archetype === 0) {
    // 0: TORN OFFICE SUIT BLAZER + CROOKED TIE
    const rings: LoftRing[] = [
      { y: -0.04, rx: 0.168, rz: 0.112, shape: jaggedHem(0.4, 0.042) }, // Shredded suit tails!
      { y: 0.12, rx: 0.162, rz: 0.106 },
      { y: 0.32, rx: 0.198, rz: 0.120 },
      { y: 0.45, rx: 0.208, rz: 0.120 },
      { y: 0.51, rx: 0.095, rz: 0.088 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // Torn suit lapels jutting sharply outward
    for (const s of [-1, 1]) {
      const lapel = createBeveledBoxGeometry(0.056, 0.22, 0.022, 0.004);
      lapel.rotateZ(s * -0.26);
      lapel.translate(s * 0.068, 0.37, 0.122);
      parts.push(lapel);
    }
    // Crooked dangling necktie swinging askew!
    const tie = createBeveledBoxGeometry(0.036, 0.24, 0.014, 0.003);
    tie.rotateZ(0.28);
    tie.translate(0.024, 0.34, 0.128);
    parts.push(tie);
  } else if (archetype === 1) {
    // 1: SHREDDED STREET HOODIE (baggy jagged hem + bunched torn hood around back of neck!)
    const rings: LoftRing[] = [
      { y: -0.05, rx: 0.184, rz: 0.124, shape: jaggedHem(1.7, 0.052) },
      { y: 0.14, rx: 0.182, rz: 0.120 },
      { y: 0.34, rx: 0.212, rz: 0.130 },
      { y: 0.46, rx: 0.214, rz: 0.126 },
      { y: 0.52, rx: 0.112, rz: 0.104 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // Bunched ragged hoodie cowl behind neck
    const hood = createLoftGeometry(
      [
        { y: 0.45, rx: 0.136, rz: 0.132, oz: -0.022 },
        { y: 0.54, rx: 0.122, rz: 0.120, oz: -0.028 },
      ],
      8,
      false,
      true
    );
    parts.push(hood);

    // Torn half-detached front kangaroo pocket flap
    const pocket = createBeveledBoxGeometry(0.16, 0.10, 0.028, 0.005);
    pocket.rotateZ(-0.18);
    pocket.translate(-0.02, 0.12, 0.132);
    parts.push(pocket);
  } else if (archetype === 2) {
    // 2: TATTERED TACTICAL / SECURITY VEST (broken armor plate + ripped pockets + dangling strap!)
    const rings: LoftRing[] = [
      { y: -0.02, rx: 0.166, rz: 0.112, shape: jaggedHem(3.1, 0.036) },
      { y: 0.14, rx: 0.172, rz: 0.116 },
      { y: 0.33, rx: 0.208, rz: 0.128 },
      { y: 0.45, rx: 0.212, rz: 0.124 },
      { y: 0.51, rx: 0.096, rz: 0.090 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // Crooked cracked front chest vest plate
    const plate = createBeveledBoxGeometry(0.26, 0.28, 0.048, 0.008);
    plate.rotateZ(0.06);
    plate.translate(0, 0.27, 0.124);
    parts.push(plate);

    // Asymmetric surviving torn pouches (one missing/ripped off!)
    const p1 = createBeveledBoxGeometry(0.072, 0.11, 0.044, 0.005);
    p1.rotateZ(-0.12);
    p1.translate(-0.082, 0.17, 0.156);
    parts.push(p1);

    const p2 = createBeveledBoxGeometry(0.078, 0.095, 0.044, 0.005);
    p2.rotateZ(0.24);
    p2.translate(0.078, 0.15, 0.152);
    parts.push(p2);
  } else {
    // 3: SHREDDED RAGGED CIVILIAN T-SHIRT / WORKER TANK (heavily jagged bottom + dangling cloth tatters!)
    const rings: LoftRing[] = [
      { y: 0.02, rx: 0.158, rz: 0.104, shape: jaggedHem(4.9, 0.056) }, // Deep torn belly cut!
      { y: 0.16, rx: 0.162, rz: 0.108 },
      { y: 0.34, rx: 0.198, rz: 0.122 },
      { y: 0.45, rx: 0.202, rz: 0.118 },
      { y: 0.51, rx: 0.092, rz: 0.086 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // 3 hanging jagged ripped shirt tatter strips fluttering off the torn waist!
    const strips = [
      { x: -0.11, y: -0.04, z: 0.092, rz: -0.22 },
      { x: 0.04, y: -0.05, z: 0.102, rz: 0.16 },
      { x: 0.12, y: -0.03, z: -0.088, rz: 0.28 },
    ];
    for (const st of strips) {
      const rag = createBeveledBoxGeometry(0.048, 0.135, 0.016, 0.003);
      rag.rotateZ(st.rz);
      rag.translate(st.x, st.y, st.z);
      parts.push(rag);
    }
  }

  // Short integrated torn-collar neck connector so frantic head snapping never leaves a gap!
  parts.push(
    createLoftGeometry(
      [
        { y: 0.48, rx: 0.068, rz: 0.066 },
        { y: 0.56, rx: 0.056, rz: 0.056 },
      ],
      8,
      false,
      true
    )
  );

  return mergeSimpleGeometries(parts);
}

/** Total number of distinct zombie hair / headwear silhouettes. */
export const HAIR_STYLE_COUNT = 6;

/**
 * Builds one of 6 wildly different zombie hair / headwear silhouettes so no two
 * infected share a profile — ragged mop, mohawk, long straggled hair, bowl cut,
 * wispy balding ring and a wide-brim sun hat (straight from the reference pack art).
 * Every loft starts above the skull so there is zero z-fighting.
 */
export function createHairStyleGeometry(style: number): THREE.BufferGeometry {
  if (style === 1) {
    // 1: MOHAWK — narrow jagged blade running front-to-back over the crown
    const spike = (a: number) => ({ dyAdd: Math.sin(a * 7) * 0.014 + Math.cos(a * 3) * 0.006 });
    return createLoftGeometry(
      [
        { y: 0.048, rx: 0.036, rz: 0.106, oz: -0.006, shape: spike },
        { y: 0.126, rx: 0.034, rz: 0.102, oz: -0.008, shape: spike },
        { y: 0.186, rx: 0.026, rz: 0.070, oz: -0.010 },
        { y: 0.208, rx: 0.012, rz: 0.028, oz: -0.010 },
      ],
      7,
      false,
      true
    );
  }

  if (style === 2) {
    // 2: LONG STRAGGLED HAIR falling past the jaw, cut away from the face
    const openFace = (a: number) => {
      const front = Math.cos(a);
      return front > 0
        ? { rxMul: 0.55, rzMul: 0.5, dyAdd: -0.055 * front }
        : { dyAdd: 0.012 };
    };
    const jag = (a: number) => ({ dyAdd: Math.sin(a * 6) * 0.016 });
    return createLoftGeometry(
      [
        { y: -0.145, rx: 0.098, rz: 0.108, oz: -0.052, shape: jag },
        { y: -0.05, rx: 0.116, rz: 0.128, oz: -0.030, shape: jag },
        { y: 0.045, rx: 0.118, rz: 0.132, oz: -0.014, shape: openFace },
        { y: 0.118, rx: 0.112, rz: 0.126, oz: -0.008, shape: openFace },
        { y: 0.158, rx: 0.070, rz: 0.084, oz: -0.008 },
        { y: 0.170, rx: 0.024, rz: 0.028, oz: -0.008 },
      ],
      9,
      false,
      true
    );
  }

  if (style === 3) {
    // 3: BOWL CUT — smooth dome with a hard fringe coming down over the forehead
    const fringe = (a: number) => {
      const front = Math.cos(a);
      return front > 0.05 ? { dyAdd: -0.072 * front, rzMul: 1.03 } : { dyAdd: 0.016 };
    };
    return createLoftGeometry(
      [
        { y: 0.038, rx: 0.107, rz: 0.124, oz: -0.006, shape: fringe },
        { y: 0.112, rx: 0.103, rz: 0.120, oz: -0.008 },
        { y: 0.154, rx: 0.068, rz: 0.080, oz: -0.008 },
        { y: 0.166, rx: 0.022, rz: 0.026, oz: -0.008 },
      ],
      9,
      false,
      true
    );
  }

  if (style === 4) {
    // 4: WISPY BALDING — hair clinging only to the sides & back, high receded hairline
    const recede = (a: number) => {
      const front = Math.cos(a);
      return front > 0 ? { dyAdd: -0.052 * front, rxMul: 0.9, rzMul: 0.86 } : { dyAdd: 0.014 };
    };
    const patchy = (a: number) => ({ dyAdd: Math.sin(a * 5) * 0.012 });
    return createLoftGeometry(
      [
        { y: 0.030, rx: 0.104, rz: 0.120, oz: -0.004, shape: recede },
        { y: 0.082, rx: 0.098, rz: 0.112, oz: -0.006, shape: patchy },
        { y: 0.104, rx: 0.052, rz: 0.060, oz: -0.010, shape: patchy },
        { y: 0.112, rx: 0.018, rz: 0.022, oz: -0.010 },
      ],
      8,
      false,
      true
    );
  }

  if (style === 5) {
    // 5: WIDE-BRIM SUN HAT — flat floppy brim + tapered crown (reference-pack fisherwoman!)
    const floppy = (a: number) => ({ dyAdd: Math.sin(a * 4) * 0.014 + Math.cos(a * 2) * 0.008 });
    return createLoftGeometry(
      [
        { y: 0.040, rx: 0.204, rz: 0.216, oz: -0.012, shape: floppy },
        { y: 0.054, rx: 0.202, rz: 0.214, oz: -0.012, shape: floppy },
        { y: 0.070, rx: 0.116, rz: 0.132, oz: -0.010 },
        { y: 0.132, rx: 0.106, rz: 0.122, oz: -0.010 },
        { y: 0.168, rx: 0.070, rz: 0.082, oz: -0.010 },
        { y: 0.180, rx: 0.026, rz: 0.030, oz: -0.010 },
      ],
      10,
      true,
      true
    );
  }

  // 0: RAGGED DISHEVELED MOB — the classic torn mop of hair
  const hairShape = (angle: number) => {
    const front = Math.cos(angle);
    const jag = Math.sin(angle * 5) * 0.012 + Math.cos(angle * 3) * 0.008;
    return {
      dyAdd: front < 0.15 ? -0.068 * ((0.15 - front) / 1.15) + jag : 0.014 + jag * 0.6,
    };
  };
  return createLoftGeometry(
    [
      { y: 0.064, rx: 0.102, rz: 0.118, oz: -0.004, shape: hairShape },
      { y: 0.115, rx: 0.096, rz: 0.112, oz: -0.006 },
      { y: 0.152, rx: 0.064, rz: 0.076, oz: -0.008 },
      { y: 0.164, rx: 0.024, rz: 0.028, oz: -0.008 },
    ],
    8,
    false,
    true
  );
}

/**
 * Builds a single-bone upper limb segment extending from local y = 0 down to y = -length.
 */
function createLimbSegmentGeometry(
  length: number,
  rTop: number,
  rBot: number,
  tatteredCuff = false
): THREE.BufferGeometry {
  const cuffShape = tatteredCuff
    ? (ang: number) => ({ dyAdd: Math.sin(ang * 4) * 0.018 })
    : undefined;
  return createLoftGeometry(
    [
      { y: -length, rx: rBot, rz: rBot * 1.02, shape: cuffShape },
      { y: -length * 0.5, rx: (rTop + rBot) * 0.52, rz: (rTop + rBot) * 0.52 },
      { y: 0.02, rx: rTop, rz: rTop * 1.02 },
    ],
    7,
    true,
    true
  );
}

/**
 * Builds forearm + reaching clawed zombie hand extending from elbow y = 0 down to y = -0.34.
 */
export function createZombieForearmClawGeometry(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  parts.push(createLimbSegmentGeometry(0.24, 0.048, 0.036, false));

  // Clawed reaching zombie palm + curled talon fingers
  const palm = createBeveledBoxGeometry(0.068, 0.076, 0.030, 0.008);
  palm.translate(0, -0.268, 0.006);
  parts.push(palm);

  const claws = createBeveledBoxGeometry(0.066, 0.056, 0.026, 0.007);
  claws.rotateX(-0.55);
  claws.translate(0, -0.312, 0.024);
  parts.push(claws);

  return mergeSimpleGeometries(parts);
}

/**
 * Builds lower zombie shin + tattered shoe extending from knee y = 0 down to floor y = -0.49.
 */
export function createZombieShinFootGeometry(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  parts.push(createLimbSegmentGeometry(0.39, 0.068, 0.050, false));

  // Stylized torn shoe grounded cleanly at y = -0.49
  const foot = createBeveledBoxGeometry(0.098, 0.095, 0.215, 0.014);
  foot.translate(0, -0.442, 0.045);
  parts.push(foot);

  return mergeSimpleGeometries(parts);
}

type ZombieBehavior = 'lunger' | 'sprinter' | 'flailer' | 'leaper';

interface ZombieAgent {
  index: number;
  archetype: 0 | 1 | 2 | 3;
  archetypeSlot: number;
  behavior: ZombieBehavior;

  // Spatial swarm position behind squad
  baseX: number;
  baseZ: number;
  curX: number;
  curY: number;
  curZ: number;
  scale: number;

  // Dynamic rabid motion parameters
  stridePhase: number;
  speedRate: number;
  surgeSeed: number;
  weaveSeed: number;
  headTiltZ: number;
  headTwitchFreq: number;
  leapTimer: number;
  leapDuration: number;
  isLeaping: boolean;

  // Appearance diversity (asymmetric torn sleeves/pants!)
  hasHair: boolean;
  hairSlot: number;
  /** Which of the 6 hair / headwear silhouettes this infected wears (0 = ragged mop … 5 = sun hat) */
  hairStyle: number;
  /** Which of the 4 sculpted head / face shapes this infected has */
  headVariant: number;
  /** Slot of this zombie inside its head-shape InstancedMesh */
  headVariantSlot: number;
  /** Per-instance non-uniform head proportions (wide round vs narrow long faces) */
  headWide: number;
  headTall: number;
  /** Base instance colors, kept so hit-flash can restore them */
  skinColor: THREE.Color;
  shirtColor: THREE.Color;
  /** > 0 while the zombie is flashing white-hot from a bullet impact */
  flashTimer: number;
  /** True while a decapitated zombie is flying through the air headless */
  headHidden: boolean;
  /** 0 = both arms intact, 1 / 2 = that arm has been torn off by a bullet */
  lostArm: 0 | 1 | 2;
  /** 0 = both legs intact, 1 / 2 = that leg has been torn off by a bullet */
  lostLeg: 0 | 1 | 2;
  /** True once the ragdoll has slammed into the deck (drives the landing jolt) */
  kbGrounded: boolean;
  /**
   * Articulated ragdoll joints — 10 joints × (3 angle + 3 angular velocity) = 60 floats.
   * Order: 0 spine, 1 neck, 2/3 shoulders, 4/5 elbows, 6/7 hips, 8/9 knees.
   */
  ragdoll: Float32Array;
  /** How long this knockdown lasts in seconds (gun = 2.6, friend-collision stumble = 1.5) */
  kbDuration: number;
  /** Seconds until a torn-off limb grows back */
  limbRegen: number;
  /** Non-vital hit stagger: 0.5s of reeling backwards without leaving the ground */
  flinchTimer: number;
  flinchZ: number;
  flinchVelZ: number;
  /** Cooldown so zombies don't chain-stumble every single frame */
  stumbleCd: number;
  /** Bullet holes: 4 slots × (localX, localY, localZ, size) in torso space */
  holes: Float32Array;
  holeCount: number;
  /** Copy of the latest torso world matrix so holes stay stuck to the moving body */
  torsoM: Float32Array;
  leftSleeveTorn: boolean;
  rightSleeveTorn: boolean;
  leftPantTorn: boolean;
  rightPantTorn: boolean;

  // Interactive gunshot knockback state!
  kbActive: boolean;
  kbTimer: number;
  kbPos: THREE.Vector3;
  kbVel: THREE.Vector3;
  kbRot: THREE.Euler;
  kbSpin: THREE.Vector3;
}

/** Undead skin tones — the desaturated teal / grey-green of the reference pack art. */
const SKIN_PALETTE = [
  0x8fb3a6, // Pale sea-teal (the signature reference-pack zombie skin)
  0x7ea8a0, // Deeper blue-green
  0x9aa894, // Ashy grey-green
  0x86a89b, // Muted jade
  0x93b0a8, // Light desaturated teal
  0xa2ada2, // Pale grey sage
  0x7fa6a4, // Cool slate aqua
];

/** Costume colors lifted straight off the reference pack: hazmat yellow, violet tee,
 *  soiled white dress, teal jacket, burnt-orange coverall, denim and office wear. */
const COSTUME_COLORS = [
  0xf2c14e, // Hazard-yellow hazmat jumpsuit
  0xe0ad35, // Deeper mustard coverall
  0x6c5ce7, // Violet tee (purple-shirt zombie)
  0x7d6fd8, // Soft lavender blouse
  0xe8e4dc, // Soiled white dress
  0xd6d0c2, // Off-white bonnet / smock
  0x2f8f8a, // Teal jacket
  0x3aa7a0, // Bright teal polo
  0xc0703c, // Burnt-orange worker shirt
  0x9a5b45, // Rust-brown coat
  0x3b4859, // Torn navy office jacket
  0x6b3230, // Stained burgundy hoodie
  0x4f5a3e, // Shredded olive fatigues
  0x9a958b, // Dirty white dress shirt
  0x334b68, // Denim blue overshirt
];

const PANTS_COLORS = [
  0x29384d, // Faded torn blue jeans
  0x3a322d, // Dusty brown trousers
  0x25272d, // Charcoal office slacks
  0x4c483b, // Dirty khaki cargo pants
  0x33392e, // Torn olive work pants
  0x1d1f24, // Dark torn sweatpants
  0x4a5568, // Slate grey slacks
];

/** Hair runs the full gamut: black, brown, ash grey, white, blonde, auburn. */
export const HAIR_COLORS = [
  0x1c1816, 0x33261e, 0x4b4642, 0x2a211c, 0x523929,
  0x6b6259, 0x9a958c, 0xb9b3a6, 0x7a5a33, 0xa8813f, 0x6e3b2a,
];

/** Headwear palette for hair style 5 (wide-brim sun hats & bonnets). */
const HAT_COLORS = [0xe8e2d6, 0xc9bfe4, 0x8fb3a6, 0xd9c48a, 0x9aa0a8, 0xb0603f];

/** 4 sculpted head / face shapes: [scale, slimX, noseRidge] */
export const HEAD_VARIANTS: { scale: number; slimX: number; noseRidge: number }[] = [
  { scale: 0.97, slimX: 1.05, noseRidge: 0.021 }, // Wide round face, broad nose
  { scale: 0.93, slimX: 0.90, noseRidge: 0.013 }, // Narrow long face, small nose
  { scale: 1.04, slimX: 0.99, noseRidge: 0.025 }, // Big skull, heavy brow ridge
  { scale: 0.91, slimX: 1.09, noseRidge: 0.010 }, // Small flat wide face
];

export interface ZombieShootResult {
  hit: boolean;
  worldPoint: THREE.Vector3;
  /** True when the bullet found the head — the skull pops clean off and tumbles away */
  isHeadshot: boolean;
  /** Head-shape variant of the victim, for building the detached head gib */
  headVariant: number;
  /** Skin hex of the victim, for tinting the flying flesh gibs */
  skinColor: number;
  /** Hair style of the victim (-1 = bald), for the hair that flies off with the head */
  hairStyle: number;
  /** Which arm this shot tore off: 0 = none (already gone), 1 = left, 2 = right */
  lostArm: number;
  /** Which leg this shot tore off: 0 = none, 1 = left, 2 = right */
  lostLeg: number;
  /** Exactly which part of the zombie took the bullet */
  zone: 'head' | 'torso' | 'arm' | 'leg';
  /** True when the shot landed on a vital point and the body actually went down */
  isVital: boolean;
}

/** Blazing white impact tint lerped over skin & costume when a bullet lands. */
const IMPACT_FLASH = new THREE.Color(0xfff4e0);

// Zero-GC scratch objects for bullet-hole math
const _tmA = new THREE.Matrix4();
const _tmB = new THREE.Matrix4();
const _tmC = new THREE.Matrix4();
const _tvA = new THREE.Vector3();
const _tvB = new THREE.Vector3();
const _vN = new THREE.Vector3();
const _vZ = new THREE.Vector3(0, 0, 1);
const _qA = new THREE.Quaternion();
const _sA = new THREE.Vector3();

/**
 * High-performance GPU-Instanced World War Z Zombie Horde (~84 fully articulated,
 * cel-outlined infected with 4 distinct torn costume silhouettes & zero-lag rendering!).
 */
export class WorldWarZHorde {
  public readonly group = new THREE.Group();
  public readonly count: number;
  public readonly hitMeshes: THREE.InstancedMesh[] = [];

  private readonly agents: ZombieAgent[] = [];

  // InstancedMeshes — one pair per sculpted head shape, one per hair/headwear style
  private readonly headMeshes: THREE.InstancedMesh[] = [];
  private readonly headOutlines: THREE.InstancedMesh[] = [];
  private readonly hairMeshes: THREE.InstancedMesh[] = [];
  private readonly decalMesh: THREE.InstancedMesh;

  private readonly torsoMeshes: THREE.InstancedMesh[] = [];
  private readonly torsoOutlines: THREE.InstancedMesh[] = [];
  private readonly pelvisMesh: THREE.InstancedMesh;

  private readonly upperArmMesh: THREE.InstancedMesh;
  private readonly upperArmOutline: THREE.InstancedMesh;
  private readonly forearmMesh: THREE.InstancedMesh;
  private readonly forearmOutline: THREE.InstancedMesh;

  private readonly thighMesh: THREE.InstancedMesh;
  private readonly thighOutline: THREE.InstancedMesh;
  private readonly shinMesh: THREE.InstancedMesh;
  private readonly shinOutline: THREE.InstancedMesh;

  private readonly allInstanced: THREE.InstancedMesh[] = [];
  private readonly ownedGeoms: THREE.BufferGeometry[] = [];
  private readonly ownedMats: THREE.Material[] = [];

  // Zero-GC scratch transform objects for 60fps per-frame animation
  private readonly _mRoot = new THREE.Matrix4();
  private readonly _mTorso = new THREE.Matrix4();
  private readonly _mHead = new THREE.Matrix4();
  private readonly _mPart = new THREE.Matrix4();
  private readonly _mSub = new THREE.Matrix4();
  private readonly _mLocal = new THREE.Matrix4();
  private readonly _qTemp = new THREE.Quaternion();
  private readonly _eTemp = new THREE.Euler(0, 0, 0, 'YXZ');
  private readonly _vPos = new THREE.Vector3();
  private readonly _vScale = new THREE.Vector3(1, 1, 1);

  constructor(zombieCount = 84) {
    this.count = zombieCount;
    this.group.name = 'WorldWarZ_ZombieHorde';
    this.group.userData.isObstacle = true; // Automatically excluded from 9-skin GLB/OBJ export!

    const rand = mulberry32(20130621); // World War Z release seed!
    const outlineMat = getOutlineMaterial();

    // Shared flat-shaded stylized materials
    const headMat = createMat({
      color: 0xffffff,
      map: getZombieFaceTexture(),
      roughness: 0.84,
      // Glowing blank WHITE eyes — emissive bypasses the per-instance teal skin tint
      emissive: 0xffffff,
      emissiveIntensity: 1.0,
    });
    headMat.emissiveMap = getZombieEyeTexture();
    headMat.needsUpdate = true;
    const hairMat = createMat({ color: 0xffffff, roughness: 0.90 });
    const tornClothMat = createMat({
      color: 0xffffff,
      map: getTornClothTexture(),
      roughness: 0.88,
    });
    const tornPantsMat = createMat({
      color: 0xffffff,
      map: getTornPantsTexture(),
      roughness: 0.88,
    });
    this.ownedMats.push(headMat, hairMat, tornClothMat, tornPantsMat);

    const makePair = (
      geom: THREE.BufferGeometry,
      mat: THREE.Material,
      cap: number,
      outlineThick: number,
      castShadow = true
    ): [THREE.InstancedMesh, THREE.InstancedMesh] => {
      this.ownedGeoms.push(geom);
      const mesh = new THREE.InstancedMesh(geom, mat, cap);
      mesh.castShadow = castShadow;
      mesh.receiveShadow = true;
      mesh.frustumCulled = false;
      mesh.userData.isZombieHorde = true;
      mesh.userData.isObstacle = true;
      this.group.add(mesh);
      this.allInstanced.push(mesh);

      const olGeom = buildSmoothOutlineGeometry(geom, outlineThick);
      this.ownedGeoms.push(olGeom);
      const olMesh = new THREE.InstancedMesh(olGeom, outlineMat, cap);
      olMesh.castShadow = false;
      olMesh.receiveShadow = false;
      olMesh.frustumCulled = false;
      olMesh.userData.isOutline = true;
      olMesh.userData.isObstacle = true;
      olMesh.renderOrder = 1;
      this.group.add(olMesh);
      this.allInstanced.push(olMesh);

      return [mesh, olMesh];
    };

    // 1. Four sculpted FACE SHAPES (wide round / narrow long / big skull / small flat)
    for (let v = 0; v < HEAD_VARIANTS.length; v++) {
      const headGeom = createStylizedHeadGeometry(HEAD_VARIANTS[v]);
      const [hm, ho] = makePair(headGeom, headMat, zombieCount, 0.0046, true);
      this.headMeshes.push(hm);
      this.headOutlines.push(ho);
      this.hitMeshes.push(hm);
    }

    // 2. Six distinct HAIR / HEADWEAR silhouettes (ragged, mohawk, long, bowl, wispy, sun hat)
    for (let s = 0; s < HAIR_STYLE_COUNT; s++) {
      const hairGeom = createHairStyleGeometry(s);
      this.ownedGeoms.push(hairGeom);
      const hairMesh = new THREE.InstancedMesh(hairGeom, hairMat, zombieCount);
      hairMesh.castShadow = false;
      hairMesh.receiveShadow = true;
      hairMesh.frustumCulled = false;
      hairMesh.count = 0;
      hairMesh.userData.isObstacle = true;
      this.group.add(hairMesh);
      this.allInstanced.push(hairMesh);
      this.hairMeshes.push(hairMesh);
    }

    // 2. Pelvis InstancedMesh
    const pelvisGeom = createLoftGeometry(
      [
        { y: -0.07, rx: 0.148, rz: 0.100 },
        { y: 0.04, rx: 0.162, rz: 0.108 },
      ],
      8,
      true,
      true
    );
    this.ownedGeoms.push(pelvisGeom);
    this.pelvisMesh = new THREE.InstancedMesh(pelvisGeom, tornPantsMat, zombieCount);
    this.pelvisMesh.castShadow = false;
    this.pelvisMesh.receiveShadow = true;
    this.pelvisMesh.frustumCulled = false;
    this.pelvisMesh.userData.isObstacle = true;
    this.group.add(this.pelvisMesh);
    this.allInstanced.push(this.pelvisMesh);

    // 3. Generate all 84 unique World War Z horde agents FIRST so we know exact counts per costume archetype!
    const archCounts = [0, 0, 0, 0];
    const headVariantCounts = [0, 0, 0, 0];
    const hairStyleCounts = [0, 0, 0, 0, 0, 0];

    for (let i = 0; i < zombieCount; i++) {
      const archetype = (i % 4) as 0 | 1 | 2 | 3;
      const archetypeSlot = archCounts[archetype]++;

      // World War Z Funnel Formation behind the 9-skin squad:
      // Row 0 (front lungers): z = -1.65..-2.65, closely stalking right behind the 9 heroes!
      // Mid rows: dense surging rabid pack z = -2.7..-7.5, fanning wider (-5.2..+5.2)
      // Back wave: massive tidal horde z = -7.5..-12.8, fanning wide (-7.8..+7.8) with leapers!
      const depthNorm = Math.pow(i / Math.max(1, zombieCount - 1), 0.92);
      const baseZ = -1.65 - depthNorm * 10.6 + (rand() - 0.5) * 0.65;
      const halfSpreadX = 3.15 + depthNorm * 4.4;
      // Organic golden-angle + jitter distribution so there are zero artificial grid rows!
      const golden = ((i * 0.6180339887) % 1) * 2 - 1;
      const baseX = THREE.MathUtils.clamp(
        golden * halfSpreadX + (rand() - 0.5) * 0.95,
        -halfSpreadX,
        halfSpreadX
      );

      // Assign rabid World War Z behavioral personality!
      let behavior: ZombieBehavior;
      if (i < 16) {
        behavior = i % 3 === 0 ? 'flailer' : 'lunger';
      } else if (i % 5 === 0) {
        behavior = 'leaper';
      } else if (i % 3 === 0) {
        behavior = 'flailer';
      } else {
        behavior = 'sprinter';
      }

      // Face-shape lottery: 4 sculpted heads + wildly varied head proportions
      const headVariant = Math.floor(rand() * HEAD_VARIANTS.length);
      const headVariantSlot = headVariantCounts[headVariant]++;
      const headWide = 0.90 + rand() * 0.26;
      const headTall = 0.92 + rand() * 0.20;

      // Hair lottery: 6 silhouettes, mohawk & sun hat stay a bit rarer
      const hasHair = rand() < 0.9;
      const hairRoll = rand();
      const hairStyle = hasHair
        ? hairRoll < 0.34
          ? 0
          : hairRoll < 0.5
            ? 1
            : hairRoll < 0.68
              ? 2
              : hairRoll < 0.84
                ? 3
                : hairRoll < 0.93
                  ? 4
                  : 5
        : -1;
      const hairSlot = hasHair ? hairStyleCounts[hairStyle]++ : -1;

      this.agents.push({
        index: i,
        archetype,
        archetypeSlot,
        behavior,
        baseX,
        baseZ,
        curX: baseX,
        curY: 0,
        curZ: baseZ,
        scale: 0.90 + rand() * 0.17,
        stridePhase: rand(),
        speedRate: 1.55 + rand() * 0.55, // Frantic uneven rabid infected cadence!
        surgeSeed: rand() * Math.PI * 2,
        weaveSeed: rand() * Math.PI * 2,
        headTiltZ: (rand() - 0.5) * 0.62,
        headTwitchFreq: 2.2 + rand() * 2.6,
        leapTimer: 0.6 + rand() * 3.8,
        leapDuration: 0.68 + rand() * 0.18,
        isLeaping: false,
        hasHair,
        hairSlot,
        hairStyle,
        headVariant,
        headVariantSlot,
        headWide,
        headTall,
        skinColor: new THREE.Color(0xffffff),
        shirtColor: new THREE.Color(0xffffff),
        flashTimer: 0,
        headHidden: false,
        lostArm: 0,
        lostLeg: 0,
        kbGrounded: false,
        ragdoll: new Float32Array(60),
        kbDuration: 2.6,
        limbRegen: 0,
        flinchTimer: 0,
        flinchZ: 0,
        flinchVelZ: 0,
        stumbleCd: 0,
        holes: new Float32Array(16),
        holeCount: 0,
        torsoM: new Float32Array(16),
        leftSleeveTorn: archetype === 3 || rand() < 0.36,
        rightSleeveTorn: archetype === 3 || rand() < 0.36,
        leftPantTorn: rand() < 0.32,
        rightPantTorn: rand() < 0.32,
        kbActive: false,
        kbTimer: 0,
        kbPos: new THREE.Vector3(),
        kbVel: new THREE.Vector3(),
        kbRot: new THREE.Euler(),
        kbSpin: new THREE.Vector3(),
      });
    }

    // Each head-shape / hair-style InstancedMesh only draws ITS OWN instances
    for (let v = 0; v < HEAD_VARIANTS.length; v++) {
      this.headMeshes[v].count = headVariantCounts[v];
      this.headOutlines[v].count = headVariantCounts[v];
    }
    for (let s = 0; s < HAIR_STYLE_COUNT; s++) {
      this.hairMeshes[s].count = hairStyleCounts[s];
    }

    // 4. Create the 4 distinct Torn Costume Torso InstancedMeshes!
    for (let a = 0; a < 4; a++) {
      const cap = Math.max(1, archCounts[a]);
      const geom = createZombieTorsoArchetype(a as 0 | 1 | 2 | 3);
      const [mesh, ol] = makePair(geom, tornClothMat, cap, 0.0052, true);
      mesh.userData.zombieArchetype = a;
      this.torsoMeshes.push(mesh);
      this.torsoOutlines.push(ol);
      this.hitMeshes.push(mesh);
    }

    // 5. Shared Left+Right Limb InstancedMeshes (2 * zombieCount instances each = ONLY 8 draw calls!)
    const upperArmGeom = createLimbSegmentGeometry(0.24, 0.062, 0.048, true);
    [this.upperArmMesh, this.upperArmOutline] = makePair(
      upperArmGeom,
      tornClothMat,
      zombieCount * 2,
      0.0040,
      false
    );

    const forearmGeom = createZombieForearmClawGeometry();
    [this.forearmMesh, this.forearmOutline] = makePair(
      forearmGeom,
      tornClothMat,
      zombieCount * 2,
      0.0036,
      false
    );

    const thighGeom = createLimbSegmentGeometry(0.37, 0.088, 0.068, true);
    [this.thighMesh, this.thighOutline] = makePair(
      thighGeom,
      tornPantsMat,
      zombieCount * 2,
      0.0042,
      false
    );

    const shinGeom = createZombieShinFootGeometry();
    [this.shinMesh, this.shinOutline] = makePair(
      shinGeom,
      tornPantsMat,
      zombieCount * 2,
      0.0040,
      false
    );

    // EVERY body part is shootable: head, torso, pelvis, arms, forearms, thighs, shins
    this.hitMeshes.push(
      this.pelvisMesh,
      this.upperArmMesh,
      this.forearmMesh,
      this.thighMesh,
      this.shinMesh
    );

    // BULLET HOLES — up to 4 torn punctures per zombie, stuck to the moving torso
    const holeGeom = new THREE.PlaneGeometry(1, 1);
    const holeMat = new THREE.MeshStandardMaterial({
      map: getBulletHoleTexture(),
      transparent: true,
      alphaTest: 0.45,
      roughness: 0.95,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      polygonOffsetUnits: -4,
    });
    this.ownedGeoms.push(holeGeom);
    this.ownedMats.push(holeMat);
    this.decalMesh = new THREE.InstancedMesh(holeGeom, holeMat, zombieCount * 4);
    this.decalMesh.frustumCulled = false;
    this.decalMesh.castShadow = false;
    this.decalMesh.receiveShadow = false;
    this.decalMesh.userData.isObstacle = true;
    this.group.add(this.decalMesh);
    this.allInstanced.push(this.decalMesh);

    // 6. Paint unique per-instance colors (skin, varied torn costumes, torn bare sleeves/calves, hair!)
    const col = new THREE.Color();
    const skinCol = new THREE.Color();
    const shirtCol = new THREE.Color();
    const pantsCol = new THREE.Color();
    const hairCol = new THREE.Color();

    for (const ag of this.agents) {
      const i = ag.index;
      skinCol.setHex(SKIN_PALETTE[Math.floor(rand() * SKIN_PALETTE.length)]);
      skinCol.offsetHSL((rand() - 0.5) * 0.03, (rand() - 0.5) * 0.05, (rand() - 0.5) * 0.08);

      shirtCol.setHex(COSTUME_COLORS[Math.floor(rand() * COSTUME_COLORS.length)]);
      shirtCol.offsetHSL((rand() - 0.5) * 0.04, (rand() - 0.5) * 0.08, (rand() - 0.5) * 0.10);

      pantsCol.setHex(PANTS_COLORS[Math.floor(rand() * PANTS_COLORS.length)]);
      pantsCol.offsetHSL((rand() - 0.5) * 0.02, (rand() - 0.5) * 0.06, (rand() - 0.5) * 0.08);

      hairCol.setHex(HAIR_COLORS[Math.floor(rand() * HAIR_COLORS.length)]);

      // Remember the base colors so bullet impacts can flash white and settle back
      ag.skinColor.copy(skinCol);
      ag.shirtColor.copy(shirtCol);

      this.headMeshes[ag.headVariant].setColorAt(ag.headVariantSlot, skinCol);
      this.pelvisMesh.setColorAt(i, pantsCol);
      this.torsoMeshes[ag.archetype].setColorAt(ag.archetypeSlot, shirtCol);

      if (ag.hasHair && ag.hairSlot >= 0) {
        // Wide-brim hats & bonnets pull from their own accessory palette
        if (ag.hairStyle === 5) {
          hairCol.setHex(HAT_COLORS[Math.floor(rand() * HAT_COLORS.length)]);
        }
        this.hairMeshes[ag.hairStyle].setColorAt(ag.hairSlot, hairCol);
      }

      // Asymmetric Torn Sleeves: torn arm exposes bare undead zombie skin, intact arm uses tattered shirt!
      this.upperArmMesh.setColorAt(i * 2, ag.leftSleeveTorn ? skinCol : shirtCol);
      this.upperArmMesh.setColorAt(i * 2 + 1, ag.rightSleeveTorn ? skinCol : shirtCol);
      // Forearms & claw hands mostly bare bloodied undead skin (or torn sleeve cuff)
      this.forearmMesh.setColorAt(i * 2, skinCol);
      this.forearmMesh.setColorAt(i * 2 + 1, skinCol);

      // Asymmetric Torn Pants: ripped shin exposes pale scarred undead calf!
      this.thighMesh.setColorAt(i * 2, pantsCol);
      this.thighMesh.setColorAt(i * 2 + 1, pantsCol);
      this.shinMesh.setColorAt(
        i * 2,
        ag.leftPantTorn ? col.copy(skinCol).lerp(pantsCol, 0.25) : pantsCol
      );
      this.shinMesh.setColorAt(
        i * 2 + 1,
        ag.rightPantTorn ? col.copy(skinCol).lerp(pantsCol, 0.25) : pantsCol
      );
    }

    for (const m of this.allInstanced) {
      if (m.instanceColor) m.instanceColor.needsUpdate = true;
    }

    // Run one initial layout frame so horde starts posed cleanly on frame 0
    this.update(0.016, 0, 'chase', 1.15);
  }

  public setOutlinesVisible(show: boolean): void {
    this.headOutlines.forEach((m) => {
      m.visible = show;
    });
    this.upperArmOutline.visible = show;
    this.forearmOutline.visible = show;
    this.thighOutline.visible = show;
    this.shinOutline.visible = show;
    this.torsoOutlines.forEach((m) => {
      m.visible = show;
    });
  }

  public setWireframe(wire: boolean): void {
    for (const mat of this.ownedMats) {
      if ('wireframe' in mat) {
        (mat as THREE.MeshStandardMaterial).wireframe = wire;
      }
    }
  }

  /**
   * Resolves a raycast hit on ANY zombie InstancedMesh into a blast-back knockback ragdoll!
   */
  public handleRaycastShoot(hit: THREE.Intersection): ZombieShootResult {
    const obj = hit.object as THREE.InstancedMesh;
    const instId = hit.instanceId;
    const miss = (zone: ZombieShootResult['zone']): ZombieShootResult => ({
      hit: false,
      worldPoint: hit.point,
      isHeadshot: false,
      headVariant: -1,
      skinColor: 0xffffff,
      hairStyle: -1,
      lostArm: 0,
      lostLeg: 0,
      zone,
      isVital: false,
    });
    if (instId === undefined) return miss('torso');

    // Skip instances collapsed to zero scale — torn-off limbs & decapitated heads
    obj.getMatrixAt(instId, this._mLocal);
    const el = this._mLocal.elements;
    if (Math.abs(el[0]) + Math.abs(el[1]) + Math.abs(el[2]) < 0.01) return miss('torso');

    let agent: ZombieAgent | undefined;
    let zone: ZombieShootResult['zone'] = 'torso';
    let limbSide: 1 | 2 = 1;

    const headVariant = this.headMeshes.indexOf(obj);
    if (headVariant >= 0) {
      agent = this.agents.find(
        (a) => a.headVariant === headVariant && a.headVariantSlot === instId
      );
      zone = 'head';
    } else if (obj === this.upperArmMesh || obj === this.forearmMesh) {
      agent = this.agents[instId >> 1];
      zone = 'arm';
      limbSide = instId % 2 === 0 ? 1 : 2;
    } else if (obj === this.thighMesh || obj === this.shinMesh) {
      agent = this.agents[instId >> 1];
      zone = 'leg';
      limbSide = instId % 2 === 0 ? 1 : 2;
    } else if (obj === this.pelvisMesh) {
      agent = this.agents[instId];
      zone = 'torso';
    } else if (typeof obj.userData.zombieArchetype === 'number') {
      const arch = obj.userData.zombieArchetype as number;
      agent = this.agents.find((a) => a.archetype === arch && a.archetypeSlot === instId);
      zone = 'torso';
    }

    if (!agent) return miss('torso');

    const isHeadshot = zone === 'head';

    // White-hot impact flash on skin + costume so every hit reads instantly
    agent.flashTimer = isHeadshot ? 0.22 : 0.15;

    // --- VITAL POINT CHECK: only head or heart sends the body flying --------
    const vs = agent.scale;
    const dxv = hit.point.x - agent.curX;
    // compensate the forward hunch: the chest sits ahead of the spine by ~0.13 * scale
    const dzv = hit.point.z - agent.curZ - 0.13 * vs;
    const dyv = hit.point.y - (agent.curY + 1.15 * vs);
    const isVital =
      isHeadshot ||
      (dxv * dxv + dzv * dzv < 0.16 * 0.16 * vs * vs && dyv > -0.3 * vs && dyv < 0.3 * vs);

    // Zone-accurate dismemberment: the limb you shot is the limb that comes off
    if (zone === 'arm' && agent.lostArm === 0) {
      agent.lostArm = limbSide;
      agent.limbRegen = 5;
    }
    if (zone === 'leg' && agent.lostLeg === 0) {
      agent.lostLeg = limbSide;
      agent.limbRegen = 5;
    }
    if (isHeadshot) agent.headHidden = true;

    // --- Bullet hole punched through the costume at the exact impact point --
    if (agent.torsoM[0] !== 0 || agent.torsoM[1] !== 0) {
      _tmA.fromArray(agent.torsoM);
      _tmA.invert();
      _tvA.copy(hit.point).applyMatrix4(_tmA);
      const slot = agent.holeCount < 4 ? agent.holeCount++ : Math.floor(Math.random() * 4);
      agent.holes[slot * 4] = _tvA.x;
      agent.holes[slot * 4 + 1] = _tvA.y;
      agent.holes[slot * 4 + 2] = _tvA.z;
      agent.holes[slot * 4 + 3] = 0.055 + Math.random() * 0.035;
    }

    if (!isVital) {
      // GLANCING HIT: a hard stagger in place — the body reels, it does NOT orbit away
      agent.flinchTimer = 0.5;
      agent.flinchVelZ = -2.1;
      return {
        hit: true,
        worldPoint: hit.point.clone(),
        isHeadshot,
        headVariant: agent.headVariant,
        skinColor: agent.skinColor.getHex(),
        hairStyle: agent.hasHair && agent.hairSlot >= 0 ? agent.hairStyle : -1,
        lostArm: agent.lostArm,
        lostLeg: agent.lostLeg,
        zone,
        isVital: false,
      };
    }

    // --- Vital hit: prime the ARTICULATED RAGDOLL (tuned, not "lebay") ------
    const power = isHeadshot ? 1.25 : 1.0;
    agent.kbActive = true;
    agent.kbTimer = 0;
    agent.kbDuration = 2.6;
    agent.kbGrounded = false;
    agent.flinchTimer = 0;
    agent.flinchZ = 0;
    agent.flinchVelZ = 0;
    agent.kbPos.set(agent.curX, agent.curY + 0.88 * agent.scale, agent.curZ);
    agent.kbVel.set(
      (Math.random() - 0.5) * 2.4 * power,
      (1.5 + Math.random() * 1.0) * power,
      (-3.0 - Math.random() * 1.8) * power
    );
    agent.kbRot.set(-0.4, (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.4);
    agent.kbSpin.set(
      (-3.2 - Math.random() * 2.2) * power,
      (Math.random() - 0.5) * 3.0 * power,
      (Math.random() - 0.5) * 2.6 * power
    );

    // Start the joints in a reachable stance, then fling every one of them hard
    const rd = agent.ragdoll;
    rd.fill(0);
    rd[0] = -0.35; // spine
    rd[6] = -0.5;
    rd[7] = 0.3;
    rd[8] = 0.2; // neck
    for (let s = 0; s < 2; s++) {
      const sg = s === 0 ? 1 : -1;
      rd[(2 + s) * 6] = -1.2;
      rd[(2 + s) * 6 + 2] = sg * 0.6; // shoulders reaching forward
      rd[(4 + s) * 6] = -0.5; // elbows
      rd[(6 + s) * 6] = -0.3; // hips
      rd[(8 + s) * 6] = 0.5; // knees
    }
    for (let j = 0; j < 10; j++) {
      const mag = j === 0 ? 7 : j === 1 ? 11 : j < 4 ? 14 : j < 6 ? 16 : j < 8 ? 9 : 12;
      rd[j * 6 + 3] = (Math.random() - 0.5) * mag;
      rd[j * 6 + 4] = (Math.random() - 0.5) * mag;
      rd[j * 6 + 5] = (Math.random() - 0.5) * mag;
    }

    return {
      hit: true,
      worldPoint: hit.point.clone(),
      isHeadshot,
      headVariant: agent.headVariant,
      skinColor: agent.skinColor.getHex(),
      hairStyle: agent.hasHair && agent.hairSlot >= 0 ? agent.hairStyle : -1,
      lostArm: agent.lostArm,
      lostLeg: agent.lostLeg,
      zone,
      isVital: true,
    };
  }

  /**
   * SQUAD AUTO-FIRE: picks a random living zombie and punches a round through one of
   * its parts (head / heart / arm / leg), reusing the exact same shot pipeline as a
   * player click — so knockback, dismemberment, ragdoll and bullet holes all apply.
   */
  public randomShot(): ZombieShootResult | null {
    const pool: ZombieAgent[] = [];
    for (const a of this.agents) {
      if (!a.kbActive && !a.headHidden) pool.push(a);
    }
    if (pool.length === 0) return null;
    const ag = pool[Math.floor(Math.random() * pool.length)];
    const sc = ag.scale;

    const r = Math.random();
    let obj: THREE.InstancedMesh;
    let instId: number;
    let zone: ZombieShootResult['zone'];

    if (r < 0.3) {
      zone = 'head';
      obj = this.headMeshes[ag.headVariant];
      instId = ag.headVariantSlot;
    } else if (r < 0.62) {
      zone = 'torso';
      obj = this.torsoMeshes[ag.archetype];
      instId = ag.archetypeSlot;
    } else if (r < 0.82) {
      zone = 'arm';
      const side = ag.lostArm === 0 ? (Math.random() < 0.5 ? 1 : 2) : ag.lostArm === 1 ? 2 : 1;
      obj = this.upperArmMesh;
      instId = ag.index * 2 + (side === 1 ? 0 : 1);
    } else {
      zone = 'leg';
      const side = ag.lostLeg === 0 ? (Math.random() < 0.5 ? 1 : 2) : ag.lostLeg === 1 ? 2 : 1;
      obj = this.thighMesh;
      instId = ag.index * 2 + (side === 1 ? 0 : 1);
    }

    // Fake an impact point sitting on that exact part
    const point = new THREE.Vector3();
    const sideSign = Math.random() < 0.5 ? -1 : 1;
    if (zone === 'head') {
      point.set(ag.curX + (Math.random() - 0.5) * 0.08 * sc, ag.curY + 1.6 * sc, ag.curZ + 0.1 * sc);
    } else if (zone === 'torso') {
      point.set(ag.curX + (Math.random() - 0.5) * 0.14 * sc, ag.curY + 1.15 * sc, ag.curZ + 0.16 * sc);
    } else if (zone === 'arm') {
      point.set(ag.curX + sideSign * 0.2 * sc, ag.curY + 1.2 * sc, ag.curZ + 0.28 * sc);
    } else {
      point.set(ag.curX + sideSign * 0.1 * sc, ag.curY + 0.45 * sc, ag.curZ + 0.12 * sc);
    }

    return this.handleRaycastShoot({
      object: obj,
      instanceId: instId,
      point,
    } as unknown as THREE.Intersection);
  }

  /**
   * Updates all 100 World War Z zombies with zero per-frame allocations!
   */
  public update(dt: number, elapsed: number, squadAnimMode: AnimMode, squadSpeedMult: number): void {
    if (!this.group.visible) return;

    const isChasing = squadAnimMode === 'chase';
    const isWalking = squadAnimMode === 'walk';
    const paceFactor = isChasing
      ? 1.05 * squadSpeedMult
      : isWalking
        ? 0.55
        : 0.36; // Snarling agitated twitching horde even in idle/crouch!

    const setMat = (mesh: THREE.InstancedMesh, ol: THREE.InstancedMesh | null, idx: number, m: THREE.Matrix4) => {
      mesh.setMatrixAt(idx, m);
      if (ol) ol.setMatrixAt(idx, m);
    };

    // --- Zombie-vs-zombie jostling: sometimes one gets bumped off its feet ---
    let stumbles = 0;
    const nAgents = this.agents.length;
    for (let i = 0; i < nAgents && stumbles < 6; i++) {
      const a = this.agents[i];
      if (a.kbActive || a.flinchTimer > 0 || a.stumbleCd > 0) continue;
      for (let j = i + 1; j < nAgents; j++) {
        const b = this.agents[j];
        if (b.kbActive || b.flinchTimer > 0 || b.stumbleCd > 0) continue;
        const dx = a.curX - b.curX;
        const dz = a.curZ - b.curZ;
        const d2 = dx * dx + dz * dz;
        if (d2 > 0.16) continue; // closer than 0.40m

        const dist = Math.sqrt(d2);
        const sep = (0.4 - dist) * 0.7 * dt;
        const nx = dist > 1e-4 ? dx / dist : i % 2 === 0 ? 1 : -1;
        a.baseX = THREE.MathUtils.clamp(a.baseX + nx * sep, -8, 8);
        b.baseX = THREE.MathUtils.clamp(b.baseX - nx * sep, -8, 8);

        // Occasionally the shove knocks one flat — it lies there, then gets back up
        if (Math.random() < 0.014) {
          const v = Math.random() < 0.5 ? a : b;
          v.kbActive = true;
          v.kbTimer = 0;
          v.kbDuration = 1.5;
          v.kbGrounded = false;
          v.stumbleCd = 5 + Math.random() * 5;
          v.kbPos.set(v.curX, v.curY + 0.88 * v.scale, v.curZ);
          v.kbVel.set(
            (Math.random() - 0.5) * 1.1,
            0.9 + Math.random() * 0.6,
            (Math.random() - 0.5) * 1.3
          );
          v.kbRot.set(-0.25, (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.4);
          v.kbSpin.set(
            -2.0 - Math.random() * 1.6,
            (Math.random() - 0.5) * 1.8,
            (Math.random() - 0.5) * 1.6
          );
          const rdS = v.ragdoll;
          rdS.fill(0);
          rdS[0] = -0.35;
          rdS[6] = -0.5;
          for (let k = 0; k < 10; k++) {
            rdS[k * 6 + 3] = (Math.random() - 0.5) * 3.4;
            rdS[k * 6 + 4] = (Math.random() - 0.5) * 3.4;
            rdS[k * 6 + 5] = (Math.random() - 0.5) * 3.4;
          }
          stumbles++;
          if (stumbles >= 6) break;
        }
      }
    }

    let colorsDirty = false;
    const flashCol = new THREE.Color();

    for (let i = 0; i < this.agents.length; i++) {
      const ag = this.agents[i];
      const sc = ag.scale;

      // 0. BULLET-IMPACT FLASH — skin + costume blaze white-hot, then settle back to base color
      if (ag.flashTimer > 0) {
        ag.flashTimer = Math.max(0, ag.flashTimer - dt);
        const t = ag.flashTimer > 0 ? Math.min(1, ag.flashTimer / 0.2) : 0;
        flashCol.copy(ag.skinColor).lerp(IMPACT_FLASH, t);
        this.headMeshes[ag.headVariant].setColorAt(ag.headVariantSlot, flashCol);
        flashCol.copy(ag.shirtColor).lerp(IMPACT_FLASH, t);
        this.torsoMeshes[ag.archetype].setColorAt(ag.archetypeSlot, flashCol);
        colorsDirty = true;
      }

      // Hit stagger (0 → 1 envelope), torn-limb regen and collision cooldown
      if (ag.flinchTimer > 0) ag.flinchTimer = Math.max(0, ag.flinchTimer - dt);
      const fl = ag.flinchTimer > 0 ? ag.flinchTimer / 0.5 : 0;
      if (ag.limbRegen > 0) {
        ag.limbRegen -= dt;
        if (ag.limbRegen <= 0) {
          ag.lostArm = 0;
          ag.lostLeg = 0;
        }
      }
      if (ag.stumbleCd > 0) ag.stumbleCd -= dt;
      if (ag.flinchZ !== 0 || ag.flinchVelZ !== 0) {
        ag.flinchZ += ag.flinchVelZ * dt;
        ag.flinchVelZ *= Math.exp(-7 * dt);
        ag.flinchZ *= Math.exp(-2.4 * dt);
        if (Math.abs(ag.flinchZ) < 0.003 && Math.abs(ag.flinchVelZ) < 0.02) {
          ag.flinchZ = 0;
          ag.flinchVelZ = 0;
        }
      }

      // 1. Handle knocked-back blasted zombies flying backwards before scrambling back into the swarm!
      if (ag.kbActive) {
        ag.kbTimer += dt;
        const rd = ag.ragdoll;

        // --- Root body ballistic flight --------------------------------------
        ag.kbVel.y -= 11.5 * dt;
        ag.kbPos.addScaledVector(ag.kbVel, dt);

        const grounded = ag.kbPos.y <= 0.18 * sc + 0.001;
        if (grounded) {
          if (ag.kbPos.y < 0.18 * sc) ag.kbPos.y = 0.18 * sc;
          // One solid thud and then it rests — no ping-pong jitter on the floor
          if (ag.kbVel.y < -1.3) ag.kbVel.y *= -0.28;
          else if (ag.kbVel.y < 0) ag.kbVel.y = 0;
          ag.kbVel.x *= Math.exp(-4.5 * dt); // slide friction
          ag.kbVel.z *= Math.exp(-4.5 * dt);
          ag.kbSpin.multiplyScalar(Math.exp(-5.5 * dt));

          // Settle flat: nearest lie-down pitch, roll levelled out
          const lie = -Math.PI / 2 + Math.round((ag.kbRot.x + Math.PI / 2) / Math.PI) * Math.PI;
          const ease = 1 - Math.exp(-4.5 * dt);
          ag.kbRot.x += (lie - ag.kbRot.x) * ease;
          ag.kbRot.z += -ag.kbRot.z * ease * 1.4;
          ag.kbRot.y += ag.kbSpin.y * dt;

          // First slam: every joint takes a jolt so the body flops as it lands
          if (!ag.kbGrounded) {
            ag.kbGrounded = true;
            for (let j = 0; j < 10; j++) {
              rd[j * 6 + 3] += (Math.random() - 0.5) * 5.5;
              rd[j * 6 + 4] += (Math.random() - 0.5) * 5.5;
              rd[j * 6 + 5] += (Math.random() - 0.5) * 5.5;
            }
          }
        } else {
          ag.kbRot.x += ag.kbSpin.x * dt;
          ag.kbRot.y += ag.kbSpin.y * dt;
          ag.kbRot.z += ag.kbSpin.z * dt;
        }

        // --- 10 articulated joints: violent fling in the air, sprawl on deck --
        const stiff = grounded ? 15 : 0;
        const damp = grounded ? Math.exp(-7.5 * dt) : Math.exp(-1.15 * dt);
        for (let j = 0; j < 10; j++) {
          const b = j * 6;
          const side = j % 2 === 0 ? 1 : -1;
          let tx = 0;
          let ty = 0;
          let tz = 0;
          if (j === 0) {
            tx = -0.42;
            ty = 0.08;
            tz = 0.06;
          } else if (j === 1) {
            tx = -0.72;
            ty = 0.24;
            tz = 0.1;
          } else if (j < 4) {
            tx = -0.18;
            tz = side * 1.32; // shoulders flung wide
          } else if (j < 6) {
            tx = -0.72;
            tz = side * 0.18; // elbows half curled
          } else if (j < 8) {
            tx = 0.06;
            tz = side * 0.14; // hips
          } else {
            tx = 0.34 + (j % 2) * 0.18; // knees for the sprawl
          }
          const lim = j === 0 ? 1.7 : 2.6; // joints can't hyper-extend through the body
          for (let k = 0; k < 3; k++) {
            const target = k === 0 ? tx : k === 1 ? ty : tz;
            let v = rd[b + 3 + k];
            if (stiff > 0) v += (target - rd[b + k]) * stiff * dt;
            v *= damp;
            rd[b + 3 + k] = v;
            rd[b + k] += v * dt;
            if (rd[b + k] > lim) rd[b + k] = lim;
            else if (rd[b + k] < -lim) rd[b + k] = -lim;
          }
        }

        this._qTemp.setFromEuler(ag.kbRot);
        this._vScale.setScalar(sc);
        this._mRoot.compose(ag.kbPos, this._qTemp, this._vScale);

        // Pose entire ragdolled zombie cleanly relative to _mRoot
        setMat(this.pelvisMesh, null, i, this._mRoot);

        this._eTemp.set(rd[0], rd[1], rd[2]); // spine
        this._qTemp.setFromEuler(this._eTemp);
        this._vPos.set(0, 0.04, 0);
        this._vScale.set(1, 1, 1);
        this._mTorso.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mRoot);
        setMat(this.torsoMeshes[ag.archetype], this.torsoOutlines[ag.archetype], ag.archetypeSlot, this._mTorso);
        ag.torsoM.set(this._mTorso.elements); // bullet holes stay stuck while it flies

        this._vPos.set(0, 0.62, 0.01);
        this._eTemp.set(rd[6], rd[7], rd[8]); // neck
        this._qTemp.setFromEuler(this._eTemp);
        this._mHead.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
        if (ag.headHidden) {
          // Decapitated: collapse head + hair to zero so nothing floats above the neck
          this._vScale.set(0.0001, 0.0001, 0.0001);
          this._mHead.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
          this._vScale.set(1, 1, 1);
        }
        setMat(
          this.headMeshes[ag.headVariant],
          this.headOutlines[ag.headVariant],
          ag.headVariantSlot,
          this._mHead
        );
        if (ag.hasHair && ag.hairSlot >= 0) {
          this.hairMeshes[ag.hairStyle].setMatrixAt(ag.hairSlot, this._mHead);
        }

        for (let sIdx = 0; sIdx < 2; sIdx++) {
          const s = sIdx === 0 ? 1 : -1;

          // Shoulder → upper arm
          const sh = (2 + sIdx) * 6;
          this._vPos.set(s * 0.20, 0.43, 0);
          this._eTemp.set(rd[sh], rd[sh + 1], rd[sh + 2]);
          this._qTemp.setFromEuler(this._eTemp);
          const armGoneKb = sIdx === 0 ? ag.lostArm === 1 : ag.lostArm === 2;
          if (armGoneKb) this._vScale.set(0.0001, 0.0001, 0.0001);
          this._mPart.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
          if (armGoneKb) this._vScale.set(1, 1, 1);
          setMat(this.upperArmMesh, this.upperArmOutline, i * 2 + sIdx, this._mPart);

          // Elbow → forearm + claw
          const el = (4 + sIdx) * 6;
          this._vPos.set(0, -0.23, 0);
          this._eTemp.set(rd[el], rd[el + 1], rd[el + 2]);
          this._qTemp.setFromEuler(this._eTemp);
          this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
          setMat(this.forearmMesh, this.forearmOutline, i * 2 + sIdx, this._mSub);

          // Hip → thigh
          const hp = (6 + sIdx) * 6;
          this._vPos.set(s * 0.10, -0.02, 0);
          this._eTemp.set(rd[hp], rd[hp + 1], rd[hp + 2]);
          this._qTemp.setFromEuler(this._eTemp);
          const legGoneKb = sIdx === 0 ? ag.lostLeg === 1 : ag.lostLeg === 2;
          if (legGoneKb) this._vScale.set(0.0001, 0.0001, 0.0001);
          this._mPart.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mRoot);
          if (legGoneKb) this._vScale.set(1, 1, 1);
          setMat(this.thighMesh, this.thighOutline, i * 2 + sIdx, this._mPart);

          // Knee → shin + shoe
          const kn = (8 + sIdx) * 6;
          this._vPos.set(0, -0.36, 0);
          this._eTemp.set(rd[kn], rd[kn + 1], rd[kn + 2]);
          this._qTemp.setFromEuler(this._eTemp);
          this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
          setMat(this.shinMesh, this.shinOutline, i * 2 + sIdx, this._mSub);
        }

        if (ag.kbTimer > ag.kbDuration) {
          ag.kbActive = false;
          ag.kbGrounded = false;
          ag.headHidden = false; // scrambled back up with its head reattached
          ag.lostArm = 0; // ...and its limbs reattached
          ag.lostLeg = 0;
          ag.limbRegen = 0;
          // Stands up exactly where it landed — no teleport pop back into the lane
          ag.baseX = THREE.MathUtils.clamp(ag.kbPos.x, -8, 8);
          ag.baseZ = THREE.MathUtils.clamp(ag.kbPos.z, -12.6, -1.45);
          ag.curX = ag.baseX;
          ag.curZ = ag.baseZ;
        }
        continue;
      }

      // 2. Advance frantic World War Z horde stride, surging & periodic pile-up leaps!
      ag.stridePhase = (ag.stridePhase + dt * ag.speedRate * paceFactor) % 1;
      const ph = ag.stridePhase * Math.PI * 2;
      const sWave = Math.sin(ph);
      const cWave = Math.cos(ph);

      // Surging forward/back wave + lateral swarm jostling (classic World War Z liquid-wave feel!)
      const surgeZ = isChasing
        ? Math.sin(elapsed * 1.45 + ag.surgeSeed) * 0.42 +
          Math.sin(elapsed * 2.8 + ag.weaveSeed) * 0.16
        : Math.sin(elapsed * 0.9 + ag.surgeSeed) * 0.22;
      const weaveX = Math.sin(elapsed * 1.15 + ag.weaveSeed) * (isChasing ? 0.34 : 0.14);

      // Periodic World War Z frantic pile-up leaps for leaper zombies while chasing!
      let leapArc = 0;
      let leapEnv = 0;
      if (isChasing && ag.behavior === 'leaper') {
        ag.leapTimer -= dt;
        if (!ag.isLeaping && ag.leapTimer <= 0) {
          ag.isLeaping = true;
          ag.leapTimer = ag.leapDuration;
        } else if (ag.isLeaping) {
          const lp = 1 - Math.max(0, ag.leapTimer / ag.leapDuration);
          leapArc = Math.sin(lp * Math.PI) * 0.72;
          leapEnv = Math.sin(lp * Math.PI);
          if (ag.leapTimer <= 0) {
            ag.isLeaping = false;
            ag.leapTimer = 1.6 + ((i * 0.37) % 2.4);
          }
        }
      } else {
        ag.isLeaping = false;
      }

      // March on the squad until they slam into the barricade line, then mill there
      if (ag.baseZ > -1.45) {
        ag.baseZ = Math.max(-1.45, ag.baseZ - (0.32 + ag.speedRate * 0.18) * dt);
      }
      ag.curX = ag.baseX + weaveX;
      ag.curZ = ag.baseZ + surgeZ + leapEnv * 0.65 + ag.flinchZ;

      // Grounded stride height + springy sprint bounce + leap height (strictly >= 0, zero floor clip!)
      const strideLift = isChasing ? Math.abs(sWave) * 0.082 : isWalking ? Math.abs(sWave) * 0.025 : 0;
      const hipBaseY = (isChasing ? 0.878 : 0.888) * sc;
      ag.curY = leapArc;

      // Aggressive rabid forward torso pitch & chaotic jerky yaw/roll!
      const isLunger = ag.behavior === 'lunger';
      const isFlailer = ag.behavior === 'flailer';
      const hipsRotY = sWave * (isChasing ? 0.18 : 0.08) + Math.sin(elapsed * 1.6 + ag.weaveSeed) * 0.12;
      const hipsRotZ = -sWave * (isFlailer ? 0.11 : 0.055);
      const hipsRotX = leapEnv * 0.32;

      this._vPos.set(ag.curX, hipBaseY + (strideLift + leapArc) * sc, ag.curZ);
      this._eTemp.set(hipsRotX, hipsRotY, hipsRotZ);
      this._qTemp.setFromEuler(this._eTemp);
      this._vScale.setScalar(sc);
      this._mRoot.compose(this._vPos, this._qTemp, this._vScale);
      setMat(this.pelvisMesh, null, i, this._mRoot);

      // Upper Torso: feral hunched forward charge, plus the recoil lean of a hit stagger
      const torsoPitch =
        (isChasing ? (isLunger ? 0.56 : 0.46) : 0.28) +
        Math.abs(cWave) * 0.06 +
        leapEnv * 0.28 +
        fl * 0.5;
      const torsoTwist = -sWave * (isFlailer ? 0.34 : 0.24);
      const torsoRoll = isFlailer ? Math.sin(elapsed * 3.4 + ag.surgeSeed) * 0.1 : sWave * 0.05;

      this._vPos.set(0, 0.02, 0);
      this._eTemp.set(torsoPitch, torsoTwist, torsoRoll);
      this._qTemp.setFromEuler(this._eTemp);
      this._vScale.set(1, 1, 1);
      this._mTorso.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mRoot);
      setMat(
        this.torsoMeshes[ag.archetype],
        this.torsoOutlines[ag.archetype],
        ag.archetypeSlot,
        this._mTorso
      );
      ag.torsoM.set(this._mTorso.elements); // bullet holes ride along with this body

      // Feral head sway — wild enough to read as an animal, smooth enough to run like the squad
      const twitch =
        Math.sin(elapsed * ag.headTwitchFreq + ag.surgeSeed) * 0.11 +
        Math.sin(elapsed * ag.headTwitchFreq * 1.7) * 0.04;
      const headPitch = -torsoPitch * 0.72 + Math.sin(elapsed * 3.4 + i) * 0.05 + fl * 0.55;
      const headYaw = -(hipsRotY + torsoTwist) * 0.65 + twitch * 0.65;
      const headRoll = ag.headTiltZ + twitch * 0.55;

      this._vPos.set(0, 0.635, 0.012);
      this._eTemp.set(headPitch, headYaw, headRoll);
      this._qTemp.setFromEuler(this._eTemp);
      // Per-zombie FACE SHAPE: wide round skulls vs narrow long ones
      this._vScale.set(ag.headWide, ag.headTall, 1);
      this._mHead.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
      this._vScale.set(1, 1, 1);
      setMat(
        this.headMeshes[ag.headVariant],
        this.headOutlines[ag.headVariant],
        ag.headVariantSlot,
        this._mHead
      );
      if (ag.hasHair && ag.hairSlot >= 0) {
        this.hairMeshes[ag.hairStyle].setMatrixAt(ag.hairSlot, this._mHead);
      }

      // Rabid Reaching / Clawing / Flailing Arms!
      for (let sIdx = 0; sIdx < 2; sIdx++) {
        const s = sIdx === 0 ? 1 : -1;
        const armPhase = sIdx === 0 ? sWave : -sWave;
        let armX: number;
        let armZ: number;
        let elbowX: number;

        if (leapEnv > 0.15) {
          // Diving superman-claw lunge over the horde!
          armX = -2.15 + armPhase * 0.18;
          armZ = s * 0.24;
          elbowX = -0.35;
        } else if (isLunger) {
          // Desperate outstretched World War Z clawing hands reaching straight for the squad's backs!
          armX = -1.58 + armPhase * 0.36;
          armZ = s * (0.14 + Math.sin(elapsed * 6.5 + i + sIdx) * 0.08);
          elbowX = -0.42 - Math.max(0, -armPhase) * 0.38;
        } else if (isFlailer) {
          // Chaotic manic thrashing infected arms!
          armX = -1.25 + armPhase * 0.85;
          armZ = s * (0.38 + Math.abs(armPhase) * 0.32);
          elbowX = -0.78 - Math.abs(armPhase) * 0.45;
          // (kept on the same smooth cadence as the legs — no high-frequency jitter)
        } else {
          // Ferocious rabid predator sprint pump!
          armX = -0.58 + armPhase * (isChasing ? 0.92 : 0.42);
          armZ = s * 0.16;
          elbowX = -1.08 - Math.max(0, -armPhase) * 0.46;
        }

        this._vPos.set(s * 0.205, 0.435, 0.01);
        this._eTemp.set(armX, s * -0.14, armZ);
        this._qTemp.setFromEuler(this._eTemp);
        const armGone = sIdx === 0 ? ag.lostArm === 1 : ag.lostArm === 2;
        if (armGone) this._vScale.set(0.0001, 0.0001, 0.0001);
        this._mPart.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
        if (armGone) this._vScale.set(1, 1, 1);
        setMat(this.upperArmMesh, this.upperArmOutline, i * 2 + sIdx, this._mPart);

        this._vPos.set(0, -0.23, 0);
        this._eTemp.set(elbowX, 0, 0);
        this._qTemp.setFromEuler(this._eTemp);
        this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
        setMat(this.forearmMesh, this.forearmOutline, i * 2 + sIdx, this._mSub);
      }

      // Frantic Sprinting / Leaping Zombie Legs!
      for (let sIdx = 0; sIdx < 2; sIdx++) {
        const s = sIdx === 0 ? 1 : -1;
        const lPhase = sIdx === 0 ? ph : ph + Math.PI;
        const ls = Math.sin(lPhase);
        const lc = Math.cos(lPhase);

        let hipX: number;
        let kneeX: number;
        if (leapEnv > 0.15) {
          hipX = sIdx === 0 ? -0.95 * leapEnv : 0.42 * leapEnv;
          kneeX = sIdx === 0 ? 1.42 * leapEnv : 0.72 * leapEnv;
        } else if (isChasing) {
          hipX = -ls * 0.92 - 0.14;
          kneeX = 0.20 + Math.max(0, lc) * 1.48 + Math.max(0, ls) * 0.28;
        } else if (isWalking) {
          hipX = -ls * 0.46;
          kneeX = 0.14 + Math.max(0, lc) * 0.78;
        } else {
          // Agitated prowling squat ready to pounce!
          hipX = -0.34 + ls * 0.14;
          kneeX = 0.62 - ls * 0.14;
        }

        this._vPos.set(s * 0.102, -0.02, 0);
        this._eTemp.set(hipX, 0, s * 0.04);
        this._qTemp.setFromEuler(this._eTemp);
        const legGone = sIdx === 0 ? ag.lostLeg === 1 : ag.lostLeg === 2;
        if (legGone) this._vScale.set(0.0001, 0.0001, 0.0001);
        this._mLocal.compose(this._vPos, this._qTemp, this._vScale);
        if (legGone) this._vScale.set(1, 1, 1);
        this._mPart.multiplyMatrices(this._mRoot, this._mLocal);
        setMat(this.thighMesh, this.thighOutline, i * 2 + sIdx, this._mPart);

        this._vPos.set(0, -0.36, 0);
        this._eTemp.set(kneeX, 0, 0);
        this._qTemp.setFromEuler(this._eTemp);
        this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
        setMat(this.shinMesh, this.shinOutline, i * 2 + sIdx, this._mSub);
      }
    }

    // Bullet holes ride the body: recompose every decal from the stored torso matrix
    for (let i = 0; i < this.agents.length; i++) {
      const agH = this.agents[i];
      if (agH.holeCount === 0) continue;
      _tmB.fromArray(agH.torsoM);
      for (let k = 0; k < 4; k++) {
        const o = k * 4;
        const size = agH.holes[o + 3];
        if (size <= 0) continue;
        _tvB.set(agH.holes[o], agH.holes[o + 1], agH.holes[o + 2]);
        _vN.set(_tvB.x, 0, _tvB.z);
        if (_vN.lengthSq() < 1e-6) _vN.set(0, 0, 1);
        // Torso sides face outward; anything up on the shoulders faces the sky
        _vN.y = _tvB.y > 0.42 ? 0.85 : 0.08;
        _vN.normalize();
        _qA.setFromUnitVectors(_vZ, _vN);
        _sA.set(size, size, size);
        _tvB.addScaledVector(_vN, 0.006);
        _tmC.compose(_tvB, _qA, _sA);
        _tmC.premultiply(_tmB);
        this.decalMesh.setMatrixAt(i * 4 + k, _tmC);
      }
    }

    // Mark all instance matrix / color buffers updated in one clean pass
    for (const m of this.allInstanced) {
      m.instanceMatrix.needsUpdate = true;
      if (colorsDirty && m.instanceColor) m.instanceColor.needsUpdate = true;
    }
  }

  public dispose(): void {
    this.ownedGeoms.forEach((g) => g.dispose());
    this.ownedMats.forEach((m) => m.dispose());
  }
}
