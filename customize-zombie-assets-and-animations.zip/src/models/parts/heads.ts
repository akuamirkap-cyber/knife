import * as THREE from 'three';
import {
  createGlossyGlassMat,
  createMat,
  getBuzzcutHeadTexture,
  getClawScarTexture,
  getGlossyGlassTexture,
  getSkillCapTexture,
  getWoodlandCamoTexture,
  makeStylizedMesh,
  PALETTE,
} from '../materials';
import {
  createBeveledBoxGeometry,
  createLoftGeometry,
  createStylizedHeadGeometry,
  LoftRing,
} from '../common';
import { FaceId, SkinId } from '../types';
import { buildStylizedFace } from './faces';

/**
 * Helper: builds a curved 3D shell plate wrapping around the Y axis across [-maxAngle, +maxAngle].
 */
function buildCurvedShellPlate(opts: {
  segs: number;
  maxAngle: number;
  thickness: number;
  yBot: (ang: number, tAbs: number) => number;
  yTop: (ang: number, tAbs: number) => number;
  rx: (ang: number, tAbs: number) => number;
  rz: (ang: number, tAbs: number) => number;
  zOff?: number;
  topZInset?: number;
  botZInset?: number;
}): THREE.BufferGeometry {
  const { segs, maxAngle, thickness } = opts;
  const zOff = opts.zOff ?? 0;
  const topInset = opts.topZInset ?? 0;
  const botInset = opts.botZInset ?? 0;

  const verts: number[] = [];
  const uvs: number[] = [];
  const idx: number[] = [];

  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    const ang = -maxAngle + t * maxAngle * 2;
    const tAbs = Math.abs(ang) / Math.max(0.0001, maxAngle);
    const sx = Math.sin(ang);
    const cz = Math.cos(ang);

    const rxVal = opts.rx(ang, tAbs);
    const rzVal = opts.rz(ang, tAbs);
    const yb = opts.yBot(ang, tAbs);
    const yt = opts.yTop(ang, tAbs);

    const oxBot = sx * (rxVal - botInset * 0.4);
    const ozBot = zOff + cz * (rzVal - botInset);
    const oxTop = sx * (rxVal - topInset * 0.4);
    const ozTop = zOff + cz * (rzVal - topInset);

    const ixBot = sx * Math.max(0.005, rxVal - thickness - botInset * 0.4);
    const izBot = zOff + cz * Math.max(0.005, rzVal - thickness - botInset);
    const ixTop = sx * Math.max(0.005, rxVal - thickness - topInset * 0.4);
    const izTop = zOff + cz * Math.max(0.005, rzVal - thickness - topInset);

    verts.push(oxBot, yb, ozBot);
    verts.push(oxTop, yt, ozTop);
    verts.push(ixBot, yb, izBot);
    verts.push(ixTop, yt, izTop);

    uvs.push(t, 0, t, 1, t, 0, t, 1);
  }

  for (let i = 0; i < segs; i++) {
    const a = i * 4;
    const b = (i + 1) * 4;
    idx.push(a + 0, b + 0, b + 1, a + 0, b + 1, a + 1);
    idx.push(a + 1, b + 1, b + 3, a + 1, b + 3, a + 3);
    idx.push(a + 2, b + 2, b + 0, a + 2, b + 0, a + 0);
    idx.push(a + 3, b + 3, b + 2, a + 3, b + 2, a + 2);
  }

  idx.push(0, 1, 3, 0, 3, 2);
  const last = segs * 4;
  idx.push(last + 0, last + 2, last + 3, last + 0, last + 3, last + 1);

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geom.setIndex(idx);
  geom.computeVertexNormals();
  return geom;
}

/**
 * Shared short muscular neck (30% shorter than before so EVERY skin sits naturally on the shoulders!).
 */
function buildShortNeck(mat: THREE.Material, radius = 0.059): THREE.Mesh {
  return makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 1.482, rx: radius * 1.08, rz: radius * 1.06 },
        { y: 1.530, rx: radius, rz: radius },
        { y: 1.582, rx: radius * 0.96, rz: radius * 0.96 },
      ],
      10
    ),
    mat,
    { outline: 0.0042 }
  );
}

// ============================================================================
// HEAD 01: CAPTAIN BOONIE (Shortened Neck, Stylized Face, Handlebar Mustache & Hat)
// ============================================================================
export function buildHeadBoonie(faceId: FaceId = 'grin'): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_CaptainBoonie';

  const skinMat = createMat({ color: PALETTE.skinBase, roughness: 0.76 });
  const headHairMat = createMat({
    color: 0xffffff,
    map: getBuzzcutHeadTexture(PALETTE.skinBase, PALETTE.boonieMustache),
    roughness: 0.78,
  });
  const beardMat = createMat({ color: PALETTE.boonieMustache, roughness: 0.88 });
  const hatCamoMat = createMat({
    color: 0xffffff,
    map: getWoodlandCamoTexture('hat'),
    roughness: 0.85,
  });
  const hatBandMat = createMat({ color: 0x4b5632, roughness: 0.88 });

  root.add(buildShortNeck(skinMat, 0.059));

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.672, 0.006);

  // Clean cropped brown buzzcut & low taper fade under his boonie hat (never bald!)
  const headMesh = makeStylizedMesh(
    createStylizedHeadGeometry({ scale: 1.0, slimX: 0.98, noseRidge: 0.017 }),
    headHairMat,
    { outline: 0.0048 }
  );
  headGroup.add(headMesh);

  // Golden-Ratio Image-2 eyes & sleek 3D brows + bold enlarged grin peeking cleanly under handlebar mustache!
  headGroup.add(
    buildStylizedFace(faceId, {
      mode: 'full',
      hasBeard: true,
      scale: 1.0,
      slimX: 0.98,
      noseRidge: 0.017,
      eyeYOffset: 0.002,
      mouthScale: 0.88,
      mouthYOffset: -0.016,
      browColor: PALETTE.boonieMustache,
    })
  );

  for (const s of [-1, 1]) {
    const ear = makeStylizedMesh(
      createBeveledBoxGeometry(0.020, 0.048, 0.028, 0.006),
      skinMat,
      { outline: 0.0034 }
    );
    ear.position.set(s * 0.094, 0.002, -0.006);
    ear.rotation.z = s * -0.10;
    headGroup.add(ear);
  }

  // Handlebar mustache arching cleanly above the stylized grin!
  const mustacheGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 0.84,
    thickness: 0.022,
    zOff: 0.016,
    topZInset: 0.002,
    botZInset: 0.0,
    yTop: (_ang, tAbs) => -0.029 - Math.pow(tAbs, 1.65) * 0.028,
    yBot: (_ang, tAbs) => -0.052 - Math.sin(tAbs * Math.PI * 0.78) * 0.028,
    rx: (_ang, tAbs) => 0.093 - tAbs * 0.003,
    rz: (_ang, tAbs) => 0.122 - Math.pow(tAbs, 1.35) * 0.016,
  });
  headGroup.add(makeStylizedMesh(mustacheGeom, beardMat, { outline: 0.0034 }));

  // Contoured jawline beard & sideburns
  for (const s of [-1, 1]) {
    const sideBeardGeom = buildCurvedShellPlate({
      segs: 8,
      maxAngle: 0.56,
      thickness: 0.015,
      zOff: 0.006,
      yTop: (ang) => {
        const backness = s > 0 ? (ang + 0.56) / 1.12 : (0.56 - ang) / 1.12;
        return -0.056 + Math.pow(backness, 1.55) * 0.112;
      },
      yBot: (ang) => {
        const backness = s > 0 ? (ang + 0.56) / 1.12 : (0.56 - ang) / 1.12;
        return -0.086 + Math.pow(backness, 1.8) * 0.048;
      },
      rx: () => 0.090,
      rz: () => 0.098,
    });
    const sideBeard = makeStylizedMesh(sideBeardGeom, beardMat, { outline: 0.0032 });
    sideBeard.rotation.y = s * 1.05;
    headGroup.add(sideBeard);
  }

  // Downward-sloped woodland camo boonie hat (lifted slightly so chunky 3D brows read clearly!)
  const hatGroup = new THREE.Group();
  hatGroup.position.set(0, 0.090, -0.002);
  hatGroup.rotation.x = -0.04;

  const brimShape = (outerFactor: number) => (angle: number) => {
    const side = Math.abs(Math.sin(angle));
    const front = Math.cos(angle);
    const waveY = (Math.cos(angle * 2) * 0.005 - side * 0.008) * outerFactor;
    return {
      rxMul: 1.08 + side * 0.05,
      rzMul: 0.96 + (front > 0 ? 0.03 : 0.0),
      dyAdd: waveY,
    };
  };

  const brimRings: LoftRing[] = [
    { y: -0.036, rx: 0.172, rz: 0.160, shape: brimShape(1.0) },
    { y: -0.025, rx: 0.174, rz: 0.162, shape: brimShape(1.0) },
    { y: -0.002, rx: 0.138, rz: 0.136, shape: brimShape(0.45) },
    { y: 0.016, rx: 0.105, rz: 0.114 },
  ];
  hatGroup.add(
    makeStylizedMesh(createLoftGeometry(brimRings, 12, true, false), hatCamoMat, {
      outline: 0.0044,
    })
  );

  const crownRings: LoftRing[] = [
    { y: 0.010, rx: 0.106, rz: 0.115 },
    { y: 0.056, rx: 0.097, rz: 0.106 },
    { y: 0.098, rx: 0.084, rz: 0.093 },
    { y: 0.114, rx: 0.062, rz: 0.070 },
  ];
  hatGroup.add(
    makeStylizedMesh(createLoftGeometry(crownRings, 12), hatCamoMat, { outline: 0.0046 })
  );

  hatGroup.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.024, rx: 0.105, rz: 0.114 },
          { y: 0.052, rx: 0.101, rz: 0.110 },
        ],
        12,
        false,
        false
      ),
      hatBandMat,
      { outline: 0.0028 }
    )
  );

  headGroup.add(hatGroup);
  root.add(headGroup);
  return root;
}

// ============================================================================
// HEAD 02: VENOM FANG OPS (Shortened Neck, Snug Scarf, Horned Visor & 3D Fangs)
// ============================================================================
export function buildHeadVenom(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_VenomFang';

  const helmetMat = createMat({ color: PALETTE.venomHelmet, roughness: 0.48, metalness: 0.20 });
  const visorMat = createGlossyGlassMat({
    color: 0xffffff,
    map: getGlossyGlassTexture('dark'),
    roughness: 0.05,
    metalness: 0.45,
  });
  const hornRedMat = createMat({ color: PALETTE.venomHornRed, roughness: 0.52, metalness: 0.14 });
  const mouthRedMat = createMat({ color: PALETTE.venomMouthRed, roughness: 0.68, metalness: 0.05 });
  const fangMat = createMat({ color: PALETTE.venomFangWhite, roughness: 0.40, metalness: 0.04 });
  const scarfMat = createMat({ color: PALETTE.venomScarf, roughness: 0.88 });

  // Compact tucked neck scarf (30% shorter neck profile!)
  const scarfRings: LoftRing[] = [
    { y: 1.460, rx: 0.146, rz: 0.136, oz: 0.016 },
    { y: 1.505, rx: 0.130, rz: 0.128, oz: 0.012 },
    { y: 1.552, rx: 0.112, rz: 0.114, oz: 0.006 },
    { y: 1.584, rx: 0.088, rz: 0.096, oz: 0.004 },
  ];
  root.add(makeStylizedMesh(createLoftGeometry(scarfRings, 10), scarfMat, { outline: 0.0046 }));

  const drapeShape = new THREE.Shape();
  drapeShape.moveTo(-0.122, 0.052);
  drapeShape.lineTo(0.122, 0.052);
  drapeShape.lineTo(0.010, -0.088);
  drapeShape.closePath();
  const drapeGeom = new THREE.ExtrudeGeometry(drapeShape, {
    depth: 0.026,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 1,
  });
  drapeGeom.center();
  const drape = makeStylizedMesh(drapeGeom, scarfMat, { outline: 0.0042 });
  drape.position.set(0, 1.488, 0.120);
  drape.rotation.x = -0.28;
  root.add(drape);

  const helmetGroup = new THREE.Group();
  helmetGroup.position.set(0, 1.686, 0.012);
  helmetGroup.rotation.y = -0.10;

  const aeroShape = (chinPoint: number, ridgeTop = 0) => (angle: number) => {
    const front = Math.cos(angle);
    let dzAdd = 0;
    let rxMul = 1;
    if (front > 0.40) dzAdd += chinPoint * Math.pow((front - 0.40) / 0.60, 1.35);
    if (front < -0.55) dzAdd -= ridgeTop * Math.pow((-front - 0.55) / 0.45, 1.2);
    if (front > 0.0 && Math.abs(Math.sin(angle)) > 0.65) rxMul -= 0.04;
    return { rxMul, dzAdd };
  };

  const helmetRings: LoftRing[] = [
    { y: -0.138, rx: 0.054, rz: 0.088, oz: 0.032, shape: aeroShape(0.028) },
    { y: -0.090, rx: 0.094, rz: 0.118, oz: 0.024, shape: aeroShape(0.032) },
    { y: -0.018, rx: 0.112, rz: 0.136, oz: 0.012, shape: aeroShape(0.024) },
    { y: 0.058, rx: 0.116, rz: 0.142, oz: 0.000, shape: aeroShape(0.014, 0.012) },
    { y: 0.122, rx: 0.104, rz: 0.132, oz: -0.012, shape: aeroShape(0.004, 0.018) },
    { y: 0.162, rx: 0.064, rz: 0.088, oz: -0.018 },
    { y: 0.176, rx: 0.022, rz: 0.034, oz: -0.020 },
  ];
  helmetGroup.add(
    makeStylizedMesh(createLoftGeometry(helmetRings, 12), helmetMat, { outline: 0.0052 })
  );

  // V-notch glossy visor
  const visorGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 1.04,
    thickness: 0.018,
    zOff: 0.014,
    topZInset: 0.008,
    yBot: (_ang, tAbs) =>
      tAbs < 0.28
        ? -0.046 + (tAbs / 0.28) * 0.016
        : -0.030 + Math.pow((tAbs - 0.28) / 0.72, 1.55) * 0.068,
    yTop: (_ang, tAbs) => 0.068 + Math.pow(tAbs, 1.7) * 0.022,
    rx: (_ang, tAbs) => 0.120 + (1 - tAbs) * 0.002,
    rz: (_ang, tAbs) => 0.156 + (1 - tAbs) * 0.010,
  });
  helmetGroup.add(makeStylizedMesh(visorGeom, visorMat, { outline: 0.0038 }));

  // Swept-back crimson-accented ear fins
  const finOuterShape = new THREE.Shape();
  finOuterShape.moveTo(0.065, -0.045);
  finOuterShape.lineTo(-0.075, -0.020);
  finOuterShape.lineTo(-0.115, 0.145);
  finOuterShape.lineTo(-0.022, 0.078);
  finOuterShape.closePath();

  const finOuterGeom = new THREE.ExtrudeGeometry(finOuterShape, {
    depth: 0.018,
    bevelEnabled: true,
    bevelThickness: 0.003,
    bevelSize: 0.003,
    bevelSegments: 1,
  });
  finOuterGeom.center();

  const finCrimsonShape = new THREE.Shape();
  finCrimsonShape.moveTo(0.056, -0.042);
  finCrimsonShape.lineTo(0.024, -0.034);
  finCrimsonShape.lineTo(-0.098, 0.132);
  finCrimsonShape.lineTo(-0.020, 0.074);
  finCrimsonShape.closePath();

  const finCrimsonGeom = new THREE.ExtrudeGeometry(finCrimsonShape, {
    depth: 0.024,
    bevelEnabled: false,
  });
  finCrimsonGeom.center();

  for (const s of [-1, 1]) {
    const finHolder = new THREE.Group();
    finHolder.position.set(s * 0.112, 0.088, -0.024);
    finHolder.rotation.order = 'YXZ';
    finHolder.rotation.y = -Math.PI / 2 + s * 0.18;
    finHolder.rotation.x = s * -0.16;

    finHolder.add(makeStylizedMesh(finOuterGeom, helmetMat, { outline: 0.0038 }));
    const finRed = makeStylizedMesh(finCrimsonGeom, hornRedMat, { outline: 0.0020 });
    finRed.position.set(0.008, 0.002, 0);
    finHolder.add(finRed);
    helmetGroup.add(finHolder);
  }

  // Crescent crimson mouth & 3D fangs
  const mouthGeom = buildCurvedShellPlate({
    segs: 14,
    maxAngle: 0.88,
    thickness: 0.020,
    zOff: 0.024,
    yTop: (_ang, tAbs) => -0.062 + Math.pow(tAbs, 1.75) * 0.056,
    yBot: (_ang, tAbs) => -0.124 + Math.pow(tAbs, 1.65) * 0.088,
    rx: (_ang, tAbs) => 0.112 + tAbs * 0.008,
    rz: (_ang, tAbs) => 0.158 - tAbs * 0.012,
  });
  helmetGroup.add(makeStylizedMesh(mouthGeom, mouthRedMat, { outline: 0.0034 }));

  const incisorUpper = new THREE.ConeGeometry(0.0074, 0.026, 4);
  incisorUpper.rotateX(Math.PI);
  const longCanine = new THREE.ConeGeometry(0.0102, 0.050, 4);
  longCanine.rotateX(Math.PI);
  const lowerTooth = new THREE.ConeGeometry(0.0070, 0.024, 4);

  for (const ang of [-0.72, -0.58, -0.43, -0.28, -0.14, 0.0, 0.14, 0.28, 0.43, 0.58, 0.72]) {
    const tAbs = Math.abs(ang) / 0.88;
    const isCanine = Math.abs(Math.abs(ang) - 0.43) < 0.04;
    const tooth = makeStylizedMesh(isCanine ? longCanine : incisorUpper, fangMat, {
      outline: 0.0014,
    });
    const yUpperEdge = -0.062 + Math.pow(tAbs, 1.75) * 0.056;
    tooth.position.set(
      Math.sin(ang) * (0.115 + tAbs * 0.008),
      yUpperEdge - (isCanine ? 0.019 : 0.010),
      0.025 + Math.cos(ang) * (0.164 - tAbs * 0.012)
    );
    tooth.rotation.y = ang;
    helmetGroup.add(tooth);
  }

  for (const ang of [-0.60, -0.46, -0.32, -0.19, -0.06, 0.06, 0.19, 0.32, 0.46, 0.60]) {
    const tAbs = Math.abs(ang) / 0.88;
    const tooth = makeStylizedMesh(lowerTooth, fangMat, { outline: 0.0014 });
    const yLowerEdge = -0.124 + Math.pow(tAbs, 1.65) * 0.088;
    tooth.position.set(
      Math.sin(ang) * (0.114 + tAbs * 0.008),
      yLowerEdge + 0.010,
      0.025 + Math.cos(ang) * (0.163 - tAbs * 0.012)
    );
    tooth.rotation.y = ang;
    helmetGroup.add(tooth);
  }

  root.add(helmetGroup);
  return root;
}

// ============================================================================
// HEAD 03: GOLDEN ENFORCER — SLEEK HEROIC PLANAR HUMAN SKULL GOLD MASK
//          Smooth Spherical-Low-Poly Dome, Balanced Front/Back Depth (Zero Bulge!),
//          Crisp Central Forehead-to-Chin Plane Split & Flush Oval Bronze Eyes!
// ============================================================================
export function buildHeadGold(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_GoldenMask';

  const goldMaskMat = createMat({
    color: 0xdcb139,
    roughness: 0.34,
    metalness: 0.38,
    emissive: 0x261b04,
    emissiveIntensity: 0.14,
  });
  const eyeSocketMat = createMat({
    color: 0x6f552b,
    roughness: 0.78,
    metalness: 0.12,
    side: THREE.DoubleSide,
  });
  eyeSocketMat.polygonOffset = true;
  eyeSocketMat.polygonOffsetFactor = -3;

  const eyeRimDarkMat = createMat({
    color: 0x221708,
    roughness: 0.72,
    metalness: 0.18,
    side: THREE.DoubleSide,
  });
  eyeRimDarkMat.polygonOffset = true;
  eyeRimDarkMat.polygonOffsetFactor = -2;

  root.add(buildShortNeck(goldMaskMat, 0.060));

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.668, 0.006);

  // Anatomically balanced heroic human head: smooth spherical dome top, crisp tapered jaw,
  // clean central facial spine, balanced front-to-back occiput (no protruding alien back!).
  const ringDefs = [
    { y: -0.114, rx: 0.036, rz: 0.044, oz: 0.020, nose: 0.008 }, // Sleek firm chin tip
    { y: -0.090, rx: 0.066, rz: 0.074, oz: 0.015, nose: 0.011 }, // Clean tapered lower jaw
    { y: -0.050, rx: 0.088, rz: 0.094, oz: 0.008, nose: 0.014 }, // Strong masculine jaw corner
    { y: -0.008, rx: 0.095, rz: 0.102, oz: 0.004, nose: 0.019 }, // High cheekbone & nose tip
    { y: 0.026, rx: 0.096, rz: 0.104, oz: 0.001, nose: 0.014 },  // Clean eye plane
    { y: 0.062, rx: 0.095, rz: 0.105, oz: -0.002, nose: 0.010 }, // Smooth brow & temple
    { y: 0.094, rx: 0.088, rz: 0.099, oz: -0.004, nose: 0.005 }, // Forehead dome curve 1
    { y: 0.118, rx: 0.072, rz: 0.082, oz: -0.005, nose: 0.002 }, // Smooth rounded dome curve 2
    { y: 0.134, rx: 0.046, rz: 0.053, oz: -0.005, nose: 0.0 },   // Smooth rounded crown
    { y: 0.142, rx: 0.018, rz: 0.021, oz: -0.005, nose: 0.0 },   // Top apex
  ];

  const evalGoldRing = (
    def: (typeof ringDefs)[number],
    angle: number
  ): { x: number; z: number } => {
    const front = Math.cos(angle);
    const side = Math.abs(Math.sin(angle));
    let dzAdd = 0;
    let rxMul = 1;
    // Crisp continuous vertical central facial crease (bright left / bronze right split!)
    if (front > 0.60) {
      dzAdd += def.nose * Math.pow((front - 0.60) / 0.40, 1.35);
    }
    // Slight clean planar side-temple flattening (heroic Asaro-head silhouette!)
    if (side > 0.82 && def.y > -0.04 && def.y < 0.09) {
      rxMul -= 0.025 * ((side - 0.82) / 0.18);
    }
    return {
      x: Math.sin(angle) * def.rx * rxMul,
      z: def.oz + front * def.rz + dzAdd,
    };
  };

  const sampleGoldSurface = (y: number, angle: number, pad: number): [number, number] => {
    let i0 = 0;
    for (let i = 0; i < ringDefs.length - 1; i++) {
      if (y >= ringDefs[i].y) i0 = i;
    }
    const a = ringDefs[i0];
    const b = ringDefs[Math.min(ringDefs.length - 1, i0 + 1)];
    const t = b.y === a.y ? 0 : THREE.MathUtils.clamp((y - a.y) / (b.y - a.y), 0, 1);

    const interp = {
      y,
      rx: THREE.MathUtils.lerp(a.rx, b.rx, t) + pad,
      rz: THREE.MathUtils.lerp(a.rz, b.rz, t) + pad,
      oz: THREE.MathUtils.lerp(a.oz, b.oz, t),
      nose: THREE.MathUtils.lerp(a.nose, b.nose, t),
    };
    const pt = evalGoldRing(interp, angle);
    return [pt.x, pt.z];
  };

  const maskRings: LoftRing[] = ringDefs.map((def) => ({
    y: def.y,
    rx: def.rx,
    rz: def.rz,
    oz: def.oz,
    shape: (angle: number) => {
      const front = Math.cos(angle);
      const side = Math.abs(Math.sin(angle));
      let dzAdd = 0;
      let rxMul = 1;
      if (front > 0.60) {
        dzAdd += def.nose * Math.pow((front - 0.60) / 0.40, 1.35);
      }
      if (side > 0.82 && def.y > -0.04 && def.y < 0.09) {
        rxMul -= 0.025 * ((side - 0.82) / 0.18);
      }
      return { rxMul, dzAdd };
    },
  }));

  const maskHead = makeStylizedMesh(createLoftGeometry(maskRings, 12, true, true), goldMaskMat, {
    outline: 0.0046,
  });
  headGroup.add(maskHead);

  // Flush rounded-oval recessed bronze eye cutouts contoured tightly to mask planes
  const bendOntoGoldSurface = (
    geom: THREE.BufferGeometry,
    centerAngle: number,
    centerY: number,
    pad: number
  ) => {
    const pos = geom.getAttribute('position');
    for (let i = 0; i < pos.count; i++) {
      const lx = pos.getX(i);
      const ly = pos.getY(i);
      const y = centerY + ly;
      const ang = centerAngle + lx / 0.096;
      const [x, z] = sampleGoldSurface(y, ang, pad);
      pos.setXYZ(i, x, y, z);
    }
    geom.computeVertexNormals();
    return geom;
  };

  for (const side of [-1, 1]) {
    const makeOvalEye = (w: number, h: number) => {
      const sh = new THREE.Shape();
      const innerSign = -side;
      sh.moveTo(innerSign * w * 0.94, -h * 0.06);
      sh.bezierCurveTo(
        innerSign * w * 0.50,
        h * 1.15,
        -innerSign * w * 0.65,
        h * 1.22,
        -innerSign * w * 0.96,
        h * 0.05
      );
      sh.bezierCurveTo(
        -innerSign * w * 0.70,
        -h * 1.12,
        innerSign * w * 0.50,
        -h * 1.02,
        innerSign * w * 0.94,
        -h * 0.06
      );
      return sh;
    };

    const rimGeom = bendOntoGoldSurface(
      new THREE.ShapeGeometry(makeOvalEye(0.028, 0.017), 10),
      side * 0.45,
      0.022,
      0.0030
    );
    const rimMesh = new THREE.Mesh(rimGeom, eyeRimDarkMat);
    rimMesh.renderOrder = 2;
    headGroup.add(rimMesh);

    const innerGeom = bendOntoGoldSurface(
      new THREE.ShapeGeometry(makeOvalEye(0.0235, 0.0138), 10),
      side * 0.45,
      0.022,
      0.0045
    );
    const innerMesh = new THREE.Mesh(innerGeom, eyeSocketMat);
    innerMesh.renderOrder = 3;
    headGroup.add(innerMesh);
  }

  root.add(headGroup);
  return root;
}



// ============================================================================
// HEAD 04: RED-EYE TROOPER (30% Shorter Neck + Flared PASGT & Red Gas Mask)
// ============================================================================
export function buildHeadReaper(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_RedEyeReaper';

  const helmetMat = createMat({ color: PALETTE.reaperHelmet, roughness: 0.70, metalness: 0.12 });
  const maskMat = createMat({ color: PALETTE.reaperMask, roughness: 0.76, metalness: 0.08 });
  const maskDarkMat = createMat({ color: 0x15171a, roughness: 0.62, metalness: 0.18 });
  const rigMat = createMat({ color: PALETTE.reaperRig, roughness: 0.74, metalness: 0.12 });
  const redLensMat = createMat({
    color: PALETTE.reaperLensRed,
    emissive: 0xf01c12,
    emissiveIntensity: 0.92,
    roughness: 0.16,
    metalness: 0.08,
    flatShading: false,
  });

  // Shortened sealed balaclava neck
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 1.482, rx: 0.092, rz: 0.090 },
          { y: 1.535, rx: 0.075, rz: 0.075 },
          { y: 1.585, rx: 0.072, rz: 0.074 },
        ],
        10
      ),
      maskMat,
      { outline: 0.0044 }
    )
  );

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.674, 0.008);

  const cranium = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: -0.118, rx: 0.074, rz: 0.088, oz: 0.010 },
        { y: -0.055, rx: 0.096, rz: 0.108, oz: 0.006 },
        { y: 0.025, rx: 0.104, rz: 0.114, oz: 0.000 },
        { y: 0.100, rx: 0.096, rz: 0.106, oz: -0.006 },
        { y: 0.140, rx: 0.064, rz: 0.074, oz: -0.008 },
      ],
      10
    ),
    maskMat,
    { outline: 0.0046 }
  );
  headGroup.add(cranium);

  const maskRidgeShape = (ridgeStr: number) => (angle: number) => {
    const front = Math.cos(angle);
    return {
      dzAdd: front > 0.65 ? ridgeStr * Math.pow((front - 0.65) / 0.35, 1.3) : 0,
    };
  };
  headGroup.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: -0.128, rx: 0.054, rz: 0.068, oz: 0.058, shape: maskRidgeShape(0.012) },
          { y: -0.072, rx: 0.082, rz: 0.084, oz: 0.056, shape: maskRidgeShape(0.016) },
          { y: -0.006, rx: 0.088, rz: 0.078, oz: 0.042, shape: maskRidgeShape(0.022) },
          { y: 0.046, rx: 0.074, rz: 0.062, oz: 0.028, shape: maskRidgeShape(0.014) },
        ],
        10
      ),
      maskMat,
      { outline: 0.0044 }
    )
  );

  for (const s of [-1, 1]) {
    const goggleGroup = new THREE.Group();
    goggleGroup.position.set(s * 0.050, 0.006, 0.114);
    goggleGroup.rotation.y = s * 0.25;
    goggleGroup.rotation.x = 0.02;

    const bezelGeom = new THREE.CylinderGeometry(0.044, 0.048, 0.032, 14);
    bezelGeom.rotateX(Math.PI / 2);
    goggleGroup.add(makeStylizedMesh(bezelGeom, maskDarkMat, { outline: 0.0036 }));

    const lensGeom = new THREE.SphereGeometry(0.037, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55);
    lensGeom.rotateX(Math.PI / 2);
    lensGeom.scale(1, 1, 0.36);
    const lens = makeStylizedMesh(lensGeom, redLensMat, { outline: 0.0018, castShadow: false });
    lens.position.z = 0.013;
    goggleGroup.add(lens);
    headGroup.add(goggleGroup);
  }

  const frontValveGroup = new THREE.Group();
  frontValveGroup.position.set(0, -0.074, 0.138);
  frontValveGroup.rotation.x = 0.20;

  const valveOuterGeom = new THREE.CylinderGeometry(0.044, 0.049, 0.044, 12);
  valveOuterGeom.rotateX(Math.PI / 2);
  frontValveGroup.add(makeStylizedMesh(valveOuterGeom, maskDarkMat, { outline: 0.0036 }));

  const valveMidGeom = new THREE.CylinderGeometry(0.034, 0.036, 0.016, 12);
  valveMidGeom.rotateX(Math.PI / 2);
  const valveMid = makeStylizedMesh(valveMidGeom, rigMat, { outline: 0.0022 });
  valveMid.position.z = 0.022;
  frontValveGroup.add(valveMid);

  const valveInnerGeom = new THREE.CylinderGeometry(0.021, 0.022, 0.018, 10);
  valveInnerGeom.rotateX(Math.PI / 2);
  const valveInner = makeStylizedMesh(valveInnerGeom, maskDarkMat, { outline: 0.0018 });
  valveInner.position.z = 0.026;
  frontValveGroup.add(valveInner);
  headGroup.add(frontValveGroup);

  const canisterGroup = new THREE.Group();
  canisterGroup.position.set(0.088, -0.078, 0.084);
  canisterGroup.rotation.order = 'YXZ';
  canisterGroup.rotation.y = 0.78;
  canisterGroup.rotation.x = 0.44;

  const canNeckGeom = new THREE.CylinderGeometry(0.026, 0.030, 0.030, 10);
  canNeckGeom.rotateX(Math.PI / 2);
  canisterGroup.add(makeStylizedMesh(canNeckGeom, maskDarkMat, { outline: 0.0028 }));

  const canBodyGeom = new THREE.CylinderGeometry(0.041, 0.043, 0.058, 12);
  canBodyGeom.rotateX(Math.PI / 2);
  const canBody = makeStylizedMesh(canBodyGeom, rigMat, { outline: 0.0038 });
  canBody.position.z = 0.036;
  canisterGroup.add(canBody);

  const canCapGeom = new THREE.CylinderGeometry(0.034, 0.038, 0.014, 12);
  canCapGeom.rotateX(Math.PI / 2);
  const canCap = makeStylizedMesh(canCapGeom, maskDarkMat, { outline: 0.0022 });
  canCap.position.z = 0.068;
  canisterGroup.add(canCap);
  headGroup.add(canisterGroup);

  const cheekPortGeom = new THREE.CylinderGeometry(0.022, 0.024, 0.016, 10);
  cheekPortGeom.rotateX(Math.PI / 2);
  const cheekPort = makeStylizedMesh(cheekPortGeom, maskDarkMat, { outline: 0.0024 });
  cheekPort.position.set(-0.074, -0.074, 0.088);
  cheekPort.rotation.y = -0.68;
  cheekPort.rotation.x = 0.24;
  headGroup.add(cheekPort);

  const pasgtShape = (earDrop: number, earFlare: number, browExtend: number) => (angle: number) => {
    const front = Math.cos(angle);
    const side = Math.abs(Math.sin(angle));
    let rxMul = 1;
    let dzAdd = 0;
    let dyAdd = 0;
    if (front < 0.35) {
      const earWeight = Math.min(1, (0.35 - front) / 0.75);
      dyAdd -= earDrop * earWeight;
      rxMul += earFlare * side * earWeight;
    }
    if (front > 0.45) dzAdd += browExtend * ((front - 0.45) / 0.55);
    return { rxMul, dzAdd, dyAdd };
  };

  const helmetRings: LoftRing[] = [
    { y: 0.056, rx: 0.136, rz: 0.146, oz: -0.008, shape: pasgtShape(0.082, 0.15, 0.024) },
    { y: 0.086, rx: 0.132, rz: 0.144, oz: -0.006, shape: pasgtShape(0.036, 0.06, 0.020) },
    { y: 0.134, rx: 0.124, rz: 0.136, oz: -0.008 },
    { y: 0.172, rx: 0.098, rz: 0.108, oz: -0.010 },
    { y: 0.194, rx: 0.054, rz: 0.062, oz: -0.010 },
    { y: 0.202, rx: 0.018, rz: 0.022, oz: -0.010 },
  ];
  const pasgtHelmet = makeStylizedMesh(createLoftGeometry(helmetRings, 14, false, true), helmetMat, {
    outline: 0.0052,
  });
  pasgtHelmet.rotation.x = -0.06;
  headGroup.add(pasgtHelmet);

  const helmetLining = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 0.052, rx: 0.134, rz: 0.144, oz: -0.008, shape: pasgtShape(0.082, 0.14, 0.022) },
        { y: 0.064, rx: 0.132, rz: 0.142, oz: -0.007, shape: pasgtShape(0.072, 0.12, 0.020) },
      ],
      14,
      true,
      false
    ),
    maskDarkMat,
    { outline: 0.0028 }
  );
  helmetLining.rotation.x = -0.06;
  headGroup.add(helmetLining);

  root.add(headGroup);
  return root;
}

// ============================================================================
// HEAD 05: SWAT POLICE UNIT — IMAGE 3 EXACT MATCH!
//          Sleek Smooth Tactical Helmet, Ultra-Glossy Reflective Silver Goggles,
//          Twin Cheek Chinstraps + Molded Metallic-Grey Chin Cup & Neck Gaiter!
// ============================================================================
export function buildHeadPolice(faceId: FaceId = 'cool'): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_SWATPolice';

  const skinMat = createMat({ color: PALETTE.skinBase, roughness: 0.74 });
  const balaclavaMat = createMat({ color: PALETTE.policeBalaclava, roughness: 0.84 });
  const helmetMat = createGlossyGlassMat({
    color: 0x262a31,
    roughness: 0.34,
    metalness: 0.16,
  });
  const goggleFrameMat = createMat({
    color: 0x8d97a4,
    roughness: 0.34,
    metalness: 0.42,
    flatShading: false,
  });
  const goggleLensMat = createGlossyGlassMat({
    color: 0xffffff,
    map: getGlossyGlassTexture('silver'),
    roughness: 0.04,
    metalness: 0.48,
  });
  const chinCupMat = createMat({
    color: 0x6c737d,
    roughness: 0.42,
    metalness: 0.32,
    flatShading: false,
  });
  const strapMat = createMat({ color: 0x2f343c, roughness: 0.65, metalness: 0.15 });

  root.add(buildShortNeck(balaclavaMat, 0.064));
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 1.472, rx: 0.106, rz: 0.102, oz: 0.008 },
          { y: 1.522, rx: 0.094, rz: 0.094, oz: 0.008 },
          { y: 1.552, rx: 0.082, rz: 0.086, oz: 0.006 },
        ],
        12
      ),
      strapMat,
      { outline: 0.004 }
    )
  );

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.672, 0.006);

  // Full black balaclava head base
  const headMesh = makeStylizedMesh(
    createStylizedHeadGeometry({ scale: 1.0, slimX: 0.99, noseRidge: 0.015 }),
    balaclavaMat,
    { outline: 0.0048 }
  );
  headGroup.add(headMesh);

  // Exposed peach skin eye-slit window centered cleanly around Golden-Ratio eyes & Image-2 brows!
  const slitGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 0.72,
    thickness: 0.016,
    zOff: 0.010,
    yBot: (_ang, tAbs) => -0.014 + Math.pow(tAbs, 1.6) * 0.010,
    yTop: (_ang, tAbs) => 0.048 - Math.pow(tAbs, 1.8) * 0.008,
    rx: () => 0.097,
    rz: () => 0.118,
  });
  headGroup.add(makeStylizedMesh(slitGeom, skinMat, { outline: 0.0026 }));

  // Sleek Image-2 arched 3D brows & bold winged eyes framed cleanly inside SWAT balaclava slit!
  headGroup.add(
    buildStylizedFace(faceId, {
      mode: 'eyesOnly',
      scale: 1.0,
      slimX: 0.99,
      noseRidge: 0.015,
      eyeYOffset: 0.002,
      extraOffset: 0.009,
      browColor: 0x261d18,
    })
  );

  // --- EXACT IMAGE 3 HELMET RETENTION HARNESS: TWIN CHEEK STRAPS + METALLIC-GREY CHIN CUP! ---
  // Left & Right sleek curved straps descending snugly from helmet ear rim along jawline to chin!
  for (const s of [-1, 1]) {
    const strapCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(s * 0.112, 0.022, -0.010), // Anchored directly inside helmet ear rim!
      new THREE.Vector3(s * 0.096, -0.036, 0.024), // Hugging side cheek snugly
      new THREE.Vector3(s * 0.072, -0.088, 0.058), // Sweeping down jawline
      new THREE.Vector3(s * 0.032, -0.118, 0.082), // Connecting into center chin cup!
    ]);
    const tubeGeom = new THREE.TubeGeometry(strapCurve, 12, 0.0085, 6, false);
    const strapMesh = makeStylizedMesh(tubeGeom, strapMat, { outline: 0.0022 });
    headGroup.add(strapMesh);
  }

  // Sculpted curved metallic-grey protective chin cup hugging smoothly underneath chin (exact Image 3!)
  const chinCupGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 0.68,
    thickness: 0.014,
    zOff: 0.024,
    botZInset: 0.010,
    yTop: (_ang, tAbs) => -0.096 + Math.pow(tAbs, 1.8) * 0.014,
    yBot: (_ang, tAbs) => -0.128 + Math.pow(tAbs, 1.7) * 0.022,
    rx: () => 0.068,
    rz: () => 0.072,
  });
  headGroup.add(makeStylizedMesh(chinCupGeom, chinCupMat, { outline: 0.0028 }));

  // --- SLEEK SMOOTH ROUNDED SWAT TACTICAL RIOT HELMET (20-segment smooth dome!) ---
  const swatShape = (earDrop: number) => (angle: number) => {
    const front = Math.cos(angle);
    const side = Math.abs(Math.sin(angle));
    let dyAdd = 0;
    let rxMul = 1;
    if (front < 0.30) {
      const w = Math.min(1, (0.30 - front) / 0.70);
      dyAdd -= earDrop * w;
      rxMul += 0.09 * side * w; // Clean flared ear cover wings matching Image 3!
    }
    return { rxMul, dyAdd };
  };

  const helmetRings: LoftRing[] = [
    { y: 0.044, rx: 0.130, rz: 0.140, oz: -0.006, shape: swatShape(0.068) },
    { y: 0.086, rx: 0.130, rz: 0.140, oz: -0.006, shape: swatShape(0.024) },
    { y: 0.134, rx: 0.118, rz: 0.128, oz: -0.008 },
    { y: 0.166, rx: 0.088, rz: 0.096, oz: -0.010 },
    { y: 0.184, rx: 0.046, rz: 0.052, oz: -0.010 },
    { y: 0.190, rx: 0.014, rz: 0.016, oz: -0.010 },
  ];
  headGroup.add(
    makeStylizedMesh(createLoftGeometry(helmetRings, 20, false, true), helmetMat, {
      outline: 0.005,
    })
  );

  // --- ICONIC WIDE SILVER-FRAMED GLOSSY REFLECTIVE TACTICAL GOGGLES (EXACT IMAGE 3!) ---
  const goggleStrap = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 0.062, rx: 0.135, rz: 0.146, oz: -0.006 },
        { y: 0.098, rx: 0.134, rz: 0.145, oz: -0.006 },
      ],
      20,
      false,
      false
    ),
    balaclavaMat,
    { outline: 0.0024 }
  );
  headGroup.add(goggleStrap);

  // Smooth sculpted outer silver goggle bezel
  const goggleFrameGeom = buildCurvedShellPlate({
    segs: 20,
    maxAngle: 0.86,
    thickness: 0.028,
    zOff: 0.004,
    topZInset: 0.004,
    yTop: (_ang, tAbs) => 0.126 - Math.pow(tAbs, 2.0) * 0.014,
    yBot: (_ang, tAbs) => {
      const noseArch = Math.max(0, 1 - tAbs * 3.6) * 0.022;
      return 0.052 + noseArch + Math.pow(tAbs, 2.0) * 0.010;
    },
    rx: () => 0.138,
    rz: () => 0.161,
  });
  headGroup.add(makeStylizedMesh(goggleFrameGeom, goggleFrameMat, { outline: 0.0036 }));

  // Ultra-glossy smooth polished silver-glass lens with bright specular reflection streak!
  const goggleLensGeom = buildCurvedShellPlate({
    segs: 20,
    maxAngle: 0.74,
    thickness: 0.010,
    zOff: 0.006,
    yTop: (_ang, tAbs) => 0.115 - Math.pow(tAbs, 2.0) * 0.011,
    yBot: (_ang, tAbs) => {
      const noseArch = Math.max(0, 1 - tAbs * 3.6) * 0.020;
      return 0.063 + noseArch + Math.pow(tAbs, 2.0) * 0.009;
    },
    rx: () => 0.140,
    rz: () => 0.165,
  });
  headGroup.add(makeStylizedMesh(goggleLensGeom, goggleLensMat, { outline: 0.0022 }));

  root.add(headGroup);
  return root;
}

// ============================================================================
// HEAD 06: HEAVY LMG GUNNER (Olive Beanie, Glossy Reflective Goggles, Beard & Mock-Neck)
// ============================================================================
export function buildHeadGunner(faceId: FaceId = 'fierce'): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_HeavyGunner';

  const skinMat = createMat({ color: PALETTE.skinTan, roughness: 0.76 });
  const mockNeckMat = createMat({ color: 0x3b4430, roughness: 0.86 });
  const beanieMat = createMat({ color: PALETTE.gunnerBeanie, roughness: 0.88 });
  const beanieCuffMat = createMat({ color: 0x5c6944, roughness: 0.88 });
  const goggleMat = createMat({
    color: 0x4b543f,
    roughness: 0.45,
    metalness: 0.22,
    flatShading: false,
  });
  // Ultra-glossy smooth smoked tactical goggle lens matching Image 1 sheen!
  const lensMat = createGlossyGlassMat({
    color: 0xffffff,
    map: getGlossyGlassTexture('smoke'),
    roughness: 0.05,
    metalness: 0.45,
  });
  const beardMat = createMat({ color: PALETTE.gunnerBeard, roughness: 0.88 });

  // Short sturdy olive mock-neck turtleneck collar (matches Image 1 dark olive neck base!)
  root.add(buildShortNeck(mockNeckMat, 0.066));

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.674, 0.006);

  // Cropped dark-brown buzzcut & sideburns peeking cleanly below beanie (never bald!)
  const gunnerHeadMat = createMat({
    color: 0xffffff,
    map: getBuzzcutHeadTexture(PALETTE.skinTan, PALETTE.gunnerBeard),
    roughness: 0.78,
  });
  headGroup.add(
    makeStylizedMesh(
      createStylizedHeadGeometry({ scale: 1.0, slimX: 0.98, noseRidge: 0.017 }),
      gunnerHeadMat,
      { outline: 0.0048 }
    )
  );

  for (const s of [-1, 1]) {
    const ear = makeStylizedMesh(
      createBeveledBoxGeometry(0.020, 0.046, 0.026, 0.006),
      skinMat,
      { outline: 0.0032 }
    );
    ear.position.set(s * 0.094, 0.000, -0.006);
    headGroup.add(ear);
  }

  // Sculpted rugged full dark-brown beard & mustache
  const beardGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 1.18,
    thickness: 0.020,
    zOff: 0.014,
    yTop: (_ang, tAbs) => {
      if (tAbs < 0.45) return -0.036 - tAbs * 0.032;
      return -0.050 + ((tAbs - 0.45) / 0.55) * 0.072;
    },
    yBot: (_ang, tAbs) => -0.128 + Math.pow(tAbs, 1.9) * 0.088,
    rx: (_ang, tAbs) => 0.094 - tAbs * 0.002,
    rz: (_ang, tAbs) => 0.118 - Math.pow(tAbs, 1.4) * 0.014,
  });
  headGroup.add(makeStylizedMesh(beardGeom, beardMat, { outline: 0.0036 }));

  // Stylized expressive teeth/mouth (e.g., fierce battle snarl / veteran grin) cleanly framed in beard!
  if (faceId === 'faceless') {
    const mouthGap = makeStylizedMesh(
      createBeveledBoxGeometry(0.036, 0.013, 0.010, 0.003),
      skinMat,
      { outline: 0.0018 }
    );
    mouthGap.position.set(0, -0.072, 0.131);
    headGroup.add(mouthGap);
  } else {
    // Keep Heavy Gunner's compact mouth size (mouthScale: 0.52) framed tightly inside his rugged beard!
    headGroup.add(
      buildStylizedFace(faceId, {
        mode: 'mouthOnly',
        hasBeard: true,
        scale: 1.0,
        slimX: 0.98,
        noseRidge: 0.017,
        mouthScale: 0.52,
        mouthYOffset: -0.010,
        extraOffset: 0.016,
      })
    );
  }

  // Contoured dark tactical goggles with reflective grey-blue visor glass!
  headGroup.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.008, rx: 0.104, rz: 0.118, oz: -0.002 },
          { y: 0.044, rx: 0.106, rz: 0.120, oz: -0.002 },
        ],
        14,
        false,
        false
      ),
      goggleMat,
      { outline: 0.0024 }
    )
  );

  const goggleFrameGeom = buildCurvedShellPlate({
    segs: 18,
    maxAngle: 0.84,
    thickness: 0.026,
    zOff: 0.010,
    yTop: (_ang, tAbs) => 0.064 - Math.pow(tAbs, 2.0) * 0.012,
    yBot: (_ang, tAbs) => {
      const noseNotch = Math.max(0, 1 - tAbs * 3.5) * 0.020;
      return -0.008 + noseNotch + Math.pow(tAbs, 2.0) * 0.012;
    },
    rx: () => 0.107,
    rz: () => 0.132,
  });
  headGroup.add(makeStylizedMesh(goggleFrameGeom, goggleMat, { outline: 0.0034 }));

  const goggleLensGeom = buildCurvedShellPlate({
    segs: 18,
    maxAngle: 0.72,
    thickness: 0.009,
    zOff: 0.013,
    yTop: (_ang, tAbs) => 0.054 - Math.pow(tAbs, 2.0) * 0.010,
    yBot: (_ang, tAbs) => {
      const noseNotch = Math.max(0, 1 - tAbs * 3.5) * 0.019;
      return 0.003 + noseNotch + Math.pow(tAbs, 2.0) * 0.010;
    },
    rx: () => 0.110,
    rz: () => 0.136,
  });
  headGroup.add(makeStylizedMesh(goggleLensGeom, lensMat, { outline: 0.002 }));

  // Round snug ribbed olive knit beanie (rounded crown matching Image 1!)
  const beanieRings: LoftRing[] = [
    { y: 0.050, rx: 0.114, rz: 0.124, oz: -0.004 },
    { y: 0.098, rx: 0.112, rz: 0.122, oz: -0.006 },
    { y: 0.144, rx: 0.094, rz: 0.104, oz: -0.008 },
    { y: 0.172, rx: 0.058, rz: 0.064, oz: -0.008 },
    { y: 0.184, rx: 0.020, rz: 0.022, oz: -0.008 },
  ];
  headGroup.add(
    makeStylizedMesh(createLoftGeometry(beanieRings, 14), beanieMat, { outline: 0.0048 })
  );

  headGroup.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.046, rx: 0.119, rz: 0.129, oz: -0.003 },
          { y: 0.088, rx: 0.119, rz: 0.129, oz: -0.005 },
        ],
        14,
        false,
        false
      ),
      beanieCuffMat,
      { outline: 0.0032 }
    )
  );

  root.add(headGroup);
  return root;
}

// ============================================================================
// HEAD 07: SKILL ISSUE AGENT (Full Stylized Expressive Face + "SKILL" Baseball Cap)
// ============================================================================
export function buildHeadSkill(faceId: FaceId = 'smirk'): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_SkillIssue';

  const skinMat = createMat({ color: PALETTE.skinBase, roughness: 0.74 });
  const capMat = createMat({ color: PALETTE.skillCap, roughness: 0.80 });
  const capPatchMat = createMat({
    color: 0xffffff,
    map: getSkillCapTexture(),
    roughness: 0.72,
  });

  root.add(buildShortNeck(skinMat, 0.056));

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.678, 0.008);

  // Sharp barbershop buzzcut + low taper fade under his SKILL baseball cap (never bald!)
  const skillHeadMat = createMat({
    color: 0xffffff,
    map: getBuzzcutHeadTexture(PALETTE.skinBase, 0x261f1c),
    roughness: 0.76,
  });
  headGroup.add(
    makeStylizedMesh(
      createStylizedHeadGeometry({ scale: 0.99, slimX: 0.97, noseRidge: 0.018 }),
      skillHeadMat,
      { outline: 0.0046 }
    )
  );

  // Golden-Ratio Image-2 eyes & sleek arched brows + bold 2x hero mouth showcase!
  headGroup.add(
    buildStylizedFace(faceId, {
      mode: 'full',
      hasBeard: false,
      scale: 0.99,
      slimX: 0.97,
      noseRidge: 0.018,
      eyeYOffset: 0.002,
      mouthScale: 1.0,
      mouthYOffset: 0.002,
      browColor: 0x33241b,
    })
  );

  for (const s of [-1, 1]) {
    const ear = makeStylizedMesh(
      createBeveledBoxGeometry(0.018, 0.046, 0.026, 0.006),
      skinMat,
      { outline: 0.0032 }
    );
    ear.position.set(s * 0.092, 0.002, -0.006);
    headGroup.add(ear);
  }

  // Iconic Black Baseball Cap with BIG BOLD WHITE "SKILL" PRINT!
  const capGroup = new THREE.Group();
  capGroup.position.set(0, 0.048, -0.002);
  capGroup.rotation.x = -0.05;

  const domeRings: LoftRing[] = [
    { y: 0.004, rx: 0.106, rz: 0.120, oz: -0.004 },
    { y: 0.052, rx: 0.104, rz: 0.118, oz: -0.004 },
    { y: 0.102, rx: 0.090, rz: 0.102, oz: -0.006 },
    { y: 0.132, rx: 0.056, rz: 0.064, oz: -0.006 },
    { y: 0.142, rx: 0.018, rz: 0.020, oz: -0.006 },
  ];
  capGroup.add(makeStylizedMesh(createLoftGeometry(domeRings, 14), capMat, { outline: 0.0046 }));

  const capBtn = makeStylizedMesh(new THREE.CylinderGeometry(0.012, 0.012, 0.010, 8), capMat, {
    outline: 0.002,
  });
  capBtn.position.set(0, 0.146, -0.006);
  capGroup.add(capBtn);

  const brimShape = new THREE.Shape();
  brimShape.moveTo(-0.100, 0.0);
  brimShape.quadraticCurveTo(-0.096, 0.116, 0.0, 0.126);
  brimShape.quadraticCurveTo(0.096, 0.116, 0.100, 0.0);
  brimShape.quadraticCurveTo(0.0, 0.022, -0.100, 0.0);

  const brimGeom = new THREE.ExtrudeGeometry(brimShape, {
    depth: 0.010,
    bevelEnabled: true,
    bevelThickness: 0.002,
    bevelSize: 0.002,
    bevelSegments: 1,
    curveSegments: 8,
  });
  const bPos = brimGeom.getAttribute('position');
  for (let i = 0; i < bPos.count; i++) {
    const x = bPos.getX(i);
    const y = bPos.getY(i);
    const z = bPos.getZ(i);
    bPos.setXYZ(i, x, y, z - (x * x) * 1.4 - y * 0.16);
  }
  brimGeom.rotateX(Math.PI / 2);
  brimGeom.computeVertexNormals();

  const capBrim = makeStylizedMesh(brimGeom, capMat, { outline: 0.0036 });
  capBrim.position.set(0, 0.014, 0.090);
  capGroup.add(capBrim);

  // Larger, bolder curved "SKILL" front cap print clearly readable from any distance!
  const patchGeom = new THREE.CylinderGeometry(0.098, 0.109, 0.064, 12, 1, true, -0.64, 1.28);
  const patchMesh = new THREE.Mesh(patchGeom, capPatchMat);
  patchMesh.position.set(0, 0.062, 0.016);
  patchMesh.renderOrder = 2;
  capGroup.add(patchMesh);

  headGroup.add(capGroup);
  root.add(headGroup);
  return root;
}

// ============================================================================
// HEAD 08: LEVEL-3 SPETSNAZ SURVIVOR — MASTER OVERHAUL MATCHING IMAGE 1!
//          Smooth Enveloping Gunmetal Altyn Dome, Seamless Wrapping Face Shield
//          Visor & Soft Layered Crimson Cloth Bandana (Zero Floating Blocks!)
// ============================================================================
export function buildHeadSpetsnaz(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_Level3Spetsnaz';

  const skinMat = createMat({ color: 0xc28a6c, roughness: 0.78 });
  const helmetMat = createGlossyGlassMat({ color: 0x525a64, roughness: 0.32, metalness: 0.46 });
  const visorMat = createMat({ color: 0x444b53, roughness: 0.38, metalness: 0.48, flatShading: false });
  const visorRimMat = createMat({ color: 0x2f353c, roughness: 0.45, metalness: 0.40 });
  const slitMat = createGlossyGlassMat({
    color: 0xffffff,
    map: getGlossyGlassTexture('dark'),
    roughness: 0.05,
    metalness: 0.48,
  });
  const bandanaMat = createMat({ color: PALETTE.spetsBandanaRed, roughness: 0.85 });
  const bandanaFoldMat = createMat({ color: 0xa61c21, roughness: 0.88 });

  // Short sturdy neck tucked cleanly inside layered crimson cloth bandana
  root.add(buildShortNeck(skinMat, 0.056));

  // --- SOFT LAYERED CRIMSON BANDANA NECKERCHIEF (NO RIGID DORITO TRIANGLE!) ---
  // Tier 1: Soft folded cloth collar wrapping cleanly around neck & top of shoulders
  const wrapUpper = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 1.468, rx: 0.136, rz: 0.128, oz: 0.012 },
        { y: 1.512, rx: 0.124, rz: 0.118, oz: 0.010 },
        { y: 1.556, rx: 0.102, rz: 0.104, oz: 0.008 },
      ],
      14
    ),
    bandanaMat,
    { outline: 0.0044 }
  );
  root.add(wrapUpper);

  // Tier 2: Curved layered cloth drape hugging the front chest curve with soft pointed tail!
  const bandanaDrapeGeom = buildCurvedShellPlate({
    segs: 14,
    maxAngle: 1.32, // Sweeps smoothly from left shoulder collarbone -> front V -> right collarbone!
    thickness: 0.020,
    zOff: 0.010,
    topZInset: 0.006,
    yTop: (_ang, tAbs) => 1.544 - Math.pow(tAbs, 1.5) * 0.032,
    yBot: (_ang, tAbs) => {
      // Softly scalloped natural bandana drape peaking lowest at front center (y=1.345),
      // sweeping smoothly upward around shoulders (y=1.475)!
      const vPoint = Math.pow(1 - tAbs, 1.45) * 0.135;
      const clothWave = Math.sin(tAbs * Math.PI * 2.5) * 0.008;
      return 1.480 - vPoint + clothWave;
    },
    rx: (_ang, tAbs) => 0.146 + tAbs * 0.006,
    rz: (_ang, tAbs) => 0.136 - tAbs * 0.008,
  });
  root.add(makeStylizedMesh(bandanaDrapeGeom, bandanaMat, { outline: 0.0042 }));

  // Tier 3: Diagonal upper cloth fold crease wrapping naturally across throat (zero flat bar!)
  const bandanaFoldGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 1.24,
    thickness: 0.014,
    zOff: 0.012,
    yTop: (ang, tAbs) => 1.552 - tAbs * 0.022 + ang * 0.010,
    yBot: (ang, tAbs) => 1.514 - tAbs * 0.026 + ang * 0.014,
    rx: () => 0.138,
    rz: () => 0.134,
  });
  root.add(makeStylizedMesh(bandanaFoldGeom, bandanaFoldMat, { outline: 0.003 }));

  // --- ICONIC LEVEL-3 SPETSNAZ / ALTYN ARMORED HELMET (SMOOTH & SEAMLESS!) ---
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.678, 0.008);

  // Subtle dark shadowed lower chin peeking cleanly under the bottom visor rim (exact Image 1!)
  const shadowedChin = makeStylizedMesh(
    createStylizedHeadGeometry({ scale: 0.90, slimX: 0.92, noseRidge: 0.010 }),
    skinMat,
    { outline: 0.0036 }
  );
  headGroup.add(shadowedChin);

  // Smooth wide enveloping metallic-steel Altyn military dome (16-sided smooth low-poly steel!)
  // Envelopes ears & sides completely down to y = -0.052 so there is ZERO bare gap behind the visor!
  const altynShape = (earDrop: number, earFlare: number) => (angle: number) => {
    const front = Math.cos(angle);
    const side = Math.abs(Math.sin(angle));
    let dyAdd = 0;
    let rxMul = 1;
    if (front < 0.35) {
      const w = Math.min(1, (0.35 - front) / 0.65);
      dyAdd -= earDrop * w;
      rxMul += earFlare * side * w;
    }
    return { rxMul, dyAdd };
  };

  const domeRings: LoftRing[] = [
    { y: 0.012, rx: 0.132, rz: 0.144, oz: -0.008, shape: altynShape(0.072, 0.08) }, // Full side ear armor!
    { y: 0.068, rx: 0.134, rz: 0.146, oz: -0.006, shape: altynShape(0.026, 0.03) },
    { y: 0.122, rx: 0.124, rz: 0.136, oz: -0.008 },
    { y: 0.162, rx: 0.096, rz: 0.106, oz: -0.010 },
    { y: 0.184, rx: 0.056, rz: 0.062, oz: -0.010 },
    { y: 0.194, rx: 0.020, rz: 0.022, oz: -0.010 },
  ];
  headGroup.add(
    makeStylizedMesh(createLoftGeometry(domeRings, 16, false, true), helmetMat, {
      outline: 0.0052,
    })
  );

  // --- SEAMLESS WRAPPING ARMORED FACE SHIELD VISOR (Hugs directly back to ear hinges!) ---
  // Notice maxAngle = 1.24 rad (~71° each side) so visor wings join smoothly into the side ear pivots!
  const shieldGeom = buildCurvedShellPlate({
    segs: 12,
    maxAngle: 1.24,
    thickness: 0.022,
    zOff: -0.002,
    topZInset: 0.012,
    botZInset: 0.006,
    yTop: (_ang, tAbs) => 0.082 - Math.pow(tAbs, 2.2) * 0.028,
    yBot: (_ang, tAbs) => -0.082 + Math.pow(tAbs, 2.0) * 0.034,
    rx: (_ang, tAbs) => 0.138 + tAbs * 0.004,
    rz: (_ang, tAbs) => 0.156 - tAbs * 0.006,
  });
  headGroup.add(makeStylizedMesh(shieldGeom, visorMat, { outline: 0.0044 }));

  // Upper & lower armored visor ridge lips framing the crisp dark ballistic slit
  const upperLipGeom = buildCurvedShellPlate({
    segs: 10,
    maxAngle: 0.92,
    thickness: 0.012,
    zOff: 0.002,
    yTop: () => 0.048,
    yBot: () => 0.028,
    rx: () => 0.141,
    rz: () => 0.160,
  });
  headGroup.add(makeStylizedMesh(upperLipGeom, visorRimMat, { outline: 0.0024 }));

  const lowerLipGeom = buildCurvedShellPlate({
    segs: 10,
    maxAngle: 0.92,
    thickness: 0.012,
    zOff: 0.002,
    yTop: () => -0.016,
    yBot: () => -0.036,
    rx: () => 0.141,
    rz: () => 0.160,
  });
  headGroup.add(makeStylizedMesh(lowerLipGeom, visorRimMat, { outline: 0.0024 }));

  // Sleek horizontal recessed dark visor eye-slit!
  const eyeSlitGeom = buildCurvedShellPlate({
    segs: 10,
    maxAngle: 0.86,
    thickness: 0.010,
    zOff: 0.003,
    yTop: () => 0.028,
    yBot: () => -0.016,
    rx: () => 0.142,
    rz: () => 0.159,
  });
  headGroup.add(makeStylizedMesh(eyeSlitGeom, slitMat, { outline: 0.0022 }));

  // Sleek side visor pivot hinges seated right where shield wings meet the Altyn dome!
  for (const s of [-1, 1]) {
    const pivot = makeStylizedMesh(
      createBeveledBoxGeometry(0.022, 0.044, 0.042, 0.006),
      visorRimMat,
      { outline: 0.0028 }
    );
    pivot.position.set(s * 0.142, 0.016, -0.002);
    headGroup.add(pivot);
  }

  root.add(headGroup);
  return root;
}

// ============================================================================
// HEAD 09: SILAT STRIKER (Southeast Asian Martial Artist — Shaved Military Buzzcut,
//          Strong Chiseled Jaw, Neutral Non-Smiling Face & Right-Cheek Claw Scar!)
// ============================================================================
export function buildHeadSilat(faceId: FaceId = 'neutral'): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Head_SilatStriker';

  const skinMat = createMat({ color: PALETTE.skinSEA, roughness: 0.74 });
  // Unified single-mesh head material: warm SEA skin + sharp line-up buzzcut & low taper fade (Image 1!)
  const unifiedHeadMat = createMat({
    color: 0xffffff,
    map: getBuzzcutHeadTexture(PALETTE.skinSEA, 0x28211d),
    roughness: 0.78,
  });

  // Strong athletic shortened neck
  root.add(buildShortNeck(skinMat, 0.062));

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.674, 0.007);

  // Single seamless head mesh with integrated high-fade military buzzcut (ZERO bald spot, ZERO clipping!)
  const headMesh = makeStylizedMesh(
    createStylizedHeadGeometry({ scale: 0.99, slimX: 0.99, noseRidge: 0.017 }),
    unifiedHeadMat,
    { outline: 0.0046 }
  );
  headGroup.add(headMesh);

  // Stoic Neutral non-smiling face by default (or any selected variation!)
  headGroup.add(
    buildStylizedFace(faceId, {
      mode: 'full',
      hasBeard: false,
      scale: 0.99,
      slimX: 0.99,
      noseRidge: 0.017,
      eyeYOffset: 0.001,
      mouthScale: 0.90,
      mouthYOffset: 0.002,
      browColor: 0x1c1716,
    })
  );

  // --- BADASS 3-SLASH CLAW SCRATCH SCAR ("LUKA CAKAR") ON HIS RIGHT CHEEK! ---
  // Curved face-conforming overlay hugging tightly below his right eye (x < 0 -> right cheek!)
  const clawMat = new THREE.MeshStandardMaterial({
    map: getClawScarTexture(),
    transparent: true,
    alphaTest: 0.12,
    roughness: 0.76,
    metalness: 0.02,
    flatShading: true,
    polygonOffset: true,
    polygonOffsetFactor: -3,
  });

  const clawGeom = (() => {
    const uSegs = 6;
    const vSegs = 4;
    const cols = uSegs + 1;
    const positions: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    for (let r = 0; r <= vSegs; r++) {
      const v = r / vSegs;
      const y = THREE.MathUtils.lerp(-0.056, -0.004, v);
      for (let c = 0; c <= uSegs; c++) {
        const u = c / uSegs;
        // Spans right cheek cleanly from under outer right eye (-0.90) toward nose side (-0.24)
        const ang = THREE.MathUtils.lerp(-0.90, -0.24, u);
        const tY = THREE.MathUtils.clamp((y + 0.052) / 0.057, 0, 1);
        const rx = THREE.MathUtils.lerp(0.081, 0.089, tY) + 0.0038;
        const rz = THREE.MathUtils.lerp(0.097, 0.105, tY) + 0.0038;
        const oz = THREE.MathUtils.lerp(0.010, 0.006, tY);
        const front = Math.cos(ang);
        const dzAdd = front > 0.62 ? 0.018 * Math.pow((front - 0.62) / 0.38, 1.35) : 0;
        positions.push(Math.sin(ang) * rx, y, oz + front * rz + dzAdd);
        uvs.push(u, v);
      }
    }
    for (let r = 0; r < vSegs; r++) {
      for (let c = 0; c < uSegs; c++) {
        const a = r * cols + c;
        const b = a + 1;
        const cIdx = (r + 1) * cols + c;
        const d = cIdx + 1;
        indices.push(a, b, d, a, d, cIdx);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
  })();

  const clawMesh = new THREE.Mesh(clawGeom, clawMat);
  clawMesh.renderOrder = 3;
  headGroup.add(clawMesh);

  // Sculpted ears
  for (const s of [-1, 1]) {
    const ear = makeStylizedMesh(
      createBeveledBoxGeometry(0.017, 0.044, 0.025, 0.006),
      skinMat,
      { outline: 0.0032 }
    );
    ear.position.set(s * 0.091, 0.000, -0.006);
    ear.rotation.z = s * -0.10;
    headGroup.add(ear);
  }

  root.add(headGroup);
  return root;
}

export function buildHeadById(id: SkinId, faceId: FaceId = 'grin'): THREE.Group {
  switch (id) {
    case 'boonie':
      return buildHeadBoonie(faceId);
    case 'venom':
      return buildHeadVenom();
    case 'gold':
      return buildHeadGold();
    case 'reaper':
      return buildHeadReaper();
    case 'police':
      return buildHeadPolice(faceId);
    case 'gunner':
      return buildHeadGunner(faceId);
    case 'skill':
      return buildHeadSkill(faceId);
    case 'spetsnaz':
      return buildHeadSpetsnaz();
    case 'silat':
      return buildHeadSilat(faceId);
  }
}
