import * as THREE from 'three';
import {
  createMat,
  getGunnerTattooTexture,
  getPolicePatchTexture,
  getSkillSleeveTexture,
  makeStylizedMesh,
  PALETTE,
} from '../materials';
import {
  buildLimbBetween,
  createBeveledBoxGeometry,
  createElbowCap,
  createLoftGeometry,
  createOpenJacketShellGeometry,
  createShoulderCap,
  createStylizedHand,
  createTacticalPouch,
  createTorsoGeometry,
  createWristCap,
  LoftRing,
} from '../common';
import {
  createAK47,
  createM249LMG,
  createSkillPistol,
  createSWATMarksmanRifle,
  createTacticalCarbine,
} from '../weapons';
import { SkinId } from '../types';

/**
 * Creates a clean animation pivot at `worldPos` with an inverse-offset `inner` container so
 * children authored in character-space sit identically at rest while rotating cleanly around `worldPos`.
 */
function createPivotAt(
  worldPos: THREE.Vector3,
  rigRole:
    | 'leftArmPivot'
    | 'rightArmPivot'
    | 'leftElbowPivot'
    | 'rightElbowPivot'
    | 'weaponRig'
): { pivot: THREE.Group; inner: THREE.Group } {
  const pivot = new THREE.Group();
  pivot.position.copy(worldPos);
  pivot.userData.rigRole = rigRole;
  const inner = new THREE.Group();
  inner.position.copy(worldPos).negate();
  pivot.add(inner);
  return { pivot, inner };
}

/**
 * Helper: builds a smooth curved flat leather strap along a 3D path (so Golden Agent's
 * brown leather shoulder holster hugs the tailored waistcoat shoulders with zero floating gaps!).
 */
function createCurvedFlatStrap(
  points: THREE.Vector3[],
  width: number,
  thickness: number,
  material: THREE.Material,
  outline = 0.0028
): THREE.Mesh {
  const curve = new THREE.CatmullRomCurve3(points);
  const segs = 16;
  const frames = curve.computeFrenetFrames(segs, false);

  const verts: number[] = [];
  const idx: number[] = [];

  const hw = width / 2;
  const ht = thickness / 2;

  for (let i = 0; i <= segs; i++) {
    const p = curve.getPointAt(i / segs);
    const tangent = frames.tangents[i];
    // Keep strap width oriented neatly sideways along X (perpendicular to sagittal Y-Z arch)
    const side = new THREE.Vector3(1, 0, 0);
    const normal = new THREE.Vector3().crossVectors(tangent, side).normalize();
    const binorm = new THREE.Vector3().crossVectors(normal, tangent).normalize();

    const c0 = p.clone().addScaledVector(binorm, -hw).addScaledVector(normal, ht);
    const c1 = p.clone().addScaledVector(binorm, hw).addScaledVector(normal, ht);
    const c2 = p.clone().addScaledVector(binorm, hw).addScaledVector(normal, -ht);
    const c3 = p.clone().addScaledVector(binorm, -hw).addScaledVector(normal, -ht);

    verts.push(c0.x, c0.y, c0.z, c1.x, c1.y, c1.z, c2.x, c2.y, c2.z, c3.x, c3.y, c3.z);
  }

  for (let i = 0; i < segs; i++) {
    const a = i * 4;
    const b = (i + 1) * 4;
    for (let f = 0; f < 4; f++) {
      const fNext = (f + 1) % 4;
      idx.push(a + f, b + f, b + fNext);
      idx.push(a + f, b + fNext, a + fNext);
    }
  }
  // End caps
  idx.push(0, 2, 1, 0, 3, 2);
  const last = segs * 4;
  idx.push(last + 0, last + 1, last + 2, last + 0, last + 2, last + 3);

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  geom.setIndex(idx);
  geom.computeVertexNormals();

  return makeStylizedMesh(geom, material, { outline });
}

// ============================================================================
// TORSO 01: CAPTAIN BOONIE (Black Combat Jacket + Olive-Tan 4-Mag Plate Carrier)
// ============================================================================
export function buildTorsoBoonie(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_CaptainBoonie';

  const handMat = createMat({ color: PALETTE.skinHand, roughness: 0.76 });
  const shirtMat = createMat({ color: PALETTE.boonieShirt, roughness: 0.85 });
  const vestMat = createMat({ color: PALETTE.boonieVest, roughness: 0.82 });
  const vestDarkMat = createMat({ color: PALETTE.boonieVestStrap, roughness: 0.85 });
  const magMat = createMat({ color: PALETTE.boonieMag, roughness: 0.58, metalness: 0.25 });

  // Athletic V-tapered black combat jacket torso with sloping shoulders
  const torso = makeStylizedMesh(
    createTorsoGeometry({
      yStart: 0.97,
      height: 0.54,
      waistRx: 0.164,
      waistRz: 0.108,
      chestRx: 0.208,
      chestRz: 0.126,
      shoulderRx: 0.218,
    }),
    shirtMat,
    { outline: 0.0052 }
  );
  root.add(torso);

  // Clean jacket hem over waist
  const jacketHem = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 0.960, rx: 0.170, rz: 0.114 },
        { y: 1.005, rx: 0.168, rz: 0.112 },
      ],
      10
    ),
    shirtMat,
    { outline: 0.0044 }
  );
  root.add(jacketHem);

  // Snug standing dark tactical collar
  const collar = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 1.475, rx: 0.096, rz: 0.092 },
        { y: 1.535, rx: 0.082, rz: 0.080 },
      ],
      10
    ),
    shirtMat,
    { outline: 0.0042 }
  );
  root.add(collar);

  // --- OLIVE-TAN PLATE CARRIER VEST ---
  const frontPlateShape = new THREE.Shape();
  frontPlateShape.moveTo(-0.140, -0.170);
  frontPlateShape.lineTo(0.140, -0.170);
  frontPlateShape.lineTo(0.135, 0.048);
  frontPlateShape.lineTo(0.098, 0.152);
  frontPlateShape.lineTo(-0.098, 0.152);
  frontPlateShape.lineTo(-0.135, 0.048);
  frontPlateShape.closePath();

  const plateGeom = new THREE.ExtrudeGeometry(frontPlateShape, {
    depth: 0.040,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.008,
    bevelSegments: 1,
  });
  plateGeom.center();

  const frontPlate = makeStylizedMesh(plateGeom, vestMat, { outline: 0.0046 });
  frontPlate.position.set(0, 1.292, 0.124);
  frontPlate.rotation.x = -0.05;
  root.add(frontPlate);

  // Upper chest Velcro / MOLLE horizontal strip
  const chestPatch = makeStylizedMesh(
    createBeveledBoxGeometry(0.148, 0.068, 0.014, 0.003),
    vestDarkMat,
    { outline: 0.0024 }
  );
  chestPatch.position.set(0, 1.368, 0.148);
  chestPatch.rotation.x = -0.05;
  root.add(chestPatch);

  // Back plate + MOLLE webbing
  const backPlate = makeStylizedMesh(plateGeom.clone(), vestMat, { outline: 0.0046 });
  backPlate.position.set(0, 1.292, -0.122);
  backPlate.rotation.x = 0.04;
  root.add(backPlate);

  for (let i = 0; i < 3; i++) {
    const molle = makeStylizedMesh(
      createBeveledBoxGeometry(0.198, 0.020, 0.014, 0.002),
      vestDarkMat,
      { outline: 0.002 }
    );
    molle.position.set(0, 1.19 + i * 0.066, -0.148);
    root.add(molle);
  }

  // Contoured curved vest shoulder straps & side cummerbund
  for (const s of [-1, 1]) {
    const strap = createCurvedFlatStrap(
      [
        new THREE.Vector3(s * 0.095, 1.42, 0.115),
        new THREE.Vector3(s * 0.112, 1.498, 0.048),
        new THREE.Vector3(s * 0.114, 1.508, -0.012),
        new THREE.Vector3(s * 0.105, 1.472, -0.088),
        new THREE.Vector3(s * 0.095, 1.41, -0.115),
      ],
      0.056,
      0.022,
      vestDarkMat,
      0.0034
    );
    root.add(strap);

    const cummerbund = makeStylizedMesh(
      createBeveledBoxGeometry(0.038, 0.130, 0.232, 0.005),
      vestDarkMat,
      { outline: 0.0036 }
    );
    cummerbund.position.set(s * 0.175, 1.182, 0.0);
    root.add(cummerbund);

    const sidePouch = createTacticalPouch({
      width: 0.060,
      height: 0.102,
      depth: 0.084,
      pouchMat: vestDarkMat,
      flap: true,
      flapMat: vestMat,
      outline: 0.0034,
    });
    sidePouch.position.set(s * 0.196, 1.180, 0.022);
    sidePouch.rotation.y = s * 0.12;
    root.add(sidePouch);
  }

  // 4 Front Magazine Pouches + 4 Protruding Black Magazines (exact Image 1 layout)
  const pouchX = [-0.122, -0.041, 0.041, 0.122];
  for (const px of pouchX) {
    const curveZ = 0.164 - Math.abs(px) * 0.14;
    const pouch = createTacticalPouch({
      width: 0.072,
      height: 0.116,
      depth: 0.054,
      pouchMat: vestMat,
      magMat,
      magHeight: 0.096,
      outline: 0.0036,
    });
    pouch.position.set(px, 1.176, curveZ);
    pouch.rotation.y = px * 0.82;
    root.add(pouch);

    const band = makeStylizedMesh(
      createBeveledBoxGeometry(0.075, 0.018, 0.058, 0.002),
      vestDarkMat,
      { outline: 0.0018 }
    );
    band.position.set(px, 1.196, curveZ + 0.002);
    band.rotation.y = px * 0.82;
    root.add(band);
  }

  // Natural athletic articulated arms & bold clenched fists
  for (const side of ['left', 'right'] as const) {
    const s = side === 'left' ? 1 : -1;
    const shoulder = new THREE.Vector3(s * 0.214, 1.422, 0.0);
    const elbow = new THREE.Vector3(s * 0.280, 1.185, -0.014);
    const wrist = new THREE.Vector3(s * 0.296, 0.945, 0.030);

    const sh = createPivotAt(shoulder, side === 'left' ? 'leftArmPivot' : 'rightArmPivot');
    const elb = createPivotAt(elbow, side === 'left' ? 'leftElbowPivot' : 'rightElbowPivot');
    sh.pivot.userData.ikMeta = { shoulder: shoulder.clone(), elbow: elbow.clone(), wrist: wrist.clone() };

    sh.inner.add(createShoulderCap(shoulder, shirtMat, 0.062, 0.0042));
    sh.inner.add(
      buildLimbBetween(shoulder, elbow, 0.068, 0.070, 0.062, 0.064, 0.056, 0.058, shirtMat, 10, {
        outline: 0.0046,
      })
    );

    elb.inner.add(createElbowCap(elbow, shirtMat, 0.055, 0.0040));
    elb.inner.add(
      buildLimbBetween(elbow, wrist, 0.056, 0.058, 0.052, 0.054, 0.044, 0.046, shirtMat, 10, {
        outline: 0.0044,
      })
    );
    elb.inner.add(createWristCap(wrist, handMat, 0.039, 0.0032));
    const hand = createStylizedHand(handMat, side, 'fist', 0.0038);
    hand.userData.rigRole = side === 'left' ? 'leftHand' : 'rightHand';
    hand.position.copy(wrist);
    hand.rotation.order = 'YXZ';
    hand.rotation.y = s * -1.72;
    hand.rotation.z = s * 0.08;
    hand.rotation.x = -0.06;
    elb.inner.add(hand);

    sh.inner.add(elb.pivot);
    root.add(sh.pivot);
  }

  return root;
}

// ============================================================================
// TORSO 02: VENOM FANG OPS (X-Patch Breacher Rig + Backpack + Diagonal AK-47)
// ============================================================================
export function buildTorsoVenom(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_VenomFang';

  const uniformMat = createMat({ color: PALETTE.venomUniform, roughness: 0.84 });
  const armorMat = createMat({ color: PALETTE.venomArmor, roughness: 0.72, metalness: 0.10 });
  const webbingMat = createMat({ color: PALETTE.venomWebbing, roughness: 0.86 });
  const packMat = createMat({ color: 0x222429, roughness: 0.84 });

  // Athletic sloped breacher torso
  const torso = makeStylizedMesh(
    createTorsoGeometry({
      yStart: 0.97,
      height: 0.54,
      waistRx: 0.168,
      waistRz: 0.114,
      chestRx: 0.214,
      chestRz: 0.132,
      shoulderRx: 0.224,
    }),
    uniformMat,
    { outline: 0.0054 }
  );
  root.add(torso);

  // Duty belt & left hip loop
  const belt = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 0.962, rx: 0.180, rz: 0.122 },
        { y: 1.022, rx: 0.178, rz: 0.120 },
      ],
      10
    ),
    webbingMat,
    { outline: 0.0042 }
  );
  root.add(belt);

  const hipLoop = makeStylizedMesh(
    createBeveledBoxGeometry(0.028, 0.082, 0.022, 0.004),
    webbingMat,
    { outline: 0.003 }
  );
  hipLoop.position.set(0.188, 0.928, 0.010);
  hipLoop.rotation.z = -0.24;
  root.add(hipLoop);

  // Heavy molded front chest armor plate
  const chestShape = new THREE.Shape();
  chestShape.moveTo(-0.150, -0.168);
  chestShape.lineTo(0.150, -0.168);
  chestShape.lineTo(0.142, 0.052);
  chestShape.lineTo(0.100, 0.152);
  chestShape.lineTo(-0.100, 0.152);
  chestShape.lineTo(-0.142, 0.052);
  chestShape.closePath();

  const chestGeom = new THREE.ExtrudeGeometry(chestShape, {
    depth: 0.044,
    bevelEnabled: true,
    bevelThickness: 0.009,
    bevelSize: 0.009,
    bevelSegments: 1,
  });
  chestGeom.center();

  const chestPlate = makeStylizedMesh(chestGeom, armorMat, { outline: 0.0046 });
  chestPlate.position.set(0, 1.292, 0.132);
  chestPlate.rotation.x = -0.05;
  root.add(chestPlate);

  // Iconic square chest Velcro patch with crisp X mark (exact Image 1!)
  const patchBase = makeStylizedMesh(
    createBeveledBoxGeometry(0.108, 0.088, 0.012, 0.003),
    uniformMat,
    { outline: 0.0026 }
  );
  patchBase.position.set(-0.024, 1.328, 0.160);
  patchBase.rotation.x = -0.05;
  root.add(patchBase);

  for (const rot of [0.68, -0.68]) {
    const xBar = makeStylizedMesh(
      createBeveledBoxGeometry(0.096, 0.010, 0.007, 0.001),
      webbingMat,
      { outline: 0 }
    );
    xBar.position.set(-0.024, 1.328, 0.169);
    xBar.rotation.z = rot;
    root.add(xBar);
  }

  // Lower vest mag pouches
  for (let i = -1; i <= 1; i++) {
    const pouch = createTacticalPouch({
      width: 0.076,
      height: 0.110,
      depth: 0.050,
      pouchMat: armorMat,
      flap: true,
      flapMat: webbingMat,
      outline: 0.0034,
    });
    pouch.position.set(i * 0.086, 1.168, 0.162 - Math.abs(i) * 0.014);
    pouch.rotation.y = i * 0.16;
    root.add(pouch);
  }

  // Contoured shoulder straps & cummerbund
  for (const s of [-1, 1]) {
    const strap = createCurvedFlatStrap(
      [
        new THREE.Vector3(s * 0.100, 1.425, 0.115),
        new THREE.Vector3(s * 0.118, 1.500, 0.044),
        new THREE.Vector3(s * 0.120, 1.510, -0.018),
        new THREE.Vector3(s * 0.110, 1.460, -0.105),
      ],
      0.060,
      0.024,
      armorMat,
      0.0034
    );
    root.add(strap);

    const cummer = makeStylizedMesh(
      createBeveledBoxGeometry(0.042, 0.140, 0.242, 0.005),
      webbingMat,
      { outline: 0.0036 }
    );
    cummer.position.set(s * 0.184, 1.182, 0.0);
    root.add(cummer);
  }

  // Bulky Assault Backpack (peeking cleanly behind left shoulder just like Image 1!)
  const packGroup = new THREE.Group();
  packGroup.position.set(0.024, 1.295, -0.222);

  packGroup.add(
    makeStylizedMesh(createBeveledBoxGeometry(0.365, 0.455, 0.188, 0.024), packMat, {
      outline: 0.005,
    })
  );
  const packTop = makeStylizedMesh(
    createBeveledBoxGeometry(0.315, 0.112, 0.158, 0.020),
    armorMat,
    { outline: 0.0044 }
  );
  packTop.position.set(0.016, 0.242, 0.008);
  packGroup.add(packTop);

  const packPocket = makeStylizedMesh(
    createBeveledBoxGeometry(0.275, 0.190, 0.072, 0.012),
    armorMat,
    { outline: 0.004 }
  );
  packPocket.position.set(0, -0.092, -0.100);
  packGroup.add(packPocket);
  root.add(packGroup);

  // --- AK-47 HELD DIAGONALLY & SHOULDER-ALIGNED SWAT WEAPON RIG ---
  const wepRig = createPivotAt(new THREE.Vector3(0, 1.418, 0.0), 'weaponRig');
  root.add(wepRig.pivot);

  const ak = createAK47();
  ak.position.set(-0.068, 1.220, 0.244);
  ak.rotation.order = 'YXZ';
  ak.rotation.y = -0.32;
  ak.rotation.z = -1.12;
  ak.rotation.x = 0.06;
  ak.scale.setScalar(1.05);
  wepRig.inner.add(ak);

  ak.updateMatrixWorld(true);
  const rightHandTarget = new THREE.Vector3(-0.058, -0.048, 0.018).applyMatrix4(ak.matrix);
  const leftHandTarget = new THREE.Vector3(0.165, -0.028, 0.016).applyMatrix4(ak.matrix);

  // Right arm gripping AK stock/receiver
  const rShoulder = new THREE.Vector3(-0.220, 1.425, 0.0);
  const rElbow = new THREE.Vector3(-0.308, 1.235, 0.112);
  const rWrist = rightHandTarget.clone().add(new THREE.Vector3(-0.046, 0.044, -0.018));

  wepRig.inner.add(createShoulderCap(rShoulder, uniformMat, 0.074, 0.0044));
  wepRig.inner.add(
    buildLimbBetween(rShoulder, rElbow, 0.072, 0.074, 0.066, 0.068, 0.060, 0.062, uniformMat, 10, {
      outline: 0.0048,
    })
  );
  wepRig.inner.add(createElbowCap(rElbow, uniformMat, 0.059, 0.004));
  wepRig.inner.add(
    buildLimbBetween(rElbow, rWrist, 0.060, 0.062, 0.055, 0.057, 0.046, 0.048, uniformMat, 10, {
      outline: 0.0046,
    })
  );
  wepRig.inner.add(createWristCap(rWrist, webbingMat, 0.040, 0.0032));
  const rGlove = createStylizedHand(webbingMat, 'right', 'grip', 0.0036);
  rGlove.position.copy(rWrist);
  rGlove.rotation.order = 'YXZ';
  rGlove.rotation.set(-0.22, 1.15, -0.38);
  wepRig.inner.add(rGlove);

  // Left arm locked to AK handguard during combat, articulated for 1-hand Speed Vault IK!
  const lShoulder = new THREE.Vector3(0.220, 1.425, 0.0);
  const lElbow = new THREE.Vector3(0.282, 1.188, 0.110);
  const lWrist = leftHandTarget.clone().add(new THREE.Vector3(0.036, 0.032, -0.014));

  const lSh = createPivotAt(lShoulder, 'leftArmPivot');
  const lElb = createPivotAt(lElbow, 'leftElbowPivot');
  lSh.pivot.userData.attachedToWeapon = true;
  lSh.pivot.userData.ikMeta = { shoulder: lShoulder.clone(), elbow: lElbow.clone(), wrist: lWrist.clone() };

  lSh.inner.add(createShoulderCap(lShoulder, uniformMat, 0.070, 0.0044));
  const armPatch = makeStylizedMesh(
    createBeveledBoxGeometry(0.018, 0.078, 0.064, 0.003),
    armorMat,
    { outline: 0.0026 }
  );
  armPatch.position.set(0.304, 1.328, 0.048);
  armPatch.rotation.z = -0.18;
  lSh.inner.add(armPatch);

  lSh.inner.add(
    buildLimbBetween(lShoulder, lElbow, 0.072, 0.074, 0.066, 0.068, 0.060, 0.062, uniformMat, 10, {
      outline: 0.0048,
    })
  );
  lElb.inner.add(createElbowCap(lElbow, uniformMat, 0.059, 0.004));
  lElb.inner.add(
    buildLimbBetween(lElbow, lWrist, 0.060, 0.062, 0.055, 0.057, 0.046, 0.048, uniformMat, 10, {
      outline: 0.0046,
    })
  );
  lElb.inner.add(createWristCap(lWrist, webbingMat, 0.040, 0.0032));
  const lGlove = createStylizedHand(webbingMat, 'left', 'grip', 0.0036);
  lGlove.userData.rigRole = 'leftHand';
  lGlove.position.copy(lWrist);
  lGlove.rotation.order = 'YXZ';
  lGlove.rotation.set(-0.82, -1.12, 0.42);
  lElb.inner.add(lGlove);

  lSh.inner.add(lElb.pivot);
  wepRig.inner.add(lSh.pivot);

  return root;
}

// ============================================================================
// TORSO 03: GOLDEN ENFORCER (Bespoke Tailored Navy Waistcoat, Crisp Powder-Blue
//           Rolled-Sleeve Dress Shirt, Contoured Leather Shoulder Holster & Carbine!)
// ============================================================================
export function buildTorsoGold(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_GoldenEnforcer';

  // Luminous satin gold matching Golden Mask (never dark/muddy!)
  const goldGloveMat = createMat({
    color: PALETTE.goldGlove,
    roughness: 0.30,
    metalness: 0.42,
    emissive: 0x332406,
    emissiveIntensity: 0.18,
  });
  const skinMat = createMat({ color: PALETTE.skinBase, roughness: 0.76 });
  const shirtMat = createMat({ color: PALETTE.suitShirt, roughness: 0.78 });
  const vestMat = createMat({ color: PALETTE.suitVest, roughness: 0.80 });
  const tieMat = createMat({ color: PALETTE.suitTie, roughness: 0.76 });
  const leatherMat = createMat({ color: PALETTE.suitLeather, roughness: 0.68, metalness: 0.06 });

  // 1. Sleek fitted bespoke navy waistcoat body with natural sloping shoulders!
  const torsoVest = makeStylizedMesh(
    createTorsoGeometry({
      yStart: 0.995,
      height: 0.515,
      waistRx: 0.154,
      waistRz: 0.098,
      chestRx: 0.192,
      chestRz: 0.114,
      shoulderRx: 0.202,
    }),
    vestMat,
    { outline: 0.005 }
  );
  root.add(torsoVest);

  // Crisp subtle waist belt + iconic metallic gold center buckle triangle at waistcoat V-notch!
  const waistBelt = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 0.975, rx: 0.160, rz: 0.104 },
        { y: 1.008, rx: 0.160, rz: 0.104 },
      ],
      10
    ),
    leatherMat,
    { outline: 0.0034 }
  );
  root.add(waistBelt);

  const goldBuckle = makeStylizedMesh(
    createBeveledBoxGeometry(0.052, 0.044, 0.022, 0.004),
    goldGloveMat,
    { outline: 0.003 }
  );
  goldBuckle.position.set(0, 1.002, 0.098);
  goldBuckle.rotation.z = Math.PI / 4;
  root.add(goldBuckle);

  // Twin sleek pointed tailored waistcoat bottom front hem flaps framing the gold waist notch!
  for (const s of [-1, 1]) {
    const hemShape = new THREE.Shape();
    hemShape.moveTo(0, 0.055);
    hemShape.lineTo(s * 0.118, 0.055);
    hemShape.lineTo(s * 0.108, -0.012);
    hemShape.lineTo(s * 0.036, -0.030);
    hemShape.closePath();

    const hemGeom = new THREE.ExtrudeGeometry(hemShape, {
      depth: 0.020,
      bevelEnabled: true,
      bevelThickness: 0.003,
      bevelSize: 0.003,
      bevelSegments: 1,
    });
    const hemMesh = makeStylizedMesh(hemGeom, vestMat, { outline: 0.003 });
    hemMesh.position.set(0, 1.012, 0.092);
    root.add(hemMesh);
  }

  // 2. Tailored Powder-Blue Dress Shirt Chest V-Opening + Spread Collar (ultra-clean bespoke fit!)
  const shirtVShape = new THREE.Shape();
  shirtVShape.moveTo(-0.084, 0.148);
  shirtVShape.lineTo(0.084, 0.148);
  shirtVShape.lineTo(0.0, -0.078);
  shirtVShape.closePath();

  const shirtVGeom = new THREE.ExtrudeGeometry(shirtVShape, {
    depth: 0.012,
    bevelEnabled: true,
    bevelThickness: 0.002,
    bevelSize: 0.002,
    bevelSegments: 1,
  });
  const shirtV = makeStylizedMesh(shirtVGeom, shirtMat, { outline: 0.0024 });
  shirtV.position.set(0, 1.374, 0.102);
  shirtV.rotation.x = -0.09;
  root.add(shirtV);

  // Subtle tailored welt pocket & crisp vertical seam detailing on navy waistcoat
  for (const s of [-1, 1]) {
    const pocketWelt = makeStylizedMesh(
      createBeveledBoxGeometry(0.058, 0.010, 0.008, 0.002),
      tieMat,
      { outline: 0.0014 }
    );
    pocketWelt.position.set(s * 0.086, 1.118, 0.104);
    pocketWelt.rotation.y = s * 0.24;
    root.add(pocketWelt);
  }

  // Crisp structured powder-blue dress shirt collar hugging shortened neck cleanly
  const collarBase = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 1.476, rx: 0.088, rz: 0.084 },
        { y: 1.524, rx: 0.072, rz: 0.072 },
      ],
      10
    ),
    shirtMat,
    { outline: 0.0036 }
  );
  root.add(collarBase);

  // Crisp symmetrical downward-angled spread shirt collar points framing the silk tie knot!
  for (const s of [-1, 1]) {
    const collarPointShape = new THREE.Shape();
    collarPointShape.moveTo(0, 0.040);
    collarPointShape.lineTo(s * 0.064, 0.020);
    collarPointShape.lineTo(s * 0.044, -0.028);
    collarPointShape.lineTo(s * 0.006, -0.004);
    collarPointShape.closePath();

    const cpGeom = new THREE.ExtrudeGeometry(collarPointShape, {
      depth: 0.010,
      bevelEnabled: true,
      bevelThickness: 0.002,
      bevelSize: 0.002,
      bevelSegments: 1,
    });
    const cp = makeStylizedMesh(cpGeom, shirtMat, { outline: 0.0024 });
    cp.position.set(s * 0.006, 1.498, 0.088);
    cp.rotation.y = s * -0.26;
    cp.rotation.x = -0.15;
    root.add(cp);
  }

  // 3. Sleek Flush Dark Navy Necktie (clean triangular knot + smooth tapered blade!)
  const knotShape = new THREE.Shape();
  knotShape.moveTo(-0.020, 0.020);
  knotShape.lineTo(0.020, 0.020);
  knotShape.lineTo(0.013, -0.020);
  knotShape.lineTo(-0.013, -0.020);
  knotShape.closePath();
  const knotGeom = new THREE.ExtrudeGeometry(knotShape, {
    depth: 0.014,
    bevelEnabled: true,
    bevelThickness: 0.002,
    bevelSize: 0.002,
    bevelSegments: 1,
  });
  knotGeom.center();
  const tieKnot = makeStylizedMesh(knotGeom, tieMat, { outline: 0.0024 });
  tieKnot.position.set(0, 1.494, 0.102);
  root.add(tieKnot);

  const tieBladeShape = new THREE.Shape();
  tieBladeShape.moveTo(-0.012, 0.095);
  tieBladeShape.lineTo(0.012, 0.095);
  tieBladeShape.lineTo(0.024, -0.086);
  tieBladeShape.lineTo(0.0, -0.108);
  tieBladeShape.lineTo(-0.024, -0.086);
  tieBladeShape.closePath();
  const tieBladeGeom = new THREE.ExtrudeGeometry(tieBladeShape, {
    depth: 0.007,
    bevelEnabled: true,
    bevelThickness: 0.0015,
    bevelSize: 0.0015,
    bevelSegments: 1,
  });
  const tieBlade = makeStylizedMesh(tieBladeGeom, tieMat, { outline: 0.0022 });
  tieBlade.position.set(0, 1.388, 0.114);
  tieBlade.rotation.x = -0.09;
  root.add(tieBlade);

  // Clean subtle flat waistcoat buttons down center placket
  for (let i = 0; i < 3; i++) {
    const btn = makeStylizedMesh(
      new THREE.CylinderGeometry(0.0065, 0.0065, 0.007, 8),
      tieMat,
      { outline: 0.0014 }
    );
    btn.rotation.x = Math.PI / 2;
    btn.position.set(0, 1.242 - i * 0.072, 0.112 - i * 0.004);
    root.add(btn);
  }

  // 4. ULTRA-SLEEK CONTOURED BROWN LEATHER SHOULDER HOLSTER (Sits razor-flush on waistcoat!)
  for (const s of [-1, 1]) {
    const strap = createCurvedFlatStrap(
      [
        new THREE.Vector3(s * 0.168, 1.225, 0.052),
        new THREE.Vector3(s * 0.136, 1.365, 0.096),
        new THREE.Vector3(s * 0.122, 1.466, 0.062),
        new THREE.Vector3(s * 0.120, 1.496, -0.004),
        new THREE.Vector3(s * 0.110, 1.448, -0.086),
        new THREE.Vector3(s * 0.036, 1.348, -0.112),
      ],
      0.032,
      0.010,
      leatherMat,
      0.0024
    );
    root.add(strap);

    // Lower back stabilizing strap looping back around ribs
    const ribStrap = createCurvedFlatStrap(
      [
        new THREE.Vector3(s * 0.036, 1.348, -0.114),
        new THREE.Vector3(s * 0.135, 1.275, -0.088),
        new THREE.Vector3(s * 0.176, 1.225, 0.006),
        new THREE.Vector3(s * 0.172, 1.225, 0.052),
      ],
      0.024,
      0.010,
      leatherMat,
      0.0022
    );
    root.add(ribStrap);
  }

  // Leather back center junction diamond
  const backRing = makeStylizedMesh(
    createBeveledBoxGeometry(0.058, 0.058, 0.016, 0.004),
    leatherMat,
    { outline: 0.0028 }
  );
  backRing.position.set(0, 1.348, -0.118);
  backRing.rotation.z = Math.PI / 4;
  root.add(backRing);

  // Sleek tapered brown leather pistol holster nestled neatly under his left armpit (viewer's right!)
  const underHolster = makeStylizedMesh(
    createBeveledBoxGeometry(0.044, 0.142, 0.084, 0.008),
    leatherMat,
    { outline: 0.0034 }
  );
  underHolster.position.set(0.180, 1.205, 0.050);
  underHolster.rotation.z = -0.12;
  underHolster.rotation.x = 0.20;
  root.add(underHolster);

  // Slim right-side counterweight mag pouch under right armpit
  const rightCounter = makeStylizedMesh(
    createBeveledBoxGeometry(0.036, 0.118, 0.068, 0.006),
    leatherMat,
    { outline: 0.0032 }
  );
  rightCounter.position.set(-0.178, 1.198, 0.030);
  rightCounter.rotation.z = 0.10;
  root.add(rightCounter);

  // 5. BLACK TACTICAL CARBINE SMG & SHOULDER-ALIGNED SWAT WEAPON RIG
  const wepRig = createPivotAt(new THREE.Vector3(0, 1.418, 0.0), 'weaponRig');
  root.add(wepRig.pivot);

  const carbine = createTacticalCarbine();
  carbine.position.set(0.016, 1.248, 0.228);
  carbine.rotation.order = 'YXZ';
  carbine.rotation.y = -0.24;
  carbine.rotation.z = -0.56;
  carbine.rotation.x = 0.05;
  carbine.scale.setScalar(1.02);
  wepRig.inner.add(carbine);

  carbine.updateMatrixWorld(true);
  const rightGripWorld = new THREE.Vector3(-0.068, -0.055, 0.016).applyMatrix4(carbine.matrix);
  const leftGripWorld = new THREE.Vector3(0.215, -0.022, 0.008).applyMatrix4(carbine.matrix);

  const buildRolledDressArm = (
    side: 'left' | 'right',
    shoulder: THREE.Vector3,
    elbow: THREE.Vector3,
    gripTarget: THREE.Vector3,
    wristOffset: THREE.Vector3,
    gloveRot: THREE.Euler
  ) => {
    const wrist = gripTarget.clone().add(wristOffset);
    const cuffPt = new THREE.Vector3().lerpVectors(elbow, wrist, 0.34);

    // Articulate left arm inside wepRig so Gold Mask can execute true 1-hand Speed Vault IK!
    let upperParent: THREE.Group = wepRig.inner;
    let lowerParent: THREE.Group = wepRig.inner;
    if (side === 'left') {
      const lSh = createPivotAt(shoulder, 'leftArmPivot');
      const lElb = createPivotAt(elbow, 'leftElbowPivot');
      lSh.pivot.userData.attachedToWeapon = true;
      lSh.pivot.userData.ikMeta = { shoulder: shoulder.clone(), elbow: elbow.clone(), wrist: wrist.clone() };
      lSh.inner.add(lElb.pivot);
      wepRig.inner.add(lSh.pivot);
      upperParent = lSh.inner;
      lowerParent = lElb.inner;
    }

    upperParent.add(createShoulderCap(shoulder, shirtMat, 0.067, 0.0044));
    upperParent.add(
      buildLimbBetween(shoulder, elbow, 0.068, 0.070, 0.066, 0.068, 0.064, 0.066, shirtMat, 10, {
        outline: 0.0046,
      })
    );
    lowerParent.add(createElbowCap(elbow, shirtMat, 0.064, 0.0042));
    lowerParent.add(
      buildLimbBetween(elbow, cuffPt, 0.064, 0.066, 0.064, 0.066, 0.060, 0.062, shirtMat, 10, {
        outline: 0.0046,
      })
    );

    const cuffDir = new THREE.Vector3().subVectors(wrist, elbow).normalize();
    const cuffRing = makeStylizedMesh(
      new THREE.CylinderGeometry(0.064, 0.067, 0.036, 10),
      shirtMat,
      { outline: 0.0038 }
    );
    cuffRing.position.copy(cuffPt);
    cuffRing.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), cuffDir);
    lowerParent.add(cuffRing);

    lowerParent.add(
      buildLimbBetween(cuffPt, wrist, 0.049, 0.051, 0.045, 0.047, 0.041, 0.043, skinMat, 10, {
        outline: 0.0042,
      })
    );

    const gloveCuff = makeStylizedMesh(
      new THREE.CylinderGeometry(0.045, 0.047, 0.032, 10),
      goldGloveMat,
      { outline: 0.0034 }
    );
    gloveCuff.position.copy(wrist);
    gloveCuff.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), cuffDir);
    lowerParent.add(gloveCuff);

    lowerParent.add(createWristCap(wrist, goldGloveMat, 0.039, 0.0030));
    const glove = createStylizedHand(goldGloveMat, side, 'grip', 0.0036);
    if (side === 'left') glove.userData.rigRole = 'leftHand';
    glove.position.copy(wrist);
    glove.rotation.order = 'YXZ';
    glove.rotation.copy(gloveRot);
    lowerParent.add(glove);
  };

  buildRolledDressArm(
    'right',
    new THREE.Vector3(-0.200, 1.425, 0.0),
    new THREE.Vector3(-0.296, 1.220, 0.092),
    rightGripWorld,
    new THREE.Vector3(-0.036, 0.026, -0.012),
    new THREE.Euler(-0.20, 1.12, -0.36, 'YXZ')
  );

  buildRolledDressArm(
    'left',
    new THREE.Vector3(0.200, 1.425, 0.0),
    new THREE.Vector3(0.305, 1.214, 0.086),
    leftGripWorld,
    new THREE.Vector3(0.034, 0.024, -0.012),
    new THREE.Euler(-0.80, -1.14, 0.40, 'YXZ')
  );

  return root;
}

// ============================================================================
// TORSO 04: RED-EYE TROOPER (Heavy 5-Pouch Hazard Chest Rig + H-Buckle Duty Belt)
// ============================================================================
export function buildTorsoReaper(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_RedEyeReaper';

  const uniformMat = createMat({ color: PALETTE.reaperUniform, roughness: 0.86 });
  const rigMat = createMat({ color: PALETTE.reaperRig, roughness: 0.76, metalness: 0.08 });
  const rigDarkMat = createMat({ color: 0x16181b, roughness: 0.86 });
  const buckleMat = createMat({ color: PALETTE.reaperBuckle, roughness: 0.42, metalness: 0.58 });

  // Athletic sloped stealth torso
  const torso = makeStylizedMesh(
    createTorsoGeometry({
      yStart: 0.99,
      height: 0.52,
      waistRx: 0.165,
      waistRz: 0.110,
      chestRx: 0.208,
      chestRz: 0.126,
      shoulderRx: 0.218,
    }),
    uniformMat,
    { outline: 0.0052 }
  );
  root.add(torso);

  // Heavy Duty Belt with Metallic Grey H-Buckle
  const belt = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 0.964, rx: 0.178, rz: 0.120 },
        { y: 1.028, rx: 0.178, rz: 0.120 },
      ],
      10
    ),
    rigDarkMat,
    { outline: 0.0042 }
  );
  root.add(belt);

  for (const bx of [-0.140, -0.092, 0.092, 0.140]) {
    const keeper = makeStylizedMesh(
      createBeveledBoxGeometry(0.034, 0.064, 0.024, 0.003),
      rigMat,
      { outline: 0.0026 }
    );
    const zCurve = 0.120 - Math.abs(bx) * 0.16;
    keeper.position.set(bx, 0.996, zCurve);
    keeper.rotation.y = bx * 1.4;
    root.add(keeper);
  }

  // Iconic Metallic Grey H-Shaped Quick-Release Buckle
  const buckleGroup = new THREE.Group();
  buckleGroup.position.set(0, 0.996, 0.126);
  buckleGroup.add(
    makeStylizedMesh(createBeveledBoxGeometry(0.052, 0.036, 0.020, 0.003), buckleMat, {
      outline: 0.0026,
    })
  );
  for (const s of [-1, 1]) {
    const prong = makeStylizedMesh(
      createBeveledBoxGeometry(0.020, 0.060, 0.022, 0.003),
      buckleMat,
      { outline: 0.0024 }
    );
    prong.position.set(s * 0.030, 0, 0);
    buckleGroup.add(prong);
  }
  root.add(buckleGroup);

  // Base Chest Rig Carrier Shell
  const vestShell = makeStylizedMesh(
    createBeveledBoxGeometry(0.308, 0.352, 0.252, 0.014),
    rigDarkMat,
    { outline: 0.0044 }
  );
  vestShell.position.set(0, 1.252, 0.006);
  root.add(vestShell);

  // Contoured curved rig shoulder straps
  for (const s of [-1, 1]) {
    const strap = createCurvedFlatStrap(
      [
        new THREE.Vector3(s * 0.105, 1.418, 0.118),
        new THREE.Vector3(s * 0.114, 1.495, 0.044),
        new THREE.Vector3(s * 0.116, 1.506, -0.014),
        new THREE.Vector3(s * 0.106, 1.445, -0.105),
      ],
      0.056,
      0.022,
      rigMat,
      0.0034
    );
    root.add(strap);
  }

  // UPPER ROW: 3 vertical tactical utility/mag pouches
  for (const px of [-0.098, 0.0, 0.098]) {
    const pouch = createTacticalPouch({
      width: 0.075,
      height: 0.142,
      depth: 0.052,
      pouchMat: rigMat,
      flap: true,
      flapMat: rigMat,
      outline: 0.0036,
    });
    pouch.position.set(px, 1.322, 0.148 - Math.abs(px) * 0.12);
    pouch.rotation.y = px * 0.7;
    root.add(pouch);
  }

  // LOWER ROW: 2 wide boxy belly pouches
  for (const px of [-0.084, 0.084]) {
    const lowerPouch = createTacticalPouch({
      width: 0.142,
      height: 0.108,
      depth: 0.052,
      pouchMat: rigMat,
      flap: true,
      flapMat: rigDarkMat,
      outline: 0.0036,
    });
    lowerPouch.position.set(px, 1.158, 0.144);
    lowerPouch.rotation.y = px * 0.65;
    root.add(lowerPouch);
  }

  // Back hazard pack + short radio antenna
  const backPack = makeStylizedMesh(
    createBeveledBoxGeometry(0.250, 0.330, 0.082, 0.012),
    rigMat,
    { outline: 0.0042 }
  );
  backPack.position.set(0, 1.278, -0.158);
  root.add(backPack);

  const radioAnt = makeStylizedMesh(
    new THREE.CylinderGeometry(0.0055, 0.0085, 0.22, 6),
    rigDarkMat,
    { outline: 0.002 }
  );
  radioAnt.position.set(-0.105, 1.52, -0.162);
  radioAnt.rotation.z = 0.08;
  root.add(radioAnt);

  // Calm imposing articulated tactical arms & bold black gloved hands
  for (const side of ['left', 'right'] as const) {
    const s = side === 'left' ? 1 : -1;
    const shoulder = new THREE.Vector3(s * 0.214, 1.422, 0.0);
    const elbow = new THREE.Vector3(s * 0.270, 1.186, -0.010);
    const wrist = new THREE.Vector3(s * 0.288, 0.942, 0.024);

    const sh = createPivotAt(shoulder, side === 'left' ? 'leftArmPivot' : 'rightArmPivot');
    const elb = createPivotAt(elbow, side === 'left' ? 'leftElbowPivot' : 'rightElbowPivot');
    sh.pivot.userData.ikMeta = { shoulder: shoulder.clone(), elbow: elbow.clone(), wrist: wrist.clone() };

    sh.inner.add(createShoulderCap(shoulder, uniformMat, 0.062, 0.0042));
    sh.inner.add(
      buildLimbBetween(shoulder, elbow, 0.068, 0.070, 0.062, 0.064, 0.056, 0.058, uniformMat, 10, {
        outline: 0.0046,
      })
    );
    elb.inner.add(createElbowCap(elbow, uniformMat, 0.055, 0.004));
    elb.inner.add(
      buildLimbBetween(elbow, wrist, 0.056, 0.058, 0.052, 0.054, 0.044, 0.046, uniformMat, 10, {
        outline: 0.0044,
      })
    );

    elb.inner.add(createWristCap(wrist, rigDarkMat, 0.039, 0.0032));
    const glove = createStylizedHand(rigDarkMat, side, 'relaxed', 0.0036);
    glove.userData.rigRole = side === 'left' ? 'leftHand' : 'rightHand';
    glove.position.copy(wrist);
    glove.rotation.order = 'YXZ';
    glove.rotation.y = s * -1.68;
    glove.rotation.z = s * 0.08;
    elb.inner.add(glove);

    sh.inner.add(elb.pivot);
    root.add(sh.pivot);
  }

  return root;
}

// ============================================================================
// TORSO 05: SWAT POLICE UNIT (Navy BDU + Black "POLICE" Kevlar Vest + Scoped DMR)
// ============================================================================
export function buildTorsoPolice(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_SWATPolice';

  const navyMat = createMat({ color: PALETTE.policeUniformNavy, roughness: 0.84 });
  const vestMat = createMat({ color: PALETTE.policeVestBlack, roughness: 0.78, metalness: 0.08 });
  const vestDarkMat = createMat({ color: 0x16181d, roughness: 0.86 });
  const patchMat = createMat({
    color: 0xffffff,
    map: getPolicePatchTexture(),
    roughness: 0.72,
  });

  // Navy tactical BDU torso
  root.add(
    makeStylizedMesh(
      createTorsoGeometry({
        yStart: 0.98,
        height: 0.53,
        waistRx: 0.164,
        waistRz: 0.110,
        chestRx: 0.208,
        chestRz: 0.126,
        shoulderRx: 0.218,
      }),
      navyMat,
      { outline: 0.0052 }
    )
  );

  // Heavy tactical SWAT duty belt
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.962, rx: 0.178, rz: 0.120 },
          { y: 1.026, rx: 0.178, rz: 0.120 },
        ],
        10
      ),
      vestDarkMat,
      { outline: 0.0042 }
    )
  );

  // Heavy SWAT Kevlar Plate Carrier Front & Back
  const plateShape = new THREE.Shape();
  plateShape.moveTo(-0.152, -0.172);
  plateShape.lineTo(0.152, -0.172);
  plateShape.lineTo(0.146, 0.056);
  plateShape.lineTo(0.104, 0.155);
  plateShape.lineTo(-0.104, 0.155);
  plateShape.lineTo(-0.146, 0.056);
  plateShape.closePath();

  const plateGeom = new THREE.ExtrudeGeometry(plateShape, {
    depth: 0.044,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.008,
    bevelSegments: 1,
  });
  plateGeom.center();

  const frontPlate = makeStylizedMesh(plateGeom, vestMat, { outline: 0.0046 });
  frontPlate.position.set(0, 1.292, 0.128);
  frontPlate.rotation.x = -0.05;
  root.add(frontPlate);

  const backPlate = makeStylizedMesh(plateGeom.clone(), vestMat, { outline: 0.0046 });
  backPlate.position.set(0, 1.292, -0.124);
  backPlate.rotation.x = 0.04;
  root.add(backPlate);

  // CRISP WHITE "POLICE" VELCRO PLACARD ON UPPER CHEST (cleanly proud of Kevlar plate!)
  const placard = new THREE.Mesh(new THREE.PlaneGeometry(0.188, 0.072), patchMat);
  placard.position.set(0, 1.358, 0.164);
  placard.rotation.x = -0.05;
  placard.renderOrder = 2;
  root.add(placard);

  // Back "POLICE" placard too for crisp 360° view!
  const backPlacard = new THREE.Mesh(new THREE.PlaneGeometry(0.195, 0.075), patchMat);
  backPlacard.position.set(0, 1.355, -0.160);
  backPlacard.rotation.y = Math.PI;
  backPlacard.rotation.x = 0.04;
  backPlacard.renderOrder = 2;
  root.add(backPlacard);

  // Lower belt/belly black SWAT tactical pouches
  for (let i = -1; i <= 1; i++) {
    const pouch = createTacticalPouch({
      width: 0.080,
      height: 0.108,
      depth: 0.048,
      pouchMat: vestMat,
      flap: true,
      flapMat: vestDarkMat,
      outline: 0.0034,
    });
    pouch.position.set(i * 0.088, 1.158, 0.156 - Math.abs(i) * 0.014);
    pouch.rotation.y = i * 0.16;
    root.add(pouch);
  }

  // Contoured black Kevlar shoulder straps & side cummerbund
  for (const s of [-1, 1]) {
    root.add(
      createCurvedFlatStrap(
        [
          new THREE.Vector3(s * 0.102, 1.425, 0.114),
          new THREE.Vector3(s * 0.116, 1.498, 0.042),
          new THREE.Vector3(s * 0.118, 1.506, -0.016),
          new THREE.Vector3(s * 0.108, 1.452, -0.102),
        ],
        0.058,
        0.022,
        vestMat,
        0.0034
      )
    );

    const cummer = makeStylizedMesh(
      createBeveledBoxGeometry(0.042, 0.145, 0.242, 0.005),
      vestDarkMat,
      { outline: 0.0036 }
    );
    cummer.position.set(s * 0.180, 1.185, 0.0);
    root.add(cummer);
  }

  // --- LONG SCOPED SWAT MARKSMAN DMR RIFLE & SHOULDER-ALIGNED SWAT WEAPON RIG ---
  const wepRig = createPivotAt(new THREE.Vector3(0, 1.418, 0.0), 'weaponRig');
  root.add(wepRig.pivot);

  const dmr = createSWATMarksmanRifle();
  dmr.position.set(-0.025, 1.200, 0.238);
  dmr.rotation.order = 'YXZ';
  dmr.rotation.y = -0.24;
  dmr.rotation.z = -0.94;
  dmr.rotation.x = 0.05;
  dmr.scale.setScalar(1.04);
  wepRig.inner.add(dmr);

  dmr.updateMatrixWorld(true);
  const rGripTarget = new THREE.Vector3(-0.072, -0.062, 0.014).applyMatrix4(dmr.matrix);
  const lGripTarget = new THREE.Vector3(0.248, -0.026, 0.010).applyMatrix4(dmr.matrix);

  // RIGHT ARM: Locked onto DMR pistol grip
  const rShoulder = new THREE.Vector3(-0.214, 1.422, 0.0);
  const rElbow = new THREE.Vector3(-0.342, 1.242, 0.092);
  const rWrist = rGripTarget.clone().add(new THREE.Vector3(-0.036, 0.032, -0.014));

  wepRig.inner.add(createShoulderCap(rShoulder, navyMat, 0.072, 0.0044));
  const sleevePatch = makeStylizedMesh(
    createBeveledBoxGeometry(0.016, 0.062, 0.050, 0.003),
    vestMat,
    { outline: 0.0022 }
  );
  sleevePatch.position.set(-0.296, 1.342, 0.038);
  sleevePatch.rotation.z = 0.26;
  wepRig.inner.add(sleevePatch);

  wepRig.inner.add(
    buildLimbBetween(rShoulder, rElbow, 0.070, 0.072, 0.064, 0.066, 0.058, 0.060, navyMat, 10, {
      outline: 0.0046,
    })
  );
  wepRig.inner.add(createElbowCap(rElbow, navyMat, 0.058, 0.004));
  wepRig.inner.add(
    buildLimbBetween(rElbow, rWrist, 0.058, 0.060, 0.054, 0.056, 0.045, 0.047, navyMat, 10, {
      outline: 0.0044,
    })
  );
  wepRig.inner.add(createWristCap(rWrist, vestDarkMat, 0.040, 0.0032));
  const rGlove = createStylizedHand(vestDarkMat, 'right', 'grip', 0.0036);
  rGlove.position.copy(rWrist);
  rGlove.rotation.order = 'YXZ';
  rGlove.rotation.set(-0.22, 1.12, -0.38);
  wepRig.inner.add(rGlove);

  // LEFT ARM: Locked onto DMR handguard during combat, articulated for 1-hand Speed Vault IK!
  const lShoulder = new THREE.Vector3(0.214, 1.422, 0.0);
  const lElbow = new THREE.Vector3(0.285, 1.182, 0.088);
  const lWrist = lGripTarget.clone().add(new THREE.Vector3(0.036, 0.032, -0.012));

  const lSh = createPivotAt(lShoulder, 'leftArmPivot');
  const lElb = createPivotAt(lElbow, 'leftElbowPivot');
  lSh.pivot.userData.attachedToWeapon = true;
  lSh.pivot.userData.ikMeta = { shoulder: lShoulder.clone(), elbow: lElbow.clone(), wrist: lWrist.clone() };

  lSh.inner.add(createShoulderCap(lShoulder, navyMat, 0.068, 0.0044));
  lSh.inner.add(
    buildLimbBetween(lShoulder, lElbow, 0.070, 0.072, 0.064, 0.066, 0.058, 0.060, navyMat, 10, {
      outline: 0.0046,
    })
  );
  lElb.inner.add(createElbowCap(lElbow, navyMat, 0.058, 0.004));
  lElb.inner.add(
    buildLimbBetween(lElbow, lWrist, 0.058, 0.060, 0.054, 0.056, 0.045, 0.047, navyMat, 10, {
      outline: 0.0044,
    })
  );
  lElb.inner.add(createWristCap(lWrist, vestDarkMat, 0.040, 0.0032));
  const lGlove = createStylizedHand(vestDarkMat, 'left', 'grip', 0.0036);
  lGlove.userData.rigRole = 'leftHand';
  lGlove.position.copy(lWrist);
  lGlove.rotation.order = 'YXZ';
  lGlove.rotation.set(-0.82, -1.12, 0.42);
  lElb.inner.add(lGlove);

  lSh.inner.add(lElb.pivot);
  wepRig.inner.add(lSh.pivot);

  return root;
}

// ============================================================================
// TORSO 06: HEAVY LMG GUNNER — FIXED RIGHT ARM + DETAILED SLEEVELESS MOLLE RIG
//           + SHOULDER-MOUNTED M249 SAW LMG + GRAPHIC ARM TATTOOS (IMAGE 1 EXACT!)
// ============================================================================
export function buildTorsoGunner(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_HeavyGunner';

  const skinMat = createMat({ color: PALETTE.skinTan, roughness: 0.74 });
  const tatUpperMat = createMat({
    color: 0xffffff,
    map: getGunnerTattooTexture('upper'),
    roughness: 0.74,
  });
  const tatWristMat = createMat({
    color: 0xffffff,
    map: getGunnerTattooTexture('wrist'),
    roughness: 0.74,
  });
  const tatRightWristMat = createMat({
    color: 0xffffff,
    map: getGunnerTattooTexture('rightWrist'),
    roughness: 0.74,
  });
  const tankMat = createMat({ color: PALETTE.gunnerTank, roughness: 0.86 });
  const rigMat = createMat({ color: PALETTE.gunnerRig, roughness: 0.80 });
  const rigDarkMat = createMat({ color: PALETTE.gunnerRigDark, roughness: 0.86 });
  const magMat = createMat({ color: 0x24272b, roughness: 0.58, metalness: 0.25 });
  const gloveMat = createMat({ color: PALETTE.gunnerGlove, roughness: 0.84 });

  // Broad muscular sleeveless olive tactical shirt torso (clearly visible V-chest above chest rig!)
  root.add(
    makeStylizedMesh(
      createTorsoGeometry({
        yStart: 0.97,
        height: 0.54,
        waistRx: 0.172,
        waistRz: 0.116,
        chestRx: 0.220,
        chestRz: 0.134,
        shoulderRx: 0.226,
      }),
      tankMat,
      { outline: 0.0052 }
    )
  );

  // Dark olive sleeveless armhole piping bands around left & right shoulders (exact Image 1 detail!)
  for (const s of [-1, 1]) {
    const trim = makeStylizedMesh(new THREE.TorusGeometry(0.080, 0.011, 6, 12), magMat, {
      outline: 0.0022,
    });
    trim.position.set(s * 0.214, 1.416, 0.002);
    trim.rotation.y = Math.PI / 2;
    trim.rotation.x = s * 0.18;
    root.add(trim);
  }

  // Subtle V-seam detail on olive sleeveless shirt chest (matching Image 1!)
  for (const s of [-1, 1]) {
    const vSeam = makeStylizedMesh(
      createBeveledBoxGeometry(0.014, 0.16, 0.010, 0.002),
      rigDarkMat,
      { outline: 0 }
    );
    vSeam.position.set(s * 0.036, 1.425, 0.114);
    vSeam.rotation.z = s * -0.34;
    root.add(vSeam);
  }

  // Olive waist belt + left hip utility satchel
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.962, rx: 0.184, rz: 0.124 },
          { y: 1.024, rx: 0.184, rz: 0.124 },
        ],
        10
      ),
      rigDarkMat,
      { outline: 0.0042 }
    )
  );
  const hipSatchel = createTacticalPouch({
    width: 0.102,
    height: 0.138,
    depth: 0.084,
    pouchMat: rigMat,
    flap: true,
    flapMat: rigDarkMat,
    outline: 0.0038,
  });
  hipSatchel.position.set(0.164, 0.965, 0.108);
  hipSatchel.rotation.y = 0.52;
  root.add(hipSatchel);

  // CONTOURED MULTI-LAYER OLIVE MOLLE CHEST RIG (NOT a flat boxy slab — wraps smoothly around mid-torso!)
  const rigBand = makeStylizedMesh(
    createLoftGeometry(
      [
        { y: 1.088, rx: 0.194, rz: 0.136 },
        { y: 1.220, rx: 0.214, rz: 0.146 },
        { y: 1.320, rx: 0.204, rz: 0.138 },
      ],
      10
    ),
    rigDarkMat,
    { outline: 0.0046 }
  );
  root.add(rigBand);

  // Contoured webbing shoulder straps with raised padded rib bars (exact Image 1!)
  for (const s of [-1, 1]) {
    root.add(
      createCurvedFlatStrap(
        [
          new THREE.Vector3(s * 0.114, 1.310, 0.126),
          new THREE.Vector3(s * 0.126, 1.478, 0.056),
          new THREE.Vector3(s * 0.128, 1.500, -0.016),
          new THREE.Vector3(s * 0.118, 1.430, -0.116),
          new THREE.Vector3(s * 0.112, 1.310, -0.126),
        ],
        0.062,
        0.020,
        rigMat,
        0.0034
      )
    );
    // Crisp dark shoulder strap clip buckle on upper chest
    const buckle = makeStylizedMesh(
      createBeveledBoxGeometry(0.054, 0.022, 0.016, 0.003),
      magMat,
      { outline: 0.002 }
    );
    buckle.position.set(s * 0.120, 1.372, 0.118);
    root.add(buckle);
  }

  // 4 Distinct Front Chest Rig Pouches matching Image 1 left-to-right!
  const rigSlots: { x: number; w: number; h: number; hasMag?: boolean }[] = [
    { x: -0.148, w: 0.078, h: 0.138 },
    { x: -0.062, w: 0.072, h: 0.134, hasMag: true },
    { x: 0.024, w: 0.072, h: 0.134, hasMag: true },
    { x: 0.128, w: 0.094, h: 0.140 },
  ];
  for (const sl of rigSlots) {
    const p = createTacticalPouch({
      width: sl.w,
      height: sl.h,
      depth: 0.058,
      pouchMat: rigMat,
      flap: !sl.hasMag,
      flapMat: rigDarkMat,
      magMat: sl.hasMag ? magMat : undefined,
      magHeight: 0.086,
      outline: 0.0036,
    });
    p.position.set(sl.x, 1.198, 0.168 - Math.abs(sl.x) * 0.22);
    p.rotation.y = sl.x * 1.15;
    root.add(p);
  }

  // Subtle MOLLE horizontal webbing strips on right outer olive pouch (exact Image 1!)
  for (let row = 0; row < 3; row++) {
    const web = makeStylizedMesh(
      createBeveledBoxGeometry(0.084, 0.012, 0.008, 0.001),
      rigDarkMat,
      { outline: 0 }
    );
    web.position.set(0.128, 1.158 + row * 0.030, 0.172);
    web.rotation.y = 0.15;
    root.add(web);
  }

  // --- MASSIVE M249 SAW LMG + LOCKED RIGHT SHOULDER ARM ASSEMBLY ---
  const rShoulder = new THREE.Vector3(-0.232, 1.418, 0.006);
  const rElbow = new THREE.Vector3(-0.368, 1.242, 0.034);
  const rWrist = new THREE.Vector3(-0.334, 1.466, 0.018);

  const lmgRig = createPivotAt(rShoulder, 'weaponRig');
  root.add(lmgRig.pivot);

  const lmg = createM249LMG();
  lmg.position.set(-0.105, 1.692, -0.078);
  lmg.rotation.order = 'YXZ';
  lmg.rotation.y = 0.34;
  lmg.rotation.z = 0.54;
  lmg.rotation.x = 0.04;
  lmg.scale.setScalar(1.06);
  lmgRig.inner.add(lmg);

  lmgRig.inner.add(createShoulderCap(rShoulder, skinMat, 0.080, 0.0046));
  lmgRig.inner.add(
    buildLimbBetween(rShoulder, rElbow, 0.076, 0.078, 0.072, 0.074, 0.062, 0.064, skinMat, 10, {
      outline: 0.0048,
    })
  );
  lmgRig.inner.add(createElbowCap(rElbow, skinMat, 0.060, 0.0042));
  lmgRig.inner.add(
    buildLimbBetween(
      rElbow,
      rWrist,
      0.060,
      0.062,
      0.056,
      0.058,
      0.046,
      0.048,
      tatRightWristMat,
      10,
      { outline: 0.0046 }
    )
  );
  lmgRig.inner.add(createWristCap(rWrist, gloveMat, 0.040, 0.0032));
  const rHand = createStylizedHand(gloveMat, 'right', 'grip', 0.0036, skinMat);
  rHand.position.copy(rWrist);
  rHand.rotation.order = 'YXZ';
  rHand.rotation.set(Math.PI - 0.14, 0.24, -0.10);
  lmgRig.inner.add(rHand);

  // LEFT ARM: Full shoulder + elbow articulation so his tattooed arm pumps vigorously during walk/chase!
  const lShoulder = new THREE.Vector3(0.232, 1.418, 0.006);
  const lElbow = new THREE.Vector3(0.324, 1.195, 0.006);
  const lWrist = new THREE.Vector3(0.308, 0.945, 0.036);

  const lSh = createPivotAt(lShoulder, 'leftArmPivot');
  const lElb = createPivotAt(lElbow, 'leftElbowPivot');
  lSh.pivot.userData.ikMeta = { shoulder: lShoulder.clone(), elbow: lElbow.clone(), wrist: lWrist.clone() };

  lSh.inner.add(createShoulderCap(lShoulder, skinMat, 0.070, 0.0044));
  lSh.inner.add(
    buildLimbBetween(lShoulder, lElbow, 0.078, 0.080, 0.074, 0.076, 0.064, 0.066, tatUpperMat, 10, {
      outline: 0.0048,
    })
  );
  lElb.inner.add(createElbowCap(lElbow, skinMat, 0.062, 0.0042));
  lElb.inner.add(
    buildLimbBetween(lElbow, lWrist, 0.062, 0.064, 0.058, 0.060, 0.048, 0.050, tatWristMat, 10, {
      outline: 0.0046,
    })
  );
  lElb.inner.add(createWristCap(lWrist, gloveMat, 0.040, 0.0032));
  const lHand = createStylizedHand(gloveMat, 'left', 'relaxed', 0.0036, skinMat);
  lHand.userData.rigRole = 'leftHand';
  lHand.position.copy(lWrist);
  lHand.rotation.order = 'YXZ';
  lHand.rotation.y = -1.68;
  lHand.rotation.z = 0.08;
  lElb.inner.add(lHand);

  lSh.inner.add(lElb.pivot);
  root.add(lSh.pivot);

  return root;
}

// ============================================================================
// TORSO 07: SKILL ISSUE AGENT — FIXED RIGHT ARM & PISTOL, SLEEK STREETWEAR PARKA
//           WITH FLUSH "SKILL ISSUE" SLEEVE PRINT & HAND ON HIP (IMAGE 1 EXACT!)
// ============================================================================
export function buildTorsoSkill(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_SkillIssue';

  const skinMat = createMat({ color: PALETTE.skinBase, roughness: 0.74 });
  const jacketWhite = createMat({ color: PALETTE.skillJacketWhite, roughness: 0.76 });
  const jacketShadow = createMat({ color: PALETTE.skillJacketShadow, roughness: 0.80 });
  const sleeveDark = createMat({ color: PALETTE.skillSleeveDark, roughness: 0.82 });
  const hemDark = createMat({ color: PALETTE.skillPantsBlack, roughness: 0.84 });
  const sleevePrintMat = createMat({
    color: 0xffffff,
    map: getSkillSleeveTexture(),
    roughness: 0.76,
  });

  // Tailored oversized streetwear techwear parka (subtle V-taper — NOT a stiff tin can!)
  const parkaShape = (angle: number) => {
    const front = Math.cos(angle);
    return { rzMul: Math.abs(front) > 0.65 ? 0.94 : 1.0 };
  };
  const parkaRings: LoftRing[] = [
    { y: 0.905, rx: 0.186, rz: 0.124, shape: parkaShape },
    { y: 0.960, rx: 0.194, rz: 0.128, shape: parkaShape },
    { y: 1.150, rx: 0.204, rz: 0.132, shape: parkaShape },
    { y: 1.350, rx: 0.216, rz: 0.136, shape: parkaShape },
    { y: 1.448, rx: 0.208, rz: 0.128, shape: parkaShape },
    { y: 1.498, rx: 0.142, rz: 0.112 },
  ];
  root.add(
    makeStylizedMesh(createLoftGeometry(parkaRings, 12), jacketWhite, { outline: 0.0052 })
  );

  // Dark streetwear lower hem trim
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.892, rx: 0.182, rz: 0.122 },
          { y: 0.922, rx: 0.188, rz: 0.125 },
        ],
        12
      ),
      hemDark,
      { outline: 0.0038 }
    )
  );

  // Sleek subtle front storm-flap zipper seam
  const stormFlap = makeStylizedMesh(
    createBeveledBoxGeometry(0.028, 0.56, 0.012, 0.003),
    jacketShadow,
    { outline: 0.002 }
  );
  stormFlap.position.set(-0.022, 1.212, 0.126);
  root.add(stormFlap);

  // Iconic High Asymmetric Streetwear Funnel Collar: tall dramatic sides/back with a clean
  // front dip right below the chin so his stylized smile/smirk & stubble shine clearly!
  const funnelShape = (angle: number) => {
    const front = Math.cos(angle);
    const leftSide = Math.sin(angle);
    const frontDip = front > 0.30 ? -0.042 * Math.pow((front - 0.30) / 0.70, 1.25) : 0;
    return {
      dzAdd: front > 0.30 ? 0.018 * ((front - 0.30) / 0.70) : 0,
      dyAdd: frontDip + leftSide * 0.010,
    };
  };
  const funnelRings: LoftRing[] = [
    { y: 1.480, rx: 0.122, rz: 0.118, oz: 0.008 },
    { y: 1.542, rx: 0.130, rz: 0.128, oz: 0.011, shape: funnelShape },
    { y: 1.598, rx: 0.138, rz: 0.136, oz: 0.014, shape: funnelShape },
  ];
  root.add(
    makeStylizedMesh(createLoftGeometry(funnelRings, 14, false, false), jacketWhite, {
      outline: 0.0044,
    })
  );
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 1.484, rx: 0.110, rz: 0.106, oz: 0.008 },
          { y: 1.588, rx: 0.124, rz: 0.122, oz: 0.011, shape: funnelShape },
        ],
        14,
        true,
        false
      ),
      sleeveDark,
      { outline: 0.002 }
    )
  );
  // Crisp dark angled zipper line on left side of high white collar
  const collarZip = makeStylizedMesh(
    createBeveledBoxGeometry(0.010, 0.110, 0.010, 0.002),
    hemDark,
    { outline: 0 }
  );
  collarZip.position.set(-0.058, 1.534, 0.144);
  collarZip.rotation.z = 0.20;
  collarZip.rotation.y = -0.35;
  root.add(collarZip);

  // 4 Crisp White Front Cargo Flap Pockets with sleek black snap tabs (exact Image 1!)
  const makeTechPocket = (w: number, h: number, d: number) => {
    const p = createTacticalPouch({
      width: w,
      height: h,
      depth: d,
      pouchMat: jacketWhite,
      flap: true,
      flapMat: jacketShadow,
      outline: 0.0028,
    });
    const tab = makeStylizedMesh(
      createBeveledBoxGeometry(0.018, 0.010, 0.008, 0.001),
      hemDark,
      { outline: 0 }
    );
    tab.position.set(0, h * 0.10, d * 0.56);
    p.add(tab);
    return p;
  };

  for (const px of [-0.072, 0.028]) {
    const p = makeTechPocket(0.082, 0.132, 0.024);
    p.position.set(px, 1.335, 0.134 - Math.abs(px) * 0.12);
    p.rotation.y = px * 0.7;
    root.add(p);
  }
  const lowerCargo = makeTechPocket(0.138, 0.144, 0.026);
  lowerCargo.position.set(0.014, 1.115, 0.134);
  root.add(lowerCargo);

  const sideCargo = makeTechPocket(0.076, 0.122, 0.024);
  sideCargo.position.set(-0.124, 1.120, 0.112);
  sideCargo.rotation.y = -0.46;
  root.add(sideCargo);

  // --- ARTICULATED STREETWEAR ARMS: Iconic Image-1 Pose in Idle, SWAT Pistol Ready in Walk/Chase/Crouch! ---
  // LEFT ARM: "SKILL ISSUE" upper sleeve + flat hand on hip (articulated shoulder + elbow!)
  const lShoulder = new THREE.Vector3(0.208, 1.418, 0.0);
  const lElbow = new THREE.Vector3(0.362, 1.236, 0.026);
  const lWrist = new THREE.Vector3(0.228, 1.072, 0.156);

  const lSh = createPivotAt(lShoulder, 'leftArmPivot');
  const lElb = createPivotAt(lElbow, 'leftElbowPivot');
  lSh.pivot.userData.ikMeta = { shoulder: lShoulder.clone(), elbow: lElbow.clone(), wrist: lWrist.clone() };

  lSh.inner.add(createShoulderCap(lShoulder, jacketWhite, 0.066, 0.0044));

  const lUpperLimb = buildLimbBetween(
    lShoulder,
    lElbow,
    0.078,
    0.078,
    0.075,
    0.075,
    0.068,
    0.068,
    jacketWhite,
    12,
    { outline: 0.0048 }
  );
  const uLen = lShoulder.distanceTo(lElbow);
  const sleeveArcGeom = new THREE.CylinderGeometry(
    0.073,
    0.079,
    uLen * 0.72,
    14,
    1,
    true,
    -1.45,
    1.65
  );
  const sUv = sleeveArcGeom.getAttribute('uv');
  for (let i = 0; i < sUv.count; i++) {
    sUv.setXY(i, 1 - sUv.getX(i), 1 - sUv.getY(i));
  }
  const sleeveArc = new THREE.Mesh(sleeveArcGeom, sleevePrintMat);
  sleeveArc.position.y = uLen * 0.50;
  sleeveArc.renderOrder = 2;
  lUpperLimb.add(sleeveArc);
  lSh.inner.add(lUpperLimb);

  lElb.inner.add(createElbowCap(lElbow, sleeveDark, 0.064, 0.0042));
  lElb.inner.add(
    buildLimbBetween(lElbow, lWrist, 0.066, 0.066, 0.059, 0.059, 0.048, 0.048, sleeveDark, 10, {
      outline: 0.0046,
    })
  );

  const lCuffDir = new THREE.Vector3().subVectors(lWrist, lElbow).normalize();
  const lCuff = makeStylizedMesh(
    new THREE.CylinderGeometry(0.053, 0.055, 0.044, 10),
    jacketWhite,
    { outline: 0.0034 }
  );
  lCuff.position.copy(lWrist).addScaledVector(lCuffDir, -0.024);
  lCuff.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), lCuffDir);
  lElb.inner.add(lCuff);

  lElb.inner.add(createWristCap(lWrist, skinMat, 0.039, 0.0030));
  const lHand = createStylizedHand(skinMat, 'left', 'hip', 0.0034);
  lHand.userData.rigRole = 'leftHand';
  lHand.position.copy(lWrist);
  lHand.rotation.order = 'YXZ';
  lHand.rotation.y = Math.PI + 0.18;
  lHand.rotation.z = 0.72;
  lHand.rotation.x = 0.06;
  lElb.inner.add(lHand);

  lSh.inner.add(lElb.pivot);
  root.add(lSh.pivot);

  // RIGHT ARM: Black & Gold Tactical Handgun (transitions cleanly forward to SWAT ready in Walk/Chase/Crouch!)
  const rShoulder = new THREE.Vector3(-0.208, 1.418, -0.006);
  const rElbow = new THREE.Vector3(-0.284, 1.248, -0.016);
  const rWrist = new THREE.Vector3(-0.264, 1.484, 0.028);

  const rSh = createPivotAt(rShoulder, 'rightArmPivot');
  rSh.inner.add(createShoulderCap(rShoulder, jacketWhite, 0.066, 0.0044));
  rSh.inner.add(
    buildLimbBetween(rShoulder, rElbow, 0.072, 0.072, 0.068, 0.068, 0.062, 0.062, jacketWhite, 10, {
      outline: 0.0046,
    })
  );
  rSh.inner.add(createElbowCap(rElbow, sleeveDark, 0.060, 0.004));
  rSh.inner.add(
    buildLimbBetween(rElbow, rWrist, 0.060, 0.060, 0.054, 0.054, 0.045, 0.045, sleeveDark, 10, {
      outline: 0.0044,
    })
  );

  const rCuffDir = new THREE.Vector3().subVectors(rWrist, rElbow).normalize();
  const rCuff = makeStylizedMesh(
    new THREE.CylinderGeometry(0.050, 0.052, 0.036, 10),
    jacketWhite,
    { outline: 0.0032 }
  );
  rCuff.position.copy(rWrist).addScaledVector(rCuffDir, -0.026);
  rCuff.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), rCuffDir);
  rSh.inner.add(rCuff);

  rSh.inner.add(createWristCap(rWrist, skinMat, 0.039, 0.0030));
  const rHand = createStylizedHand(skinMat, 'right', 'grip', 0.0034);
  rHand.position.copy(rWrist);
  rHand.rotation.order = 'YXZ';
  rHand.rotation.y = -0.18;
  rHand.rotation.z = Math.PI - 0.10;
  rHand.rotation.x = 0.06;
  rSh.inner.add(rHand);

  const pistol = createSkillPistol();
  pistol.position.set(0.008, -0.082, 0.038);
  pistol.rotation.set(0.0, 0.0, Math.PI + 0.06);
  pistol.scale.setScalar(1.12);
  rHand.add(pistol);
  root.add(rSh.pivot);

  return root;
}

// ============================================================================
// TORSO 08: LEVEL-3 SPETSNAZ SURVIVOR — MASTER OVERHAUL OF IMAGE 3!
//           Contoured Open Curved Charcoal Jacket, Non-Clipping Backpack Straps,
//           3/4 Rolled Sleeves & Clean Integrated Fingerless Gloves!
// ============================================================================
export function buildTorsoSpetsnaz(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_Level3Spetsnaz';

  const skinMat = createMat({ color: PALETTE.skinTan, roughness: 0.74 });
  const teeMat = createMat({ color: PALETTE.spetsTeeWhite, roughness: 0.84 });
  const jacketMat = createMat({ color: PALETTE.spetsJacket, roughness: 0.82 });
  const leatherMat = createMat({ color: PALETTE.spetsLeather, roughness: 0.72 });
  const packMat = createMat({ color: 0x4f3724, roughness: 0.84 });
  const gloveMat = createMat({ color: 0x222428, roughness: 0.84 });

  // Clean athletic off-white t-shirt torso base
  root.add(
    makeStylizedMesh(
      createTorsoGeometry({
        yStart: 0.96,
        height: 0.54,
        waistRx: 0.154,
        waistRz: 0.100,
        chestRx: 0.194,
        chestRz: 0.114,
        shoulderRx: 0.204,
      }),
      teeMat,
      { outline: 0.0046 }
    )
  );

  // SLEEK CURVED OPEN-FRONT CHARCOAL FIELD JACKET SHELL (Replaces ugly boxy flat doors!)
  // Wraps smoothly around back, ribs, and tapered front lapels revealing his tucked white tee!
  const openJacketGeom = createOpenJacketShellGeometry({
    thickness: 0.016,
    segs: 16,
    rings: [
      { y: 0.965, rx: 0.172, rz: 0.116, openHalfAngle: 0.52 }, // Lower hem neatly framing belt
      { y: 1.120, rx: 0.184, rz: 0.124, openHalfAngle: 0.50 }, // Mid waist taper
      { y: 1.295, rx: 0.208, rz: 0.134, openHalfAngle: 0.48 }, // Fitted athletic chest
      { y: 1.425, rx: 0.214, rz: 0.130, openHalfAngle: 0.50 }, // Shoulder sweep
      { y: 1.488, rx: 0.158, rz: 0.112, openHalfAngle: 0.54 }, // Collar shoulder join
    ],
  });
  root.add(makeStylizedMesh(openJacketGeom, jacketMat, { outline: 0.0046 }));

  // Slim Contoured Military Survival Rucksack sitting snugly flat on his back!
  const pack = makeStylizedMesh(
    createBeveledBoxGeometry(0.285, 0.375, 0.112, 0.022),
    packMat,
    { outline: 0.0046 }
  );
  pack.position.set(0, 1.275, -0.184);
  root.add(pack);

  const packTop = makeStylizedMesh(
    createBeveledBoxGeometry(0.265, 0.115, 0.122, 0.018),
    leatherMat,
    { outline: 0.004 }
  );
  packTop.position.set(0, 1.415, -0.180);
  root.add(packTop);

  // Contoured Brown Leather Backpack Straps routed 100% OUTSIDE jacket shell (ZERO clipping!)
  for (const s of [-1, 1]) {
    root.add(
      createCurvedFlatStrap(
        [
          new THREE.Vector3(s * 0.194, 1.185, 0.045),
          new THREE.Vector3(s * 0.168, 1.335, 0.110),
          new THREE.Vector3(s * 0.146, 1.456, 0.088),
          new THREE.Vector3(s * 0.136, 1.498, 0.002),
          new THREE.Vector3(s * 0.128, 1.442, -0.118),
          new THREE.Vector3(s * 0.122, 1.310, -0.156),
        ],
        0.036,
        0.012,
        leatherMat,
        0.0028
      )
    );
  }

  // --- ROLLED 3/4 CHARCOAL SLEEVES (ARTICULATED SHOULDER + ELBOW PIVOTS) + FINGERLESS GLOVES! ---
  for (const side of ['left', 'right'] as const) {
    const s = side === 'left' ? 1 : -1;
    const shoulder = new THREE.Vector3(s * 0.214, 1.420, 0.0);
    const elbow = new THREE.Vector3(s * 0.278, 1.196, -0.008);
    const wrist = new THREE.Vector3(s * 0.312, 0.942, 0.022);
    const cuffPt = new THREE.Vector3().lerpVectors(elbow, wrist, 0.26);

    const sh = createPivotAt(shoulder, side === 'left' ? 'leftArmPivot' : 'rightArmPivot');
    const elb = createPivotAt(elbow, side === 'left' ? 'leftElbowPivot' : 'rightElbowPivot');
    sh.pivot.userData.ikMeta = { shoulder: shoulder.clone(), elbow: elbow.clone(), wrist: wrist.clone() };

    sh.inner.add(createShoulderCap(shoulder, jacketMat, 0.062, 0.0042));
    sh.inner.add(
      buildLimbBetween(shoulder, elbow, 0.068, 0.070, 0.064, 0.066, 0.062, 0.064, jacketMat, 10, {
        outline: 0.0046,
      })
    );
    elb.inner.add(createElbowCap(elbow, jacketMat, 0.062, 0.004));
    elb.inner.add(
      buildLimbBetween(elbow, cuffPt, 0.062, 0.064, 0.061, 0.063, 0.058, 0.060, jacketMat, 10, {
        outline: 0.0044,
      })
    );

    const forearmDir = new THREE.Vector3().subVectors(wrist, elbow).normalize();
    const whiteCuff = makeStylizedMesh(
      new THREE.CylinderGeometry(0.060, 0.062, 0.036, 10),
      teeMat,
      { outline: 0.0034 }
    );
    whiteCuff.position.copy(cuffPt);
    whiteCuff.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), forearmDir);
    elb.inner.add(whiteCuff);

    elb.inner.add(
      buildLimbBetween(cuffPt, wrist, 0.048, 0.050, 0.045, 0.047, 0.040, 0.042, skinMat, 10, {
        outline: 0.0042,
      })
    );

    elb.inner.add(createWristCap(wrist, gloveMat, 0.039, 0.0030));
    const hand = createStylizedHand(gloveMat, side, 'relaxed', 0.0034, skinMat);
    hand.userData.rigRole = side === 'left' ? 'leftHand' : 'rightHand';
    hand.position.copy(wrist);
    hand.rotation.order = 'YXZ';
    hand.rotation.y = s * -1.68;
    hand.rotation.z = s * 0.08;
    elb.inner.add(hand);

    sh.inner.add(elb.pivot);
    root.add(sh.pivot);
  }

  return root;
}

// ============================================================================
// TORSO 09: SILAT STRIKER (Southeast Asian Martial Artist — Reference Image 1!)
//           Matte-Black Zip-Up Stand-Collar Track/Windbreaker Jacket, Diagonal
//           Side Zip Pockets, Heather-Grey Undershirt Hem, Black Sport Watch &
//           Bare-Hand Pencak Silat Martial-Arts Guard Stance!
// ============================================================================
export function buildTorsoSilat(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'Torso_SilatStriker';

  const skinMat = createMat({ color: PALETTE.skinSEA, roughness: 0.74 });
  const jacketMat = createMat({ color: PALETTE.silatJacketBlack, roughness: 0.80 });
  const trimMat = createMat({ color: PALETTE.silatJacketTrim, roughness: 0.84 });
  const zipMat = createMat({ color: PALETTE.silatZipSilver, roughness: 0.36, metalness: 0.62 });
  const greyHemMat = createMat({ color: PALETTE.silatGreyHem, roughness: 0.86 });
  const watchMat = createMat({ color: PALETTE.silatWatch, roughness: 0.44, metalness: 0.32 });

  // 1. Sleek Athletic Zip-Up Matte-Black Windbreaker/Track Jacket Torso (exact Image 1!)
  root.add(
    makeStylizedMesh(
      createTorsoGeometry({
        yStart: 0.995,
        height: 0.52,
        waistRx: 0.168,
        waistRz: 0.112,
        chestRx: 0.212,
        chestRz: 0.128,
        shoulderRx: 0.220,
      }),
      jacketMat,
      { outline: 0.0052 }
    )
  );

  // Subtle ribbed athletic waist hem band on black jacket
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.978, rx: 0.172, rz: 0.116 },
          { y: 1.018, rx: 0.175, rz: 0.118 },
        ],
        10
      ),
      trimMat,
      { outline: 0.004 }
    )
  );

  // ICONIC HEATHER-GREY UNDERSHIRT HEM PEEKING CLEANLY OUT BELOW BLACK JACKET (exact Image 1!)
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.938, rx: 0.166, rz: 0.110 },
          { y: 0.985, rx: 0.168, rz: 0.112 },
        ],
        10
      ),
      greyHemMat,
      { outline: 0.0038 }
    )
  );

  // Signature Short Snug Stand-Up Mandarin Collar (exact Image 1!)
  root.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 1.482, rx: 0.100, rz: 0.096 },
          { y: 1.538, rx: 0.088, rz: 0.086 },
        ],
        12
      ),
      jacketMat,
      { outline: 0.0042 }
    )
  );

  // Front center hidden-seam zipper track + metallic zip pull near collar
  const centerZip = makeStylizedMesh(
    createBeveledBoxGeometry(0.011, 0.495, 0.008, 0.002),
    trimMat,
    { outline: 0 }
  );
  centerZip.position.set(0, 1.258, 0.122);
  root.add(centerZip);

  const topZipPull = makeStylizedMesh(
    createBeveledBoxGeometry(0.012, 0.024, 0.010, 0.002),
    zipMat,
    { outline: 0.0014 }
  );
  topZipPull.position.set(0, 1.486, 0.098);
  root.add(topZipPull);

  // SIGNATURE DIAGONAL SIDE-ZIPPER JACKET POCKETS (exact Image 1 detail!)
  for (const s of [-1, 1]) {
    const pocketWelt = makeStylizedMesh(
      createBeveledBoxGeometry(0.016, 0.145, 0.012, 0.003),
      trimMat,
      { outline: 0.002 }
    );
    pocketWelt.position.set(s * 0.118, 1.138, 0.098);
    pocketWelt.rotation.order = 'YXZ';
    pocketWelt.rotation.y = s * 0.56;
    pocketWelt.rotation.z = s * -0.24;
    root.add(pocketWelt);

    // Metallic silver zipper pull tab glinting cleanly on side pocket!
    const pull = makeStylizedMesh(
      createBeveledBoxGeometry(0.008, 0.024, 0.012, 0.001),
      zipMat,
      { outline: 0 }
    );
    pull.position.set(s * 0.108, 1.192, 0.106);
    pull.rotation.y = s * 0.56;
    root.add(pull);
  }

  // Subtle folded athletic back seam & chest seam panel for crisp 360° jacket tailoring
  const chestSeam = makeStylizedMesh(
    createBeveledBoxGeometry(0.32, 0.012, 0.010, 0.002),
    trimMat,
    { outline: 0 }
  );
  chestSeam.position.set(0, 1.375, 0.122);
  root.add(chestSeam);

  // --- SLEEK ATHLETIC ARMS (TUCKED NATURAL SHOULDERS, SPORT WATCH & BOLD FISTS!) ---
  for (const side of ['left', 'right'] as const) {
    const s = side === 'left' ? 1 : -1;
    const shoulder = new THREE.Vector3(s * 0.198, 1.398, 0.0);
    const elbow = new THREE.Vector3(s * 0.268, 1.178, -0.012);
    const wrist = new THREE.Vector3(s * 0.284, 0.944, 0.028);
    const sleeveEnd = new THREE.Vector3().lerpVectors(elbow, wrist, side === 'right' ? 0.80 : 0.86);

    const sh = createPivotAt(shoulder, side === 'left' ? 'leftArmPivot' : 'rightArmPivot');
    const elb = createPivotAt(elbow, side === 'left' ? 'leftElbowPivot' : 'rightElbowPivot');
    sh.pivot.userData.ikMeta = { shoulder: shoulder.clone(), elbow: elbow.clone(), wrist: wrist.clone() };

    // Sleek flush deltoid cap tucked inside torso shoulder line (ZERO puffy balls during sprint!)
    sh.inner.add(createShoulderCap(shoulder, jacketMat, 0.056, 0.0036));
    sh.inner.add(
      buildLimbBetween(shoulder, elbow, 0.061, 0.063, 0.058, 0.060, 0.054, 0.056, jacketMat, 10, {
        outline: 0.0042,
      })
    );

    elb.inner.add(createElbowCap(elbow, jacketMat, 0.054, 0.0038));
    elb.inner.add(
      buildLimbBetween(elbow, sleeveEnd, 0.055, 0.057, 0.051, 0.053, 0.046, 0.048, jacketMat, 10, {
        outline: 0.0042,
      })
    );

    const foreDir = new THREE.Vector3().subVectors(wrist, elbow).normalize();
    const cuff = makeStylizedMesh(
      new THREE.CylinderGeometry(0.048, 0.050, 0.026, 10),
      trimMat,
      { outline: 0.0028 }
    );
    cuff.position.copy(sleeveEnd);
    cuff.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), foreDir);
    elb.inner.add(cuff);

    // Exposed tanned wrist
    elb.inner.add(
      buildLimbBetween(sleeveEnd, wrist, 0.042, 0.043, 0.040, 0.041, 0.039, 0.040, skinMat, 10, {
        outline: 0.0036,
      })
    );

    // Black tactical sport wristwatch on right wrist (exact Image 1!)
    if (side === 'right') {
      const watchPos = new THREE.Vector3().lerpVectors(sleeveEnd, wrist, 0.56);
      const watchBand = makeStylizedMesh(
        new THREE.CylinderGeometry(0.044, 0.044, 0.020, 10),
        watchMat,
        { outline: 0.0024 }
      );
      watchBand.position.copy(watchPos);
      watchBand.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), foreDir);
      elb.inner.add(watchBand);

      const watchDial = makeStylizedMesh(
        createBeveledBoxGeometry(0.014, 0.028, 0.028, 0.004),
        watchMat,
        { outline: 0.002 }
      );
      watchDial.position.copy(watchPos).add(new THREE.Vector3(-0.038, 0, 0.006));
      elb.inner.add(watchDial);
    }

    elb.inner.add(createWristCap(wrist, skinMat, 0.039, 0.0032));
    const hand = createStylizedHand(skinMat, side, 'fist', 0.0038);
    hand.userData.rigRole = side === 'left' ? 'leftHand' : 'rightHand';
    hand.position.copy(wrist);
    hand.rotation.order = 'YXZ';
    hand.rotation.y = s * -1.72;
    hand.rotation.z = s * 0.08;
    hand.rotation.x = -0.06;
    elb.inner.add(hand);

    sh.inner.add(elb.pivot);
    root.add(sh.pivot);
  }

  return root;
}

export function buildTorsoById(id: SkinId): THREE.Group {
  switch (id) {
    case 'boonie':
      return buildTorsoBoonie();
    case 'venom':
      return buildTorsoVenom();
    case 'gold':
      return buildTorsoGold();
    case 'reaper':
      return buildTorsoReaper();
    case 'police':
      return buildTorsoPolice();
    case 'gunner':
      return buildTorsoGunner();
    case 'skill':
      return buildTorsoSkill();
    case 'spetsnaz':
      return buildTorsoSpetsnaz();
    case 'silat':
      return buildTorsoSilat();
  }
}
