import * as THREE from 'three';
import { createMat, makeStylizedMesh } from '../materials';
import { createBeveledBoxGeometry } from '../common';
import { FaceId } from '../types';

export interface StylizedFaceOptions {
  /** Which parts of the face are exposed by this headgear */
  mode?: 'full' | 'eyesOnly' | 'mouthOnly';
  /** Skip the taupe 5-o'clock stubble overlay when character wears a full 3D beard/mustache */
  hasBeard?: boolean;
  /** Head scale & slimX matching the parent createStylizedHeadGeometry */
  scale?: number;
  slimX?: number;
  noseRidge?: number;
  /** Mouth scale multiplier: 1.0 = bold 2x hero mouth, ~0.52 = compact (Heavy Gunner) */
  mouthScale?: number;
  /** Vertical nudge for mouth */
  mouthYOffset?: number;
  /** Vertical nudge for eyes/brows */
  eyeYOffset?: number;
  /** Extra outward Z lift (e.g. over Police's balaclava slit or Gunner's beard) */
  extraOffset?: number;
  /** Eyebrow hair color */
  browColor?: number;
}

const faceTextureCache = new Map<string, THREE.CanvasTexture>();

/**
 * Evaluates the exact (x, z) surface point of `createStylizedHeadGeometry` at any (y, angle),
 * plus an outward offset `pad` so curved face overlays hug the faceted head seamlessly.
 */
function sampleHeadSurface(
  y: number,
  angle: number,
  s: number,
  sx: number,
  ridge: number,
  pad: number
): [number, number] {
  const rings = [
    { y: -0.128 * s, rx: 0.030 * s * sx, rz: 0.036 * s, oz: 0.024 * s, rm: 0.65, cf: 1.0 },
    { y: -0.100 * s, rx: 0.058 * s * sx, rz: 0.072 * s, oz: 0.018 * s, rm: 0.85, cf: 0.9 },
    { y: -0.052 * s, rx: 0.082 * s * sx, rz: 0.098 * s, oz: 0.010 * s, rm: 1.05, cf: 0.7 },
    { y: 0.005 * s, rx: 0.090 * s * sx, rz: 0.106 * s, oz: 0.006 * s, rm: 1.20, cf: 0.4 },
    { y: 0.062 * s, rx: 0.091 * s * sx, rz: 0.110 * s, oz: 0.000 * s, rm: 0.75, cf: 0.15 },
    { y: 0.110 * s, rx: 0.082 * s * sx, rz: 0.102 * s, oz: -0.006 * s, rm: 0.35, cf: 0.0 },
  ];

  let i0 = 0;
  for (let i = 0; i < rings.length - 1; i++) {
    if (y >= rings[i].y) i0 = i;
  }
  const rA = rings[i0];
  const rB = rings[Math.min(rings.length - 1, i0 + 1)];
  const t = rB.y === rA.y ? 0 : THREE.MathUtils.clamp((y - rA.y) / (rB.y - rA.y), 0, 1);

  const rx0 = THREE.MathUtils.lerp(rA.rx, rB.rx, t);
  const rz0 = THREE.MathUtils.lerp(rA.rz, rB.rz, t);
  const oz = THREE.MathUtils.lerp(rA.oz, rB.oz, t);
  const rm = THREE.MathUtils.lerp(rA.rm, rB.rm, t);
  const cf = THREE.MathUtils.lerp(rA.cf, rB.cf, t);

  const front = Math.cos(angle);
  const side = Math.abs(Math.sin(angle));

  let rx = rx0;
  let dzAdd = 0;
  if (front > 0.62) {
    dzAdd += ridge * rm * Math.pow((front - 0.62) / 0.38, 1.35);
  }
  if (front > 0.1 && side > 0.5) {
    rx *= 1 - cf * 0.055;
  }

  const x = Math.sin(angle) * (rx + pad);
  const z = oz + Math.cos(angle) * (rz0 + pad) + dzAdd;
  return [x, z];
}

export function buildFaceConformingPatch(opts: {
  yMin: number;
  yMax: number;
  maxAngle: number;
  uSegs: number;
  vSegs: number;
  s: number;
  sx: number;
  ridge: number;
  pad: number;
}): THREE.BufferGeometry {
  const { yMin, yMax, maxAngle, uSegs, vSegs, s, sx, ridge, pad } = opts;
  const cols = uSegs + 1;
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let r = 0; r <= vSegs; r++) {
    const v = r / vSegs;
    const y = THREE.MathUtils.lerp(yMin, yMax, v);
    for (let c = 0; c <= uSegs; c++) {
      const u = c / uSegs;
      const ang = THREE.MathUtils.lerp(-maxAngle, maxAngle, u);
      const [x, z] = sampleHeadSurface(y, ang, s, sx, ridge, pad);
      positions.push(x, y, z);
      uvs.push(u, v);
    }
  }

  for (let r = 0; r < vSegs; r++) {
    for (let c = 0; c < uSegs; c++) {
      const a = r * cols + c;
      const b = a + 1;
      const cIdx = (r + 1) * cols + c;
      const d = cIdx + 1;
      indices.push(a, b, d, a, d, cIdx);
    }
  }

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geom.setIndex(indices);
  geom.computeVertexNormals();
  return geom;
}

/**
 * Builds the exact sleek sculpted arched 3D low-poly eyebrow blade from Reference Image 2:
 * crisp tapered inner bridge corner, gentle clean outer arch, slim refined silhouette (NOT fat sausages!).
 */
function createSleekArchedBrowGeometry(
  side: -1 | 1,
  s: number,
  style: Exclude<FaceId, 'faceless'>
): THREE.BufferGeometry {
  // Local coordinates: inner edge near x = 0, extending outward in direction `side`!
  const shape = new THREE.Shape();

  if (style === 'grin') {
    // Sleek heavier connected veteran brow dipping firmly at inner bridge
    const w = 0.064 * s;
    const pts: [number, number][] = [
      [0.0, -0.005 * s],
      [side * w * 0.55, -0.002 * s],
      [side * w, -0.004 * s],
      [side * w * 0.96, 0.009 * s],
      [side * w * 0.50, 0.011 * s],
      [0.0, 0.008 * s],
    ];
    if (side < 0) pts.reverse();
    shape.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i][0], pts[i][1]);
    shape.closePath();
  } else if (style === 'fierce') {
    // Sharp angled V-warlord brow (sleek, clean, aggressive)
    const w = 0.056 * s;
    const pts: [number, number][] = [
      [side * 0.005 * s, -0.007 * s],
      [side * w * 0.58, 0.001 * s],
      [side * w, 0.006 * s],
      [side * w * 0.95, 0.016 * s],
      [side * w * 0.48, 0.011 * s],
      [side * 0.005 * s, 0.004 * s],
    ];
    if (side < 0) pts.reverse();
    shape.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i][0], pts[i][1]);
    shape.closePath();
  } else if (style === 'cool') {
    const w = 0.055 * s;
    const lift = side > 0 ? 0.003 * s : 0;
    const pts: [number, number][] = [
      [side * 0.008 * s, -0.004 * s],
      [side * w * 0.55, 0.000 * s + lift],
      [side * w, -0.001 * s + lift],
      [side * w * 0.94, 0.009 * s + lift],
      [side * w * 0.48, 0.010 * s + lift],
      [side * 0.008 * s, 0.005 * s],
    ];
    if (side < 0) pts.reverse();
    shape.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i][0], pts[i][1]);
    shape.closePath();
  } else if (style === 'neutral') {
    // Focused stoic straight martial-artist brows (clean, determined, level with slight inner dip)
    const w = 0.056 * s;
    const pts: [number, number][] = [
      [side * 0.007 * s, -0.005 * s],
      [side * w * 0.55, -0.001 * s],
      [side * w, 0.000 * s],
      [side * w * 0.96, 0.010 * s],
      [side * w * 0.50, 0.010 * s],
      [side * 0.007 * s, 0.005 * s],
    ];
    if (side < 0) pts.reverse();
    shape.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i][0], pts[i][1]);
    shape.closePath();
  } else {
    // EXACT IMAGE 2 ARCHED EYEBROW BLADE ('smirk'):
    // Tapered inner corner dipping gently toward nose, clean sculpted peak over outer eye, sleek outer drop!
    const w = 0.058 * s;
    const pts: [number, number][] = [
      [side * 0.008 * s, -0.0045 * s], // crisp lower inner corner
      [side * w * 0.52, 0.0005 * s],   // lower arch curve
      [side * w, -0.0015 * s],         // sleek outer bottom tip
      [side * w * 0.95, 0.0095 * s],   // outer upper bevel
      [side * w * 0.56, 0.0125 * s],   // signature upper arch peak!
      [side * 0.008 * s, 0.0055 * s],  // crisp upper inner corner
    ];
    if (side < 0) pts.reverse();
    shape.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i][0], pts[i][1]);
    shape.closePath();
  }

  const extrude = new THREE.ExtrudeGeometry(shape, {
    depth: 0.012 * s,
    bevelEnabled: true,
    bevelThickness: 0.0022 * s,
    bevelSize: 0.0018 * s,
    bevelSegments: 1,
    curveSegments: 1,
  });
  extrude.translate(0, 0, -0.006 * s);
  return extrude;
}

/**
 * Generates crisp vector Canvas texture matching Reference Image 2's iconic bold winged
 * rectangular black eyes framed by soft rosy-peach angled eye sockets!
 */
function getStylizedEyesTexture(faceId: Exclude<FaceId, 'faceless'>): THREE.CanvasTexture {
  const key = `eyes_v2_${faceId}`;
  const cached = faceTextureCache.get(key);
  if (cached) return cached;

  const w = 512;
  const h = 192;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, w, h);

  // Clean Golden-Ratio horizontal eye spacing (leaves harmonious nose bridge center gap like Image 2!)
  const centers = [
    { cx: 142, side: -1 },
    { cx: 370, side: 1 },
  ];

  // Shared helper: draws Reference Image 2's exact winged rectangular eye + angled rosy socket!
  const drawImage2Eye = (
    cx: number,
    cy: number,
    side: number,
    halfW: number,
    halfH: number,
    wingOut: number,
    slantInner = 0,
    withGlint = false
  ) => {
    const padX = 16;
    const padY = 15;

    // 1. Soft rosy-peach angled eye socket frame (exact Image 2 shading!)
    ctx.fillStyle = '#cf917b';
    ctx.beginPath();
    if (side < 0) {
      // Viewer's LEFT eye -> outer corner wing extends LEFT!
      ctx.moveTo(cx - halfW - wingOut - padX, cy - halfH - padY);
      ctx.lineTo(cx + halfW + padX, cy - halfH - padY + slantInner);
      ctx.lineTo(cx + halfW + padX - 4, cy + halfH + padY);
      ctx.lineTo(cx - halfW - padX + 4, cy + halfH + padY);
    } else {
      // Viewer's RIGHT eye -> outer corner wing extends RIGHT!
      ctx.moveTo(cx - halfW - padX, cy - halfH - padY + slantInner);
      ctx.lineTo(cx + halfW + wingOut + padX, cy - halfH - padY);
      ctx.lineTo(cx + halfW + padX - 4, cy + halfH + padY);
      ctx.lineTo(cx - halfW - padX + 4, cy + halfH + padY);
    }
    ctx.closePath();
    ctx.fill();

    // 2. Crisp bold jet-black winged stylized eye (EXACT IMAGE 2 SILHOUETTE!)
    ctx.fillStyle = '#070608';
    ctx.beginPath();
    if (side < 0) {
      ctx.moveTo(cx - halfW - wingOut, cy - halfH);
      ctx.lineTo(cx + halfW, cy - halfH + slantInner);
      ctx.lineTo(cx + halfW, cy + halfH);
      ctx.lineTo(cx - halfW + 4, cy + halfH);
      ctx.lineTo(cx - halfW - 1, cy - halfH * 0.15);
    } else {
      ctx.moveTo(cx - halfW, cy - halfH + slantInner);
      ctx.lineTo(cx + halfW + wingOut, cy - halfH);
      ctx.lineTo(cx + halfW + 1, cy - halfH * 0.15);
      ctx.lineTo(cx + halfW - 4, cy + halfH);
      ctx.lineTo(cx - halfW, cy + halfH);
    }
    ctx.closePath();
    ctx.fill();

    if (withGlint) {
      ctx.fillStyle = '#f2f5f8';
      ctx.fillRect(cx - halfW * 0.35, cy - halfH * 0.55, 16, 13);
    }
  };

  for (const { cx, side } of centers) {
    const cy = 98;
    if (faceId === 'grin') {
      // Bold Image-2 winged eye, slightly wider & focused
      drawImage2Eye(cx, cy, side, 48, 36, 22, 2, false);
    } else if (faceId === 'smirk') {
      // 100% EXACT REFERENCE IMAGE 2 WINGED EYE!
      drawImage2Eye(cx, cy, side, 50, 42, 24, 0, false);
    } else if (faceId === 'fierce') {
      drawImage2Eye(cx, cy, side, 50, 36, 24, 14, true);
    } else if (faceId === 'neutral') {
      // Intense stoic focused winged dark eyes (serious fighter gaze!)
      drawImage2Eye(cx, cy, side, 48, 35, 22, 6, false);
    } else {
      drawImage2Eye(cx, cy, side, 48, 38, 22, 4, true);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  faceTextureCache.set(key, tex);
  return tex;
}

/**
 * Generates crisp full-bleed vector Canvas textures for the 4 stylized mouths.
 * Drawn full-width & full-height inside the canvas so the mouth reads 2x bolder & cleaner!
 */
function getStylizedMouthTexture(faceId: Exclude<FaceId, 'faceless'>): THREE.CanvasTexture {
  const key = `mouth_v2_${faceId}`;
  const cached = faceTextureCache.get(key);
  if (cached) return cached;

  const w = 512;
  const h = 256;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, w, h);

  if (faceId === 'grin') {
    // BIG BOLD CLASSIC D-SHAPED BRIGHT WHITE SMILE + HORIZONTAL DARK BITE LINE!
    ctx.fillStyle = '#473026';
    ctx.beginPath();
    ctx.moveTo(30, 32);
    ctx.quadraticCurveTo(256, 54, 482, 32);
    ctx.quadraticCurveTo(420, 232, 256, 234);
    ctx.quadraticCurveTo(92, 232, 30, 32);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#fbfaf7';
    ctx.beginPath();
    ctx.moveTo(46, 44);
    ctx.quadraticCurveTo(256, 64, 466, 44);
    ctx.quadraticCurveTo(408, 218, 256, 220);
    ctx.quadraticCurveTo(104, 218, 46, 44);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#31201a';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.moveTo(68, 126);
    ctx.quadraticCurveTo(256, 144, 444, 126);
    ctx.stroke();
  } else if (faceId === 'smirk') {
    // BIG BOLD CHARISMATIC ASYMMETRIC WHITE-TEETH HERO SMIRK!
    ctx.fillStyle = '#473026';
    ctx.beginPath();
    ctx.moveTo(36, 98);
    ctx.quadraticCurveTo(268, 98, 480, 22);
    ctx.quadraticCurveTo(438, 222, 266, 226);
    ctx.quadraticCurveTo(108, 226, 36, 98);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#fbfaf7';
    ctx.beginPath();
    ctx.moveTo(54, 106);
    ctx.quadraticCurveTo(268, 108, 464, 38);
    ctx.quadraticCurveTo(424, 208, 266, 212);
    ctx.quadraticCurveTo(122, 212, 54, 106);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#31201a';
    ctx.lineWidth = 12;
    ctx.beginPath();
    ctx.moveTo(84, 152);
    ctx.quadraticCurveTo(276, 158, 438, 106);
    ctx.stroke();
  } else if (faceId === 'fierce') {
    // BIG BOLD CLENCHED COMMANDO BATTLE SNARL TEETH!
    ctx.fillStyle = '#351e19';
    ctx.beginPath();
    ctx.moveTo(28, 66);
    ctx.quadraticCurveTo(256, 28, 484, 66);
    ctx.lineTo(454, 216);
    ctx.quadraticCurveTo(256, 188, 58, 216);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#faf9f5';
    ctx.beginPath();
    ctx.moveTo(44, 78);
    ctx.quadraticCurveTo(256, 44, 468, 78);
    ctx.lineTo(440, 202);
    ctx.quadraticCurveTo(256, 174, 72, 202);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#2d1a15';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.moveTo(58, 138);
    ctx.quadraticCurveTo(256, 114, 454, 138);
    ctx.stroke();

    ctx.lineWidth = 6;
    for (const tx of [162, 256, 350]) {
      ctx.beginPath();
      ctx.moveTo(tx, 66);
      ctx.lineTo(tx, 190);
      ctx.stroke();
    }
  } else if (faceId === 'neutral') {
    // STOIC NEUTRAL CLOSED MOUTH (Firm straight serious martial-artist lips — NO smile, NO teeth!)
    ctx.strokeStyle = '#3b241c';
    ctx.lineWidth = 17;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(106, 124);
    ctx.quadraticCurveTo(256, 116, 406, 124);
    ctx.stroke();

    // Subtle upper & lower lip contour shading for strong stoic expression
    ctx.strokeStyle = '#a86e56';
    ctx.lineWidth = 11;
    ctx.beginPath();
    ctx.moveTo(166, 158);
    ctx.quadraticCurveTo(256, 166, 346, 158);
    ctx.stroke();
  } else {
    // TACTICAL COOL: Confident wide sleek toothy half-grin with upper flash!
    ctx.fillStyle = '#402921';
    ctx.beginPath();
    ctx.moveTo(46, 106);
    ctx.quadraticCurveTo(260, 128, 472, 46);
    ctx.quadraticCurveTo(420, 194, 260, 194);
    ctx.quadraticCurveTo(118, 194, 46, 106);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#faf9f6';
    ctx.beginPath();
    ctx.moveTo(64, 112);
    ctx.quadraticCurveTo(260, 134, 456, 62);
    ctx.quadraticCurveTo(408, 178, 260, 178);
    ctx.quadraticCurveTo(132, 178, 64, 112);
    ctx.closePath();
    ctx.fill();

    // Subtle lower lip shadow
    ctx.strokeStyle = '#b4775f';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(192, 224);
    ctx.quadraticCurveTo(260, 236, 328, 218);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  faceTextureCache.set(key, tex);
  return tex;
}

/**
 * Builds the 4 Golden-Ratio stylized low-poly face variations matching Reference Image 2:
 * - Eyes lowered to Golden Ratio vertical center (`y ≈ +0.008`, bold winged Image-2 eyes!)
 * - Sleek tapered arched 3D eyebrows hugging right above eyes (`y ≈ +0.036`)
 * - 2x enlarged bold curved stylized mouths (`mouthScale: 1.0` default; compact `0.52` on Heavy Gunner)
 */
export function buildStylizedFace(
  faceId: FaceId,
  opts: StylizedFaceOptions = {}
): THREE.Group {
  const group = new THREE.Group();
  group.name = `Face_${faceId}`;

  if (faceId === 'faceless') {
    return group;
  }

  const mode = opts.mode ?? 'full';
  const s = opts.scale ?? 1.0;
  const sx = opts.slimX ?? 0.98;
  const ridge = opts.noseRidge ?? 0.017;
  const eyeY = opts.eyeYOffset ?? 0;
  const mouthY = opts.mouthYOffset ?? 0;
  const mouthScale = opts.mouthScale ?? 1.0;
  const extraPad = opts.extraOffset ?? 0;

  const showEyes = mode === 'full' || mode === 'eyesOnly';
  const showMouth = mode === 'full' || mode === 'mouthOnly';

  const browMat = createMat({
    color: opts.browColor ?? 0x3b281c,
    roughness: 0.84,
  });

  // =========================================================================
  // 1. GEOMETRIC 5-O'CLOCK TAUPE STUBBLE BAND (Veteran Grin on clean-shaven heads)
  // =========================================================================
  if (mode === 'full' && faceId === 'grin' && !opts.hasBeard) {
    const stubbleMat = createMat({
      color: 0xb19c89,
      roughness: 0.88,
      flatShading: true,
    });
    const stubbleGeom = buildFaceConformingPatch({
      yMin: -0.126 * s,
      yMax: -0.026 * s,
      maxAngle: 1.38,
      uSegs: 8,
      vSegs: 4,
      s,
      sx,
      ridge,
      pad: 0.0022 + extraPad,
    });
    const stubbleMesh = new THREE.Mesh(stubbleGeom, stubbleMat);
    stubbleMesh.castShadow = false;
    stubbleMesh.receiveShadow = true;
    group.add(stubbleMesh);
  }

  // =========================================================================
  // 2. GOLDEN-RATIO IMAGE-2 WINGED EYES + SLEEK ARCHED 3D EYEBROWS
  // =========================================================================
  if (showEyes) {
    const eyeTex = getStylizedEyesTexture(faceId);
    const eyeMat = new THREE.MeshStandardMaterial({
      map: eyeTex,
      transparent: true,
      alphaTest: 0.30,
      roughness: 0.72,
      metalness: 0.02,
      flatShading: true,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });

    // Golden-Ratio Eye Band: centered right at y = +0.010, bold & wide matching Image 2!
    const eyesGeom = buildFaceConformingPatch({
      yMin: (-0.010 + eyeY) * s,
      yMax: (0.028 + eyeY) * s,
      maxAngle: 0.74,
      uSegs: 8,
      vSegs: 2,
      s,
      sx,
      ridge,
      pad: 0.0032 + extraPad,
    });
    const eyesMesh = new THREE.Mesh(eyesGeom, eyeMat);
    eyesMesh.renderOrder = 2;
    group.add(eyesMesh);

    // SLEEK ARCHED 3D SCULPTED EYEBROWS (EXACT IMAGE 2 SHAPE — wrapping cleanly along brow planes!)
    for (const side of [-1, 1] as const) {
      const browGeom = createSleekArchedBrowGeometry(side, s, faceId);
      const brow = makeStylizedMesh(browGeom, browMat, { outline: 0.0018 });
      // Inner brow anchored over nose bridge; positive side*0.48 sweeps outer tips BACKWARD hugging temples!
      const [bx, bz] = sampleHeadSurface(
        (0.035 + eyeY) * s,
        side * 0.05,
        s,
        sx,
        ridge,
        0.0045 + extraPad
      );
      brow.position.set(bx, (0.035 + eyeY) * s, bz);
      brow.rotation.y = side * 0.48;
      group.add(brow);
    }
  }

  // =========================================================================
  // 3. BOLD 2x ENLARGED GOLDEN-RATIO MOUTH (Compact when mouthScale ~ 0.52 on Gunner!)
  // =========================================================================
  if (showMouth) {
    const mouthTex = getStylizedMouthTexture(faceId);
    const mouthMat = new THREE.MeshStandardMaterial({
      map: mouthTex,
      transparent: true,
      alphaTest: 0.30,
      roughness: 0.48,
      metalness: 0.02,
      flatShading: true,
      polygonOffset: true,
      polygonOffsetFactor: -3,
    });

    // Golden-Ratio Mouth Center: y = -0.062 (balanced between eyes +0.010 and chin -0.128!)
    // Full 2x Hero Size at mouthScale = 1.0: halfHeight = 0.025 (0.050 tall), maxAngle = 0.70!
    const mouthCenterY = (-0.062 + mouthY) * s;
    const halfH = 0.025 * mouthScale * s;
    const maxAng = THREE.MathUtils.clamp(0.70 * Math.pow(mouthScale, 0.75), 0.36, 0.78);

    const mouthGeom = buildFaceConformingPatch({
      yMin: Math.max(-0.120 * s, mouthCenterY - halfH),
      yMax: mouthCenterY + halfH,
      maxAngle: maxAng,
      uSegs: 8,
      vSegs: 2,
      s,
      sx,
      ridge,
      pad: 0.0044 + extraPad,
    });
    const mouthMesh = new THREE.Mesh(mouthGeom, mouthMat);
    mouthMesh.renderOrder = 3;
    group.add(mouthMesh);
  }

  // =========================================================================
  // 4. SIGNATURE ACCENTS (CHEEK BATTLE SCAR on 'fierce', NOSE BANDAGE on 'cool')
  // =========================================================================
  if (mode === 'full' && faceId === 'fierce') {
    const scarMat = createMat({ color: 0xa45848, roughness: 0.85 });
    const [sxPos, szPos] = sampleHeadSurface(-0.022 * s, 0.54, s, sx, ridge, 0.004 + extraPad);
    const scar = makeStylizedMesh(
      createBeveledBoxGeometry(0.036 * s, 0.007 * s, 0.006 * s, 0.001),
      scarMat,
      { outline: 0 }
    );
    scar.position.set(sxPos, -0.022 * s, szPos);
    scar.rotation.order = 'YXZ';
    scar.rotation.y = 0.52;
    scar.rotation.z = -0.58;
    group.add(scar);
  }

  if (mode === 'full' && faceId === 'cool') {
    const bandageMat = createMat({ color: 0xeed9be, roughness: 0.82 });
    const padMat = createMat({ color: 0xdcc0a0, roughness: 0.86 });
    const [, bz] = sampleHeadSurface(-0.022 * s, 0, s, sx, ridge, 0.004 + extraPad);
    const bandage = makeStylizedMesh(
      createBeveledBoxGeometry(0.052 * s, 0.015 * s, 0.008 * s, 0.002),
      bandageMat,
      { outline: 0.0015 }
    );
    bandage.position.set(0, -0.022 * s, bz);
    bandage.rotation.z = 0.12;
    group.add(bandage);

    const centerPad = makeStylizedMesh(
      createBeveledBoxGeometry(0.018 * s, 0.011 * s, 0.009 * s, 0.001),
      padMat,
      { outline: 0 }
    );
    centerPad.position.set(0, -0.022 * s, bz + 0.001);
    centerPad.rotation.z = 0.12;
    group.add(centerPad);
  }

  return group;
}
