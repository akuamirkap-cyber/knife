import * as THREE from 'three';

export interface StylizedMatOptions {
  color: number | string;
  roughness?: number;
  metalness?: number;
  emissive?: number | string;
  emissiveIntensity?: number;
  map?: THREE.Texture | null;
  side?: THREE.Side;
  flatShading?: boolean;
}

const sharedOutlineMaterial = new THREE.MeshBasicMaterial({
  color: 0x110e0f,
  side: THREE.BackSide,
});

const sharedEdgeLineMaterial = new THREE.LineBasicMaterial({
  color: 0x121011,
  transparent: true,
  opacity: 0.62,
});

const sharedSubtleEdgeMaterial = new THREE.LineBasicMaterial({
  color: 0x151314,
  transparent: true,
  opacity: 0.34,
});

export function getOutlineMaterial(): THREE.MeshBasicMaterial {
  return sharedOutlineMaterial;
}

export function createMat(opts: StylizedMatOptions): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color: opts.color,
    roughness: opts.roughness ?? 0.80,
    metalness: opts.metalness ?? 0.04,
    emissive:
      opts.emissive !== undefined
        ? new THREE.Color(opts.emissive)
        : new THREE.Color(0x000000),
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    map: opts.map ?? null,
    side: opts.side ?? THREE.FrontSide,
    flatShading: opts.flatShading ?? true,
  });
}

/**
 * Smooth, ultra-glossy clearcoat glass/visor material for tactical goggles & helmet shields.
 * Uses smooth shading + high clearcoat + studio reflection map so glass always looks slick and polished!
 */
export function createGlossyGlassMat(opts: {
  color: number | string;
  metalness?: number;
  roughness?: number;
  map?: THREE.Texture | null;
  emissive?: number | string;
  emissiveIntensity?: number;
}): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: opts.color,
    roughness: opts.roughness ?? 0.06,
    metalness: opts.metalness ?? 0.42,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
    reflectivity: 1.0,
    envMapIntensity: 1.45,
    map: opts.map ?? null,
    emissive:
      opts.emissive !== undefined
        ? new THREE.Color(opts.emissive)
        : new THREE.Color(0x000000),
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    flatShading: false,
  });
}

export function buildSmoothOutlineGeometry(
  source: THREE.BufferGeometry,
  thickness: number
): THREE.BufferGeometry {
  const geom = source.index ? source.toNonIndexed() : source.clone();
  const pos = geom.getAttribute('position') as THREE.BufferAttribute;
  const count = pos.count;

  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vC = new THREE.Vector3();
  const ab = new THREE.Vector3();
  const ac = new THREE.Vector3();
  const faceNormal = new THREE.Vector3();

  const normalMap = new Map<string, THREE.Vector3>();
  const keyOf = (x: number, y: number, z: number) =>
    `${Math.round(x * 1600)},${Math.round(y * 1600)},${Math.round(z * 1600)}`;

  for (let i = 0; i < count; i += 3) {
    vA.fromBufferAttribute(pos, i);
    vB.fromBufferAttribute(pos, i + 1);
    vC.fromBufferAttribute(pos, i + 2);
    ab.subVectors(vB, vA);
    ac.subVectors(vC, vA);
    faceNormal.crossVectors(ab, ac);
    if (faceNormal.lengthSq() < 1e-12) continue;
    faceNormal.normalize();

    const verts = [vA, vB, vC];
    for (const v of verts) {
      const k = keyOf(v.x, v.y, v.z);
      let acc = normalMap.get(k);
      if (!acc) {
        acc = new THREE.Vector3();
        normalMap.set(k, acc);
      }
      acc.add(faceNormal);
    }
  }

  for (const acc of normalMap.values()) {
    if (acc.lengthSq() > 1e-10) acc.normalize();
  }

  const newPositions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const n = normalMap.get(keyOf(x, y, z));
    if (n) {
      newPositions[i * 3] = x + n.x * thickness;
      newPositions[i * 3 + 1] = y + n.y * thickness;
      newPositions[i * 3 + 2] = z + n.z * thickness;
    } else {
      newPositions[i * 3] = x;
      newPositions[i * 3 + 1] = y;
      newPositions[i * 3 + 2] = z;
    }
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(newPositions, 3));
  return out;
}

export interface StylizedMeshOptions {
  outline?: number;
  edgeThreshold?: number;
  subtleEdges?: boolean;
  castShadow?: boolean;
  receiveShadow?: boolean;
  name?: string;
}

export function makeStylizedMesh(
  geometry: THREE.BufferGeometry,
  material: THREE.Material,
  opts: StylizedMeshOptions = {}
): THREE.Mesh {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.castShadow = opts.castShadow ?? true;
  mesh.receiveShadow = opts.receiveShadow ?? true;
  if (opts.name) mesh.name = opts.name;

  const outlineThickness = opts.outline ?? 0.0050;
  if (outlineThickness > 0) {
    const outlineGeom = buildSmoothOutlineGeometry(geometry, outlineThickness);
    const outlineMesh = new THREE.Mesh(outlineGeom, sharedOutlineMaterial);
    outlineMesh.userData.isOutline = true;
    outlineMesh.castShadow = false;
    outlineMesh.receiveShadow = false;
    outlineMesh.renderOrder = 1;
    mesh.add(outlineMesh);
  }

  const edgeAngle = opts.edgeThreshold ?? 0;
  if (edgeAngle > 0) {
    const edges = new THREE.EdgesGeometry(geometry, edgeAngle);
    const line = new THREE.LineSegments(
      edges,
      opts.subtleEdges ? sharedSubtleEdgeMaterial : sharedEdgeLineMaterial
    );
    line.userData.isOutline = true;
    line.userData.isEdgeLine = true;
    line.renderOrder = 2;
    mesh.add(line);
  }

  return mesh;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const textureCache = new Map<string, THREE.CanvasTexture>();

function finalizeTexture(
  key: string,
  canvas: HTMLCanvasElement,
  repeatX = 1,
  repeatY = 1,
  wrap = false
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.anisotropy = 4;
  if (wrap) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeatX, repeatY);
  }
  textureCache.set(key, tex);
  return tex;
}

/**
 * Geometric Woodland Camo for Boonie pants/hat & Heavy Gunner trousers.
 */
export function getWoodlandCamoTexture(
  variant: 'pants' | 'hat' | 'gunner' = 'pants'
): THREE.CanvasTexture {
  const key = `camo_${variant}`;
  const cached = textureCache.get(key);
  if (cached) return cached;

  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(variant === 'pants' ? 48291 : variant === 'hat' ? 91733 : 62914);

  ctx.fillStyle =
    variant === 'pants' ? '#60753c' : variant === 'hat' ? '#6c7c48' : '#6f7c46';
  ctx.fillRect(0, 0, size, size);

  const palette =
    variant === 'gunner'
      ? ['#98945e', '#4b5a32', '#6a4e32', '#7e894c', '#453525', '#878352']
      : variant === 'pants'
        ? ['#9da066', '#40502a', '#5f462e', '#758747', '#3d2f21', '#8b9058']
        : ['#9b9b67', '#475731', '#624d35', '#798850', '#3a4626'];

  const drawWrappedPoly = (
    cx: number,
    cy: number,
    radiusX: number,
    radiusY: number,
    sides: number,
    rot: number,
    color: string
  ) => {
    const pts: [number, number][] = [];
    for (let i = 0; i < sides; i++) {
      const ang = rot + (i / sides) * Math.PI * 2 + (rand() - 0.5) * 0.42;
      const rMod = 0.6 + rand() * 0.62;
      pts.push([Math.cos(ang) * radiusX * rMod, Math.sin(ang) * radiusY * rMod]);
    }
    ctx.fillStyle = color;
    for (let ox = -size; ox <= size; ox += size) {
      for (let oy = -size; oy <= size; oy += size) {
        ctx.beginPath();
        for (let i = 0; i < pts.length; i++) {
          const px = cx + ox + pts[i][0];
          const py = cy + oy + pts[i][1];
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
      }
    }
  };

  for (let i = 0; i < 28; i++) {
    drawWrappedPoly(
      rand() * size,
      rand() * size,
      (variant === 'hat' ? 42 : 54) + rand() * 64,
      (variant === 'hat' ? 32 : 60) + rand() * 68,
      4 + Math.floor(rand() * 3),
      rand() * Math.PI * 2,
      palette[i % palette.length]
    );
  }
  for (let i = 0; i < 30; i++) {
    drawWrappedPoly(
      rand() * size,
      rand() * size,
      24 + rand() * 38,
      26 + rand() * 42,
      3 + Math.floor(rand() * 3),
      rand() * Math.PI * 2,
      palette[Math.floor(rand() * palette.length)]
    );
  }

  return finalizeTexture(
    key,
    canvas,
    variant === 'hat' ? 1.15 : 1.0,
    variant === 'hat' ? 0.85 : 0.85,
    true
  );
}

/**
 * Crisp white "POLICE" Velcro placard texture for SWAT chest vest.
 */
export function getPolicePatchTexture(): THREE.CanvasTexture {
  const key = 'police_patch';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 192;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#1d2026';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = '#363c46';
  ctx.lineWidth = 10;
  ctx.strokeRect(8, 8, canvas.width - 16, canvas.height - 16);

  ctx.fillStyle = '#f3f5f8';
  ctx.font = '900 106px "Space Grotesk", "Arial Black", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('POLICE', canvas.width / 2, canvas.height / 2 + 4);

  return finalizeTexture(key, canvas);
}

/**
 * Crisp white "SKILL" emblem texture for Black Streetwear Baseball Cap.
 */
export function getSkillCapTexture(): THREE.CanvasTexture {
  const key = 'skill_cap';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 192;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#1a1c21';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = '#ffffff';
  ctx.font = '900 124px "Space Grotesk", "Arial Black", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('SKILL', canvas.width / 2, canvas.height / 2 + 6);

  return finalizeTexture(key, canvas);
}

/**
 * Smooth glossy stylized glass reflection texture (crisp bright left-side studio glare streak
 * fading into deep smoked glass, matching Image 3 Police goggles & Image 1 Gunner goggles!).
 */
export function getGlossyGlassTexture(tint: 'silver' | 'smoke' | 'dark' = 'silver'): THREE.CanvasTexture {
  const key = `glossy_glass_${tint}`;
  const cached = textureCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, 512, 180);
  if (tint === 'silver') {
    grad.addColorStop(0.0, '#727c88');
    grad.addColorStop(0.18, '#c5cfd9');
    grad.addColorStop(0.28, '#f5f8fc'); // Crisp glossy specular glare band (exact Image 3!)
    grad.addColorStop(0.38, '#a4b0be');
    grad.addColorStop(0.62, '#5a6573');
    grad.addColorStop(0.84, '#7d8896');
    grad.addColorStop(1.0, '#49525e');
  } else if (tint === 'smoke') {
    grad.addColorStop(0.0, '#4b555f');
    grad.addColorStop(0.20, '#96a4b0');
    grad.addColorStop(0.30, '#e3ebf2'); // Bright sleek glass highlight matching Gunner Image 1!
    grad.addColorStop(0.42, '#6c7985');
    grad.addColorStop(0.75, '#3b444d');
    grad.addColorStop(1.0, '#54606b');
  } else {
    grad.addColorStop(0.0, '#181b20');
    grad.addColorStop(0.22, '#3d4552');
    grad.addColorStop(0.32, '#7d8a9c');
    grad.addColorStop(0.44, '#242931');
    grad.addColorStop(1.0, '#13161a');
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 256);

  // Secondary subtle bright top rim gleam
  const topGlare = ctx.createLinearGradient(0, 0, 0, 64);
  topGlare.addColorStop(0, 'rgba(255,255,255,0.28)');
  topGlare.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = topGlare;
  ctx.fillRect(0, 0, 512, 64);

  return finalizeTexture(key, canvas);
}

/**
 * Bold streetwear "SKILL ISSUE" black typography panel mapped right-side-up on Skill Issue's white sleeve.
 */
export function getSkillSleeveTexture(): THREE.CanvasTexture {
  const key = 'skill_sleeve';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#e0e3e9';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Subtle shoulder piping line
  ctx.fillStyle = '#3b404a';
  ctx.fillRect(0, 0, canvas.width, 18);

  // Crisp stacked upright "SKILL" over "ISSUE" centered cleanly!
  ctx.fillStyle = '#1b1e25';
  ctx.font = '900 132px "Space Grotesk", "Arial Black", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('SKILL', 256, 200);

  ctx.font = '800 84px "Space Grotesk", "Arial Black", sans-serif';
  ctx.fillText('ISSUE', 256, 326);

  return finalizeTexture(key, canvas);
}

/**
 * Bold vertical white "SKILL ISSUE" stripe down right black techwear cargo jogger leg.
 */
export function getSkillLegTexture(): THREE.CanvasTexture {
  const key = 'skill_leg';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 160;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#191b20';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.save();
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate(Math.PI / 2);
  ctx.fillStyle = '#e4e7ed';
  ctx.font = 'italic 900 62px "Space Grotesk", "Arial Black", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('SKILL ISSUE', 0, 2);
  ctx.restore();

  return finalizeTexture(key, canvas);
}

/**
 * Stylized arm tattoos for Heavy Gunner's muscular left upper arm & wrist cuff.
 */
export function getGunnerTattooTexture(part: 'upper' | 'wrist' | 'rightWrist'): THREE.CanvasTexture {
  const key = `gunner_tat_${part}`;
  const cached = textureCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base warm stylized tan skin matching PALETTE.skinTan
  ctx.fillStyle = '#dfa382';
  ctx.fillRect(0, 0, 512, 512);

  if (part === 'upper') {
    // Note: on buildLimbBetween(shoulder->elbow), v=0 (y=512) is shoulder, v=1 (y=0) is elbow!
    // And u=0 (x=0/512) is FRONT (+Z), u=0.25 (x=128) is OUTER LEFT (+X).
    // Place bold stylized skull/hat-crest half-sleeve on front-outer bicep (x=86 and wrapped around x=512)!
    const drawCrest = (cx: number) => {
      ctx.save();
      // Flip vertically so top of tattoo faces shoulder (y=420) and ribbon banner sits toward elbow (y=155)!
      ctx.translate(cx, 275);
      ctx.scale(1, -1);

      // Rich sepia-brown shaded half-sleeve crest silhouette (matching Image 1!)
      ctx.fillStyle = '#6c4736';
      ctx.beginPath();
      ctx.moveTo(-78, 88);
      ctx.quadraticCurveTo(-96, -24, -46, -110);
      ctx.quadraticCurveTo(0, -138, 52, -108);
      ctx.quadraticCurveTo(96, -24, 78, 88);
      ctx.quadraticCurveTo(0, 126, -78, 88);
      ctx.closePath();
      ctx.fill();

      // Dark stylized skull/cowboy emblem silhouette inside
      ctx.fillStyle = '#38241b';
      ctx.beginPath();
      ctx.arc(0, -18, 48, 0, Math.PI * 2);
      ctx.fill();

      // Stylized brim/cloud swirl top
      ctx.beginPath();
      ctx.ellipse(0, -64, 70, 22, -0.1, 0, Math.PI * 2);
      ctx.fill();

      // Negative-space eye sockets
      ctx.fillStyle = '#dfa382';
      ctx.beginPath();
      ctx.arc(-19, -20, 13, 0, Math.PI * 2);
      ctx.arc(19, -20, 13, 0, Math.PI * 2);
      ctx.fill();

      // Crisp curved banner scroll ribbon below crest (near lower bicep!)
      ctx.fillStyle = '#dfa382';
      ctx.strokeStyle = '#38241b';
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(-72, 74);
      ctx.quadraticCurveTo(0, 102, 72, 74);
      ctx.lineTo(66, 108);
      ctx.quadraticCurveTo(0, 136, -66, 108);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.restore();
    };

    // Centered right on true front-outer left bicep (u = 0.81 -> outer-front facing camera!)
    drawCrest(416);
    drawCrest(416 - 512);
  } else if (part === 'wrist') {
    // Note: on buildLimbBetween(elbow->wrist), v=1 (y=0) is WRIST and v=0 (y=512) is ELBOW!
    // So y=118 places the barbed-wire tattoo RIGHT ABOVE THE LEFT GLOVE WRIST (exact Image 1!)
    ctx.strokeStyle = '#33221c';
    ctx.lineWidth = 10;
    ctx.beginPath();
    for (let x = 0; x <= 512; x += 32) {
      const y = 118 + (x % 64 === 0 ? -20 : 20);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    ctx.lineWidth = 7;
    for (let x = 32; x < 512; x += 64) {
      ctx.beginPath();
      ctx.moveTo(x - 14, 96);
      ctx.lineTo(x + 14, 140);
      ctx.moveTo(x + 14, 96);
      ctx.lineTo(x - 14, 140);
      ctx.stroke();
    }
  } else {
    // Subtle small emblem/cross ink right below right wrist (visible on his raised right forearm in Image 1!)
    ctx.strokeStyle = '#3c271f';
    ctx.lineWidth = 9;
    for (const cx of [128, 384]) {
      ctx.beginPath();
      ctx.moveTo(cx, 88);
      ctx.lineTo(cx, 150);
      ctx.moveTo(cx - 24, 112);
      ctx.lineTo(cx + 24, 112);
      ctx.stroke();
    }
  }

  return finalizeTexture(key, canvas, 1, 1, true);
}

/**
 * Distressed faded indigo denim jeans texture with crisp low-poly wear & white-thread rips
 * for Level-3 Spetsnaz Wasteland Survivor!
 */
export function getDistressedDenimTexture(): THREE.CanvasTexture {
  const key = 'distressed_denim';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(31415);

  // Base rugged denim indigo
  ctx.fillStyle = '#3c5674';
  ctx.fillRect(0, 0, size, size);

  // Subtle vertical denim fade bands
  const bands = ['#486687', '#344c68', '#527092', '#39526e'];
  for (let i = 0; i < 18; i++) {
    ctx.fillStyle = bands[i % bands.length];
    ctx.globalAlpha = 0.45;
    const x = rand() * size;
    const y = rand() * size;
    const w = 36 + rand() * 78;
    const h = 80 + rand() * 140;
    ctx.fillRect(x, y, w, h);
  }
  ctx.globalAlpha = 1;

  // Subtle distressed faded denim wear + few tasteful hand-styled rips (clean, not noisy!)
  for (let i = 0; i < 4; i++) {
    const rx = 60 + rand() * (size - 140);
    const ry = 100 + rand() * (size - 200);
    const rw = 36 + rand() * 34;
    const rh = 10 + rand() * 8;

    ctx.fillStyle = '#293e56';
    ctx.fillRect(rx, ry, rw, rh);

    ctx.strokeStyle = '#8fa9c2';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(rx + 3, ry + rh * 0.35);
    ctx.lineTo(rx + rw - 3, ry + rh * 0.35);
    ctx.moveTo(rx + 6, ry + rh * 0.72);
    ctx.lineTo(rx + rw - 6, ry + rh * 0.72);
    ctx.stroke();
  }

  return finalizeTexture(key, canvas, 1.0, 1.0, true);
}

/**
 * Rugged dark-indigo martial artist denim jeans with subtle worn thigh fades & battle scuffs
 * (matching Reference Image 1 — Silat Striker).
 */
export function getSilatDenimTexture(): THREE.CanvasTexture {
  const key = 'silat_denim';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(99127);

  ctx.fillStyle = '#293a52';
  ctx.fillRect(0, 0, size, size);

  // Subtle vertical denim weave fades & thigh highlights
  const tones = ['#324763', '#223146', '#3a5170', '#2d405a'];
  for (let i = 0; i < 20; i++) {
    ctx.fillStyle = tones[i % tones.length];
    ctx.globalAlpha = 0.42;
    ctx.fillRect(rand() * size, rand() * size, 32 + rand() * 72, 90 + rand() * 140);
  }
  ctx.globalAlpha = 1;

  // Subtle gritty battle scuffs & dark wear along lower knees (echoing Image 1 fight wear!)
  for (let i = 0; i < 6; i++) {
    ctx.fillStyle = i % 2 === 0 ? 'rgba(32, 24, 24, 0.34)' : 'rgba(92, 34, 30, 0.22)';
    const x = 40 + rand() * (size - 80);
    const y = 80 + rand() * (size - 160);
    ctx.beginPath();
    ctx.ellipse(x, y, 22 + rand() * 34, 12 + rand() * 20, rand() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  return finalizeTexture(key, canvas, 1.0, 1.0, true);
}

/**
 * Unified single-mesh UV head texture for Silat Striker:
 * Paints warm Southeast Asian tan skin + razor-clean high-fade military buzzcut directly onto
 * the single `createStylizedHeadGeometry` mesh with `ClampToEdgeWrapping` on V!
 * Guarantees ZERO top bald spot, ZERO rear skin clipping, and 100% seamless 360° shaved buzzcut!
 *
 * UV Layout of `createLoftGeometry`:
 *  - u = 0.0 / 1.0 : front center (+Z, forehead & nose)
 *  - u = 0.25      : left temple (+X, above left ear)
 *  - u = 0.50      : back center (-Z, occiput & nape)
 *  - u = 0.75      : right temple (-X, above right ear)
 *  - v = 0.0 (canvas y = 512) : chin tip (-0.128)
 *  - v = 1.0 (canvas y = 0)   : top crown apex (+0.156)
 */
/**
 * Unified single-mesh sharp-lineup buzzcut + low temple taper fade texture (matching Reference Image 1!).
 * Parameterized by skin color & hair color so ALL open-face characters (Silat, Boonie, Gunner, Skill)
 * have crisp, full, low-fade buzzcut hair with sharp temple corners, neat sideburns, and ZERO bald gaps!
 *
 * UV Layout of `createStylizedHeadGeometry`:
 *  - angle 0 (u=0/1) : Front forehead center (+Z)
 *  - angle ±1.57     : Left/Right temples directly above ears (±X)
 *  - angle ±3.14     : Back of skull / nape (-Z)
 *  - v = 0 (y=512)   : Chin (-0.128) | v = 0.56 : Brow | v = 0.67 : Sharp forehead line-up | v = 1 (y=0) : Apex (+0.156)
 */
export function getBuzzcutHeadTexture(
  skinHex: number,
  hairHex = 0x261f1c
): THREE.CanvasTexture {
  const key = `buzzcut_head_${skinHex.toString(16)}_${hairHex.toString(16)}`;
  const cached = textureCache.get(key);
  if (cached) return cached;

  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32((skinHex ^ hairHex) >>> 0);

  const skinCol = new THREE.Color(skinHex);
  const hairCol = new THREE.Color(hairHex);
  const midDark = hairCol.clone().lerp(skinCol, 0.24);
  const midFade = hairCol.clone().lerp(skinCol, 0.58);
  const skinCss = `#${skinCol.getHexString()}`;
  const hairCss = `#${hairCol.getHexString()}`;
  const midDarkCss = `#${midDark.getHexString()}`;
  const midFadeCss = `#${midFade.getHexString()}`;

  // 1. Base warm skin tone across entire head
  ctx.fillStyle = skinCss;
  ctx.fillRect(0, 0, size, size);

  // Compute exact Reference Image 1 sharp buzzcut hairline contour per angular column!
  const getContourAtAngle = (absAng: number): { bottomV: number; fadeSpan: number } => {
    // absAng in [0..PI]: 0 = center forehead, 0.72 = forehead corner, 1.25 = sideburn front of ear,
    // 1.60 = right above ear, 2.25 = behind ear, 3.14 = back nape!
    if (absAng < 0.72) {
      // CRISP LOW STRAIGHT HORIZONTAL FOREHEAD LINE-UP (exact Image 1 — NOT high bowl cut!)
      const edgeDrop = Math.pow(absAng / 0.72, 3.2) * 0.014;
      return { bottomV: 0.675 - edgeDrop, fadeSpan: 0.022 };
    }
    if (absAng < 1.05) {
      // SHARP 90° TEMPLE CORNER ("C-CUP") dropping neatly down toward sideburn!
      const t = (absAng - 0.72) / 0.33;
      const smoothT = t * t * (3 - 2 * t);
      return {
        bottomV: THREE.MathUtils.lerp(0.661, 0.445, smoothT),
        fadeSpan: THREE.MathUtils.lerp(0.024, 0.055, smoothT),
      };
    }
    if (absAng < 1.38) {
      // NEAT SHORT TAPERED SIDEBURN in front of ear (like Image 1!)
      const t = (absAng - 1.05) / 0.33;
      return {
        bottomV: THREE.MathUtils.lerp(0.445, 0.485, t),
        fadeSpan: THREE.MathUtils.lerp(0.055, 0.095, t),
      };
    }
    if (absAng < 1.92) {
      // LOW CLEAN TAPER FADE wrapping smoothly right above the ear!
      const t = (absAng - 1.38) / 0.54;
      const arch = Math.sin(t * Math.PI) * 0.032;
      return {
        bottomV: THREE.MathUtils.lerp(0.485, 0.395, t) + arch,
        fadeSpan: 0.115,
      };
    }
    // BACK OF HEAD & CLEAN LOW MILITARY NAPE TAPER (full rich buzzcut down behind ears to nape!)
    const t = (absAng - 1.92) / (Math.PI - 1.92);
    const smoothT = t * t * (3 - 2 * t);
    return {
      bottomV: THREE.MathUtils.lerp(0.395, 0.295, smoothT),
      fadeSpan: THREE.MathUtils.lerp(0.115, 0.130, smoothT),
    };
  };

  for (let px = 0; px < size; px++) {
    const u = px / size;
    const rawAng = u * Math.PI * 2;
    const absAng = rawAng <= Math.PI ? rawAng : Math.PI * 2 - rawAng;

    const { bottomV, fadeSpan } = getContourAtAngle(absAng);
    const solidTopV = Math.min(0.95, bottomV + fadeSpan);

    const yBottom = Math.round((1 - bottomV) * size);
    const ySolid = Math.round((1 - solidTopV) * size);

    // Rich uniform cropped buzzcut hair from crown apex (y=0) cleanly down to fade line
    ctx.fillStyle = hairCss;
    ctx.fillRect(px, 0, 1, Math.max(1, ySolid));

    // Smooth barbershop low taper fade transition into skin
    if (yBottom > ySolid) {
      const grad = ctx.createLinearGradient(0, ySolid, 0, yBottom);
      grad.addColorStop(0.0, hairCss);
      grad.addColorStop(0.38, midDarkCss);
      grad.addColorStop(0.74, midFadeCss);
      grad.addColorStop(1.0, skinCss);
      ctx.fillStyle = grad;
      ctx.fillRect(px, ySolid, 1, yBottom - ySolid + 1);
    }
  }

  // 2. Natural fine buzzcut velvet sheen & cropped hair texture grain across top & sides!
  for (let i = 0; i < 3200; i++) {
    const px = Math.floor(rand() * size);
    const u = px / size;
    const rawAng = u * Math.PI * 2;
    const absAng = rawAng <= Math.PI ? rawAng : Math.PI * 2 - rawAng;
    const { bottomV } = getContourAtAngle(absAng);
    const maxY = (1 - (bottomV + 0.015)) * size;
    if (maxY <= 4) continue;
    const py = rand() * maxY;
    const alpha = 0.10 + rand() * 0.14;
    ctx.fillStyle = i % 3 === 0 ? `rgba(12, 9, 8, ${alpha})` : `rgba(82, 68, 60, ${alpha * 0.72})`;
    ctx.fillRect(px, py, 2, 3);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.anisotropy = 4;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set(key, tex);
  return tex;
}

/**
 * Badass stylized 3-slash diagonal claw scratch scar ("luka cakar") for Silat's right cheek!
 */
export function getClawScarTexture(): THREE.CanvasTexture {
  const key = 'claw_scar_cheek';
  const cached = textureCache.get(key);
  if (cached) return cached;

  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, size, size);

  // Draw 3 crisp tapered parallel diagonal claw scratches (upper-left to lower-right across cheek!)
  const scratches = [
    { x0: 54, y0: 52, x1: 186, y1: 162, w: 12 },
    { x0: 84, y0: 36, x1: 218, y1: 148, w: 14 }, // Center deepest claw slash
    { x0: 42, y0: 92, x1: 168, y1: 198, w: 11 },
  ];

  // Soft faint bruised redness halo immediately hugging the slashes
  for (const sc of scratches) {
    ctx.strokeStyle = 'rgba(150, 42, 36, 0.34)';
    ctx.lineWidth = sc.w + 14;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(sc.x0, sc.y0);
    ctx.lineTo(sc.x1, sc.y1);
    ctx.stroke();
  }

  // Sharp tapered crimson/dark-red claw gouges!
  for (const sc of scratches) {
    const dx = sc.x1 - sc.x0;
    const dy = sc.y1 - sc.y0;
    const len = Math.hypot(dx, dy);
    const nx = (-dy / len) * (sc.w * 0.55);
    const ny = (dx / len) * (sc.w * 0.55);
    const mx = (sc.x0 + sc.x1) * 0.5;
    const my = (sc.y0 + sc.y1) * 0.5;

    // Outer crimson scratch rim
    ctx.fillStyle = '#9c2220';
    ctx.beginPath();
    ctx.moveTo(sc.x0, sc.y0);
    ctx.quadraticCurveTo(mx + nx, my + ny, sc.x1, sc.y1);
    ctx.quadraticCurveTo(mx - nx, my - ny, sc.x0, sc.y0);
    ctx.closePath();
    ctx.fill();

    // Inner deep dark-blood scratch core
    ctx.fillStyle = '#4e0d0e';
    ctx.beginPath();
    ctx.moveTo(sc.x0 + dx * 0.12, sc.y0 + dy * 0.12);
    ctx.quadraticCurveTo(mx + nx * 0.42, my + ny * 0.42, sc.x1 - dx * 0.12, sc.y1 - dy * 0.12);
    ctx.quadraticCurveTo(mx - nx * 0.42, my - ny * 0.42, sc.x0 + dx * 0.12, sc.y0 + dy * 0.12);
    ctx.closePath();
    ctx.fill();
  }

  return finalizeTexture(key, canvas);
}

/**
 * Shared Palette Presets calibrated directly across all 9 skins.
 */
export const PALETTE = {
  // Skin tones
  skinBase: 0xe3ac90,
  skinHand: 0xe6b095,
  skinTan: 0xdfa382,
  skinSEA: 0xd59672, // Warm medium-tan Southeast Asian martial artist skin tone

  // 01: Boonie Captain
  boonieMustache: 0x4b2f24,
  boonieShirt: 0x1a1c1f,
  boonieVest: 0x978e60,
  boonieVestStrap: 0x7e774f,
  boonieMag: 0x26282c,
  boonieBootUpper: 0x716a48,
  boonieBootLower: 0x625c3e,
  boonieBootSole: 0x2a2822,

  // 02: Venom Fang Ops
  venomHelmet: 0x26282d,
  venomVisor: 0x131518,
  venomHornRed: 0xa42024,
  venomMouthRed: 0x7b141b,
  venomFangWhite: 0xf6f4f0,
  venomScarf: 0x33373b,
  venomUniform: 0x272a2f,
  venomArmor: 0x33373d,
  venomWebbing: 0x1d1f23,
  venomKnee: 0x3a3e45,
  venomBoot: 0x1b1d20,

  // 03: Golden Enforcer
  goldMask: 0xdcb442,
  goldEyeSocket: 0x6c5522,
  goldGlove: 0xe4bc46,
  suitShirt: 0xaec8e8,
  suitVest: 0x2a3754,
  suitTie: 0x202b44,
  suitPants: 0x25324c,
  suitLeather: 0x734129,
  suitShoe: 0x1d1f24,

  // 04: Red-Eye Trooper
  reaperHelmet: 0x383d41,
  reaperMask: 0x25282c,
  reaperLensRed: 0xf5261d,
  reaperUniform: 0x1e2024,
  reaperRig: 0x2e3238,
  reaperBuckle: 0x6f757e,
  reaperKnee: 0x34383e,
  reaperBoot: 0x191b1f,

  // 05: SWAT Police Marksman
  policeHelmet: 0x252930,
  policeGoggleFrame: 0xa7b0bb,
  policeGoggleLens: 0x5c6878,
  policeBalaclava: 0x1b1e23,
  policeUniformNavy: 0x273654,
  policeVestBlack: 0x20232a,
  policeKnee: 0x323740,
  policeBoot: 0x181a1e,

  // 06: Heavy LMG Gunner
  gunnerBeanie: 0x4f5c3a,
  gunnerGoggle: 0x26292d,
  gunnerLens: 0x465159,
  gunnerBeard: 0x4a3123,
  gunnerTank: 0x5e6b40,
  gunnerRig: 0x70774c,
  gunnerRigDark: 0x565d39,
  gunnerAmmoGreen: 0x62733d,
  gunnerGlove: 0x373c36,
  gunnerBoot: 0x716a46,

  // 07: Skill Issue Streetwear Agent
  skillCap: 0x1a1c21,
  skillJacketWhite: 0xe0e3e9,
  skillJacketShadow: 0xc2c8d2,
  skillSleeveDark: 0x3a3f48,
  skillPantsBlack: 0x191b20,
  skillSock: 0x262930,
  skillSneaker: 0x17191d,
  skillLaceWhite: 0xf0f2f5,
  skillPistolGold: 0xe4ba3d,

  // 08: Level-3 Spetsnaz Survivor
  spetsHelmet: 0x474d54,
  spetsVisorSteel: 0x383e45,
  spetsSlitDark: 0x121417,
  spetsBandanaRed: 0xc22227,
  spetsBandanaDark: 0x99181c,
  spetsJacket: 0x282b30,
  spetsTeeWhite: 0xe0deda,
  spetsLeather: 0x73492d,
  spetsBootBrown: 0x6c4830,
  spetsBootSole: 0x362418,
  spetsKneePad: 0x675b4c,

  // 09: Silat Striker (Southeast Asian Martial Artist — Image 1)
  silatHair: 0x161414,
  silatJacketBlack: 0x1a1c21,
  silatJacketTrim: 0x262930,
  silatZipSilver: 0x8e96a2,
  silatGreyHem: 0xbac0c8,
  silatWatch: 0x141619,
  silatSportUpper: 0x181a1f,
  silatSportSole: 0x373c45,
  silatSportAccent: 0x555c68,

  // Weapons
  gunMetalDark: 0x25282c,
  gunMetalMid: 0x383d44,
  gunMetalLight: 0x7c838d,
  akWood: 0x844625,
  akWoodDark: 0x69361c,
};
