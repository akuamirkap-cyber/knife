import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { createRallyCarModel, DEFAULT_RALLY_BUILD } from '../arenas/rc-drift/pigeon/rally-model.js';
import { CAR_SCALE } from '../arenas/rc-drift/pigeon/rmx-drift-adapter';
import type { RallyBuild } from '../arenas/rc-drift/pigeon/rally-config';

/**
 * PRODRIFT menu diorama — a bright low-poly Mt. Haruna clearing: gradient sky with sun,
 * pine forest, ridge lines, a sweeping asphalt road and the existing Rally Group B model
 * parked hero-style. Rendered once behind the DOM menu overlay (transparent renderer opt-out:
 * the diorama is fully lit, the menu text sits above it).
 */
export default function MenuScene({ className, build = DEFAULT_RALLY_BUILD }: { className?: string; build?: RallyBuild }) {
  const host = useRef<HTMLDivElement>(null);
  const carRef = useRef<ReturnType<typeof createRallyCarModel> | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);

  useEffect(() => {
    const hostEl = host.current;
    if (!hostEl) return;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.domElement.setAttribute('aria-hidden', 'true');
    hostEl.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xd8e4e6, 105, 300);

    const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 600);
    camera.position.set(-3.2, 1.55, 8.15); // ~30% zoom out so the title doesn't sit on the car
    const lookAt = new THREE.Vector3(0.55, 1.02, 0.35);

    // --- sky dome with sun disc (reused HSL gradient recipe) ---
    const sunDir = new THREE.Vector3(-0.52, 0.62, 0.58).normalize();
    const domeUniforms = {
      topColor: { value: new THREE.Color().setHSL(0.6, 1, 0.62) },
      bottomColor: { value: new THREE.Color(0xffffff) },
      offset: { value: 33 },
      exponent: { value: 0.55 },
      sunDirection: { value: sunDir },
    };
    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(360, 32, 16),
      new THREE.ShaderMaterial({
        uniforms: domeUniforms,
        vertexShader: `varying vec3 vWorldPosition; void main() { vec4 wp = modelMatrix * vec4(position, 1.0); vWorldPosition = wp.xyz; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
        fragmentShader: `uniform vec3 topColor; uniform vec3 bottomColor; uniform float offset; uniform float exponent; uniform vec3 sunDirection; varying vec3 vWorldPosition;
          void main() {
            float h = normalize(vWorldPosition + offset).y;
            float f = max(pow(max(h, 0.0), exponent), 0.0);
            vec3 dir = normalize(vWorldPosition);
            float s = max(dot(dir, sunDirection), 0.0);
            float disc = pow(s, 1500.0) * 26.0;
            float inner = pow(s, 140.0) * 0.8;
            float glow = pow(s, 18.0) * 0.26;
            float wash = pow(s, 5.0) * 0.08;
            gl_FragColor = vec4(mix(bottomColor, topColor, f) + (disc + inner + glow + wash) * vec3(1.0, 0.93, 0.8), 1.0);
            #include <colorspace_fragment>
          }`,
        side: THREE.BackSide, depthWrite: false, fog: false,
      }),
    );
    dome.renderOrder = -30;
    scene.add(dome);

    // --- lights (the three.js HSL example rig, warm & bright) ---
    const hemi = new THREE.HemisphereLight(new THREE.Color().setHSL(0.6, 1, 0.6), new THREE.Color().setHSL(0.095, 1, 0.75), 1.9);
    hemi.position.set(0, 50, 0);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight(new THREE.Color().setHSL(0.1, 1, 0.95), 2.9);
    sun.position.set(-28, 40, 26);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 1, far: 120 });
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.03;
    scene.add(sun, sun.target);
    const bounce = new THREE.DirectionalLight(0xbdd3e8, 0.55);
    bounce.position.set(24, 8, -14);
    scene.add(bounce);

    // --- canvas-painted grass texture ---
    const grassCanvas = document.createElement('canvas'); grassCanvas.width = grassCanvas.height = 512;
    const g = grassCanvas.getContext('2d')!;
    g.fillStyle = '#77a84e'; g.fillRect(0, 0, 512, 512);
    const greens = ['#82b457', '#6a9a45', '#8fbe62', '#5d8c3e', '#93c468', '#71a04b'];
    for (let i = 0; i < 700; i++) {
      g.fillStyle = greens[i % greens.length];
      const r = 6 + Math.random() * 34;
      g.beginPath(); g.ellipse(Math.random() * 512, Math.random() * 512, r, r * (0.5 + Math.random() * 0.8), Math.random() * Math.PI, 0, Math.PI * 2); g.fill();
    }
    const grassTex = new THREE.CanvasTexture(grassCanvas);
    grassTex.wrapS = grassTex.wrapT = THREE.RepeatWrapping; grassTex.repeat.set(28, 28); grassTex.colorSpace = THREE.SRGBColorSpace; grassTex.anisotropy = 8;

    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(340, 48),
      new THREE.MeshStandardMaterial({ map: grassTex, roughness: 0.95 }),
    );
    ground.rotation.x = -Math.PI / 2; ground.position.y = -0.02; ground.receiveShadow = true;
    scene.add(ground);

    // --- sweeping asphalt road with edge lines ---
    const roadCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-150, 0, 44), new THREE.Vector3(-80, 0, 22), new THREE.Vector3(-34, 0, 7.5),
      new THREE.Vector3(6, 0, -1.5), new THREE.Vector3(48, 0, -6.5), new THREE.Vector3(100, 0, -18), new THREE.Vector3(150, 0, -34),
    ], false, 'catmullrom', 0.35);
    function ribbon(offsetA: number, offsetB: number, y: number, color: number, roughness = 0.9) {
      const N = 120, pos: number[] = [], idx: number[] = [];
      for (let i = 0; i <= N; i++) {
        const t = i / N, p = roadCurve.getPointAt(t), tan = roadCurve.getTangentAt(t);
        const nx = -tan.z, nz = tan.x;
        pos.push(p.x + nx * offsetA, y, p.z + nz * offsetA, p.x + nx * offsetB, y, p.z + nz * offsetB);
        if (i < N) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      geo.setIndex(idx); geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color, roughness, side: THREE.DoubleSide }));
      mesh.receiveShadow = true;
      scene.add(mesh);
      return mesh;
    }
    ribbon(-4.6, 4.6, 0.012, 0x3c3e42, 0.94);
    ribbon(-4.35, -4.05, 0.02, 0xe8e6df, 0.8);
    ribbon(4.05, 4.35, 0.02, 0xe8e6df, 0.8);
    // faded centre dashes
    const dashMat = new THREE.MeshStandardMaterial({ color: 0xd8c84a, roughness: 0.7, polygonOffset: true, polygonOffsetFactor: -2 });
    for (let t = 0.02; t < 1; t += 0.055) {
      const p = roadCurve.getPointAt(t), tan = roadCurve.getTangentAt(t), ang = Math.atan2(tan.x, tan.z);
      const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.28, 2.2), dashMat);
      dash.rotation.set(-Math.PI / 2, 0, ang);
      dash.position.set(p.x, 0.024, p.z);
      scene.add(dash);
    }

    // --- Mt. Haruna touge guardrails (red/white) along the road ---
    const railCanvas = document.createElement('canvas'); railCanvas.width = 256; railCanvas.height = 32;
    const rctx = railCanvas.getContext('2d')!;
    rctx.fillStyle = '#e8e6df'; rctx.fillRect(0, 0, 256, 32);
    rctx.fillStyle = '#c62b2b';
    for (let x = 0; x < 256; x += 64) rctx.fillRect(x, 0, 32, 32);
    const railTex = new THREE.CanvasTexture(railCanvas);
    railTex.wrapS = railTex.wrapT = THREE.RepeatWrapping; railTex.repeat.set(46, 1); railTex.colorSpace = THREE.SRGBColorSpace;
    function railRibbon(side: 1 | -1) {
      const N = 100, pos: number[] = [], uv: number[] = [], idx: number[] = [];
      for (let i = 0; i <= N; i++) {
        const t = i / N, p = roadCurve.getPointAt(t), tan = roadCurve.getTangentAt(t);
        const nx = -tan.z, nz = tan.x, off = side * 4.95;
        pos.push(p.x + nx * off, 0.28, p.z + nz * off, p.x + nx * off, 0.62, p.z + nz * off);
        uv.push(t * 46, 0, t * 46, 1);
        if (i < N) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
      geo.setIndex(idx); geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: railTex, side: THREE.DoubleSide, roughness: 0.6 }));
      scene.add(mesh);
    }
    railRibbon(1); railRibbon(-1);
    // rail posts
    const postGeo = new THREE.BoxGeometry(0.09, 0.42, 0.09);
    const postMat = new THREE.MeshStandardMaterial({ color: 0xc9c7bd, roughness: 0.7 });
    const postCount = Math.floor(roadCurve.getLength() / 2.6);
    const posts = new THREE.InstancedMesh(postGeo, postMat, postCount * 2);
    const postDummy = new THREE.Object3D();
    for (let i = 0; i < postCount; i++) {
      const t = i / (postCount - 1), p = roadCurve.getPointAt(t), tan = roadCurve.getTangentAt(t);
      const nx = -tan.z, nz = tan.x;
      for (let k = 0; k < 2; k++) {
        const side = k === 0 ? 1 : -1;
        postDummy.position.set(p.x + nx * side * 4.95, 0.2, p.z + nz * side * 4.95);
        postDummy.rotation.set(0, 0, 0); postDummy.updateMatrix();
        posts.setMatrixAt(i * 2 + k, postDummy.matrix);
      }
    }
    posts.frustumCulled = false;
    scene.add(posts);

    // --- Mt. Haruna start banner across the road ---
    const bannerCanvas = document.createElement('canvas'); bannerCanvas.width = 1024; bannerCanvas.height = 160;
    const bctx = bannerCanvas.getContext('2d')!;
    bctx.fillStyle = '#b3121b'; bctx.fillRect(0, 0, 1024, 160);
    bctx.fillStyle = '#ffd23f'; bctx.fillRect(0, 128, 1024, 20); bctx.fillRect(0, 12, 1024, 12);
    bctx.fillStyle = '#ffffff'; bctx.font = 'italic 900 84px "Barlow Condensed", "Arial Black", sans-serif'; bctx.textAlign = 'center'; bctx.textBaseline = 'middle';
    bctx.fillText('Mt. HARUNA TOUGE', 512, 82);
    const bannerTex = new THREE.CanvasTexture(bannerCanvas); bannerTex.colorSpace = THREE.SRGBColorSpace;
    const bannerGroup = new THREE.Group();
    const bp = roadCurve.getPointAt(0.62), btan = roadCurve.getTangentAt(0.62), bnx = -btan.z, bnz = btan.x;
    const bannerAngle = Math.atan2(btan.x, btan.z);
    const postMatB = new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: 0.5, metalness: 0.4 });
    for (const side of [1, -1]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, 3.4, 0.16), postMatB);
      post.position.set(side * 4.4, 1.7, 0);
      bannerGroup.add(post);
    }
    const beam = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.24, 0.18), postMatB);
    beam.position.set(0, 3.3, 0);
    bannerGroup.add(beam);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 1.15), new THREE.MeshStandardMaterial({ map: bannerTex, roughness: 0.6, emissive: 0xffffff, emissiveMap: bannerTex, emissiveIntensity: 0.25 }));
    face.position.set(0, 2.6, 0.1);
    bannerGroup.add(face);
    const face2 = face.clone();
    face2.position.z = -0.1; face2.rotation.y = Math.PI;
    bannerGroup.add(face2);
    bannerGroup.position.set(bp.x, 0, bp.z);
    bannerGroup.rotation.y = bannerAngle;
    scene.add(bannerGroup);

    // --- ridge lines of low-poly mountains ---
    function ridge(radius: number, peaks: number, minH: number, maxH: number, tint: number, jitter: number) {
      const positions: number[] = [], colors: number[] = [];
      const base = new THREE.Color(tint);
      const col = new THREE.Color();
      const ring = (r: number, y: number, n: number) => {
        const pts: THREE.Vector3[] = [];
        for (let i = 0; i <= n; i++) {
          const a = (i / n) * Math.PI * 2;
          pts.push(new THREE.Vector3(Math.cos(a) * (r + (Math.sin(i * 12.9898) * jitter)), y, Math.sin(a) * (r + (Math.cos(i * 78.233) * jitter))));
        }
        return pts;
      };
      const inner = ring(radius * 0.86, -2, peaks * 2), outer = ring(radius, -2, peaks * 2);
      const spike = (a: number, h: number, r: number) => new THREE.Vector3(Math.cos(a) * r, h, Math.sin(a) * r);
      for (let i = 0; i < peaks * 2; i++) {
        const a = (i / (peaks * 2)) * Math.PI * 2;
        const h = minH + Math.abs(Math.sin(i * 2.399 + radius)) * (maxH - minH);
        const tip = spike(a + Math.PI / (peaks * 2), h, radius * 0.97);
        const p0 = inner[i], p1 = inner[i + 1], q0 = outer[i], q1 = outer[i + 1];
        const shade = 0.72 + Math.abs(Math.sin(i * 1.7)) * 0.5;
        col.copy(base).multiplyScalar(shade);
        positions.push(p0.x, p0.y, p0.z, p1.x, p1.y, p1.z, tip.x, tip.y, tip.z);
        positions.push(q0.x, q0.y, q0.z, tip.x, tip.y, tip.z, q1.x, q1.y, q1.z);
        for (let k = 0; k < 6; k++) colors.push(col.r, col.g, col.b);
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
      geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 1 }));
      scene.add(mesh);
    }
    ridge(150, 26, 16, 42, 0x8496a3, 22);
    ridge(105, 20, 12, 30, 0x5e7268, 16);
    ridge(66, 14, 6, 17, 0x44584a, 10);

    // --- instanced low-poly pines ---
    const trunkGeo = new THREE.CylinderGeometry(0.11, 0.15, 0.9, 5); trunkGeo.translate(0, 0.45, 0);
    const cone1Geo = new THREE.ConeGeometry(1.05, 1.9, 6); cone1Geo.translate(0, 1.55, 0);
    const cone2Geo = new THREE.ConeGeometry(0.72, 1.35, 6); cone2Geo.translate(0, 2.6, 0);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5b3d24, roughness: 1, flatShading: true });
    const pineMat = new THREE.MeshStandardMaterial({ color: 0x3c6b34, roughness: 0.95, flatShading: true });
    const pineMat2 = new THREE.MeshStandardMaterial({ color: 0x2e5528, roughness: 0.95, flatShading: true });
    const COUNT = 110;
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, COUNT);
    const cones1 = new THREE.InstancedMesh(cone1Geo, pineMat, COUNT);
    const cones2 = new THREE.InstancedMesh(cone2Geo, pineMat2, COUNT);
    const roadPts: THREE.Vector3[] = [];
    for (let i = 0; i < 60; i++) roadPts.push(roadCurve.getPointAt(i / 59));
    const dummy = new THREE.Object3D();
    let placed = 0, guard = 0;
    while (placed < COUNT && guard++ < 4000) {
      const a = Math.random() * Math.PI * 2, r = 15 + Math.pow(Math.random(), 0.75) * 105;
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (roadPts.some(p => (p.x - x) * (p.x - x) + (p.z - z) * (p.z - z) < 30)) continue;
      dummy.position.set(x, 0, z);
      dummy.rotation.y = Math.random() * Math.PI;
      dummy.scale.setScalar(0.65 + Math.random() * 0.85);
      dummy.updateMatrix();
      trunks.setMatrixAt(placed, dummy.matrix);
      cones1.setMatrixAt(placed, dummy.matrix);
      cones2.setMatrixAt(placed, dummy.matrix);
      placed++;
    }
    trunks.frustumCulled = cones1.frustumCulled = cones2.frustumCulled = false;
    scene.add(trunks, cones1, cones2);

    // --- rocks ---
    const rockGeo = new THREE.DodecahedronGeometry(0.7, 0);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x8d9297, roughness: 1, flatShading: true });
    for (let i = 0; i < 14; i++) {
      const rock = new THREE.Mesh(rockGeo, rockMat);
      const a = Math.random() * Math.PI * 2, r = 16 + Math.random() * 55;
      rock.position.set(Math.cos(a) * r, 0.1, Math.sin(a) * r);
      if (roadPts.some(p => (p.x - rock.position.x) ** 2 + (p.z - rock.position.z) ** 2 < 26)) continue;
      rock.scale.set(0.5 + Math.random() * 1.6, 0.4 + Math.random() * 0.9, 0.5 + Math.random() * 1.6);
      rock.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
      rock.castShadow = true;
      scene.add(rock);
    }

    // --- the existing Rally Group B model, parked hero ---
    const car = createRallyCarModel({ THREE, build, headlights: true });
    car.scale.setScalar(CAR_SCALE * 1.12);
    car.position.set(0.4, 0, 0.7);
    car.rotation.y = -1.15;
    car.traverse(object => {
      const mesh = object as THREE.Mesh;
      if (mesh.isMesh) { mesh.castShadow = true; mesh.receiveShadow = true; }
    });
    scene.add(car);
    carRef.current = car;
    sceneRef.current = scene;

    // --- yellow crates (reference vibe) ---
    const crateMat = new THREE.MeshStandardMaterial({ color: 0xd9b23c, roughness: 0.85 });
    const crateEdge = new THREE.MeshStandardMaterial({ color: 0xa8802a, roughness: 0.9 });
    const crateGeo = new THREE.BoxGeometry(1, 1, 1);
    const crateSpots: [number, number, number, number][] = [[6.4, 0.62, 3.4, 1.15], [8.1, 0.5, 4.6, 0.9], [7.4, 1.62, 4.0, 0.72], [-7.2, 0.55, 4.9, 1.0]];
    for (const [x, y, z, s] of crateSpots) {
      const crate = new THREE.Group();
      const box = new THREE.Mesh(crateGeo, crateMat); box.scale.set(s, s, s); box.castShadow = true; box.receiveShadow = true;
      const lid = new THREE.Mesh(crateGeo, crateEdge); lid.scale.set(s * 1.02, s * 0.09, s * 1.02); lid.position.y = s * 0.47;
      crate.add(box, lid);
      crate.position.set(x, y, z);
      crate.rotation.y = Math.random() * Math.PI;
      scene.add(crate);
    }

    // --- resize + loop ---
    const resize = () => {
      const w = hostEl.clientWidth, h = hostEl.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(hostEl);
    const clock = new THREE.Clock();
    let frame = 0, last = 0;
    const tick = () => {
      frame = requestAnimationFrame(tick);
      const t = clock.getElapsedTime();
      if (t - last < 1 / 60) return;
      last = t;
      camera.position.set(-3.2 + Math.sin(t * 0.32) * 0.3, 1.55 + Math.sin(t * 0.5) * 0.06, 8.15 + Math.cos(t * 0.27) * 0.22);
      camera.lookAt(lookAt);
      car.rotation.y = -1.15 + Math.sin(t * 0.4) * 0.012;
      renderer.render(scene, camera);
    };
    tick();

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      scene.traverse(object => {
        const mesh = object as THREE.Mesh;
        if (!mesh.isMesh) return;
        mesh.geometry?.dispose();
        const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(material)) for (const entry of material) entry.dispose();
        else material?.dispose();
      });
      grassTex.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  // swap the car live when the build changes (garage overlay)
  useEffect(() => {
    const scene = sceneRef.current, old = carRef.current;
    if (!scene || !old) return;
    const fresh = createRallyCarModel({ THREE, build, headlights: true });
    fresh.scale.setScalar(CAR_SCALE * 1.12);
    fresh.position.set(0.4, 0, 0.7);
    fresh.rotation.y = -1.15 + Math.sin(performance.now() * 0.0004) * 0.01;
    fresh.traverse(object => {
      const mesh = object as THREE.Mesh;
      if (mesh.isMesh) { mesh.castShadow = true; mesh.receiveShadow = true; }
    });
    scene.remove(old);
    old.traverse(object => {
      const mesh = object as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.geometry?.dispose();
      const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(material)) for (const entry of material) entry.dispose();
      else material?.dispose();
    });
    scene.add(fresh);
    carRef.current = fresh;
  }, [build]);

  return <div ref={host} className={className} aria-hidden="true" />;
}
