import * as THREE from 'three';

/**
 * Atmospheric fog for every built-in material:
 * exponential-squared distance fog, thicker in the valleys (low altitude haze) and
 * slightly bluer with distance (aerial perspective) so far ridges stack up in layers.
 */
export function installFog() {
  const C = THREE.ShaderChunk as Record<string, string>;
  C.fog_pars_vertex = /* glsl */ `
#ifdef USE_FOG
  varying float vFogDepth;
  varying float vFogWY;
#endif`;
  C.fog_vertex = /* glsl */ `
#ifdef USE_FOG
  vFogDepth = - mvPosition.z;
  vFogWY = cameraPosition.y + dot( viewMatrix[ 1 ].xyz, mvPosition.xyz );
#endif`;
  C.fog_pars_fragment = /* glsl */ `
#ifdef USE_FOG
  uniform vec3 fogColor;
  varying float vFogDepth;
  varying float vFogWY;
  #ifdef FOG_EXP2
    uniform float fogDensity;
  #else
    uniform float fogNear;
    uniform float fogFar;
  #endif
#endif`;
  C.fog_fragment = /* glsl */ `
#ifdef USE_FOG
  #ifdef FOG_EXP2
    float lowAir = exp( - max( vFogWY - 40.0, 0.0 ) * 0.0038 );
    float dens = fogDensity * mix( 0.5, 1.55, lowAir );
    float fogFactor = 1.0 - exp( - dens * dens * vFogDepth * vFogDepth );
    float far01 = clamp( vFogDepth / 5000.0, 0.0, 1.0 );
    vec3 fogTint = mix( fogColor, fogColor * vec3( 0.90, 0.96, 1.06 ), far01 * 0.85 );
    gl_FragColor.rgb = mix( gl_FragColor.rgb, fogTint, fogFactor );
  #else
    float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
    gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
  #endif
#endif`;
}
