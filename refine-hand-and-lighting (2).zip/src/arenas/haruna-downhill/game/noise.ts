// Small deterministic helpers: RNG, gradient noise, fbm.

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export function mulberry32(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const perm = new Uint8Array(512);
(() => {
  const r = mulberry32(20240);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
})();

const G2 = [
  [1, 1],
  [-1, 1],
  [1, -1],
  [-1, -1],
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
];
const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);

/** Perlin gradient noise, roughly in [-1, 1] */
export function noise2(x: number, y: number) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const X = xi & 255;
  const Y = yi & 255;
  const aa = perm[perm[X] + Y];
  const ab = perm[perm[X] + Y + 1];
  const ba = perm[perm[X + 1] + Y];
  const bb = perm[perm[X + 1] + Y + 1];
  const g = (h: number, dx: number, dy: number) => {
    const q = G2[h & 7];
    return q[0] * dx + q[1] * dy;
  };
  const u = fade(xf);
  const v = fade(yf);
  const x1 = lerp(g(aa, xf, yf), g(ba, xf - 1, yf), u);
  const x2 = lerp(g(ab, xf, yf - 1), g(bb, xf - 1, yf - 1), u);
  return lerp(x1, x2, v) * 1.5;
}

export function fbm(x: number, y: number, oct = 4, lac = 2, gain = 0.5) {
  let amp = 1;
  let f = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += noise2(x * f + i * 17.3, y * f - i * 9.1) * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / norm;
}

export function ridged(x: number, y: number, oct = 4) {
  let amp = 1;
  let f = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < oct; i++) {
    const n = 1 - Math.abs(noise2(x * f + i * 5.7, y * f + i * 3.3));
    sum += n * n * amp;
    norm += amp;
    amp *= 0.5;
    f *= 2.07;
  }
  return sum / norm; // 0..1
}

/** 1D smooth (Catmull-Rom) interpolation through control points [[t, v], ...] */
export function curve1D(pts: number[][], t: number) {
  const n = pts.length;
  if (t <= pts[0][0]) return pts[0][1];
  if (t >= pts[n - 1][0]) return pts[n - 1][1];
  let i = 0;
  while (i < n - 2 && t > pts[i + 1][0]) i++;
  const p0 = pts[Math.max(0, i - 1)];
  const p1 = pts[i];
  const p2 = pts[i + 1];
  const p3 = pts[Math.min(n - 1, i + 2)];
  const h = p2[0] - p1[0];
  const u = (t - p1[0]) / h;
  // finite-difference tangents (non-uniform)
  const m1 = (p2[1] - p0[1]) / (p2[0] - p0[0]);
  const m2 = (p3[1] - p1[1]) / (p3[0] - p1[0]);
  const u2 = u * u;
  const u3 = u2 * u;
  return (
    (2 * u3 - 3 * u2 + 1) * p1[1] +
    (u3 - 2 * u2 + u) * h * m1 +
    (-2 * u3 + 3 * u2) * p2[1] +
    (u3 - u2) * h * m2
  );
}
