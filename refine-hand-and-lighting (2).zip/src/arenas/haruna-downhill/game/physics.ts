import type { Track } from './trackLayout';
import { clamp, smoothstep } from './noise';

export interface CarInput {
  throttle: number; // 0..1
  brake: number; // 0..1
  steer: number; // -1..1, + = left
  handbrake: boolean;
  clutch: boolean;
}

const G = 9.81;
const M = 1050;
const IZ = 1500;
const A = 1.1; // CG -> front axle
const B = 1.3; // CG -> rear axle
const L = A + B;
const HCG = 0.5;
const POWER = 100000; // W
const WALL = 5.75;

function tire(alpha: number, fz: number, mu: number, stiff = 9.5, shape = 1.45) {
  return -mu * fz * Math.sin(shape * Math.atan(stiff * alpha));
}

export class CarSim {
  x = 0;
  z = 0;
  psi = 0;
  u = 0; // forward speed (m/s)
  v = 0; // left speed
  w = 0; // yaw rate (+ = left)
  delta = 0;
  steerSm = 0;
  thr = 0;
  rpm = 1000;
  gear = 1;
  ax = 0;
  ay = 0;
  idx = 0;
  lat = 0; // lateral offset from centreline (+ left)
  slip = 0; // body side-slip (rad)
  frontSlip = 0;
  rearSlip = 0;
  rearSpin = 0; // 0..1 how much the rear tyres are sliding/spinning
  kick = 0;
  wallHit = 0; // impulse strength of the latest wall contact (for camera shake / sounds)
  y = 0;
  pitch = 0;
  roll = 0;
  grade = 0;
  assist = 0.75;
  onWall = false;
  speedKmh = 0;
  slipPrev = 0;
  gains = { kb: 28, kw: 0.8, kd: 5 };
  betaDotF = 0;
  dVelDbg = 0;

  reset(track: Track, s: number, lat = 0) {
    const i = clamp(Math.floor(s), 0, track.n - 2);
    const ps = track.psi[i];
    this.psi = ps;
    this.x = track.x[i] + lat * Math.cos(ps);
    this.z = track.z[i] - lat * Math.sin(ps);
    this.u = 0;
    this.v = 0;
    this.w = 0;
    this.delta = 0;
    this.steerSm = 0;
    this.thr = 0;
    this.idx = i;
    this.kick = 0;
    this.slip = 0;
    this.rearSpin = 0;
    this.wallHit = 0;
    this.updateRoad(track);
  }

  get vxw() {
    return this.u * Math.sin(this.psi) + this.v * Math.cos(this.psi);
  }
  get vzw() {
    return this.u * Math.cos(this.psi) - this.v * Math.sin(this.psi);
  }

  private findIdx(track: Track, global = false) {
    const lo = global ? 0 : Math.max(0, this.idx - 40);
    const hi = global ? track.n - 1 : Math.min(track.n - 1, this.idx + 60);
    let best = 1e12;
    let bi = this.idx;
    for (let i = lo; i <= hi; i++) {
      const dx = this.x - track.x[i];
      const dz = this.z - track.z[i];
      const d = dx * dx + dz * dz;
      if (d < best) {
        best = d;
        bi = i;
      }
    }
    this.idx = bi;
  }

  updateRoad(track: Track) {
    this.findIdx(track);
    const i = this.idx;
    const ps = track.psi[i];
    const dx = this.x - track.x[i];
    const dz = this.z - track.z[i];
    this.lat = dx * Math.cos(ps) - dz * Math.sin(ps);
    const along = dx * Math.sin(ps) + dz * Math.cos(ps);
    const j = clamp(i + (along >= 0 ? 1 : -1), 0, track.n - 1);
    const dyds = (track.y[j] - track.y[i]) * (along >= 0 ? 1 : -1);
    this.y = track.y[i] + dyds * along;
    this.grade = -dyds; // + = downhill along travel direction
  }

  step(dt: number, inp: CarInput, track: Track, locked = false) {
    // --- driver input smoothing ---
    const thTarget = locked ? 0 : inp.throttle;
    const rate = thTarget > this.thr ? 5.5 : 14;
    this.thr += (thTarget - this.thr) * Math.min(1, dt * rate);
    const stTarget = locked ? 0 : inp.steer;
    const sr = Math.abs(stTarget) > Math.abs(this.steerSm) ? 5.2 : 8;
    this.steerSm += (stTarget - this.steerSm) * Math.min(1, dt * sr);

    const speed = Math.hypot(this.u, this.v);
    const uAbs = Math.max(Math.abs(this.u), 2.0);
    this.slip = Math.atan2(this.v, Math.max(Math.abs(this.u), 0.8));

    // --- steering: normal grip steering + RC-drift "gyro" controller ---
    const aSlip = Math.abs(this.slip);
    const fwd = this.u > 2 ? 1 : 0;
    const dMax = 0.56 / (1 + Math.pow(speed / 12, 1.5));
    const slideAmt = smoothstep(0.05, 0.26, aSlip) * fwd;
    const hbOn = inp.handbrake && !locked;
    const kickOn = this.kick > 0.05;
    let delta = this.steerSm * dMax * (1 + 0.35 * slideAmt);
    let tq = 0;
    let tqAmt = 0;
    const dVel = clamp(Math.atan2(this.v + A * this.w, uAbs), -0.62, 0.62);
    this.dVelDbg = dVel;
    if (this.assist > 0) {
      // the stick sets the DRIFT ANGLE we want; the gyro counter-steers to hold it
      const betaMax = 0.40 + 0.2 * smoothstep(8, 20, speed);
      const betaDes = -this.steerSm * betaMax * smoothstep(3, 9, speed);
      const betaDot = (this.slip - this.slipPrev) / Math.max(dt, 1e-4);
      this.slipPrev = this.slip;
      const bd = clamp(this.betaDotF + (betaDot - this.betaDotF) * Math.min(1, dt * 18), -4, 4);
      this.betaDotF = bd;
      const err = this.slip - betaDes;
      // yaw-rate reference from the bend ahead, signed by the stick (the "gyro" part)
      const ia = clamp(this.idx + Math.floor(this.u * 0.35) + 4, 0, track.n - 1);
      const kRoad = clamp(Math.abs(track.kappa[ia]), 0.011, 0.06);
      const wRef = this.steerSm * kRoad * Math.max(this.u, 4) * smoothstep(3, 9, speed);
      const g = this.gains;
      const dDrift = clamp(dVel + g.kw * (wRef - this.w), -0.62, 0.62);
      // virtual gyro torque: holds the slide angle the stick asks for (authority-limited)
      tq = clamp(g.kb * err + g.kd * bd, -9, 9);
      const engaged = Math.max(slideAmt, hbOn || kickOn ? 0.55 * fwd : 0) * this.assist;
      tqAmt = Math.max(slideAmt, hbOn || kickOn ? 0.5 * fwd : 0) * this.assist;
      delta = delta + (dDrift - delta) * engaged;
      // when the nose is far past the slide angle the stick can never push it further
      const over = smoothstep(0.75, 1.05, aSlip) * fwd;
      delta = delta + (dVel - delta) * over;
    } else {
      this.slipPrev = this.slip;
      const slide = slideAmt;
      delta += dVel * 0.4 * slide;
    }
    delta = clamp(delta, -0.64, 0.64);
    this.delta += (delta - this.delta) * Math.min(1, dt * 22);
    const d = this.delta;
    const sd = Math.sin(d);
    const cd = Math.cos(d);

    // --- load transfer ---
    let fzf = (M * G * B) / L - (M * this.ax * HCG) / L;
    let fzr = (M * G * A) / L + (M * this.ax * HCG) / L;
    fzf = Math.max(fzf, 2500);
    fzr = Math.max(fzr, 2500);

    // --- longitudinal demands ---
    const reversing = this.u < -0.5 || (inp.brake > 0.1 && this.u < 0.8 && inp.throttle < 0.1 && !locked);
    let drive = 0;
    if (!reversing) drive = this.thr * Math.min(POWER / Math.max(speed, 6.5), 7600);
    else drive = -(inp.brake * 3200) * (this.u > -9 ? 1 : 0);
    if (this.kick > 0) {
      drive += 9500 * Math.min(1, this.kick * 3);
      this.kick -= dt;
    }
    let brake = !reversing && !locked ? inp.brake * 9800 : locked ? 12000 : 0;
    if (locked && Math.abs(this.u) < 0.2) brake = 0;
    const engineBrake = this.thr < 0.05 ? 320 + 18 * Math.abs(this.u) : 0;
    let drag = 0.62 * this.u * Math.abs(this.u) + 210 * Math.sign(this.u);
    // drift governor: while sliding, hold a speed that suits the bend (like a good RC gyro/ESC)
    let driftPush = 0;
    if (this.assist > 0 && !locked && this.u > 3) {
      const R = 1 / Math.max(Math.abs(track.kappa[this.idx]), 1 / 450);
      const vT = clamp(Math.sqrt(8.2 * R), 10, 30);
      const dmA = smoothstep(0.1, 0.32, aSlip);
      if (this.u > vT) {
        const over = clamp((this.u - vT) / 1.8, 0, 1);
        drive *= 1 - over * dmA;
        drag += 3600 * over * dmA * this.assist;
      } else if (this.thr > 0.3) {
        driftPush = 1500 * dmA * this.thr * clamp((vT - this.u) / 3, 0, 1);
      }
    }
    const hb = inp.handbrake && !locked;

    const muF = 1.18;
    const muR = 1.12;
    // brake split 64/36 (front/rear) + handbrake on the rear
    const sgnU = this.u >= 0 ? 1 : -1;
    let fxfBrake = Math.min(brake * 0.64, muF * fzf * 0.95) * -sgnU;
    let fxrBrake = Math.min(brake * 0.36, muR * fzr * 0.95) * -sgnU;
    if (hb) fxrBrake += -sgnU * Math.min(0.55 * muR * fzr, 5200);
    const driveLimit = muR * fzr;
    const driveApplied = clamp(drive, -driveLimit, driveLimit);
    const demand = Math.abs(drive) / driveLimit; // >1 means wheelspin
    const rearUse = clamp(Math.abs(driveApplied + fxrBrake) / driveLimit, 0, 1);
    const frontUse = clamp(Math.abs(fxfBrake) / (muF * fzf), 0, 1);

    // --- lateral tyre forces ---
    const vFront = this.v + A * this.w;
    const vRear = this.v - B * this.w;
    const latWf = -this.u * sd + vFront * cd;
    const lonWf = this.u * cd + vFront * sd;
    const alphaF = Math.atan2(latWf, Math.max(Math.abs(lonWf), 1.6));
    const alphaR = Math.atan2(vRear, uAbs);
    const circleF = Math.sqrt(Math.max(0.12, 1 - frontUse * frontUse * 0.85));
    let circleR = Math.sqrt(Math.max(0.1, 1 - rearUse * rearUse * 0.45));
    // wheelspin beyond the limit steals extra lateral grip -> power oversteer
    circleR *= 1 - 0.5 * clamp(demand - 0.85, 0, 1.4) * Math.min(1, this.thr * 1.4);
    if (hb) circleR *= 0.5;
    if (this.assist > 0 && !locked) {
      const po = smoothstep(0.45, 0.9, Math.abs(this.steerSm)) * smoothstep(8, 13, speed) * smoothstep(0.55, 0.95, this.thr);
      circleR *= 1 - 0.34 * po * this.assist * (1 - smoothstep(0.3, 0.6, aSlip));
    }
    if (this.kick > 0.05) circleR *= this.assist > 0 ? 0.5 : 0.34;
    // drift stabiliser: once the slide is deep the rear tyres bite again, so a held drift settles
    // at a controllable angle instead of spinning out
    const stab = smoothstep(0.34, 0.72, Math.abs(this.slip)) * (0.35 + 0.65 * this.assist) * (hb ? 0.35 : 1);
    circleR += (0.95 - circleR) * stab;
    circleR = Math.max(circleR, this.assist > 0 ? 0.2 + 0.32 * this.assist : 0.17);
    const fyF = tire(alphaF, fzf, muF * circleF);
    const fyR = tire(alphaR, fzr, muR * circleR, 8.5, 1.4);
    this.frontSlip = alphaF;
    this.rearSlip = alphaR;
    this.rearSpin = clamp(
      Math.abs(alphaR) / 0.2 * 0.8 + (demand > 1 ? (demand - 1) * 0.6 : 0) + (hb ? 0.6 : 0) + (this.kick > 0 ? 0.5 : 0),
      0,
      1.5
    );

    // --- body forces ---
    const fxBody = driveApplied + driftPush + fxrBrake + fxfBrake * cd - fyF * sd - drag - sgnU * engineBrake;
    const fyBody = fyF * cd + fyR + fxfBrake * sd;
    const mz = A * (fyF * cd + fxfBrake * sd) - B * fyR;

    let aU = fxBody / M + this.v * this.w;
    let aV = fyBody / M - this.u * this.w;
    const aW = mz / IZ;
    let aW2 = aW + tq * tqAmt;
    if (this.assist > 0) {
      // never let the car swing past ~60 degrees: gentle torque back towards the travel direction
      aW2 -= Math.sign(this.slip) * 7.5 * smoothstep(0.85, 1.25, aSlip) * this.assist * (this.u > 1.5 ? 1 : 0);
      // dynamic yaw-rate ceiling from the bend ahead: the car can swing, but never whip around
      const ia2 = clamp(this.idx + Math.floor(this.u * 0.35) + 4, 0, track.n - 1);
      const kR = clamp(Math.abs(track.kappa[ia2]), 0.011, 0.06);
      const wLim = clamp(1.4 * Math.max(this.u, 6) * kR + 0.4, 0.95, 2.0);
      if (Math.abs(this.w) > wLim) aW2 -= Math.sign(this.w) * (Math.abs(this.w) - wLim) * 16 * this.assist;
    }

    // gravity along the road
    const gs = this.grade * G * 0.62;
    const dpsi = this.psi - track.psi[this.idx];
    aU += gs * Math.cos(dpsi);
    aV += gs * Math.sin(-dpsi);

    this.ax += (aU - this.ax) * Math.min(1, dt * 7);
    this.ay += (aV - this.ay) * Math.min(1, dt * 7);

    this.u += aU * dt;
    this.v += aV * dt;
    this.w += aW2 * dt;
    // low speed stabilisation
    if (speed < 3) {
      const k = 1 - speed / 3;
      this.v *= 1 - Math.min(1, dt * 8 * k);
      this.w *= 1 - Math.min(1, dt * 6 * k);
    }
    this.w *= 1 - Math.min(1, dt * (0.35 + 2.4 * smoothstep(0.32, 0.85, Math.abs(this.slip)) * (0.4 + 0.6 * this.assist)));
    if (locked && Math.abs(this.u) < 0.4) {
      this.u = 0;
      this.v *= 0.9;
    }

    // --- integrate ---
    this.psi += this.w * dt;
    const sp = Math.sin(this.psi);
    const cp = Math.cos(this.psi);
    this.x += (this.u * sp + this.v * cp) * dt;
    this.z += (this.u * cp - this.v * sp) * dt;

    // --- road + walls ---
    this.updateRoad(track);
    this.collide(track);
    this.updateRoad(track);

    // --- drivetrain display ---
    const kmh = Math.abs(this.u) * 3.6;
    this.speedKmh = kmh;
    const gearTop = [48, 82, 118, 158, 210];
    let g = 0;
    while (g < 4 && kmh > gearTop[g] * 0.93) g++;
    this.gear = this.u < -0.5 ? -1 : g + 1;
    const lo = g === 0 ? 0 : gearTop[g - 1] * 0.93;
    const hi = gearTop[g] * 0.93;
    const target = 2200 + ((kmh - lo) / Math.max(1, hi - lo)) * 5600 + this.thr * 600;
    this.rpm += (target - this.rpm) * Math.min(1, dt * 10);
    this.pitch = clamp(Math.atan(this.grade * Math.cos(dpsi)) * 0.9 - this.ax * 0.0035, -0.25, 0.25);
    this.roll = clamp(this.ay * 0.006 + this.w * 0.02, -0.12, 0.12);
  }

  private collide(track: Track) {
    this.wallHit = 0;
    this.onWall = false;
    const i = this.idx;
    const ps = track.psi[i];
    const dpsi = Math.atan2(Math.sin(this.psi - ps), Math.cos(this.psi - ps));
    const ext = Math.abs(Math.sin(dpsi)) * 2.05 + Math.abs(Math.cos(dpsi)) * 0.86;
    const lx = Math.cos(ps);
    const lz = -Math.sin(ps);
    for (const sgn of [1, -1]) {
      const over = sgn * this.lat + ext - WALL;
      if (over > 0) {
        this.onWall = true;
        // push back
        this.x -= lx * sgn * over;
        this.z -= lz * sgn * over;
        const vwx = this.vxw;
        const vwz = this.vzw;
        const vn = (vwx * lx + vwz * lz) * sgn; // velocity into the wall
        if (vn > 0) {
          const e = 0.22;
          const dvx = -(1 + e) * vn * lx * sgn;
          const dvz = -(1 + e) * vn * lz * sgn;
          const nvx = vwx + dvx;
          const nvz = vwz + dvz;
          // scrape friction along the rail
          const fr = 1 - Math.min(0.22, vn * 0.018 + 0.004);
          const sp = Math.sin(this.psi);
          const cp = Math.cos(this.psi);
          this.u = (nvx * sp + nvz * cp) * fr;
          this.v = (nvx * cp - nvz * sp) * fr;
          this.wallHit = vn;
          // nose gets knocked away from the wall
          this.w += -sgn * clamp(Math.sin(dpsi) * 0.0, -1, 1) - sgn * Math.sign(dpsi * sgn) * Math.min(1.2, vn * 0.05) * -1;
          this.w *= 0.7;
        } else {
          this.u *= 0.9985;
        }
      }
    }
  }

  /** force a physical re-spawn near the road */
  respawn(track: Track, s: number) {
    this.reset(track, s, 0);
  }
}
