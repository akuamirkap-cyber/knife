// Synthesized RC audio: brushless motor whine, gear whine, plastic-tyre hiss.
export class AudioEngine {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private motorA!: OscillatorNode;
  private motorB!: OscillatorNode;
  private gear!: OscillatorNode;
  private motorGain!: GainNode;
  private gearGain!: GainNode;
  private motorFilter!: BiquadFilterNode;
  private slideFilter!: BiquadFilterNode;
  private slideGain!: GainNode;
  private noiseBuf!: AudioBuffer;
  private enabled = true;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.enabled ? 0.55 : 0;
    const comp = ctx.createDynamicsCompressor();
    this.master.connect(comp);
    comp.connect(ctx.destination);

    // motor
    this.motorFilter = ctx.createBiquadFilter();
    this.motorFilter.type = 'lowpass';
    this.motorFilter.frequency.value = 900;
    this.motorFilter.Q.value = 2;
    this.motorGain = ctx.createGain();
    this.motorGain.gain.value = 0;
    this.motorA = ctx.createOscillator();
    this.motorA.type = 'sawtooth';
    this.motorB = ctx.createOscillator();
    this.motorB.type = 'square';
    const bGain = ctx.createGain();
    bGain.gain.value = 0.35;
    this.motorA.connect(this.motorFilter);
    this.motorB.connect(bGain).connect(this.motorFilter);
    this.motorFilter.connect(this.motorGain).connect(this.master);
    this.gear = ctx.createOscillator();
    this.gear.type = 'triangle';
    this.gearGain = ctx.createGain();
    this.gearGain.gain.value = 0;
    this.gear.connect(this.gearGain).connect(this.master);
    this.motorA.start();
    this.motorB.start();
    this.gear.start();

    // tyre noise
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuf;
    noise.loop = true;
    this.slideFilter = ctx.createBiquadFilter();
    this.slideFilter.type = 'bandpass';
    this.slideFilter.frequency.value = 2000;
    this.slideFilter.Q.value = 1.1;
    this.slideGain = ctx.createGain();
    this.slideGain.gain.value = 0;
    noise.connect(this.slideFilter).connect(this.slideGain).connect(this.master);
    noise.start();
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.ctx) this.master.gain.setTargetAtTime(v ? 0.55 : 0, this.ctx.currentTime, 0.05);
  }

  update(rpm: number, throttle: number, slide: number, speed: number) {
    const ctx = this.ctx;
    if (!ctx || !this.enabled) return;
    const t = ctx.currentTime;
    const f = 55 + rpm * 820;
    this.motorA.frequency.setTargetAtTime(f, t, 0.03);
    this.motorB.frequency.setTargetAtTime(f * 1.5, t, 0.03);
    this.gear.frequency.setTargetAtTime(f * 3.1, t, 0.03);
    this.motorFilter.frequency.setTargetAtTime(500 + rpm * 3200 + throttle * 800, t, 0.05);
    this.motorGain.gain.setTargetAtTime(0.025 + throttle * 0.09 + rpm * 0.05, t, 0.05);
    this.gearGain.gain.setTargetAtTime(rpm * 0.018, t, 0.05);
    const sl = Math.min(1, slide) * Math.min(1, speed / 1.5);
    this.slideFilter.frequency.setTargetAtTime(1300 + sl * 1900 + speed * 60, t, 0.05);
    this.slideGain.gain.setTargetAtTime(sl * 0.2, t, 0.04);
  }

  silence() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.motorGain.gain.setTargetAtTime(0, t, 0.05);
    this.gearGain.gain.setTargetAtTime(0, t, 0.05);
    this.slideGain.gain.setTargetAtTime(0, t, 0.05);
  }

  hit(strength: number) {
    const ctx = this.ctx;
    if (!ctx || !this.enabled) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 700;
    const g = ctx.createGain();
    const t = ctx.currentTime;
    g.gain.setValueAtTime(Math.min(0.5, strength * 0.18), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random());
    src.stop(t + 0.2);
  }

  beep(freq = 1800, dur = 0.06, times = 1) {
    const ctx = this.ctx;
    if (!ctx || !this.enabled) return;
    for (let k = 0; k < times; k++) {
      const o = ctx.createOscillator();
      o.type = 'square';
      o.frequency.value = freq;
      const g = ctx.createGain();
      const t = ctx.currentTime + k * (dur + 0.05);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.06, t + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + dur + 0.02);
    }
  }
}
