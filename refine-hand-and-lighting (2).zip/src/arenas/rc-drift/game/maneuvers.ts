// ============================================================
//  Donut & figure-8 detector (RC units, shared by RC + Rally)
//  A "lobe" = continuous rotation in one direction (with hysteresis)
//  while sliding at low/medium speed.
//   • every 360° inside one lobe            -> DONUT (streak 1,2,3…)
//   • two consecutive opposite lobes ≥ 250° -> ANGKA 8
// ============================================================
export type ManeuverEvent =
  | { type: 'donut'; streak: number; dir: number; total: number }
  | { type: 'eight'; count: number };

export interface ManeuverInput {
  r: number; // yaw rate rad/s
  u: number; // forward speed m/s
  v: number; // lateral speed m/s
  speed: number; // m/s
}

const TAU = Math.PI * 2;
const HALF_MIN = (250 * Math.PI) / 180;

export class ManeuverDetector {
  donuts = 0;
  eights = 0;
  streak = 0;
  /** 0..1 progress of the current 360° loop (HUD). */
  progress = 0;
  dir = 0;
  private rot = 0; // rotation in the current lobe (rad)
  private slideT = 0;
  private lobeT = 0;
  private looseT = 0;
  private t = 0;
  private prev: { dir: number; end: number; ok: boolean } | null = null;

  reset() {
    this.rot = this.slideT = this.lobeT = this.looseT = this.progress = 0;
    this.dir = this.streak = 0;
    this.prev = null;
  }

  private endLobe(): ManeuverEvent | null {
    let ev: ManeuverEvent | null = null;
    const ok = this.dir !== 0 && this.rot >= HALF_MIN && this.slideT >= this.lobeT * 0.55;
    if (ok && this.prev && this.prev.ok && this.prev.dir === -this.dir && this.t - this.lobeT - this.prev.end < 1.6) {
      this.eights++;
      ev = { type: 'eight', count: this.eights };
      this.prev = null; // non-overlapping pairs
    } else {
      this.prev = { dir: this.dir, end: this.t, ok };
    }
    this.rot = this.slideT = this.lobeT = this.progress = 0;
    this.streak = 0;
    return ev;
  }

  step(dt: number, c: ManeuverInput): ManeuverEvent | null {
    this.t += dt;
    const beta = Math.abs(Math.atan2(c.v, Math.max(Math.abs(c.u), 0.05)));
    const inZone = c.speed < 4.6 && c.u > -0.3;
    let ev: ManeuverEvent | null = null;

    // lobe boundaries (hysteresis on yaw rate) — close the running lobe exactly once
    if (this.dir !== 0 && (c.r * this.dir < -0.6 || !inZone)) {
      ev = this.endLobe();
      this.dir = 0;
    }
    if (!inZone) return ev;
    if (this.dir === 0) {
      if (Math.abs(c.r) <= 0.6) return ev;
      this.dir = Math.sign(c.r);
      this.looseT = 0;
    }

    // stopped rotating for a while -> lobe over
    if (Math.abs(c.r) < 0.35) {
      this.looseT += dt;
      if (this.looseT > 0.8) {
        const e = this.endLobe();
        this.dir = 0;
        return ev ?? e;
      }
    } else this.looseT = 0;

    this.lobeT += dt;
    if (beta > 0.26 && c.speed > 0.4) this.slideT += dt;
    if (c.r * this.dir > 0) this.rot += Math.abs(c.r) * dt;
    const loops = Math.floor(this.rot / TAU);
    this.progress = (this.rot % TAU) / TAU;
    if (loops > this.streak && this.slideT >= this.lobeT * 0.6) {
      this.streak = loops;
      this.donuts++;
      ev = ev ?? { type: 'donut', streak: this.streak, dir: this.dir, total: this.donuts };
    }
    return ev;
  }
}
