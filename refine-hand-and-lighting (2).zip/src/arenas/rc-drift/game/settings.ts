// ============================================================
//  Settings, presets & tiny reactive stores (no external libs)
// ============================================================

export type Drivetrain = 'RWD' | 'AWD';
export type TireType = 'hard' | 'standard' | 'soft';
export type SurfaceType = 'ptile' | 'concrete' | 'carpet';
export type MotorPos = 'low' | 'high';

export interface Settings {
  // Gyro & drivetrain
  gyroOn: boolean;
  gyroGain: number; // 0..100 %
  yawLimit: number; // deg/s max yaw rate commanded by the assisted gyro
  drivetrain: Drivetrain;
  awdRatio: number; // front overdrive ratio (CS)
  // Full propo control (keyboard -> proportional)
  steerResponse: number; // s to reach full steering
  throttleResponse: number; // s to reach full throttle
  throttleEPA: number; // % max throttle
  featherLevel: number; // % throttle while holding Shift
  steerAngle: number; // deg max steering
  steerAssist: boolean; // keyboard steering assist
  tractionControl: number; // % comfort traction control / anti-spin (0 = off)
  speedLimit: number; // km/h speed limiter (0 = off)
  servoSpeed: number; // s / 60deg
  dragBrake: number; // %
  // Suspension & chassis
  springF: number; // 1..10
  springR: number; // 1..10
  damping: number; // 1..10
  rideHeight: number; // mm
  motorPos: MotorPos;
  wheelbase: number; // mm
  // Wheel alignment
  camberF: number; // deg
  camberR: number; // deg
  toeF: number; // deg (+ = toe-out)
  toeR: number; // deg (+ = toe-in)
  caster: number; // deg
  ackermann: number; // %
  // Tires & surface
  tire: TireType;
  surface: SurfaceType;
  // Visual / audio
  bodyColor: string;
  showBody: boolean;
  smoke: boolean;
  skidmarks: boolean;
  sound: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  gyroOn: true,
  gyroGain: 70,
  yawLimit: 195,
  drivetrain: 'RWD',
  awdRatio: 0.9,
  steerResponse: 0.2,
  throttleResponse: 0.35,
  throttleEPA: 80,
  featherLevel: 50,
  steerAngle: 55,
  steerAssist: true,
  tractionControl: 0,
  speedLimit: 0,
  servoSpeed: 0.07,
  dragBrake: 5,
  springF: 4,
  springR: 3,
  damping: 5,
  rideHeight: 6,
  motorPos: 'low',
  wheelbase: 257,
  camberF: -6,
  camberR: -1.5,
  toeF: 1,
  toeR: 2,
  caster: 8,
  ackermann: 40,
  tire: 'standard',
  surface: 'ptile',
  bodyColor: '#c8101a',
  showBody: true,
  smoke: true,
  skidmarks: true,
  sound: true,
};

// ------------------------------------------------------------
//  Descriptors (used by the keyboard-driven setup panel)
// ------------------------------------------------------------
export type SettingDesc =
  | {
      key: keyof Settings;
      label: string;
      group: string;
      kind: 'range';
      min: number;
      max: number;
      step: number;
      unit?: string;
      decimals?: number;
      info: string;
    }
  | { key: keyof Settings; label: string; group: string; kind: 'toggle'; info: string; on?: string; off?: string }
  | {
      key: keyof Settings;
      label: string;
      group: string;
      kind: 'select';
      options: { value: string; label: string; swatch?: string }[];
      info: string;
    };

export const BODY_COLORS = [
  { value: '#c8101a', label: 'Merah 86RB', swatch: '#c8101a' },
  { value: '#f2f2f2', label: 'Putih Mutiara', swatch: '#f2f2f2' },
  { value: '#151515', label: 'Hitam Glossy', swatch: '#151515' },
  { value: '#ff7a00', label: 'Oranye', swatch: '#ff7a00' },
  { value: '#1d56ff', label: 'Biru MST', swatch: '#1d56ff' },
  { value: '#6a7078', label: 'Abu LBMT', swatch: '#6a7078' },
  { value: '#ff2fa8', label: 'Pink Neon', swatch: '#ff2fa8' },
  { value: '#7cff3a', label: 'Hijau Neon', swatch: '#7cff3a' },
];

export const SETTING_DESCS: SettingDesc[] = [
  // ---------------- Gyro & Penggerak ----------------
  {
    key: 'gyroOn',
    label: 'Gyro MGX',
    group: 'Gyro & Penggerak',
    kind: 'toggle',
    on: 'AKTIF',
    off: 'MATI',
    info: 'Gyro mendeteksi putaran (yaw) mobil lalu otomatis memberi counter-steer, sehingga buntut mobil tidak gampang melintir saat sudut drift lebar. Matikan untuk tantangan hardcore.',
  },
  {
    key: 'gyroGain',
    label: 'Gain Gyro',
    group: 'Gyro & Penggerak',
    kind: 'range',
    min: 0,
    max: 100,
    step: 5,
    unit: '%',
    info: 'Sensitivitas gyro. Tinggi = counter-steer otomatis lebih kuat & stabil, tapi bisa terasa "kaku". Rendah = lebih bebas & realistis, butuh kontrol lebih halus. Ideal 60–80%.',
  },
  {
    key: 'yawLimit',
    label: 'Batas Putar Gyro',
    group: 'Gyro & Penggerak',
    kind: 'range',
    min: 90,
    max: 240,
    step: 5,
    unit: '°/s',
    info: 'Kecepatan putar (yaw) maksimum yang diizinkan gyro saat setir ditahan (aktif bila Asisten Setir ON). Rendah = putaran kalem, donut berupa lingkaran yang rapi & transisi angka 8 tidak mudah spin. 195°/s = standar (rotasi agresif, donut berputar di tempat).',
  },
  {
    key: 'drivetrain',
    label: 'Penggerak',
    group: 'Gyro & Penggerak',
    kind: 'select',
    options: [
      { value: 'RWD', label: 'RWD (Realistis)' },
      { value: 'AWD', label: 'AWD (Mudah)' },
    ],
    info: 'RWD: hanya roda belakang yang menggerakkan, terasa paling realistis seperti drift mobil asli. AWD: keempat roda menarik, mobil lebih mudah dikendalikan pemula.',
  },
  {
    key: 'awdRatio',
    label: 'Rasio Depan:Belakang (AWD)',
    group: 'Gyro & Penggerak',
    kind: 'range',
    min: 0.8,
    max: 1.2,
    step: 0.05,
    decimals: 2,
    unit: 'x',
    info: 'Khusus AWD: rasio putaran roda depan terhadap belakang. <1.00 = depan lebih lambat, buntut mudah keluar & drift gampang (ideal 0.90). >1.00 = depan overdrive, sangat stabil tapi cenderung grip/understeer.',
  },
  // ---------------- Kontrol Full Propo ----------------
  {
    key: 'steerResponse',
    label: 'Ramping Setir',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 0.05,
    max: 0.6,
    step: 0.05,
    decimals: 2,
    unit: 's',
    info: 'Simulasi kontrol proporsional (full propo) di keyboard: berapa lama tombol ditekan sampai setir penuh. Tap singkat = belok sedikit, tahan = belok penuh. Lebih besar = lebih halus.',
  },
  {
    key: 'throttleResponse',
    label: 'Ramping Gas',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 0.05,
    max: 1,
    step: 0.05,
    decimals: 2,
    unit: 's',
    info: 'Waktu gas naik dari 0 ke penuh saat tombol ditahan. Nilai lebih besar membuat gas lebih halus seperti menarik trigger perlahan.',
  },
  {
    key: 'throttleEPA',
    label: 'Throttle EPA',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 30,
    max: 100,
    step: 5,
    unit: '%',
    info: 'Batas gas maksimum (End Point Adjustment) seperti di remote XTR-03. Turunkan agar putaran roda belakang lebih terkendali. Hotkey: Z / X.',
  },
  {
    key: 'featherLevel',
    label: 'Gas Halus (Shift)',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 20,
    max: 80,
    step: 5,
    unit: '%',
    info: 'Persentase gas saat menahan SHIFT + W. Gunakan untuk "feathering" — menjaga sudut drift tanpa spin.',
  },
  {
    key: 'steerAssist',
    label: 'Asisten Setir Keyboard',
    group: 'Kontrol Full Propo',
    kind: 'toggle',
    on: 'AKTIF',
    off: 'MATI (Murni)',
    info: 'Karena tombol keyboard hanya on/off, asisten ini menjaga roda depan di sudut grip optimal & menyesuaikan perintah setir dengan kecepatan (bersama gyro). MATI = rate-gyro murni seperti remote asli, jauh lebih sulit.',
  },
  {
    key: 'tractionControl',
    label: 'Kontrol Traksi (Anti-Spin)',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 0,
    max: 100,
    step: 10,
    unit: '%',
    info: 'Bantuan nyaman: membatasi selip roda belakang di kecepatan rendah & otomatis mengurangi gas HANYA saat mobil hampir spin (putaran melebihi target gyro atau sudut drift > 50°). Drift normal tidak terganggu. Membuat donut & angka 8 stabil walau W ditahan terus. 0% = mati (murni).',
  },
  {
    key: 'speedLimit',
    label: 'Batas Kecepatan',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 0,
    max: 30,
    step: 1,
    unit: ' km/j',
    info: 'Limiter kecepatan maksimum (km/j RC). Berbeda dengan Throttle EPA, tenaga di bawah batas tetap utuh sehingga mobil tetap bisa drift, donut & angka 8 — hanya kecepatan di lurusan yang dibatasi. 0 = tanpa batas.',
  },
  {
    key: 'steerAngle',
    label: 'Sudut Setir Maks',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 30,
    max: 65,
    step: 1,
    unit: '°',
    info: 'Sudut belok roda depan maksimum (sistem steering sudut lebar RMX 2.5). Sudut besar memungkinkan drift dengan sudut ekstrem.',
  },
  {
    key: 'servoSpeed',
    label: 'Kecepatan Servo',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 0.04,
    max: 0.16,
    step: 0.01,
    decimals: 2,
    unit: 's/60°',
    info: 'Kecepatan servo SC-0352. Lebih kecil = servo lebih cepat, gyro lebih sigap menangkap slide.',
  },
  {
    key: 'dragBrake',
    label: 'Drag Brake ESC',
    group: 'Kontrol Full Propo',
    kind: 'range',
    min: 0,
    max: 30,
    step: 5,
    unit: '%',
    info: 'Efek pengereman motor saat gas dilepas. Tinggi = roda belakang cepat melambat & grip kembali (mobil lurus lebih cepat).',
  },
  // ---------------- Suspensi & Sasis ----------------
  {
    key: 'springF',
    label: 'Pegas Depan',
    group: 'Suspensi & Sasis',
    kind: 'range',
    min: 1,
    max: 10,
    step: 1,
    info: 'Kekerasan pegas depan. Lebih keras = transfer beban lebih banyak ke depan, grip depan turun (understeer). Lebih lunak = depan lebih menggigit.',
  },
  {
    key: 'springR',
    label: 'Pegas Belakang',
    group: 'Suspensi & Sasis',
    kind: 'range',
    min: 1,
    max: 10,
    step: 1,
    info: 'Kekerasan pegas belakang. Lunak = traksi belakang lebih baik & drift lebih maju. Keras = buntut lebih liar dan mudah sliding.',
  },
  {
    key: 'damping',
    label: 'Oli Shock',
    group: 'Suspensi & Sasis',
    kind: 'range',
    min: 1,
    max: 10,
    step: 1,
    info: 'Viskositas oli shock hidrolik. Encer = perpindahan beban lambat & body lebih goyang. Kental = respons transisi lebih cepat & tajam.',
  },
  {
    key: 'rideHeight',
    label: 'Ride Height',
    group: 'Suspensi & Sasis',
    kind: 'range',
    min: 4,
    max: 10,
    step: 1,
    unit: 'mm',
    info: 'Tinggi sasis dari lantai. Rendah = titik berat rendah, mobil lebih stabil. Tinggi = body roll lebih besar dan transfer beban lebih banyak.',
  },
  {
    key: 'motorPos',
    label: 'Posisi Motor',
    group: 'Suspensi & Sasis',
    kind: 'select',
    options: [
      { value: 'low', label: 'Rendah (Low CG)' },
      { value: 'high', label: 'Tinggi (High CG)' },
    ],
    info: 'RMX 2.5 punya dua posisi dudukan motor. Rendah = lebih stabil. Tinggi = transfer beban lebih besar, traksi belakang saat akselerasi naik.',
  },
  {
    key: 'wheelbase',
    label: 'Wheelbase',
    group: 'Suspensi & Sasis',
    kind: 'range',
    min: 254,
    max: 260,
    step: 1,
    unit: 'mm',
    info: 'Jarak sumbu roda (257mm ±3mm). Lebih panjang = drift lebih stabil & tenang. Lebih pendek = transisi lebih lincah.',
  },
  // ---------------- Sudut Roda ----------------
  {
    key: 'camberF',
    label: 'Camber Depan',
    group: 'Sudut Roda',
    kind: 'range',
    min: -12,
    max: 0,
    step: 0.5,
    decimals: 1,
    unit: '°',
    info: 'Kemiringan roda depan (0 s/d -12°). Camber negatif besar menjaga tapak ban tetap menempel saat setir patah penuh. Sweet spot sekitar -5° s/d -8°.',
  },
  {
    key: 'camberR',
    label: 'Camber Belakang',
    group: 'Sudut Roda',
    kind: 'range',
    min: -6,
    max: 0,
    step: 0.5,
    decimals: 1,
    unit: '°',
    info: 'Camber belakang lebih negatif = traksi maju berkurang sehingga buntut lebih mudah sliding. Mendekati 0 = dorongan maju lebih kuat.',
  },
  {
    key: 'toeF',
    label: 'Toe Depan',
    group: 'Sudut Roda',
    kind: 'range',
    min: -3,
    max: 3,
    step: 0.5,
    decimals: 1,
    unit: '°',
    info: 'Positif = toe-out (roda depan membuka): respon awal belok lebih tajam. Negatif = toe-in: lebih stabil lurus tapi kurang responsif.',
  },
  {
    key: 'toeR',
    label: 'Toe Belakang',
    group: 'Sudut Roda',
    kind: 'range',
    min: -1,
    max: 4,
    step: 0.5,
    decimals: 1,
    unit: '°',
    info: 'Positif = toe-in roda belakang: drift lebih stabil dan maju. Mendekati 0 / negatif = buntut lebih liar dan sudut drift lebih besar.',
  },
  {
    key: 'caster',
    label: 'Caster',
    group: 'Sudut Roda',
    kind: 'range',
    min: 6,
    max: 12,
    step: 2,
    unit: '°',
    info: 'Caster 6/8/10/12° seperti di RMX 2.5. Tinggi = camber dinamis bertambah saat setir dibelokkan & mobil lebih stabil. Rendah = setir lebih ringan dan lincah.',
  },
  {
    key: 'ackermann',
    label: 'Ackermann',
    group: 'Sudut Roda',
    kind: 'range',
    min: 0,
    max: 100,
    step: 10,
    unit: '%',
    info: 'Perbedaan sudut roda dalam vs luar. 0% = paralel (umum untuk drift sudut besar). Tinggi = roda dalam berbelok lebih tajam, enak di tikungan sempit.',
  },
  // ---------------- Ban & Lintasan ----------------
  {
    key: 'tire',
    label: 'Kompon Ban',
    group: 'Ban & Lintasan',
    kind: 'select',
    options: [
      { value: 'hard', label: 'Keras (Licin)' },
      { value: 'standard', label: 'Standar RTR' },
      { value: 'soft', label: 'Lunak (Grip)' },
    ],
    info: 'Ban drift plastik keras. Makin keras makin licin & mudah drift namun lambat. Ban lunak lebih menggigit & cepat tetapi butuh tenaga untuk drift.',
  },
  {
    key: 'surface',
    label: 'Permukaan Track',
    group: 'Ban & Lintasan',
    kind: 'select',
    options: [
      { value: 'ptile', label: 'P-Tile (Standar)' },
      { value: 'concrete', label: 'Beton Poles (Licin)' },
      { value: 'carpet', label: 'Karpet (Grip)' },
    ],
    info: 'Jenis lantai lintasan. P-Tile adalah lantai standar track drift RC indoor.',
  },
  // ---------------- Tampilan & Audio ----------------
  {
    key: 'bodyColor',
    label: 'Warna Body',
    group: 'Tampilan & Audio',
    kind: 'select',
    options: BODY_COLORS,
    info: 'Warna body shell 86RB (Rocket Bunny style).',
  },
  {
    key: 'showBody',
    label: 'Body Shell',
    group: 'Tampilan & Audio',
    kind: 'toggle',
    on: 'TAMPIL',
    off: 'LIHAT SASIS',
    info: 'Lepas body untuk melihat sasis RMX 2.5: suspensi coilover bergerak, gyro MGX berkedip, spur gear berputar. Hotkey: B.',
  },
  { key: 'smoke', label: 'Efek Debu/Asap', group: 'Tampilan & Audio', kind: 'toggle', info: 'Partikel debu halus dari ban saat sliding.' },
  { key: 'skidmarks', label: 'Bekas Ban', group: 'Tampilan & Audio', kind: 'toggle', info: 'Jejak ban plastik di lantai track.' },
  { key: 'sound', label: 'Suara', group: 'Tampilan & Audio', kind: 'toggle', info: 'Suara motor brushless & desis ban. Hotkey: M.' },
];

// ------------------------------------------------------------
//  Presets
// ------------------------------------------------------------
export interface Preset {
  id: string;
  name: string;
  desc: string;
  values: Partial<Settings>;
}

export const PRESETS: Preset[] = [
  {
    id: 'rtr',
    name: 'RTR Standar',
    desc: 'Setelan pabrik RMX 2.5: RWD + gyro MGX 70%. Seimbang & nyaman.',
    values: {
      yawLimit: 195,
      tractionControl: 0,
      speedLimit: 0,
      featherLevel: 50,
      gyroOn: true,
      gyroGain: 70,
      drivetrain: 'RWD',
      steerAssist: true,
      steerResponse: 0.2,
      throttleResponse: 0.35,
      throttleEPA: 80,
      steerAngle: 55,
      servoSpeed: 0.07,
      springF: 4,
      springR: 3,
      damping: 5,
      rideHeight: 6,
      motorPos: 'low',
      wheelbase: 257,
      camberF: -6,
      camberR: -1.5,
      toeF: 1,
      toeR: 2,
      caster: 8,
      ackermann: 40,
      tire: 'standard',
      dragBrake: 5,
    },
  },
  {
    id: 'beginner',
    name: 'Pemula Nyaman (AWD)',
    desc: 'AWD + gyro, gas lebih lembut. Paling mudah untuk belajar drift.',
    values: {
      yawLimit: 195,
      tractionControl: 0,
      speedLimit: 0,
      featherLevel: 50,
      gyroOn: true,
      gyroGain: 60,
      drivetrain: 'AWD',
      awdRatio: 0.9,
      steerAssist: true,
      steerResponse: 0.25,
      throttleResponse: 0.45,
      throttleEPA: 70,
      steerAngle: 52,
      servoSpeed: 0.07,
      springF: 3,
      springR: 4,
      damping: 6,
      rideHeight: 5,
      motorPos: 'low',
      wheelbase: 260,
      camberF: -5,
      camberR: -1.5,
      toeF: 0.5,
      toeR: 1.5,
      caster: 10,
      ackermann: 40,
      tire: 'standard',
      dragBrake: 10,
    },
  },
  {
    id: 'pro',
    name: 'Pro RWD Agresif',
    desc: 'Sudut setir 62°, servo cepat, gyro 55%. Sudut drift besar & transisi cepat.',
    values: {
      yawLimit: 195,
      tractionControl: 0,
      speedLimit: 0,
      featherLevel: 50,
      gyroOn: true,
      gyroGain: 55,
      drivetrain: 'RWD',
      steerAssist: true,
      steerResponse: 0.12,
      throttleResponse: 0.25,
      throttleEPA: 95,
      steerAngle: 62,
      servoSpeed: 0.05,
      springF: 5,
      springR: 2,
      damping: 7,
      rideHeight: 5,
      motorPos: 'high',
      wheelbase: 255,
      camberF: -8,
      camberR: -2,
      toeF: 1.5,
      toeR: 1,
      caster: 10,
      ackermann: 20,
      tire: 'standard',
      dragBrake: 5,
    },
  },
  {
    id: 'hardcore',
    name: 'Tanpa Gyro (Hardcore)',
    desc: 'Gyro dimatikan. Kamu sendiri yang harus counter-steer. Untuk pembuktian skill!',
    values: {
      yawLimit: 195,
      tractionControl: 0,
      speedLimit: 0,
      featherLevel: 50,
      gyroOn: false,
      drivetrain: 'RWD',
      steerAssist: false,
      steerResponse: 0.1,
      throttleResponse: 0.3,
      throttleEPA: 75,
      steerAngle: 58,
      servoSpeed: 0.05,
      springF: 4,
      springR: 3,
      damping: 5,
      camberF: -6,
      camberR: -1.5,
      toeF: 1,
      toeR: 3,
      caster: 10,
      ackermann: 30,
      tire: 'standard',
      dragBrake: 10,
    },
  },
  {
    id: 'santai',
    name: 'Santai Pro (WASD + Spasi)',
    desc: 'Drift pro kontrol keyboard: Spasi melepas grip menyamping + dorong akselerasi tetap hidup, auto counter-steer 25–45°, max angle clamp >55°, dan snap-back halus saat Spasi dilepas.',
    values: {
      gyroOn: true,
      gyroGain: 80,
      yawLimit: 120,
      drivetrain: 'RWD',
      steerAssist: true,
      tractionControl: 75,
      speedLimit: 25,
      steerResponse: 0.15,
      throttleResponse: 0.3,
      throttleEPA: 80,
      featherLevel: 55,
      steerAngle: 62,
      servoSpeed: 0.04,
      dragBrake: 5,
      springF: 5,
      springR: 2,
      damping: 6,
      rideHeight: 5,
      motorPos: 'low',
      wheelbase: 257,
      camberF: -6.5,
      camberR: -1.5,
      toeF: 1,
      toeR: 3,
      caster: 10,
      ackermann: 30,
      tire: 'standard',
    },
  },
];

/** RC factory default (RTR Standar on P-Tile). Only cosmetic preferences are kept. */
export function rcDefaultSetup(current: Settings): Settings {
  const { bodyColor, showBody, smoke, skidmarks, sound } = current;
  return { ...DEFAULT_SETTINGS, bodyColor, showBody, smoke, skidmarks, sound };
}

/** Which preset the current setup equals (null = custom). */
export function matchPreset(s: Settings): Preset | null {
  if (s.surface !== DEFAULT_SETTINGS.surface) return null;
  return PRESETS.find((p) => (Object.keys(p.values) as (keyof Settings)[]).every((k) => s[k] === p.values[k])) ?? null;
}

// ------------------------------------------------------------
//  Handling character (for bars in setup panel)
// ------------------------------------------------------------
export function computeCharacter(s: Settings) {
  const c = (v: number) => Math.max(4, Math.min(100, Math.round(v)));
  const gyro = s.gyroOn ? s.gyroGain : 0;
  const awd = s.drivetrain === 'AWD';
  const tireMu = s.tire === 'hard' ? 0.86 : s.tire === 'soft' ? 1.14 : 1;
  const surfMu = s.surface === 'concrete' ? 0.87 : s.surface === 'carpet' ? 1.25 : 1;
  const grip = tireMu * surfMu;

  const stabilitas =
    25 + gyro * 0.45 + (awd ? 18 + (s.awdRatio - 0.9) * 40 : 0) + s.toeR * 4 + (s.wheelbase - 257) * 2 +
    (s.caster - 8) * 1.5 - (s.rideHeight - 6) * 2 - (s.motorPos === 'high' ? 4 : 0) + (s.springF - s.springR) * 1.5 +
    (s.steerAssist ? (195 - (s.yawLimit ?? 195)) * 0.1 : 0) + (s.tractionControl ?? 0) * 0.22;
  const inisiasi =
    40 + (awd ? -12 : 10) - (grip - 1) * 70 + Math.abs(s.camberR) * 4 + (s.springR - 4) * 3 + s.throttleEPA * 0.12 -
    s.toeR * 3 - gyro * 0.08;
  const respons =
    30 + (0.16 - s.servoSpeed) * 300 + (0.6 - s.steerResponse) * 50 + (s.damping - 5) * 3 + s.toeF * 4 +
    (s.steerAngle - 45) * 0.6 - (s.wheelbase - 257) * 1.5;
  const traksi =
    35 + (grip - 1) * 90 + (awd ? 18 : 0) - Math.abs(s.camberR) * 4 + (5 - s.springR) * 3 + s.toeR * 2 +
    (s.motorPos === 'high' ? 5 : 0);
  const kenyamanan =
    stabilitas * 0.45 + (100 - Math.abs(inisiasi - 55)) * 0.25 + s.steerResponse * 40 + s.throttleResponse * 15 +
    (s.tractionControl ?? 0) * 0.12 + (s.speedLimit ? Math.max(0, 28 - s.speedLimit) * 0.8 : 0);
  return {
    Stabilitas: c(stabilitas),
    'Mudah Drift': c(inisiasi),
    Respons: c(respons),
    Traksi: c(traksi),
    Kenyamanan: c(kenyamanan),
  };
}

// ------------------------------------------------------------
//  Minimal external store implementation
// ------------------------------------------------------------
type Listener = () => void;

function createStore<T extends object>(initial: T, persistKey?: string) {
  let state = initial;
  if (persistKey && typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(persistKey);
      if (raw) state = { ...initial, ...JSON.parse(raw) };
    } catch {
      /* ignore */
    }
  }
  const listeners = new Set<Listener>();
  return {
    get: () => state,
    set: (patch: Partial<T>) => {
      state = { ...state, ...patch };
      if (persistKey && typeof localStorage !== 'undefined') {
        try {
          localStorage.setItem(persistKey, JSON.stringify(state));
        } catch {
          /* ignore */
        }
      }
      listeners.forEach((l) => l());
    },
    subscribe: (l: Listener) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
  };
}

export const settingsStore = createStore<Settings>({ ...DEFAULT_SETTINGS }, 'rmx25-settings-v1');

export type UIMode = 'start' | 'drive' | 'setup' | 'help';
export interface UIState {
  mode: UIMode;
  trackId?: string;
}
export const uiStore = createStore<UIState>({ mode: 'start', trackId: 'haruna' });

// Formatting helper
export function formatValue(d: SettingDesc, v: unknown): string {
  if (d.kind === 'toggle') return v ? d.on ?? 'ON' : d.off ?? 'OFF';
  if (d.kind === 'select') return d.options.find((o) => o.value === v)?.label ?? String(v);
  if (d.key === 'speedLimit' && !v) return 'TANPA BATAS';
  if (d.key === 'tractionControl' && !v) return 'MATI';
  const n = v as number;
  const txt = d.decimals ? n.toFixed(d.decimals) : String(Math.round(n * 100) / 100);
  return `${d.key === 'toeF' || d.key === 'toeR' ? (n > 0 ? '+' : '') : ''}${txt}${d.unit ?? ''}`;
}
