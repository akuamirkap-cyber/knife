import { useEffect, useState } from 'react';
import { PRESETS, uiStore } from '../game/settings';
import { engineRef } from '../game/engine';
import { TRACKS, type ArenaTrackId } from '../game/track';
import { useUI } from './useGame';

const FEATURES = [
  {
    icon: '🌀',
    title: 'Gyro MGX',
    text: 'Menjaga arah mobil agar tidak mudah melintir saat sudut belok lebar — counter-steer otomatis.',
    color: 'from-sky-500/30',
  },
  {
    icon: '⚙️',
    title: 'RWD / AWD',
    text: 'AWD lebih mudah dikendalikan pemula, RWD terasa paling realistis. Ganti kapan saja dengan T.',
    color: 'from-red-500/30',
  },
  {
    icon: '🎮',
    title: 'Full Propo di Keyboard',
    text: 'Input setir & gas di-ramping secara proporsional: tap = halus, tahan = penuh. SHIFT = gas halus.',
    color: 'from-emerald-500/30',
  },
  {
    icon: '🔧',
    title: 'Suspensi & Sudut Roda',
    text: 'Pegas, oli shock, ride height, camber, toe, caster & Ackermann bisa disetel untuk manuver yang halus.',
    color: 'from-amber-500/30',
  },
];

const KEYS: [string, string][] = [
  ['W / ↑', 'Gas (tahan = makin dalam)'],
  ['S / ↓', 'Rem ESC / mundur'],
  ['A D / ← →', 'Setir proporsional'],
  ['SHIFT + W', 'Gas halus (feathering)'],
  ['SPACE', 'Rem tangan (inisiasi)'],
  ['G • Q/E', 'Gyro on/off • gain −/+'],
  ['T', 'Ganti RWD ↔ AWD'],
  ['Z / X', 'Throttle EPA −/+'],
  ['C', 'Ganti kamera'],
  ['B', 'Lepas body (lihat sasis)'],
  ['1 – 5', 'Preset cepat'],
  ['TAB • H', 'Setup garasi • Bantuan'],
];

const TRACK_CARDS: { id: ArenaTrackId; icon: string; tint: string }[] = [
  { id: 'haruna', icon: '⛰️', tint: 'from-emerald-500/25' },
  { id: 'prodrift', icon: '🏁', tint: 'from-sky-500/25' },
];

export default function StartScreen({ onExit }: { onExit?: () => void } = {}) {
  const ui = useUI();
  const [sel, setSel] = useState(0);
  const [track, setTrack] = useState<ArenaTrackId>(() => (engineRef.current?.trackId as ArenaTrackId) ?? 'haruna');
  const options = [{ id: 'custom', name: 'Setelan Saya', desc: 'Lanjutkan dengan setelan terakhir yang tersimpan.' }, ...PRESETS];
  const chooseTrack = (id: ArenaTrackId) => {
    setTrack(id);
    engineRef.current?.setTrack(id);
    uiStore.set({ trackId: id });
  };

  useEffect(() => {
    const start = (idx: number) => {
      const o = options[idx];
      if (o.id !== 'custom') engineRef.current?.applyPreset(o.id);
      uiStore.set({ mode: 'drive' });
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') setSel((v) => (v - 1 + options.length) % options.length);
      else if (e.code === 'ArrowRight' || e.code === 'KeyD') setSel((v) => (v + 1) % options.length);
      else if (e.code === 'Backspace' && onExit) {
        e.preventDefault();
        onExit();
      } else if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        start(sel);
      } else if (/^Digit[1-6]$/.test(e.code)) setSel(Number(e.code.slice(5)) - 1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel]);

  return (
    <div className="font-game absolute inset-0 select-none overflow-y-auto text-white">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_25%,rgba(0,0,0,0.75)_75%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-56 bg-gradient-to-b from-black/80 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-72 bg-gradient-to-t from-black/90 to-transparent" />

      <div className="relative flex min-h-full flex-col p-5 md:p-8">
        {/* title */}
        <div className="text-center md:text-left">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-black/40 px-3 py-1 text-[11px] font-black tracking-[0.3em] text-amber-300">
            MST • RTR • 1/10 RWD DRIFT
          </div>
          <h1 className="font-title mt-2 text-4xl font-black italic leading-none tracking-tight drop-shadow-[0_4px_0_rgba(0,0,0,0.6)] md:text-6xl">
            RMX 2.5 <span className="bg-gradient-to-r from-red-500 to-amber-400 bg-clip-text text-transparent">DRIFT SIM</span>
          </h1>
          <p className="mt-2 max-w-xl text-base font-semibold text-white/75 md:text-lg">
            Simulasi mobil RC drift ternyaman di dunia — dimainkan cukup pakai keyboard. Fokus di mobilnya, lintasannya simpel.
          </p>
        </div>

        {/* track selection — Mt. Haruna default, PRODRIFT race track is the optional choice */}
        <div className="mt-4">
          <div className="mb-1.5 text-[11px] font-black tracking-[0.3em] text-white/50">PILIH LINTASAN (TRACK)</div>
          <div className="grid max-w-2xl grid-cols-1 gap-2 sm:grid-cols-2">
            {TRACK_CARDS.map(({ id, icon, tint }) => {
              const def = TRACKS[id];
              const active = (ui.trackId ?? track) === id;
              return (
                <button
                  key={id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => chooseTrack(id)}
                  className={`rounded-xl border p-3 text-left transition ${
                    active ? 'border-amber-400 bg-amber-400/15 shadow-[0_0_22px_rgba(251,191,36,0.22)]' : 'border-white/10 bg-black/50 hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{icon}</span>
                    <span className="text-base font-black leading-tight">{def.name}</span>
                    <span className={`ml-auto rounded-full px-2 py-0.5 text-[10px] font-black tracking-[0.2em] ${def.tag === 'DEFAULT' ? 'bg-emerald-500/80 text-black' : 'bg-white/15 text-white/75'}`}>{def.tag}</span>
                  </div>
                  <div className="mt-1.5 text-[12px] leading-snug text-white/65">{def.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-5 flex flex-1 flex-col justify-between gap-5 lg:flex-row">
          {/* features */}
          <div className="grid max-w-md grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-1">
            <div className="text-[11px] font-black tracking-[0.3em] text-white/50">FAKTOR YANG MEMBUAT RC DRIFT NYAMAN</div>
            {FEATURES.map((f) => (
              <div key={f.title} className={`rounded-xl border border-white/10 bg-gradient-to-r ${f.color} to-black/50 p-3 backdrop-blur-md`}>
                <div className="flex items-center gap-2 text-base font-black">
                  <span className="text-xl">{f.icon}</span>
                  {f.title}
                </div>
                <div className="mt-0.5 text-[13px] leading-snug text-white/75">{f.text}</div>
              </div>
            ))}
          </div>

          {/* keys */}
          <div className="h-fit max-w-sm rounded-2xl border border-white/10 bg-black/55 p-4 backdrop-blur-md">
            <div className="mb-2 text-[11px] font-black tracking-[0.3em] text-white/50">KONTROL KEYBOARD</div>
            <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5 text-[13px]">
              {KEYS.map(([k, v]) => (
                <div key={k} className="contents">
                  <kbd className="rounded-md bg-white/15 px-2 py-0.5 text-center text-xs font-black">{k}</kbd>
                  <span className="text-white/80">{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* presets */}
        <div className="mt-6">
          <div className="mb-2 text-center text-[11px] font-black tracking-[0.3em] text-white/60">PILIH SETELAN (← →)</div>
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-6">
            {options.map((o, i) => (
              <button
                key={o.id}
                onClick={() => {
                  if (sel === i) {
                    if (o.id !== 'custom') engineRef.current?.applyPreset(o.id);
                    uiStore.set({ mode: 'drive' });
                  } else setSel(i);
                }}
                className={`rounded-xl border p-3 text-left transition ${
                  sel === i ? 'scale-[1.03] border-amber-400 bg-amber-400/15 shadow-[0_0_25px_rgba(251,191,36,0.25)]' : 'border-white/10 bg-black/50 hover:bg-white/5'
                }`}
              >
                <div className="text-sm font-black">{o.name}</div>
                <div className="mt-1 text-[11px] leading-snug text-white/60">{o.desc}</div>
              </button>
            ))}
          </div>
          <div className="mt-5 text-center">
            <div className="inline-block animate-pulse rounded-full bg-gradient-to-r from-red-600 to-amber-500 px-8 py-3 text-lg font-black italic tracking-widest shadow-[0_0_40px_rgba(239,68,68,0.45)]">
              TEKAN ENTER UNTUK MULAI
            </div>
            <div className="mt-2 text-xs text-white/45">
              Disarankan memakai headphone • Pengaturan tersimpan otomatis{onExit ? ' • BACKSPACE: pilih mode game' : ''}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
