import { useEffect, useMemo, useRef, useState } from 'react';
import {
  computeCharacter,
  formatValue,
  PRESETS,
  SETTING_DESCS,
  settingsStore,
  uiStore,
  DEFAULT_SETTINGS,
  type Preset,
  type SettingDesc,
  type Settings,
} from '../game/settings';
import { engineRef } from '../game/engine';
import { useSettings } from './useGame';

type Item =
  | { type: 'header'; label: string }
  | { type: 'preset'; preset: Preset; idx: number }
  | { type: 'setting'; desc: SettingDesc }
  | { type: 'action'; id: 'resume' | 'reset-car' | 'menu' | 'defaults'; label: string; info: string };

function adjust(desc: SettingDesc, s: Settings, dir: number) {
  const v = s[desc.key];
  if (desc.kind === 'toggle') return { [desc.key]: !v } as Partial<Settings>;
  if (desc.kind === 'select') {
    const i = desc.options.findIndex((o) => o.value === v);
    const n = desc.options.length;
    return { [desc.key]: desc.options[(i + dir + n) % n].value } as Partial<Settings>;
  }
  const raw = (v as number) + dir * desc.step;
  const dec = Math.max(0, (String(desc.step).split('.')[1] || '').length);
  const nv = Math.min(desc.max, Math.max(desc.min, Number(raw.toFixed(dec))));
  return { [desc.key]: nv } as Partial<Settings>;
}

type Props = { variant?: 'rc' | 'rally'; onClose?: () => void; onResetCar?: () => void; onMenu?: () => void };

export default function SetupPanel({ variant = 'rc', onClose, onResetCar, onMenu }: Props = {}) {
  const rally = variant === 'rally';
  const s = useSettings();
  const [sel, setSel] = useState(0);
  const rowRefs = useRef<(HTMLDivElement | null)[]>([]);

  const items = useMemo<Item[]>(() => {
    const out: Item[] = [{ type: 'header', label: 'Preset Cepat (Enter untuk pakai)' }];
    PRESETS.forEach((p, idx) => out.push({ type: 'preset', preset: p, idx }));
    let group = '';
    for (const d of SETTING_DESCS) {
      if (rally && d.group === 'Tampilan & Audio') continue;
      if (d.group !== group) {
        group = d.group;
        out.push({ type: 'header', label: group });
      }
      out.push({ type: 'setting', desc: d });
    }
    out.push({ type: 'header', label: 'Aksi' });
    out.push({ type: 'action', id: 'resume', label: '▶ Lanjut Main', info: 'Tutup setup dan lanjut drift. (TAB / ESC)' });
    out.push({
      type: 'action',
      id: 'reset-car',
      label: rally ? '↺ Ulangi Lintasan' : '↺ Reset Mobil ke Lintasan',
      info: rally ? 'Mulai ulang dari garis start Sirkuit Pinus.' : 'Kembalikan mobil ke tengah lintasan terdekat.',
    });
    out.push({ type: 'action', id: 'defaults', label: '⟲ Kembalikan Setelan Pabrik', info: 'Kembalikan semua setelan ke default RTR (tampilan tidak berubah).' });
    out.push({ type: 'action', id: 'menu', label: rally ? '⌂ Pilih Mode Game' : '⌂ Menu Utama', info: rally ? 'Kembali ke menu pilih mode.' : 'Kembali ke layar judul.' });
    return out;
  }, [rally]);

  const selectable = useMemo(() => items.map((it, i) => (it.type === 'header' ? -1 : i)).filter((i) => i >= 0), [items]);
  const curIndex = selectable[Math.min(sel, selectable.length - 1)];
  const cur = items[curIndex];

  const activate = (it: Item, dir = 1) => {
    const st = settingsStore.get();
    if (it.type === 'preset') {
      if (!rally && engineRef.current) engineRef.current.applyPreset(it.preset.id);
      else settingsStore.set(it.preset.values);
    } else if (it.type === 'setting') {
      settingsStore.set(adjust(it.desc, st, dir));
    } else if (it.type === 'action') {
      if (rally) {
        if (it.id === 'resume') onClose?.();
        if (it.id === 'reset-car') onResetCar?.();
        if (it.id === 'menu') onMenu?.();
      } else {
        if (it.id === 'resume') uiStore.set({ mode: 'drive' });
        if (it.id === 'reset-car') {
          engineRef.current?.resetCar();
          uiStore.set({ mode: 'drive' });
        }
        if (it.id === 'menu') uiStore.set({ mode: 'start' });
      }
      if (it.id === 'defaults') {
        const { bodyColor, showBody, smoke, skidmarks, sound } = st;
        settingsStore.set({ ...DEFAULT_SETTINGS, bodyColor, showBody, smoke, skidmarks, sound });
      }
    }
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (rally) {
        // Rally mode: own every key while the panel is open (game stays paused).
        e.stopImmediatePropagation();
        if (e.code === 'Tab' || e.code === 'Escape' || e.code === 'KeyP') {
          e.preventDefault();
          if (!e.repeat) onClose?.();
          return;
        }
      }
      const n = selectable.length;
      const it = items[selectable[Math.min(sel, n - 1)]];
      switch (e.code) {
        case 'ArrowUp':
        case 'KeyW':
          e.preventDefault();
          setSel((v) => (v - 1 + n) % n);
          break;
        case 'ArrowDown':
        case 'KeyS':
          e.preventDefault();
          setSel((v) => (v + 1) % n);
          break;
        case 'ArrowLeft':
        case 'KeyA':
          e.preventDefault();
          if (it.type === 'setting') activate(it, -1);
          break;
        case 'ArrowRight':
        case 'KeyD':
          e.preventDefault();
          if (it.type === 'setting') activate(it, 1);
          break;
        case 'Enter':
        case 'Space':
          e.preventDefault();
          activate(it, 1);
          break;
        case 'PageUp':
          setSel((v) => Math.max(0, v - 6));
          break;
        case 'PageDown':
          setSel((v) => Math.min(n - 1, v + 6));
          break;
      }
    };
    window.addEventListener('keydown', onKey, rally);
    return () => window.removeEventListener('keydown', onKey, rally);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel, items, selectable, rally]);

  useEffect(() => {
    rowRefs.current[curIndex]?.scrollIntoView({ block: 'nearest' });
  }, [curIndex]);

  const ch = computeCharacter(s);
  const info =
    cur?.type === 'setting'
      ? cur.desc.info
      : cur?.type === 'preset'
        ? cur.preset.desc
        : cur?.type === 'action'
          ? cur.info
          : '';

  return (
    <div className="font-game absolute inset-0 text-white">
      {/* left panel */}
      <div className="absolute bottom-4 left-4 top-4 flex w-[min(460px,calc(100vw-2rem))] flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#0b0d12]/90 shadow-2xl backdrop-blur-xl">
        <div className="border-b border-white/10 bg-gradient-to-r from-red-700/60 to-transparent px-5 py-3">
          <div className="text-[11px] font-black tracking-[0.35em] text-white/60">{rally ? 'PRODRIFT • SISTEM DRIFT' : 'GARASI • SETUP'}</div>
          <div className="text-2xl font-black italic leading-tight">{rally ? 'Setelan Drift RMX 2.5' : 'MST RMX 2.5 RTR'}</div>
          <div className="text-xs text-white/60">↑↓ pilih • ←→ ubah • ENTER pakai/toggle • TAB/ESC kembali</div>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2 [scrollbar-width:thin]">
          {items.map((it, i) => {
            if (it.type === 'header')
              return (
                <div key={i} className="mb-1 mt-3 px-2 text-[10px] font-black uppercase tracking-[0.3em] text-amber-400/90">
                  {it.label}
                </div>
              );
            const active = i === curIndex;
            const selIdx = selectable.indexOf(i);
            const base = `flex cursor-pointer items-center justify-between gap-3 rounded-lg px-3 py-1.5 transition ${
              active ? 'bg-white/15 ring-1 ring-amber-400/80' : 'hover:bg-white/5'
            }`;
            if (it.type === 'preset')
              return (
                <div
                  key={i}
                  ref={(el) => {
                    rowRefs.current[i] = el;
                  }}
                  className={base}
                  onClick={() => {
                    setSel(selIdx);
                    activate(it);
                  }}
                >
                  <span className="text-sm font-bold">
                    <span className="mr-2 rounded bg-white/15 px-1.5 text-xs">{it.idx + 1}</span>
                    {it.preset.name}
                  </span>
                  <span className="text-[10px] font-bold text-white/40">{active ? 'ENTER' : ''}</span>
                </div>
              );
            if (it.type === 'action')
              return (
                <div
                  key={i}
                  ref={(el) => {
                    rowRefs.current[i] = el;
                  }}
                  className={base}
                  onClick={() => {
                    setSel(selIdx);
                    activate(it);
                  }}
                >
                  <span className="text-sm font-bold">{it.label}</span>
                </div>
              );
            const d = it.desc;
            const v = s[d.key];
            const disabled = d.key === 'awdRatio' && s.drivetrain !== 'AWD';
            return (
              <div
                key={i}
                ref={(el) => {
                  rowRefs.current[i] = el;
                }}
                className={`${base} ${disabled ? 'opacity-40' : ''}`}
                onClick={() => setSel(selIdx)}
              >
                <span className="text-sm font-semibold">{d.label}</span>
                <div className="flex items-center gap-2">
                  {d.kind === 'range' && (
                    <div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full bg-amber-400" style={{ width: `${(((v as number) - d.min) / (d.max - d.min)) * 100}%` }} />
                    </div>
                  )}
                  <button
                    className="rounded px-1 text-white/50 hover:text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSel(selIdx);
                      activate(it, -1);
                    }}
                  >
                    ◀
                  </button>
                  <span
                    className={`min-w-[92px] text-center text-sm font-black tabular-nums ${
                      d.kind === 'toggle' ? (v ? 'text-emerald-400' : 'text-red-400') : 'text-white'
                    }`}
                  >
                    {d.kind === 'select' && d.key === 'bodyColor' && (
                      <span className="mr-1.5 inline-block h-3 w-3 rounded-full border border-white/40 align-middle" style={{ background: v as string }} />
                    )}
                    {formatValue(d, v)}
                  </span>
                  <button
                    className="rounded px-1 text-white/50 hover:text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSel(selIdx);
                      activate(it, 1);
                    }}
                  >
                    ▶
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="min-h-[92px] border-t border-white/10 bg-black/40 px-5 py-3 text-[13px] leading-snug text-white/80">
          <div className="mb-1 text-[10px] font-black tracking-[0.3em] text-amber-400">
            {cur?.type === 'setting' ? cur.desc.label.toUpperCase() : cur?.type === 'preset' ? 'PRESET' : 'INFO'}
          </div>
          {info}
        </div>
      </div>

      {/* right side: character + specs */}
      <div className="absolute right-4 top-4 hidden w-[300px] flex-col gap-3 lg:flex">
        <div className="rounded-2xl border border-white/10 bg-black/60 p-4 backdrop-blur-md">
          <div className="mb-2 text-[10px] font-black tracking-[0.3em] text-white/60">KARAKTER HANDLING</div>
          {Object.entries(ch).map(([k, val]) => (
            <div key={k} className="mb-2">
              <div className="flex justify-between text-xs font-bold">
                <span>{k}</span>
                <span className="tabular-nums text-white/70">{val}</span>
              </div>
              <div className="mt-0.5 h-2 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-sky-400 via-emerald-400 to-amber-400 transition-all duration-300"
                  style={{ width: `${val}%` }}
                />
              </div>
            </div>
          ))}
          <div className="mt-2 text-[11px] text-white/50">Perubahan langsung diterapkan ke fisika mobil.</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/60 p-4 text-xs backdrop-blur-md">
          <div className="mb-2 text-[10px] font-black tracking-[0.3em] text-white/60">
            {rally ? 'SUMBER SISTEM DRIFT: RMX 2.5 RTR' : 'SPESIFIKASI RMX 2.5 RTR'}
          </div>
          {rally && (
            <div className="mb-2 rounded-lg bg-amber-400/10 p-2 text-[11px] leading-snug text-amber-100/90">
              Fisika RMX 2.5 berjalan 1:1 seperti mode RC: respons, km/j di speedometer, sudut drift, gyro & semua setelan identik. Mobil tampil di ukuran asli (lebar 1,9 m, skala 1:8,4 dari RMX) di sirkuit selebar 15 m dengan run-off beraspal — gerak per panjang mobil sama persis dengan RC.
            </div>
          )}
          {[
            ['Skala', '1/10 Drift Car'],
            ['Penggerak', 'RWD (sim: RWD / AWD)'],
            ['Wheelbase', `${s.wheelbase} mm (257 ±3)`],
            ['Lebar hex', 'F 178 / R 171 mm'],
            ['Caster', '6 / 8 / 10 / 12°'],
            ['Camber', '0 s/d −12°'],
            ['Motor', 'XBL 2500Kv Brushless'],
            ['ESC', 'XBL50 Brushless'],
            ['Gyro', 'MGX'],
            ['Radio', 'XTR-03 2.4GHz'],
            ['Servo', 'SC-0352'],
            ['Baterai', 'LiPo 2S shorty'],
          ].map(([a, b]) => (
            <div key={a} className="flex justify-between border-b border-white/5 py-0.5">
              <span className="text-white/50">{a}</span>
              <span className="font-bold">{b}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
