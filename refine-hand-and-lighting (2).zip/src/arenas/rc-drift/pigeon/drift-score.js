const cap = (value, low, high) => Math.max(low, Math.min(high, value));
const degrees = 180 / Math.PI;

export const outsideMultiplier = 1.48;
export const medalGoals = Object.freeze({ bronze: 1800, silver: 4200, gold: 7600 });
export function driftMedal(score) {
  return score >= medalGoals.gold ? 'gold' : score >= medalGoals.silver ? 'silver' : score >= medalGoals.bronze ? 'bronze' : null;
}

export function createDriftScore(opts = {}) {
  const minAngle = opts.minAngle ?? .226, comboAngle = opts.comboAngle ?? .181, maxAngle = opts.maxAngle ?? 1.245;
  const spinAngle = opts.spinAngle ?? 1.24, minSlip = opts.minSlip ?? .27;
  let banked = 0, peak = 0, combo = 0, gripTime = 0, linkWindow = 0, activeTime = 0;
  let lastSide = 0, candidate = 0, candidateTime = 0, legTime = 0, links = 0, allLinks = 0;
  let gravelTime = 0, spinTime = 0, notice = 0, grace = 1, danger = '';
  let saved = 0, savedLinks = 0, savedMultiplier = 1, phase = 'idle', result = null, sequence = 0, outer = false;
  let comboBonus = 0, bankedBonus = 0;

  const multiplier = () => Math.min(5, 1 + links * .83 + activeTime * .19);
  function clearChain() {
    combo = gripTime = activeTime = lastSide = candidate = candidateTime = legTime = links = linkWindow = spinTime = gravelTime = 0;
    comboBonus = 0;
    grace = 1; outer = false;
  }
  function settle(loss = '') {
    if (!combo) { clearChain(); return; }
    saved = Math.round(combo); savedLinks = links; savedMultiplier = multiplier();
    if (saved >= 15) {
      if (!loss) { banked += saved; peak = Math.max(peak, saved); allLinks += links; bankedBonus += comboBonus; }
      danger = loss; result = loss ? 'lost' : 'banked'; notice = 2.12; sequence++;
    }
    clearChain(); phase = 'idle';
  }
  function reset() {
    banked = peak = saved = savedLinks = notice = allLinks = bankedBonus = 0;
    savedMultiplier = 1; danger = ''; result = null; phase = 'idle'; clearChain();
  }

  function step(dt, sample) {
    const angle = Math.abs(sample.beta), side = Math.sign(sample.beta);
    notice = Math.max(0, notice - dt);
    const useful = sample.speed > (combo ? 7.2 : 8.8) && sample.along > 3.1 && sample.forward > 1 && sample.slip > minSlip;
    const wide = sample.outside && sample.roughness < .35;
    const active = useful && angle > (combo ? comboAngle : minAngle) && angle < maxAngle && sample.impact < .85 && sample.roughness < .72;

    if (combo) {
      gravelTime = sample.roughness > .70 ? gravelTime + dt : Math.max(0, gravelTime - dt * 2);
      spinTime = sample.speed > 6 && (sample.forward < -.95 || angle > spinAngle || sample.along < -2.9) ? spinTime + dt : Math.max(0, spinTime - dt * 2);
      if (sample.impact > 1.45) { settle('DINDING'); return; }
      if (spinTime > .25) { settle('SPIN'); return; }
      if (gravelTime > .61) { settle('KELUAR JALUR'); return; }
    }

    if (active) {
      if (side !== candidate) { candidate = side; candidateTime = 0; }
      candidateTime += dt;
    } else { candidate = 0; candidateTime = 0; }
    if (active && (candidateTime >= .16 || (combo && side === lastSide))) {
      if (!lastSide) lastSide = side;
      if (lastSide !== side) {
        if (legTime > .34 && sample.speed > 9.1) { links++; combo += 112 * multiplier(); sequence++; }
        lastSide = side; legTime = 0;
      }
      const accuracy = .57 + .43 * cap(1 - Math.abs(angle - .64) / .57, 0, 1);
      const lineSpeed = Math.min(sample.pointsAlong ?? sample.along, 29) * 3.6;
      legTime += dt; activeTime += dt; gripTime = 0; grace = 1;
      const earned = lineSpeed * (angle * degrees) * .16 * accuracy * multiplier();
      combo += earned * (wide ? outsideMultiplier : 1) * dt;
      if(wide)comboBonus+=earned*(outsideMultiplier-1)*dt;
      phase = 'drift'; outer = wide; result = null; danger = '';
      if (sample.linking) linkWindow = .48;
    } else {
      outer = false;
      if (!combo) return;
      linkWindow = sample.linking ? .48 : Math.max(0,linkWindow-dt);
      gripTime += dt;
      const window = linkWindow > 0 ? 1.52 : 1.04;
      grace = cap(1-gripTime/window, 0, 1);
      phase = 'carry';
      if (gripTime > window && (angle < .245 || sample.speed < 6.5 || gripTime > 1.82)) settle();
    }
  }

  function snapshot() {
    const last = !combo && notice > 0 ? result : null;
    return { total:banked, top:peak, points:combo ? Math.round(combo) : last ? saved : 0,
      multiplier:combo ? multiplier() : last ? savedMultiplier : 1, links:combo ? links : last ? savedLinks : 0, allLinks,
      grace, outer, phase:last || phase, cause:last==='lost'?danger:'', sequence,
      bonusPoints:Math.round(bankedBonus), pendingBonus:Math.round(comboBonus) };
  }
  return {step,reset,snapshot,get inBonus(){return outer;},finish:()=>settle(spinTime>.1?'SPIN':gravelTime>.3?'KELUAR JALUR':'')};
}