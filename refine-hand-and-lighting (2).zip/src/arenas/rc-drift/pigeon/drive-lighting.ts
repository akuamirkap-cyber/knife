import type * as Three from 'three';

/**
 * Default drive-scene lighting for Rally Group B Lab, modelled on the three.js hemisphere/directional
 * lighting example (HSL sun & sky, gradient sky dome with offset/exponent, white haze fog).
 * Every parameter the example exposes for tweaking is here, mapped to a 0–100 percentage:
 *   hemi    — HemisphereLight intensity  (example: 2)
 *   dir     — DirectionalLight intensity (example: 3)
 *   shadow  — directional shadow intensity (example: 1, i.e. 100%)
 * plus two on/off switches (hemisphere / directional) like the example's GUI toggles.
 */
export type LightingState = {
  /** 0–100 — HemisphereLight (langit ↔ tanah) intensity, 100 = example value 2.0 */
  hemi: number;
  /** 0–100 — DirectionalLight (matahari) intensity, 100 = example value 3.0 */
  dir: number;
  /** 0–100 — dirLight.shadow.intensity (0% = bayangan hilang, 100% = example value 1) */
  shadow: number;
  /** HemisphereLight visible (example: toggle hemisphere light) */
  hemiOn: boolean;
  /** DirectionalLight visible (example: toggle directional light) */
  dirOn: boolean;
};

export const DEFAULT_LIGHTING: LightingState = { hemi: 100, dir: 100, shadow: 100, hemiOn: true, dirOn: true };
/** Example intensity the 0–100 slider maps onto. */
export const HEMI_MAX = 2.0, DIR_MAX = 3.0;
export type LightingMood = 'day' | 'rain' | 'night';
export const DEFAULT_MOOD: LightingMood = 'day';

export type DriveLighting = {
  scene: unknown;
  hemi: Three.HemisphereLight;
  dir: Three.DirectionalLight;
  dome: Three.Mesh;
  background: Three.Color;
  fog: Three.Fog;
  /** normalised world-space direction towards the sun (for god rays & sky disc) */
  readonly sunDirection: Three.Vector3;
  /** current percentages (kept in sync with apply()) */
  readonly state: LightingState;
  /** 'day' cerah siang · 'rain' hujan siang (mendung, langit kelabu) · 'night' malam (gelap + bintang + bulan) */
  setMood(mood: LightingMood): void;
  readonly mood: LightingMood;
  apply(next: Partial<LightingState>): LightingState;
};

export function createDriveLighting(
  T: typeof Three,
  scene: Three.Scene,
  opts: { radius: number; fogNear: number; fogFar: number },
): DriveLighting {
  // The example works in HSL: blue sky dome light, warm sand ground bounce, near-white warm sun.
  const hemiSky = new T.Color().setHSL(0.6, 1, 0.6);
  const hemiGround = new T.Color().setHSL(0.095, 1, 0.75);
  const sunColor = new T.Color().setHSL(0.1, 1, 0.95);
  const background = new T.Color().setHSL(0.6, 0, 1);

  // LIGHTS (example values: hemi 2, dir 3, position (-1, 1.75, 1) * 30)
  const hemi = new T.HemisphereLight(hemiSky, hemiGround, HEMI_MAX);
  hemi.position.set(0, 50, 0);
  scene.add(hemi);

  // Sun placed down the Mt. Haruna start straight (~42° elevation): the opening downhill frames a
  // bright high-noon disc with god rays spilling over the ridge. Same HSL colours as the example.
  const dir = new T.DirectionalLight(sunColor, DIR_MAX);
  dir.position.set(0.78, 0.36, -0.10).multiplyScalar(88);
  dir.castShadow = true;
  dir.shadow.mapSize.width = 2048;
  dir.shadow.mapSize.height = 2048;
  const d = 50;
  dir.shadow.camera.left = -d; dir.shadow.camera.right = d;
  dir.shadow.camera.top = d; dir.shadow.camera.bottom = -d;
  dir.shadow.camera.far = 3500;
  dir.shadow.bias = -0.0001;
  if ('intensity' in dir.shadow) dir.shadow.intensity = 1; // r160+: contoh "shadow intensity" di GUI
  scene.add(dir, dir.target);

  // Direction towards the sun disc baked into the dome
  const sunDirection = dir.position.clone().normalize();
  // FOG & BACKGROUND (example: scene.background HSL(0.6, 0, 1), fog same colour)
  scene.background = background;
  const fog = new T.Fog(background, opts.fogNear, opts.fogFar);
  scene.fog = fog;

  // SKYDOME (example: topColor copies the hemisphere colour; offset 33, exponent 0.6)
  const uniforms = {
    topColor: { value: hemiSky.clone() },
    bottomColor: { value: new T.Color(0xffffff) },
    offset: { value: 33 },
    exponent: { value: 0.6 },
    sunDirection: { value: sunDirection.clone() },
    sunTint: { value: new T.Color(1.0, 0.93, 0.80) },
    discPower: { value: 1500.0 },
    discGain: { value: 30.0 },
    innerGain: { value: 0.9 },
    glowGain: { value: 0.30 },
    washGain: { value: 0.10 },
  };
  const domeMaterial = new T.ShaderMaterial({
    uniforms,
    vertexShader: /* glsl */`
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPosition.xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: /* glsl */`
      uniform vec3 topColor; uniform vec3 bottomColor; uniform float offset; uniform float exponent;
      uniform vec3 sunDirection;
      uniform vec3 sunTint; uniform float discPower, discGain, innerGain, glowGain, washGain;
      varying vec3 vWorldPosition;
      void main() {
        float h = normalize(vWorldPosition + offset).y;
        float f = max(pow(max(h, 0.0), exponent), 0.0);
        // Brilliant high-noon sun / night moon: pin-sharp HDR disc, a warm inner ring, a broad halo and a wide atmospheric wash.
        vec3 dir = normalize(vWorldPosition);
        float s = max(dot(dir, sunDirection), 0.0);
        float disc = pow(s, discPower) * discGain;
        float inner = pow(s, 140.0) * innerGain;
        float glow = pow(s, 20.0) * glowGain;
        float wash = pow(s, 5.0) * washGain;
        vec3 sun = (disc + inner + glow + wash) * sunTint;
        gl_FragColor = vec4(mix(bottomColor, topColor, f) + sun, 1.0);
        #include <colorspace_fragment>
      }`,
    side: T.BackSide,
    depthWrite: false,
    fog: false,
  });
  const dome = new T.Mesh(new T.SphereGeometry(opts.radius, 32, 15), domeMaterial);
  dome.name = 'HSL gradient sky dome';
  dome.renderOrder = -30;
  scene.add(dome);

  // Star field for the night mood (only ~visible at 'night')
  const starCount = 650, starPos = new Float32Array(starCount * 3);
  let seed = 88172645463325252n;
  const rand = () => { seed = (seed * 6364136223846793005n + 1442695040888963407n) & 0xffffffffffffffffn; return Number((seed >> 11n) & 0xffffffn) / 0x1000000; };
  for (let i = 0; i < starCount; i++) {
    const a = rand() * Math.PI * 2, e = Math.acos(rand() * 0.92 + 0.08); // bias to upper sky
    const r = opts.radius * 0.93;
    starPos[i * 3] = Math.sin(e) * Math.cos(a) * r;
    starPos[i * 3 + 1] = Math.cos(e) * r;
    starPos[i * 3 + 2] = Math.sin(e) * Math.sin(a) * r;
  }
  const starGeo = new T.BufferGeometry();
  starGeo.setAttribute('position', new T.BufferAttribute(starPos, 3));
  const starMat = new T.PointsMaterial({ color: 0xcfe0ff, size: opts.radius * 0.0045, sizeAttenuation: true, fog: false, transparent: true, opacity: 0, depthWrite: false });
  const stars = new T.Points(starGeo, starMat);
  stars.name = 'Night stars';
  stars.renderOrder = -25;
  scene.add(stars);

  const state: LightingState = { ...DEFAULT_LIGHTING };
  const clampPct = (v: number) => Math.min(100, Math.max(0, Number.isFinite(v) ? v : 100));
  let mood: LightingMood = 'day';
  const baseFog = { near: opts.fogNear, far: opts.fogFar, color: background.clone() };
  const hemiSkyDay = hemiSky.clone(), hemiGroundDay = hemiGround.clone(), sunColorDay = sunColor.clone();
  function setMood(next: LightingMood) {
    mood = next;
    const u = domeMaterial.uniforms;
    if (mood === 'day') {
      scene.background = baseFog.color;
      scene.fog = fog; fog.color.copy(baseFog.color); fog.near = baseFog.near; fog.far = baseFog.far;
      hemi.color.copy(hemiSkyDay); hemi.groundColor.copy(hemiGroundDay);
      dir.color.copy(sunColorDay);
      u.topColor.value.copy(hemiSkyDay); u.bottomColor.value.set(0xffffff);
      u.sunTint.value.setRGB(1.0, 0.93, 0.80); u.discPower.value = 1500.0; u.discGain.value = 30.0;
      u.innerGain.value = 0.9; u.glowGain.value = 0.30; u.washGain.value = 0.10;
      starMat.opacity = 0;
    } else if (mood === 'rain') {
      // Overcast midday: grey steel sky, milky close haze, cool desaturated light — the sun drowned behind cloud.
      const rainFog = new T.Color(0x9fabB2);
      scene.background = rainFog;
      scene.fog = fog; fog.color.copy(rainFog); fog.near = Math.max(30, baseFog.near * 0.055); fog.far = baseFog.far * 0.30;
      hemi.color.set(0xaebbc2); hemi.groundColor.set(0x565a4e);
      dir.color.set(0xd6dde2);
      u.topColor.value.set(0x5d6b77); u.bottomColor.value.set(0x9dabB3);
      u.sunTint.value.setRGB(0.55, 0.58, 0.60); u.discPower.value = 900.0; u.discGain.value = 0.55;
      u.innerGain.value = 0.05; u.glowGain.value = 0.035; u.washGain.value = 0.012;
      starMat.opacity = 0;
    } else {
      // Night: deep indigo dome, bright moon (the "sun" disc re-tinted as a cool moon), dense near fog, lamps & headlights carry the scene.
      const nightFog = new T.Color(0x060d1c);
      scene.background = nightFog;
      scene.fog = fog; fog.color.copy(nightFog); fog.near = Math.max(40, baseFog.near * 0.032); fog.far = baseFog.far * 0.21;
      hemi.color.set(0x2c3a5c); hemi.groundColor.set(0x05070a);
      dir.color.set(0xb9c9e8);
      u.topColor.value.set(0x03081a); u.bottomColor.value.set(0x0e1a30);
      u.sunTint.value.setRGB(0.78, 0.85, 1.0); u.discPower.value = 2600.0; u.discGain.value = 22.0;
      u.innerGain.value = 0.55; u.glowGain.value = 0.16; u.washGain.value = 0.045;
      starMat.opacity = 0.95;
    }
    apply({});
  }
  function apply(next: Partial<LightingState>) {
    Object.assign(state, next);
    state.hemi = clampPct(state.hemi); state.dir = clampPct(state.dir); state.shadow = clampPct(state.shadow);
    hemi.visible = state.hemiOn;
    dir.visible = state.dirOn;
    const hemiMood = mood === 'night' ? 0.16 : mood === 'rain' ? 0.62 : 1;
    const dirMood = mood === 'night' ? 0.15 : mood === 'rain' ? 0.38 : 1;
    hemi.intensity = HEMI_MAX * state.hemi / 100 * hemiMood;
    dir.intensity = DIR_MAX * state.dir / 100 * dirMood;
    if ('intensity' in dir.shadow) dir.shadow.intensity = state.shadow / 100 * (mood === 'night' ? 0.4 : 1);
    return { ...state };
  }
  apply({});
  return { scene, hemi, dir, dome, background, fog, sunDirection, get mood() { return mood; }, get state() { return { ...state }; }, setMood, apply };
}
