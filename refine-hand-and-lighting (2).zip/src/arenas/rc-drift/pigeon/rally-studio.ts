import * as Three from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { RallyBuild } from './rally-config';
import { createRallyCourse } from './rally-course';
import { createHarunaRallyCourse } from './haruna-course';
import type { DriftZone, RunMode, Telemetry } from './rally-course';
import { createRallyCarModel } from './rally-model.js';
import { physicsStep } from './drift-physics.js';
import type { DriverInput, DriftState } from './drift-physics.js';
import { createDriftEffects } from './drift-effects';
import { createDriveAudio } from './drift-audio';
import { bumperLens, chaseLens, createDriveClock, createRenderBudget, lensRush } from './speed-cues.js';
import { createRoadExposure } from './road-exposure';
import { createCinematicPost } from './cinematic-post';
import type { FilmComposite } from './cinematic-post';
import { DEFAULT_LIGHTING } from './drive-lighting';
import type { LightingState } from './drive-lighting';

/** Individual cinematic switches (see the Kamera & Eksposure panel). `true` = effect on ("sesudah"). */
export type FilmFlags = FilmComposite & { shake: boolean; fovNarrow: boolean };
/** Default = exactly the switches that ship ON in the Kamera & Eksposure panel. */
/** Per user request the default look is clean: every cinematic effect OFF except Bloom & Glare Halus. */
export const DEFAULT_FILM: FilmFlags = { rays: true, contrastExposure: false, aces: false, bloom: true, motionBlur: false, shake: false, grain: false, dof: false, fovNarrow: false };
import { batchRigidParts } from './render-batching';
import type { RallyModel } from './rally-model.js';
import { createGhostScene } from './ghost-scene';
import { createBotGrid } from './bots';
import type { BotGrid } from './bots';
import { createTrackside } from './trackside';
import type { Trackside } from './trackside';
import { createRain } from './rain';
import type { Rain } from './rain';
import type { LightingMood } from './drive-lighting';
import { TRACK_SCALE } from './rally-road.js';
import { CAR_SCALE, DRIFT_SIM } from './rmx-drift-adapter';
import { coachingCue, ghostFollowTime } from './ghost-replay.js';
import type { GhostHudData, GhostMode } from './ghost-replay.js';

const TAU = Math.PI * 2;
export type ViewId = 'threeQuarter' | 'front' | 'noseDetail' | 'rear' | 'rearQuarter' | 'rearDetail' | 'left' | 'right' | 'top';
export type DriveKey = 'w' | 's' | 'a' | 'd';
export type GripKey = DriveKey | 'space';
export type ViewerMode = 'garage' | 'drive';
export type DriveCamera = 'chase' | 'overhead' | 'cockpit' | 'bumper';
export type CourseId = 'pinus' | 'haruna';
type ActiveCourse = ReturnType<typeof createRallyCourse> | ReturnType<typeof createHarunaRallyCourse>;
const T = Three;

type ViewPreset = { yaw: number; polar: number; y: number; x?: number; z?: number; zoom?: number };
const presets: Record<ViewId, ViewPreset> = {
  threeQuarter: { yaw: .870, polar: 1.288, y: .984 },
  front: { yaw: 0, polar: 1.471, y: 1.02, zoom: 1.125 },
  noseDetail: { yaw: -.765, polar: 1.245, x: -.106, y: .720, z: 2.098, zoom: 1.80 },
  rear: { yaw: Math.PI, polar: 1.493, y: 1.01, zoom: 1.12 },
  rearQuarter: { yaw: 2.67, polar: 1.378, y: 1.035, zoom: 1.08 },
  rearDetail: { yaw: -2.609, polar: 1.482, x: -.082, y: 1.030, z: -1.927, zoom: 1.58 },
  left: { yaw: Math.PI / 2, polar: 1.55, y: .96 },
  right: { yaw: -Math.PI / 2, polar: 1.55, y: .96 },
  top: { yaw: Math.PI / 2, polar: .001, y: .94, zoom: .98 },
};

type StudioCallbacks = {
  onManualOrbit: () => void;
  onTelemetry: (next: Telemetry) => void;
  onGhost: (next: GhostHudData|null) => void;
  onCourse: (route: string, start: { x: number; y: number }, length: number, zones: DriftZone[], name?: string) => void;
};
export type Studio = {
  view: (name: ViewId) => void;
  mode: (name: ViewerMode) => void;
  course: (id: CourseId) => void;
  camera: (name: DriveCamera) => void;
  ghost: (mode:GhostMode) => void;
  ghostSeek: (time:number) => void;
  ghostRate: (rate:number) => void;
  ghostPlay: (playing:boolean) => void;
  pause: (paused: boolean) => void;
  inspectGear: (enabled: boolean) => void;
  restart: (type?: RunMode) => void;
  zoomBy: (direction: number) => void;
  turntable: (enabled: boolean, wait?: number) => void;
  configure: (build: RallyBuild) => void;
  headlights: (enabled: boolean) => void;
  assist: (enabled: boolean) => void;
  sound: (enabled: boolean) => void;
  speedEffects: (enabled: boolean) => void;
  cinematic: (flags: FilmFlags) => void;
  lighting: (next: Partial<LightingState>) => void;
  mood: (next: LightingMood) => void;
  feint: (enabled: boolean) => void;
  unlockAudio: () => void;
  input: (key: GripKey, down: boolean) => void;
  releaseInputs: () => void;
  dispose: () => void;
};

export async function createStudio(host: HTMLDivElement, callbacks: StudioCallbacks, signal: AbortSignal, initial: { build: RallyBuild; headlights: boolean; view: ViewId; mode: ViewerMode; course?: CourseId; camera: DriveCamera; assist: boolean; sound: boolean; speedEffects: boolean; cinematic?: FilmFlags; lighting?: Partial<LightingState>; feintFlick?: boolean; mood?: LightingMood }): Promise<Studio | undefined> {
  await Promise.resolve();
  if (signal.aborted) return;

  const scene = new T.Scene();
  const renderer = new T.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = T.SRGBColorSpace;
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.13;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = T.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.domElement.setAttribute('aria-label', 'Model 3D interaktif coupe reli Grup B');
  renderer.domElement.setAttribute('role', 'img');
  host.append(renderer.domElement);

  const camera = new T.OrthographicCamera(-5, 5, 2.1, -2.1, .1, 64);
  const driverCamera = new T.PerspectiveCamera(60,1,.032,640*TRACK_SCALE);
  const chaseCamera = new T.PerspectiveCamera(53,1,.11,640*TRACK_SCALE);
  const aerialCamera = new T.PerspectiveCamera(43,1,.17,640*TRACK_SCALE);
  const bumperCamera = new T.PerspectiveCamera(60,1,.058,640*TRACK_SCALE);
  const cockpitLayer=2, companionLayer=3;
  driverCamera.layers.set(cockpitLayer);
  const mirrorCamera = new T.PerspectiveCamera(38,3.9,.15,640*TRACK_SCALE);
  const mirrorTarget = new T.WebGLRenderTarget(272,70,{ depthBuffer:true });
  mirrorTarget.texture.generateMipmaps=false;
  mirrorTarget.texture.repeat.x=-1; mirrorTarget.texture.offset.x=1;
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = .085;
  controls.enablePan = false;
  controls.rotateSpeed = .73;
  controls.zoomSpeed = .93;
  controls.minZoom = .62;
  controls.maxZoom = 2.7;
  controls.minPolarAngle = .001;
  controls.maxPolarAngle = 1.77;

  const hemi = new T.HemisphereLight(0xe4eaff, 0x65594c, 1.52);
  scene.add(hemi);
  function directional(color: number, strength: number, at: [number, number, number]) {
    const light = new T.DirectionalLight(color, strength); light.position.set(...at); scene.add(light); return light;
  }
  const key = directional(0xffeee2, 2.68, [-3.8, 7.5, 5.4]);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  Object.assign(key.shadow.camera, { left: -4.5, right: 4.5, top: 4.5, bottom: -4.5, near: 1, far: 20 });
  key.shadow.bias = -.0006;
  key.shadow.normalBias = .026;
  directional(0xe8ecff, 1.25, [5.6, 3.2, 1.7]);
  directional(0xf3f2ff, 1.55, [-1.8, 4.6, -6.7]);

  // Head/taillight beams for rain & night moods (children of the car, so they follow it everywhere)
  const headL = new T.SpotLight(0xffe6b8, 0, 90, 0.68, 0.55, 1.5); headL.position.set(0.52, 0.84, 2.05);
  const headR = new T.SpotLight(0xffe6b8, 0, 90, 0.68, 0.55, 1.5); headR.position.set(-0.52, 0.84, 2.05);
  const tailFlare = new T.PointLight(0xff2d18, 0, 11, 1.7); tailFlare.position.set(0, 0.82, -2.12);
  const car = createRallyCarModel({ ...initial, THREE: T });
  headL.target.position.set(1.1, 0, 16); car.add(headL.target);
  headR.target.position.set(-1.1, 0, 16); car.add(headR.target);
  car.add(headL, headR, tailFlare);
  scene.add(car);
  function cockpitLights(model:RallyModel) {
    // The first-person camera renders only the cockpit layer, so give that layer its own bright daylight rig.
    const skyFill=new T.HemisphereLight(0xeaf4ff,0x7a6248,1.62);
    skyFill.layers.set(cockpitLayer);model.add(skyFill);
    // Midday sun through the windscreen: warm, high and strong enough to model the knuckles and thumb web.
    const sun=new T.DirectionalLight(0xfff0d6,2.35);
    sun.position.set(.22,2.26,1.14);sun.target.position.set(.47,1.168,-.193);
    sun.layers.set(cockpitLayer);model.add(sun,sun.target);
    const bounce=new T.PointLight(0xf3f7ff,.56,2.55,1.55);
    bounce.layers.set(cockpitLayer);bounce.position.set(.248,1.729,-.412);model.add(bounce);
    const windshieldFill=new T.PointLight(0xffe4bc,.44,2.7,1.65);
    windshieldFill.layers.set(cockpitLayer);windshieldFill.position.set(.48,1.46,.49);model.add(windshieldFill);
  }
  function enableCabin(model:RallyModel) {
    // Exterior kit and wheel pivots stay out of their own cockpit draw pass.
    for(const part of ['cabin','hood','mirrors','evoHeritageDecals','classicHeritageDecals','evoRallyDecals','classicRallyDecals']) {
      model.getObjectByName(part)?.traverse(object=>object.layers.enable(cockpitLayer));
    }
    model.getObjectByName('lights')?.traverse(object=>{if((object as Three.PointLight).isPointLight)object.layers.enable(cockpitLayer);});
    cockpitLights(model);batchRigidParts(model);
  }
  enableCabin(car);
  const eyeRotation=new T.Quaternion(), carRotation=new T.Quaternion(), aim=new T.Vector3(), driverLocal=new T.Vector3(),
    mirrorLocal=new T.Vector3(), mirrorAim=new T.Vector3();
  const cameraOrigin=new T.Vector3(), cameraForward=new T.Vector3(), cameraFocus=new T.Vector3();
  const effects=createDriftEffects(T), audio=createDriveAudio(), exposure=createRoadExposure(T), post=createCinematicPost(T,renderer);
  audio.setEnabled(initial.sound);

  const grid = new T.Mesh(new T.PlaneGeometry(60, 60), new T.ShaderMaterial({
    transparent: true, depthWrite: false,
    vertexShader: `varying vec2 p; void main() { p = position.xy; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `varying vec2 p;
      void main() {
        vec2 p1 = p * 1.24;
        vec2 footprint = max(fwidth(p1), vec2(0.0001));
        vec2 q = abs(fract(p1 - 0.5) - 0.5) / footprint;
        vec2 resolved = (1.0 - min(q, 1.0)) * (1.0 - smoothstep(0.18, 0.63, footprint));
        float fade = 1.0 - smoothstep(2.4, 10.0, length(p));
        gl_FragColor = vec4(0.61, 0.64, 0.67, max(resolved.x, resolved.y) * fade * 0.101);
      }`,
  }));
  grid.rotation.x = -Math.PI / 2; grid.position.y = -.045; grid.renderOrder = -5; scene.add(grid);
  const ground = new T.Mesh(new T.PlaneGeometry(24, 24), new T.ShadowMaterial({ opacity: .13, depthWrite: false }));
  ground.rotation.x = -Math.PI / 2; ground.position.y = -.036; ground.receiveShadow = true; ground.renderOrder = -4; scene.add(ground);

  function contactMap() {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
    const c = canvas.getContext('2d')!;
    const gradient = c.createRadialGradient(64, 64, 4, 64, 64, 64);
    gradient.addColorStop(0, 'rgba(0,0,0,.83)'); gradient.addColorStop(.48, 'rgba(0,0,0,.61)');
    gradient.addColorStop(.77, 'rgba(0,0,0,.24)'); gradient.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = gradient; c.fillRect(0, 0, 128, 128);
    return new T.CanvasTexture(canvas);
  }
  const stamp = contactMap();
  function contact(x: number, z: number, w: number, l: number, alpha: number, parent:Three.Object3D=scene, y=-.028) {
    const mesh = new T.Mesh(new T.PlaneGeometry(w, l), new T.MeshBasicMaterial({ map: stamp, transparent: true, opacity: alpha, depthWrite: false }));
    mesh.rotation.x = -Math.PI / 2; mesh.position.set(x, y, z); mesh.renderOrder = 1; parent.add(mesh);
  }
  contact(0, .05, 3.83, 6.37, .77);
  for (const x of [-1.038, 1.038]) for (const z of [1.665, -1.433]) contact(x, z, .88, 1.06, .70);
  const driveShadow=new T.Group();
  contact(-.02,-.19,4.62,7.00,.84,driveShadow,.017);
  contact(.31,-.49,4.93,6.17,.29,driveShadow,.019);
  for(const x of [-1.038,1.038]) for(const z of [1.665,-1.433]) contact(x,z,.75,1.05,.76,driveShadow,.022);

  const lineMaterial = new T.LineBasicMaterial({ color: 0x83858a, opacity: .22, transparent: true, depthWrite: false });
  const circlePoints = Array.from({ length: 160 }, (_, i) => {
    const a = i / 160 * TAU;
    return new T.Vector3(Math.sin(a) * 3.25, -.023, Math.cos(a) * 3.25);
  });
  const circle = new T.LineLoop(new T.BufferGeometry().setFromPoints(circlePoints), lineMaterial);
  circle.renderOrder = -2; scene.add(circle);
  const tickPoints: Three.Vector3[] = [], accentPoints: Three.Vector3[] = [];
  for (let i = 0; i < 48; i++) {
    const a = i / 48 * TAU, r = i % 12 === 0 ? 3.46 : i % 4 === 0 ? 3.38 : 3.31;
    const target = i === 3 || i === 27 ? accentPoints : tickPoints;
    target.push(new T.Vector3(Math.sin(a) * 3.27, -.022, Math.cos(a) * 3.27), new T.Vector3(Math.sin(a) * r, -.022, Math.cos(a) * r));
  }
  scene.add(new T.LineSegments(new T.BufferGeometry().setFromPoints(tickPoints), lineMaterial));
  scene.add(new T.LineSegments(new T.BufferGeometry().setFromPoints(accentPoints), new T.LineBasicMaterial({ color: 0xc08d3b, transparent: true, opacity: .67, depthWrite: false })));

  const spherical = new T.Spherical(), orbit = new T.Vector3(), up = new T.Vector3(0, 1, 0);
  function setCamera(yaw: number, polar: number, y: number, x = 0, z = .013) {
    controls.target.set(x, y, z);
    orbit.setFromSpherical(spherical.set(11, polar, yaw));
    camera.position.copy(controls.target).add(orbit);
  }
  function presetFor(id: ViewId) {
    const s1 = car.userData.build.rear === 's1';
    const view: ViewPreset = s1 && id === 'rearQuarter' ? { yaw: -2.356, polar: 1.475, y: 1.055, z: -.084, zoom: 1.06 }
      : s1 && id === 'rear' ? { yaw: Math.PI, polar: 1.518, y: 1.066, z: -.088, zoom: 1.26 } : presets[id];
    const wingAllowance = car.userData.build.wing === 'high' && id !== 'noseDetail' && id !== 'top' ? .085 : 0;
    return { ...view, y: view.y + wingAllowance };
  }
  const initialView = presetFor(initial.view);
  setCamera(initialView.yaw, initialView.polar, initialView.y, initialView.x, initialView.z);
  camera.zoom = initialView.zoom ?? 1;
  controls.update();

  let dirty = true, frameId = 0, lastTime = performance.now();
  let auto = false, autoFrom = Infinity, dragged = false, pauseUntil = 0, redrawUntil = 0;
  let speed = 0, steer = 0, tapSteer = 0, tapUntil = 0;
  let destinationZoom = camera.zoom;
  let transition: null | { start: number; yaw: number; dyaw: number; polar: number; target: Three.Vector3; zoom: number; to: ViewPreset } = null;
  const keys = new Set<GripKey>();
  const inputQueue:{ key:GripKey; down:boolean; at:number }[]=[];
  const clock=createDriveClock(physicsStep), renderBudget=createRenderBudget();
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let mode:ViewerMode='garage', paused=false;
  let activeCourseId:CourseId=initial.course??'pinus';
  let course:ActiveCourse|null=null;
  let ghost:ReturnType<typeof createGhostScene>|null=null;
  let ghostMode:GhostMode='off',ghostPlaying=true,ghostReportAt=0,ghostLaunch=false,ghostOffset=0,ghostLap=0;
  let bots:BotGrid|null=null, trackside:Trackside|null=null;
  const rain:Rain = createRain(T, 470);
  let mood: LightingMood = initial.mood ?? 'day';
  let recent:Telemetry | null=null, reportAt=0, mirrorAt=0;
  let headingOffset=0, bumpCycle=0, cockpitAspect=1.8, controlGlance=0, inspectAmount=0;
  let inspectingGear=false, assistDrive=initial.assist, kineticEffects=initial.speedEffects, film: FilmFlags = { ...DEFAULT_FILM, ...(initial.cinematic ?? {}) },
    lightingState: LightingState = { ...DEFAULT_LIGHTING, ...(initial.lighting ?? {}) };
    let feintFlick=initial.feintFlick===true;
  // Cinematic rig state: smoothed G-force offsets, kerb / rev-limiter shake energy, and the running clock for the grain.
  let gLat=0, gLong=0, shakeEnergy=0, shakeClock=0, postTime=0;
  const rigRight=new T.Vector3(), rigUp=new T.Vector3(), rigForward=new T.Vector3();
  let chosenCamera:DriveCamera=initial.camera, activeCamera:DriveCamera=initial.camera;
  let cameraReady=false, chaseYaw=0, aerialYaw=0, bumperYaw=0, slideCam=0, padEngaged=false;
  // Exact dynamic chase camera from 3d-car-drift-simulator (2).zip:
  // blends car heading with velocity vector (0.38) so drift angles showcase cleanly!
  let rcPitch=0, rcFrame=-9, rcCount=0;
  const rcPos=new T.Vector3(), rcLook=new T.Vector3(), rcWantPos=new T.Vector3(), rcWantLook=new T.Vector3();
  let lightsUser = true; // the L key toggle — headlights desired on
  function applyMoodLights() {
    const night = mood === 'night', wet = mood === 'rain';
    headL.intensity = night ? (lightsUser ? 380 : 0) : wet ? (lightsUser ? 95 : 0) : 0;
    headR.intensity = headL.intensity;
    tailFlare.intensity = night ? 4.5 : wet ? 2 : 0;
    car.userData.setHeadlights(night ? lightsUser : wet ? lightsUser : false);
  }
  const smoothPos=new T.Vector3(), smoothLook=new T.Vector3();
  const sunProject=new T.Vector3(), sunForward=new T.Vector3(), sunWorld=new T.Vector3();
  let smoothCamReady=false;
  function cinematicRig(view:Three.PerspectiveCamera, dt:number, target:DriftState, bumper:boolean) {
    // Camera mounted to the car: lateral / longitudinal G ease the lens off-axis, kerbs and the rev limiter rattle it.
    if(!film.shake||prefersReducedMotion||inspectingGear||dt<=0) {gLat=gLong=shakeEnergy=0;return;}
    const cockpit=activeCamera==='cockpit', overhead=activeCamera==='overhead';
    gLat=T.MathUtils.damp(gLat,T.MathUtils.clamp(target.accelLat/9.81,-1.4,1.4),6,dt);
    gLong=T.MathUtils.damp(gLong,T.MathUtils.clamp(target.accelLong/9.81,-1.4,1.4),5,dt);
    const kerb=T.MathUtils.clamp((target.roughness-.04)*3.4,0,1);
    const limiter=target.rev>.955&&target.throttle>.55?1:0;
    const speedRumble=T.MathUtils.smoothstep(Math.abs(target.speed),16,44)*.22;
    const want=Math.max(kerb*(.55+.45*T.MathUtils.smoothstep(Math.abs(target.speed),3,20)),limiter*.6,speedRumble);
    shakeEnergy=want>shakeEnergy?T.MathUtils.damp(shakeEnergy,want,22,dt):T.MathUtils.damp(shakeEnergy,want,6,dt);
    shakeClock+=dt*(limiter?58:kerb>.1?37:19);
    const n1=Math.sin(shakeClock)*.62+Math.sin(shakeClock*2.31+1.3)*.38;
    const n2=Math.sin(shakeClock*1.47+.7)*.58+Math.sin(shakeClock*3.07+2.1)*.42;
    const n3=Math.sin(shakeClock*.83+2.9)*.7+Math.sin(shakeClock*2.73)*.3;
    const scale=(cockpit?.011:bumper?.016:overhead?.03:.02)*shakeEnergy;
    rigRight.set(1,0,0).applyQuaternion(view.quaternion);
    rigUp.set(0,1,0).applyQuaternion(view.quaternion);
    rigForward.set(0,0,-1).applyQuaternion(view.quaternion);
    const gScale=cockpit?.012:bumper?.03:.06;
    view.position.addScaledVector(rigRight,-gLat*gScale+n1*scale).addScaledVector(rigUp,n2*scale+gLong*gScale*.35);
    view.rotateZ(gLat*(cockpit?.012:.028)+n3*scale*.9);
    view.rotateX(-gLong*(cockpit?.006:.012)+n2*scale*.4);
    view.rotateY(n1*scale*.3);
  }
  function rcChase(dt:number, model:RallyModel, target:DriftState) {
    const yaw=model.rotation.y, spd=target.speed;
    const fx=Math.sin(yaw), fz=Math.cos(yaw);
    const snap=!cameraReady||rcCount-rcFrame>2||dt<=0; rcFrame=++rcCount;

    // Exact heading/velocity blend (3d-car-drift-simulator (2).zip updateCamera)
    let dirX=fx, dirZ=fz;
    if(spd>4) {
      const vxNorm=target.vx/spd, vzNorm=target.vz/spd;
      const blend=DRIFT_SIM.CAM_VEL_BLEND; // 0.38
      dirX=fx*(1-blend)+vxNorm*blend;
      dirZ=fz*(1-blend)+vzNorm*blend;
      const len=Math.hypot(dirX,dirZ)||1;
      dirX/=len; dirZ/=len;
    }

    // Track elevation pitch compensation (0 on flat Sirkuit Pinus, crisp clear view on sloped Mt. Haruna)
    rcPitch=snap?model.rotation.x:rcPitch+(model.rotation.x-rcPitch)*(1-Math.exp(-dt*5));
    const slopeRaise=T.MathUtils.clamp(rcPitch*4.2,-1.1,1.8);
    const slopeDrop=T.MathUtils.clamp(-rcPitch*2.4,-1.2,1.2);
    const p=model.position;
    rcWantPos.set(
      p.x-dirX*DRIFT_SIM.CAM_DIST_CLOSE,
      p.y+DRIFT_SIM.CAM_HEIGHT_CLOSE+slopeRaise,
      p.z-dirZ*DRIFT_SIM.CAM_DIST_CLOSE,
    );
    rcWantLook.set(
      p.x+fx*DRIFT_SIM.CAM_LOOK_AHEAD,
      p.y+DRIFT_SIM.CAM_LOOK_Y+slopeDrop,
      p.z+fz*DRIFT_SIM.CAM_LOOK_AHEAD,
    );


    if(film.fovNarrow) {
      // Dynamic chase (neck FX): the rig trails the car's own heading with a fraction-of-a-second lag, so when the
      // tail steps out the camera is still behind the old heading and the car's flank fills the frame. Pull the
      // camera in and down a little to suit the tighter lens.
      rcWantPos.set(p.x-dirX*(DRIFT_SIM.CAM_DIST_CLOSE+.9),p.y+DRIFT_SIM.CAM_HEIGHT_CLOSE*.80+slopeRaise,p.z-dirZ*(DRIFT_SIM.CAM_DIST_CLOSE+.9));
    }
    if(snap) {
      rcPos.copy(rcWantPos);
      rcLook.copy(rcWantLook);
      cameraReady=true;
    } else {
      const posAlpha=1-Math.exp(-(film.fovNarrow?DRIFT_SIM.CAM_POS_LERP*.52:DRIFT_SIM.CAM_POS_LERP)*dt);
      const lookAlpha=1-Math.exp(-(film.fovNarrow?DRIFT_SIM.CAM_LOOK_LERP*.55:DRIFT_SIM.CAM_LOOK_LERP)*dt);
      rcPos.lerp(rcWantPos,posAlpha);
      rcLook.lerp(rcWantLook,lookAlpha);
    }

    chaseCamera.position.copy(rcPos);
    // Broadcast-style 45–55° lens when the FOV switch is on; the stock arcade lens otherwise.
    const targetFov=film.fovNarrow
      ?47+Math.min(7,spd*.16)
      :DRIFT_SIM.CAM_BASE_FOV+Math.min(DRIFT_SIM.CAM_FOV_MAX_BOOST,spd*DRIFT_SIM.CAM_FOV_SPEED);
    if(Math.abs(chaseCamera.fov-targetFov)>.01) {
      chaseCamera.fov=snap?targetFov:chaseCamera.fov+(targetFov-chaseCamera.fov)*(1-Math.exp(-DRIFT_SIM.CAM_FOV_LERP*dt));
      chaseCamera.updateProjectionMatrix();
    }
    chaseCamera.up.set(0,1,0);
    chaseCamera.lookAt(rcLook);
    return chaseCamera;
  }
  let rush=0, width=1, height=1, maxResolution=1, drewDrive=false, renderPace=1/60;
  const previousPose={x:0,y:0,z:0,yaw:0,pitch:0,roll:0,ready:false};
  let timedStep=0;
  let pedalKey: 'w'|'s'|null=null, pedalUntil=0, handbrakeUntil=0;
  let previousHand=false;

  function applyResolution() {
    // HD pipeline: keep up to ~5.2 megapixels of drawing buffer (≈ QHD@1.6x CSS on 1080p, 2x on ≤720p) and a denser
    // minimum floor, instead of the old ~2 MP cap that made the cockpit look soft on modern displays.
    const scale=mode==='drive'?renderBudget.scale:1;
    const floor=Math.min(1,1000/width,560/height);
    const pixelRatio=Math.max(Math.min(maxResolution,floor),maxResolution*scale);
    renderer.setDrawingBufferSize(width,height,pixelRatio);
  }

  function resize() {
    const size=host.getBoundingClientRect();
    if (!size.width || !size.height) return;
    width=size.width;height=size.height;
    const aspect = width / height;
    cockpitAspect=aspect;
    const overhead = width >= 550 && car.userData.build.wing === 'high' ? 1.101 : 1;
    const vertical = Math.max(3.63, (width < 550 ? 6.92 : 7.40) / aspect) * overhead;
    camera.left = -vertical * aspect / 2; camera.right = vertical * aspect / 2;
    camera.top = vertical / 2; camera.bottom = -vertical / 2;
    camera.updateProjectionMatrix();
    for(const view of [driverCamera,chaseCamera,aerialCamera,bumperCamera]) {view.aspect=aspect;view.updateProjectionMatrix();}
    maxResolution=Math.min(window.devicePixelRatio||2,2,Math.sqrt(5200000/(width*height)));
    applyResolution();
    dirty = true;
  }
  resize();
  const observer = new ResizeObserver(resize); observer.observe(host);
  renderer.shadowMap.needsUpdate = true;

  function changeView(id: ViewId) {
    const to = presetFor(id);
    const from = spherical.setFromVector3(orbit.copy(camera.position).sub(controls.target));
    const diff = to.yaw - from.theta, dyaw = Math.atan2(Math.sin(diff), Math.cos(diff));
    destinationZoom = to.zoom ?? 1;
    transition = { start: performance.now(), yaw: from.theta, dyaw, polar: from.phi, target: controls.target.clone(), zoom: camera.zoom, to };
    dirty = true;
  }

  function cockpitPose(dt:number, model:RallyModel, run:DriftState) {
    const eye=model.userData.sockets.driverEye;
    eye.getWorldPosition(driverCamera.position);eye.getWorldQuaternion(eyeRotation);
    const motion=(prefersReducedMotion||inspectingGear)?0:T.MathUtils.clamp(Math.abs(run.cueSpeed??run.speed)/25,0,1);
    bumpCycle+=Math.abs(run.cueSpeed??run.speed)*dt*motion*.65;
    headingOffset=T.MathUtils.damp(headingOffset,run.steer*.04+T.MathUtils.clamp(run.beta*.48,-.42,.42),2.8,dt);
    const narrow=1-T.MathUtils.smoothstep(cockpitAspect,.85,1.65);
    const reaching=model.userData.driverAction.reach;
    controlGlance=T.MathUtils.damp(controlGlance,inspectingGear?0:reaching*reaching,7.5,dt);
    inspectAmount=prefersReducedMotion?Number(inspectingGear):T.MathUtils.damp(inspectAmount,Number(inspectingGear),8,dt);
    if(Math.abs(inspectAmount-Number(inspectingGear))<.001) inspectAmount=Number(inspectingGear);
    const look=inspectAmount;
    const driveFov=T.MathUtils.lerp(56,74,narrow)+rush*T.MathUtils.lerp(7.2,4.8,narrow), detailFov=T.MathUtils.lerp(37,48,narrow);
    driverCamera.fov=T.MathUtils.lerp(driveFov,detailFov,look);
    driverCamera.updateProjectionMatrix();
    driverLocal.set(run.steer*.008*(1-look)-.213*look,
      Math.sin(bumpCycle*2.4)*motion*.0018-.069*look,-.014-narrow*.022+.121*look+.026*rush*(1-look)).multiplyScalar(CAR_SCALE).applyQuaternion(eyeRotation);
    driverCamera.position.add(driverLocal);
    driverCamera.up.set(0,1,0).applyQuaternion(eyeRotation);
    aim.set(T.MathUtils.lerp(-.055+headingOffset-controlGlance*(.024+.085*narrow),-.327,look),
      T.MathUtils.lerp(-.288-.055*narrow-controlGlance*.022+.036*rush,-.434-.042*narrow,look),1).applyQuaternion(eyeRotation).add(driverCamera.position);
    driverCamera.lookAt(aim);
  }

  let smoothPitch=0, smoothRoll=0;
  function drivePose(dt:number) {
    if(!course) return driverCamera;
    const run=course.state;
    const alpha=previousPose.ready&&!paused&&!inspectingGear&&!course.finished?clock.alpha:1;
    const x=T.MathUtils.lerp(previousPose.x,run.x,alpha),z=T.MathUtils.lerp(previousPose.z,run.z,alpha);
    const arc=Math.atan2(Math.sin(run.yaw-previousPose.yaw),Math.cos(run.yaw-previousPose.yaw));
    const yaw=previousPose.yaw+arc*alpha;
    const targetSurface='slopeAt' in course&&typeof course.slopeAt==='function'
      ?course.slopeAt(x,z,yaw)
      :{y:'heightAt' in course&&typeof course.heightAt==='function'?course.heightAt(x,z):0,pitch:0,roll:0};
    const y=targetSurface.y;
    if(!previousPose.ready||dt<=0) {smoothPitch=targetSurface.pitch;smoothRoll=targetSurface.roll;}
    else {
      smoothPitch=T.MathUtils.damp(smoothPitch,targetSurface.pitch,10,dt);
      smoothRoll=T.MathUtils.damp(smoothRoll,targetSurface.roll,10,dt);
    }
    car.position.set(x,y,z);car.rotation.order='YXZ';car.rotation.set(smoothPitch,yaw,smoothRoll);
    driveShadow.position.set(x,y,z);driveShadow.rotation.order='YXZ';driveShadow.rotation.set(smoothPitch,yaw,smoothRoll);
    const watched=ghostMode==='watch'?ghost:null;
    const target=watched?.motion??run, model=watched?.car??car;
    const trackYaw=watched?.playback.heading??course.heading;
    const active=kineticEffects&&!prefersReducedMotion&&!inspectingGear;
    rush=active?T.MathUtils.damp(rush,lensRush(target.cueSpeed??target.speed),2.8,dt):0;
    if(activeCamera==='cockpit') {cockpitPose(dt,model,target);return driverCamera;}
    if(activeCamera==='chase') return rcChase(dt,model,target);
    const smooth=(angle:number,wanted:number,rate:number)=>angle+Math.atan2(Math.sin(wanted-angle),Math.cos(wanted-angle))*(1-Math.exp(-rate*dt));
    if(!cameraReady) slideCam=target.beta;
    slideCam=T.MathUtils.damp(slideCam,target.beta,4.2,dt);
    const slideAir=T.MathUtils.clamp(Math.abs(slideCam)*1.42,0,1), heading=model.rotation.y+slideCam*(.66+slideAir*.28);
    const tall=1-T.MathUtils.smoothstep(cockpitAspect,.63,1.30);
    const lowHeading=model.rotation.y+T.MathUtils.clamp(slideCam*.56,-.48,.48);
    if(!cameraReady) {chaseYaw=heading;aerialYaw=trackYaw;bumperYaw=lowHeading;cameraReady=true;smoothCamReady=false;}
    chaseYaw=smooth(chaseYaw,heading,4.0);aerialYaw=smooth(aerialYaw,trackYaw,2.8);bumperYaw=smooth(bumperYaw,lowHeading,9.0);
    if(activeCamera==='bumper') {
      const lens=bumperLens(tall,rush),mYaw=model.rotation.y;
      const wantX=model.position.x+Math.sin(mYaw)*2.53*CAR_SCALE;
      const wantY=model.position.y+lens.height*CAR_SCALE;
      const wantZ=model.position.z+Math.cos(mYaw)*2.53*CAR_SCALE;
      const slopePitch=-model.rotation.x*.85;
      cameraFocus.set(wantX+Math.sin(bumperYaw),wantY+lens.pitch+slopePitch,wantZ+Math.cos(bumperYaw));
      if(!smoothCamReady||dt<=0) {smoothPos.set(wantX,wantY,wantZ);smoothLook.copy(cameraFocus);smoothCamReady=true;}
      else {smoothPos.lerp(cameraOrigin.set(wantX,wantY,wantZ),1-Math.exp(-dt*12));smoothLook.lerp(cameraFocus,1-Math.exp(-dt*11));}
      bumperCamera.position.copy(smoothPos);
      // Hood / bumper rig on the cinematic setting uses a tighter 50–55° lens so the road ahead reads denser.
      bumperCamera.fov=film.fovNarrow?Math.min(55,50+rush*5):lens.field;bumperCamera.updateProjectionMatrix();bumperCamera.lookAt(smoothLook);
      return bumperCamera;
    }
    const skyView=activeCamera==='overhead', view=skyView?aerialCamera:chaseCamera;
    const angle=skyView?aerialYaw:chaseYaw;
    cameraForward.set(Math.sin(angle),0,Math.cos(angle));
    cameraOrigin.copy(model.position);
    const lens=chaseLens(tall,rush,slideAir,target.accelLong);
    const wantPos=cameraOrigin.clone().addScaledVector(cameraForward,skyView?-11.8-tall*1.4+rush*1.55:-lens.following);
    wantPos.y=model.position.y+(skyView?31.4+tall*3.7-rush*2.4:lens.height);
    cameraFocus.copy(cameraOrigin).addScaledVector(cameraForward,skyView?5.4+tall*1.6+rush*4.3:lens.lookAhead-(watched?1.6:0));
    cameraFocus.y=model.position.y+(skyView?.16:lens.lookHeight-(watched?.28:0));
    if(!smoothCamReady||dt<=0) {smoothPos.copy(wantPos);smoothLook.copy(cameraFocus);smoothCamReady=true;}
    else {smoothPos.lerp(wantPos,1-Math.exp(-dt*4.5));smoothLook.lerp(cameraFocus,1-Math.exp(-dt*6.0));}
    view.position.copy(smoothPos);
    view.fov=skyView?47+tall*4+rush*4.2:lens.field;
    view.updateProjectionMatrix();view.lookAt(smoothLook);
    if(!skyView&&!prefersReducedMotion) view.rotateZ(slideCam*.026);
    return view;
  }

  function applyDriveCamera() {
    const next=inspectingGear?'cockpit':chosenCamera;
    const watching=ghostMode==='watch', interior=next==='cockpit';
    activeCamera=next;cameraReady=false;smoothCamReady=false;inspectAmount=controlGlance=headingOffset=0;
    if(!watching&&ghostMode==='follow')driverCamera.layers.enable(companionLayer);
    else driverCamera.layers.disable(companionLayer);
    car.userData.setCockpitView(interior&&!watching,true);
    car.userData.setMirrorTexture(interior&&!watching?mirrorTarget.texture:null);
    if(ghost) {
      ghost.setCockpit(interior&&watching);
      ghost.car.userData.setMirrorTexture(interior&&watching?mirrorTarget.texture:null);
      if(ghostMode==='off')ghost.car.visible=ghost.shell.visible=ghost.trail.mesh.visible=ghost.effects.root.visible=false;
    }
    const labels:Record<DriveCamera,string>={chase:'Kamera belakang',overhead:'Kamera atas',cockpit:'Kokpit',bumper:'Kamera bemper'};
    const courseLabel=activeCourseId==='haruna'?'Mt. Haruna':'Sirkuit Pinus';
    renderer.domElement.dataset.camera=next;
    renderer.domElement.dataset.subject=watching?'ghost':'player';
    renderer.domElement.setAttribute('aria-label',`${labels[next]} ${watching?'Ghost AI':'pemain'} di ${courseLabel}`);
    mirrorAt=0;dirty=true;
  }

  function publishGhost(now:number,force=false) {
    if(!ghost||ghostMode==='off') {if(force)callbacks.onGhost(null);return;}
    if(!force&&now<ghostReportAt)return;
    ghostReportAt=now+62;
    const {playback,reference}=ghost, frame=playback.frame, {input,state}=frame;
    const player=recent;
    const paceDelta=ghostMode==='follow'&&player&&player.distance>7?player.time-reference.timeAtDistance(player.distance):null;
    const {bonusSeconds,bonusCoverage}=frame;
    callbacks.onGhost({mode:ghostMode,time:playback.time,duration:reference.duration,rate:playback.rate,
      playing:ghostPlaying&&!playback.ended&&!paused,ended:playback.ended,cue:coachingCue(frame),telemetry:frame.telemetry,
      gas:Number(input.gas),brake:Number(input.brake),handbrake:input.handbrake,steering:T.MathUtils.radToDeg(state.steerAngle),
      lapTarget:reference.result.time,bonusSeconds,bonusCoverage,zoneCount:reference.zoneSeconds.length,clips:reference.clips,paceDelta});
  }

  function seekGhost(time:number) {
    if(!ghost)return;
    ghost.seek(time,ghostMode==='watch');rush=0;cameraReady=false;mirrorAt=0;dirty=true;
    publishGhost(performance.now(),true);
  }

  function stageGhostAhead() {
    if(!course||!ghost)return;
    const player=course.snapshot(),target=player.distance+8.8;
    const start=ghost.reference.frames.find(frame=>frame.telemetry.distance>=target);
    const elapsed=start?.time??ghost.reference.duration;
    ghost.seek(elapsed);ghostOffset=elapsed-player.time;
    ghostLaunch=course.state.speed>.32;ghostLap=course.lap;
  }

  function switchGhost(next:GhostMode) {
    if(!course||!course.track||mode!=='drive'||next===ghostMode)return;
    if(next!=='off'&&!ghost) {
      ghost=createGhostScene(course.track);
      ghost.shell.traverse(object=>object.layers.enable(companionLayer));
      enableCabin(ghost.car);
      ghost.effects.root.traverse(object=>object.layers.enable(cockpitLayer));
      ghost.trail.mesh.layers.enable(cockpitLayer);
      course.scene.add(ghost.car,ghost.shell,ghost.effects.root,ghost.trail.mesh);
    }
    const before=ghostMode;ghostMode=next;
    if(next==='watch'||before==='watch') {
      inspectingGear=false;clock.reset();timedStep=0;releaseInputs();audio.silence();
    }
    if(next==='follow')stageGhostAhead();
    if(ghost&&next==='watch'&&before==='off')ghost.seek(0,true);
    if(next==='watch') {
      if(ghost?.playback.ended)ghost.seek(0,true);
      ghostPlaying=true;
    }
    applyDriveCamera();
    lastTime=performance.now();
    publishGhost(performance.now(),true);
  }

  function publishCourse(now:number,force=false) {
    if(!course||(!force&&now<reportAt)) return;
    reportAt=now+52;
    const next=course.snapshot();
    if(force||!recent||next.time!==recent.time||next.speed!==recent.speed||next.gear!==recent.gear||next.coasting!==recent.coasting||Math.abs(next.throttle-recent.throttle)>.025||Math.abs(next.rev-recent.rev)>.012||next.drift.phase!==recent.drift.phase||next.controlPhase!==recent.controlPhase||next.finished!==recent.finished) {
      if(recent&&next.drift.sequence!==recent.drift.sequence) {
        if(next.drift.phase==='banked') audio.feedback('bank');
        else if(next.drift.phase==='lost') audio.feedback('lost');
        else if(next.drift.links>recent.drift.links) audio.feedback('link');
      }
      recent=next;callbacks.onTelemetry(next);
    }
  }

  function updateMirror(now:number) {
    if(!course||now<mirrorAt) return;
    mirrorAt=now+(renderPace>.044?315:ghostMode==='watch'?210:157);
    const target=ghostMode==='watch'&&ghost?ghost.car:car;
    target.getWorldQuaternion(carRotation);
    mirrorCamera.position.copy(target.localToWorld(mirrorLocal.set(-.17,1.59,-2.91)));
    mirrorAim.set(-.055,-.039,-1).applyQuaternion(carRotation).add(mirrorCamera.position);
    mirrorCamera.lookAt(mirrorAim);
    const visible=target.visible;target.visible=false;
    renderer.setRenderTarget(mirrorTarget);
    renderer.render(course.scene,mirrorCamera);
    renderer.setRenderTarget(null);
    target.visible=visible;
  }

  function freeObjectGraph(root: Three.Object3D) {
    const freed = new Set<unknown>();
    root.traverse((object: Three.Object3D) => {
      const renderable = object as Three.Mesh;
      if (renderable.geometry && !freed.has(renderable.geometry)) { renderable.geometry.dispose(); freed.add(renderable.geometry); }
      const materials = renderable.material ? (Array.isArray(renderable.material) ? renderable.material : [renderable.material]) : [];
      materials.forEach(material => {
        if (freed.has(material)) return;
        for (const value of Object.values(material)) {
          if ((value as Three.Texture | undefined)?.isTexture && !freed.has(value)) { (value as Three.Texture).dispose(); freed.add(value); }
        }
        material.dispose(); freed.add(material);
      });
      if ((object as Three.InstancedMesh).isInstancedMesh) (object as Three.InstancedMesh).dispose();
    });
  }

  function syncCameraFar(id: CourseId) {
    const farDist = id === 'haruna' ? 9500 : 640 * TRACK_SCALE;
    for (const view of [driverCamera, chaseCamera, aerialCamera, bumperCamera, mirrorCamera]) {
      if (view.far !== farDist) { view.far = farDist; view.updateProjectionMatrix(); }
    }
  }

  function loadCourse(id: CourseId) {
    car.removeFromParent();
    effects.root.removeFromParent();
    driveShadow.removeFromParent();
    if (ghost) {
      ghost.car.removeFromParent();
      ghost.shell.removeFromParent();
      ghost.effects.root.removeFromParent();
      ghost.trail.mesh.removeFromParent();
      ghost = null;
    }
    ghostMode = 'off';
    callbacks.onGhost(null);
    if (course) {
      freeObjectGraph(course.scene);
      course = null;
    }
    activeCourseId = id;
    syncCameraFar(id);
    course = id === 'haruna' ? createHarunaRallyCourse(T, renderer) : createRallyCourse(T);
    course.lighting.apply(lightingState);
    course.lighting.setMood(mood);
    if (bots) bots.setTrack(course.botTrack); else bots = createBotGrid(T, course.botTrack);
    course.scene.add(bots.group);
    // rebuild trackside (spectators & lamps) for this circuit
    if (trackside) { trackside.dispose(); trackside = null; }
    trackside = createTrackside(T, {
      sampler: course.botTrack,
      barrier: activeCourseId === 'pinus' ? 22.6 : 5.95,
      lampHeight: activeCourseId === 'pinus' ? 6.4 : 4.6,
      seed: activeCourseId === 'pinus' ? 1337 : 4242,
    });
    trackside.setMood(mood);
    course.scene.add(trackside.group);
    course.scene.add(rain.object);
    rain.setVisible(mood === 'rain');
    applyMoodLights();
    course.setFeintMode?.(feintFlick);
    effects.reset();
    effects.root.traverse(object => object.layers.enable(cockpitLayer));
    course.scene.add(effects.root, driveShadow);
    course.scene.traverse(object => object.layers.enable(cockpitLayer));
    if (mode === 'drive') course.scene.add(car);
    clock.reset(); timedStep = 0; paused = false; inspectingGear = false;
    inspectAmount = headingOffset = controlGlance = bumpCycle = mirrorAt = rush = 0;
    previousPose.ready = false; cameraReady = false; smoothCamReady = false;
    car.scale.setScalar(CAR_SCALE);
    driveShadow.scale.setScalar(CAR_SCALE);
    car.userData.resetDriver(course.state.gear);
    car.userData.tick(.06, course.state);
    callbacks.onCourse(course.route, course.startMarker, course.length, course.zones, id === 'haruna' ? 'MT. HARUNA' : 'SIRKUIT PINUS');
    if (mode === 'drive') {
      applyDriveCamera();
      publishCourse(performance.now(), true);
    }
    dirty = true;
  }

  function setMode(next:ViewerMode) {
    if(mode===next) return;
    mode=next;releaseInputs();auto=false;dragged=false;paused=false;controlGlance=0;inspectingGear=false;inspectAmount=0;
    clock.reset();timedStep=0;renderBudget.clearSamples();drewDrive=false;renderPace=1/60;applyResolution();
    transition=null; controls.enabled=next==='garage'; dirty=true;
    if(next==='drive') {
      if(!course) loadCourse(activeCourseId);
      else course.scene.add(car);
      car.scale.setScalar(CAR_SCALE);driveShadow.scale.setScalar(CAR_SCALE); // real-size car on the circuit
      renderer.shadowMap.enabled=false;
      renderer.toneMappingExposure=activeCourseId==='haruna'?1.08:1.20;
      car.userData.resetDriver(course!.state.gear);previousPose.ready=false;cameraReady=false;smoothCamReady=false;
      applyDriveCamera();publishCourse(performance.now(),true);
    } else {
      audio.silence();
      scene.add(car);car.position.set(0,0,0);car.rotation.set(0,0,0);car.scale.setScalar(1);car.visible=true;
      car.userData.setCockpitView(false);car.userData.setMirrorTexture(null);
      renderer.shadowMap.enabled=true;renderer.shadowMap.needsUpdate=true;
      renderer.toneMappingExposure=1.13;
      renderer.domElement.dataset.camera='garage';
      renderer.domElement.setAttribute('aria-label','Model 3D interaktif coupe reli Grup B');
      speed=steer=0;
    }
  }

  controls.addEventListener('change', () => { dirty = true; });
  controls.addEventListener('start', () => {
    transition = null; destinationZoom = camera.zoom; dragged = true;
    auto = false; callbacks.onManualOrbit();
  });
  controls.addEventListener('end', () => { dragged = false; pauseUntil = performance.now() + 200; destinationZoom = camera.zoom; });

  function readPad() {
    let pad:Gamepad|undefined;
    if(navigator.getGamepads) try {
      pad=Array.from(navigator.getGamepads()).find(item=>item?.connected&&item.mapping==='standard')??undefined;
    } catch { /* Keyboard and touch still work when gamepads are unavailable. */ }
    const axis=pad?.axes[0]??0, dead=.14;
    const stick=-Math.sign(axis)*Math.max(0,Math.abs(axis)-dead)**1.19/(1-dead)**1.19;
    const gas=pad?.buttons[7]?.value??0, brake=pad?.buttons[6]?.value??0, brakeButton=Boolean(pad?.buttons[0]?.pressed);
    if(!padEngaged&&(gas>.15||brake>.15||brakeButton)) audio.unlock();
    padEngaged=gas>.15||brake>.15||brakeButton;
    return {gas,brake,stick,brakeButton};
  }

  function driverInput(now:number,pad:ReturnType<typeof readPad>):DriverInput {
    while(inputQueue.length&&inputQueue[0].at<=now) {
      const {key,down,at}=inputQueue.shift()!;
      if(!down) {
        keys.delete(key);
        // A touch or keyboard tap gives the brake a short pulse after release as well.
        continue;
      }
      if(keys.has(key)) continue;
      keys.add(key);
      if(key==='w'||key==='s') {pedalKey=key;pedalUntil=at;}
      else if(key==='space') {
        handbrakeUntil=at;
      }
      else {tapSteer=key==='a'?1:-1;tapUntil=at;}
    }
    const left=keys.has('a'),right=keys.has('d');
    const wish=left||right?Number(left)-Number(right):now<tapUntil?tapSteer:0;
    const hand=now<handbrakeUntil||keys.has('space')||pad.brakeButton;
    if(hand&&!previousHand&&!keys.has('space')&&pad.brakeButton&&assistDrive)handbrakeUntil=now+115;
    previousHand=hand;
    return {gas:keys.has('w')||(now<pedalUntil&&pedalKey==='w')?1:pad.gas,
      brake:keys.has('s')||(now<pedalUntil&&pedalKey==='s')?1:pad.brake,
      steer:wish||pad.stick,handbrake:hand,assist:assistDrive,response:'smooth'};
  }

  function frame(now: number) {
    const elapsed=Math.max(0,(now-lastTime)/1000);
    const dt = Math.min(elapsed, .075);
    lastTime = now;
    if (mode==='drive' && course) {
      const watched=ghostMode==='watch'?ghost:null;
      const run=course.state, moving=!watched&&!inspectingGear&&!course.finished;
      const rolling=moving&&Boolean(run.speed||run.steer), moved=run.speed;
      let grabbing=false;
      if(!paused&&moving) {
        const pad=readPad(), activeCourse=course;
        clock.advance(elapsed,(step,sampleAge)=>{
          const controls=driverInput(now-sampleAge*1000,pad);grabbing=controls.handbrake;
          const prevSurf='slopeAt' in activeCourse&&typeof activeCourse.slopeAt==='function'
            ?activeCourse.slopeAt(run.x,run.z,run.yaw)
            :{y:'heightAt' in activeCourse&&typeof activeCourse.heightAt==='function'?activeCourse.heightAt(run.x,run.z):0,pitch:0,roll:0};
          previousPose.x=run.x;previousPose.y=prevSurf.y;previousPose.z=run.z;
          previousPose.yaw=run.yaw;previousPose.pitch=prevSurf.pitch;previousPose.roll=prevSurf.roll;previousPose.ready=true;
          const before=activeCourse.time;
          activeCourse.step(step,controls);timedStep=activeCourse.time>before+step*.5?step:0;
          effects.step(step,run);
          return !activeCourse.finished;
        });
        if(course.finished) {audio.silence();dirty=true;publishCourse(now,true);}
        else publishCourse(now);
      }
      let ghostMoved=false;
      if(ghost&&ghostMode!=='off') {
        if(ghostMode==='follow'&&ghostLap!==course.lap)stageGhostAhead();
        if(moving&&run.speed>.32)ghostLaunch=true;
        const running=!paused&&!inspectingGear&&!ghost.playback.ended&&(watched?ghostPlaying:ghostLaunch&&!course.finished);
        if(running) {
          // The HUD is throttled; the comparison car reads the continuous physics clock instead.
          const time=watched?ghost.playback.time+(elapsed<2.4?elapsed*ghost.playback.rate:0)
            :ghostFollowTime(course.time,ghostOffset,clock.alpha,timedStep);
          ghostMoved=ghost.move(time,!!watched);
        }
        if(ghostMoved&&watched&&ghost.playback.ended)audio.silence();
        if(ghostMoved||(!watched&&moving&&course.time>0))publishGhost(now,ghostMoved&&ghost.playback.ended);
        const dx=run.x-ghost.car.position.x,dz=run.z-ghost.car.position.z,range=dx*dx+dz*dz;
        const follow=!watched&&!inspectingGear&&range>3.24&&range<43000&&ghost.playback.time>0;
        const light=!!watched&&activeCamera!=='cockpit'&&activeCamera!=='bumper'&&renderBudget.scale<.83;
        ghost.display(follow,!!watched&&!light&&activeCamera!=='bumper',light);
        ghost.trail.mesh.visible=!inspectingGear;
        ghost.effects.root.visible=!!watched;
        const lapDistance=T.MathUtils.clamp(course.progress-(course.lap-1)*course.length,0,course.length);
        ghost.trail.update(watched?.playback.distance??lapDistance,!!watched,activeCamera==='cockpit');
      }
      car.visible=!watched;effects.root.visible=!watched;
      if(!paused&&(rolling||grabbing)) redrawUntil=Math.max(redrawUntil,now+285);
      const action=(watched?.car??car).userData.driverAction;
      const inspectingMotion=inspectingGear?inspectAmount<1||!action.contact||action.mode!=='gear':inspectAmount>0;
      const driveMotion=ghostMoved||moving&&!course.finished&&(rolling||run.speed||run.steer||keys.size||action.mode!=='wheel'||now<redrawUntil||effects.smoky);
      const needsFrame=dirty||(!paused&&(inspectingMotion||driveMotion));
      if(driveMotion&&drewDrive&&!paused) {
        renderPace=T.MathUtils.damp(renderPace,Math.min(elapsed,.13),7,Math.min(elapsed,.15));
        if(renderBudget.sample(elapsed))applyResolution();
      } else if(!driveMotion||paused) {renderBudget.clearSamples();renderPace=1/60;}
      drewDrive=Boolean(needsFrame&&driveMotion&&!paused);
      if(needsFrame) {
        const target=watched?.motion??run;
        if(!paused) {
          if(!watched)car.userData.tick(dt,{...run,handbrake:!inspectingGear&&run.handbrake,serviceBrake:!inspectingGear&&run.serviceBrake,
            displayKmh:recent?.speed,inspectGear:inspectingGear,animateCabin:true});
          if(bots) {
            const playerLapDistance=T.MathUtils.clamp(course.progress-(course.lap-1)*course.length,0,course.length);
            bots.update(dt,playerLapDistance,course.lane??0,course.progress>1||ghostMode!=='off');
          }
          else if(watched.car.visible)watched.paintDetail(dt);
          if(watched?ghostPlaying&&!watched.playback.ended:moving&&!course.finished)audio.sample(target,activeCamera==='cockpit',activeCamera==='bumper');
          if(moved!==run.speed||grabbing||car.userData.driverAction.mode!=='wheel') redrawUntil=Math.max(redrawUntil,now+105);
        }
        const visualDt=paused?0:Math.min(elapsed,.19),view=drivePose(visualDt);
        rain.update(view,visualDt);
        if('tickVisuals' in course&&typeof course.tickVisuals==='function') {
          course.tickVisuals(visualDt,car.position,view.position,renderer.domElement.height);
        }
        const projection=renderer.domElement.height/(2*Math.tan(T.MathUtils.degToRad(view.fov*.5)));
        (watched?.effects??effects).update(projection,view.position);
        if(watched) {driveShadow.position.copy(watched.car.position);driveShadow.rotation.y=watched.car.rotation.y;}
        renderer.domElement.dataset.grip=action.mode;
        renderer.domElement.dataset.contact=String(action.contact);
        (watched?.car??car).userData.updateGlow(view.position);
        if(activeCamera==='cockpit'&&(!paused||dirty)) updateMirror(now);
        const bumper=activeCamera==='bumper', subject=watched?.car??car;
        cinematicRig(view,visualDt,target,bumper);
        postTime+=visualDt;
        const pace=watched?.playback.rate??1;
        const anyPost=film.rays||film.contrastExposure||film.aces||film.bloom||film.motionBlur||film.grain||film.dof;
        // Project the sun into view space for the god rays; fade it out behind the camera / at the frame edges.
        const sunDirection=(course as {lighting?:{sunDirection?:Three.Vector3}}|null)?.lighting?.sunDirection;
        let sunUv={x:.5,y:.72}, sunOn=0;
        if(sunDirection) {
          sunForward.set(0,0,-1).applyQuaternion(view.quaternion);
          const facing=sunForward.dot(sunDirection);
          sunWorld.copy(sunDirection).multiplyScalar(5200).add(view.position).project(view);
          let facingGain=T.MathUtils.smoothstep(facing,.04,.42);
          if(!Number.isFinite(sunWorld.x)||sunWorld.z>1) facingGain=0;
          else facingGain*=1-T.MathUtils.smoothstep(Math.hypot(sunWorld.x,sunWorld.y),1.05,1.55);
          sunOn=facingGain;
          sunUv={x:T.MathUtils.clamp(sunWorld.x*.5+.5,-.6,1.6),y:T.MathUtils.clamp(sunWorld.y*.5+.5,-.6,1.6)};
        }
        const drawScene=()=>{
          if(anyPost) post.render(course!.scene,{camera:view,vx:target.vx*pace,vz:target.vz*pace,speed:Math.abs(target.cueSpeed??target.speed),
            time:postTime,exposure:renderer.toneMappingExposure,view:activeCamera,quality:renderBudget.scale,sunUv,sunOn,
            flags:{rays:film.rays,contrastExposure:film.contrastExposure,aces:film.aces,bloom:film.bloom,motionBlur:film.motionBlur,grain:film.grain,dof:film.dof}});
          else renderer.render(course!.scene,view);
        };
        if(bumper) {
          const shown=subject.visible;subject.visible=false;
          try {drawScene();} finally {subject.visible=shown;}
        } else drawScene();
        const advancing=watched?ghostPlaying&&!watched.playback.ended:!course.finished;
        const exposureLimit=(watched||ghost?.shell.visible) ? .032 : .047;
        if(!film&&kineticEffects&&!prefersReducedMotion&&!paused&&advancing&&(bumper||activeCamera==='chase')&&target.forwardSpeed>3
          &&renderer.capabilities.isWebGL2&&renderBudget.scale>=.83&&renderPace<exposureLimit) {
          exposure.render(renderer,view,target.vx*pace,target.vz*pace,bumper);
        }
        dirty=false;
      }
      frameId=requestAnimationFrame(frame);
      return;
    }
    if (transition) {
      const st = transition;
      const progress = prefersReducedMotion ? 1 : T.MathUtils.clamp((now - st.start) / 570, 0, 1);
      const t = 1 - (1 - progress) ** 3;
      setCamera(st.yaw + st.dyaw * t, T.MathUtils.lerp(st.polar, st.to.polar, t), T.MathUtils.lerp(st.target.y, st.to.y, t),
        T.MathUtils.lerp(st.target.x, st.to.x ?? 0, t), T.MathUtils.lerp(st.target.z, st.to.z ?? .013, t));
      camera.zoom = T.MathUtils.lerp(st.zoom, destinationZoom, t); camera.updateProjectionMatrix();
      if (progress === 1) transition = null;
      dirty = true;
    } else if (!dragged) {
      if (Math.abs(camera.zoom - destinationZoom) > .0005) {
        camera.zoom = prefersReducedMotion ? destinationZoom : T.MathUtils.damp(camera.zoom, destinationZoom, 13, dt);
        camera.updateProjectionMatrix(); dirty = true;
      }
      if (auto && now > Math.max(autoFrom, pauseUntil)) {
        orbit.copy(camera.position).sub(controls.target).applyAxisAngle(up, -dt * .165);
        camera.position.copy(controls.target).add(orbit); dirty = true;
      }
    }
    controls.update();

    const oldSpeed = speed, oldSteer = steer;
    const accelerator = Number(keys.has('w')) - Number(keys.has('s'));
    if (accelerator) speed = T.MathUtils.clamp(speed + dt * (accelerator > 0 ? 9.5 : -8.5), -11.1, 29.16);
    else speed *= Math.exp(-dt * .66);
    if (Math.abs(speed) < .08) speed = 0;
    const steering = Number(keys.has('a')) - Number(keys.has('d'));
    steer = T.MathUtils.damp(steer, steering || (now < tapUntil ? tapSteer : 0), 10, dt);
    if (Math.abs(steer) < .001) steer = 0;
    const active = Boolean(speed || oldSpeed || steer || oldSteer || now < redrawUntil);
    if (active) redrawUntil = speed || steer ? now + 220 : redrawUntil;
    if (dirty || active) {
      car.userData.tick(dt, { speed, steer });
      car.userData.updateGlow(camera.position);
      renderer.render(scene, camera);
      dirty = false;
    }
    frameId = requestAnimationFrame(frame);
  }
  if(initial.mode==='drive') setMode('drive');
  frame(performance.now());
  function releaseInputs() {keys.clear();inputQueue.length=0;tapUntil=0;pedalUntil=0;handbrakeUntil=0;previousHand=false;pedalKey=null;}

  return {
    view: changeView,
    mode:setMode,
    course(id) {
      if (id === activeCourseId && course) return;
      loadCourse(id);
      if (mode === 'drive') renderer.toneMappingExposure = id === 'haruna' ? 1.08 : 1.20;
    },
    camera(name) { if(chosenCamera===name)return;chosenCamera=name;if(mode==='drive'&&!inspectingGear)applyDriveCamera(); },
    ghost:switchGhost,
    ghostSeek:seekGhost,
    ghostRate(rate) {if(ghost){ghost.playback.setRate(rate);publishGhost(performance.now(),true);}},
    ghostPlay(value) {
      ghostPlaying=value;
      if(value&&ghost?.playback.ended)seekGhost(0);
      if(!value)audio.silence();
      dirty=true;publishGhost(performance.now(),true);
    },
    pause(value) { paused=value;clock.reset();timedStep=0;releaseInputs();if(value)audio.silence();dirty=true;publishGhost(performance.now(),true); },
    inspectGear(enabled) {
      if(mode!=='drive'||ghostMode==='watch'||inspectingGear===enabled) return;
      const before=activeCamera;
      inspectingGear=enabled;clock.reset();timedStep=0;releaseInputs();
      if(enabled)audio.silence();
      applyDriveCamera();
      if(!enabled&&before!==activeCamera)inspectAmount=0;
    },
    restart(type) {
      if(!course) return;
      course.reset(type);effects.reset();clock.reset();timedStep=0;releaseInputs();paused=false;inspectingGear=false;
      if(ghost&&ghostMode==='follow') {stageGhostAhead();publishGhost(performance.now(),true);}
      inspectAmount=headingOffset=controlGlance=bumpCycle=mirrorAt=rush=0;
      previousPose.ready=false;cameraReady=false;smoothCamReady=false;
      car.userData.resetDriver(course.state.gear);
      car.userData.tick(.06,course.state);bots?.placeAtStart();applyDriveCamera();publishCourse(performance.now(),true);
    },
    zoomBy(direction) {
      destinationZoom = T.MathUtils.clamp(destinationZoom * (direction > 0 ? 1.22 : 1 / 1.22), controls.minZoom, controls.maxZoom);
      dirty = true;
    },
    turntable(enabled, wait = 0) { auto = enabled; autoFrom = performance.now() + wait; },
    configure(build) {
      const previous = car.userData.build;
      car.userData.setBuild(build);
      if (previous.nose !== build.nose || previous.wing !== build.wing || previous.rear !== build.rear) renderer.shadowMap.needsUpdate = true;
      if (previous.wing !== build.wing) resize();
      dirty = true;
    },
    headlights(enabled) { lightsUser = Boolean(enabled); applyMoodLights(); redrawUntil = Math.max(redrawUntil, performance.now() + 470); dirty = true; },
    mood(next) { mood = next; course?.lighting.setMood(mood); trackside?.setMood(mood); rain.setVisible(mood === 'rain'); applyMoodLights(); dirty = true; },
    assist(enabled) {assistDrive=enabled;},
    sound(enabled) {audio.setEnabled(enabled);if(enabled)audio.unlock();dirty=true;},
    speedEffects(enabled) {kineticEffects=enabled;dirty=true;},
    cinematic(flags) {film={...DEFAULT_FILM,...flags};gLat=gLong=shakeEnergy=0;dirty=true;},
    lighting(next) {lightingState={...lightingState,...next};course?.lighting.apply(lightingState);dirty=true;},
    feint(enabled) {feintFlick=enabled;course?.setFeintMode?.(feintFlick);dirty=true;},
    unlockAudio: audio.unlock,
    input(input, down) {
      if(mode==='drive') {
        if(!paused&&!inspectingGear&&ghostMode!=='watch'&&!course?.finished) {
          inputQueue.push({key:input,down,at:performance.now()});dirty=true;
        }
        return;
      }
      if (!down) { keys.delete(input); return; }
      if(input==='space') return;
      if (keys.has(input)) return;
      keys.add(input);
      if (input === 'w' || input === 's') {
        speed = T.MathUtils.clamp(speed + (input === 'w' ? .80 : -.80), -11.1, 29.16);
      } else {tapSteer=input==='a'?1:-1;tapUntil=performance.now()+105;}
      dirty = true;
    },
    releaseInputs,
    dispose() {
      cancelAnimationFrame(frameId); observer.disconnect(); controls.dispose();audio.dispose();exposure.dispose();post.dispose();
      freeObjectGraph(scene);
      trackside?.dispose(); trackside = null; rain.dispose();
      bots?.dispose();bots=null;
      if (course) freeObjectGraph(course.scene);
      mirrorTarget.dispose();key.shadow.dispose(); renderer.dispose(); renderer.domElement.remove();
    },
  };
}