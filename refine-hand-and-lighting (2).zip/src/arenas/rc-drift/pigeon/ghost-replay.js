import { physicsStep } from './drift-physics.js';
import { createRmxPilot } from './rmx-pilot.js';
import { GHOST_SETTINGS } from './rmx-drift-adapter';

const captureStep=2*physicsStep, idle={gas:0,brake:0,steer:0,handbrake:false};

export function buildGhostReference(track) {
  // Reference lap driven with the RMX 2.5 drift system (fixed RTR setup) on the RMX-proportioned circuit
  const run=track.createRun('ghost',{settings:GHOST_SETTINGS}), pilot=createRmxPilot(track,{settings:GHOST_SETTINGS,look:10.4,grip:1.05}), frames=[];
  const zoneSeconds=track.zones.map(()=>0),zoneEntries=track.zones.map(()=>-1);
  let input=idle,impact=0,activeDrift=0,bonusSeconds=0,bonusCoverage=0;
  const distanceSamples=[{distance:0,time:0}];
  function record(time) {
    const state={...run.state,wheels:Object.fromEntries(Object.entries(run.state.wheels).map(([id,wheel])=>[id,{...wheel}]))};
    const telemetry=run.snapshot();
    frames.push({time,state,input,telemetry,heading:run.heading,bonusZone:run.scoringZone,bonusSeconds,bonusCoverage});
    if(telemetry.distance>distanceSamples[distanceSamples.length-1].distance)distanceSamples.push({distance:telemetry.distance,time:telemetry.time});
  }
  record(0);
  for(let i=0;i<120*150&&!run.finished;i++) {
    if(i%4===0)input=pilot(run);
    run.step(physicsStep,input);
    impact=Math.max(impact,run.impact);
    if(run.state.speed>9&&Math.abs(run.state.beta)>.265)activeDrift+=physicsStep;
    const sector=run.scoringZone;
    if(sector!==-1) {
      zoneSeconds[sector]+=physicsStep;bonusSeconds+=physicsStep;
      if(zoneEntries[sector]<0)zoneEntries[sector]=(i+1)*physicsStep;
      if(zoneSeconds[sector]>=.25&&zoneSeconds[sector]-physicsStep<.25)bonusCoverage++;
    }
    if(i%2===1||run.finished)record((i+1)*physicsStep);
  }
  const finish=frames[frames.length-1];
  const clips=zoneEntries.flatMap((time,index)=>zoneSeconds[index]>=.25?[{time:Math.max(0,time-.70),zone:index+1}]:[]);
  function timeAtDistance(target) {
    let from=0,to=distanceSamples.length-1;
    while(from+1<to) {
      const i=(from+to)>>1;
      if(distanceSamples[i].distance<target)from=i;else to=i;
    }
    const a=distanceSamples[from],b=distanceSamples[to];
    if(a===b)return a.time;
    const weight=Math.max(0,Math.min(1,(target-a.distance)/(b.distance-a.distance)));
    return lerp(a.time,b.time,weight);
  }
  return {frames,duration:finish.time,result:finish.telemetry,impact,activeDrift,bonusSeconds,zoneSeconds,clips,timeAtDistance};
}

const lerp=(a,b,t)=>a+(b-a)*t;
const wrap=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
const positions=['x','z','vx','vz','speed','steer','steerAngle','accelLong','accelLat','forwardSpeed','lateralSpeed','beta','rev','throttle','brake','rearLock','yawRate','rearSlip','tireNoise','roughness','driftBlend','cueSpeed','bodyRoll','bodyPitch','wheelTurn'];
const wheelIds=['FL','FR','RL','RR'];
const wheelValues=['x','z','angle','omega','along','across','height','load','slip','roughness'];

export function createGhostPlayback(reference) {
  let time=0,index=0,blend=0,rate=1;
  const {frames,duration}=reference,last=frames.length-1;
  const visual={...frames[0].state,wheels:Object.fromEntries(wheelIds.map(id=>[id,{...frames[0].state.wheels[id]}]))};
  const wheels=visual.wheels;
  function seek(next) {
    time=Math.max(0,Math.min(duration,Number.isFinite(next)?next:0));
    index=Math.min(last,Math.floor(time/captureStep+1e-8));
    if(time>=duration)index=last;
    const a=frames[index],b=frames[Math.min(last,index+1)];
    blend=a===b?0:Math.max(0,Math.min(1,(time-a.time)/(b.time-a.time)));
  }
  function sample() {
    const a=frames[index].state,b=frames[Math.min(last,index+1)].state;
    for(const name of positions)visual[name]=lerp(a[name],b[name],blend);
    visual.rcSpeed=Number.isFinite(a.rcSpeed)&&Number.isFinite(b.rcSpeed)?lerp(a.rcSpeed,b.rcSpeed,blend):undefined;
    visual.yaw=wrap(a.yaw,b.yaw,blend);
    visual.gear=a.gear;visual.shifting=a.shifting;visual.serviceBrake=a.serviceBrake;visual.handbrake=a.handbrake;visual.coasting=a.coasting;
    visual.driftPhase=a.driftPhase;visual.driftDirection=a.driftDirection;
    for(const id of wheelIds) {
      const from=a.wheels[id],to=b.wheels[id],wheel=wheels[id];
      for(const name of wheelValues)wheel[name]=lerp(from[name],to[name],blend);
      wheel.spin=wrap(from.spin,to.spin,blend);
    }
    return visual;
  }
  return {
    get time(){return time;},get rate(){return rate;},get ended(){return time>=duration;},get frame(){return frames[index];},
    get heading(){return wrap(frames[index].heading,frames[Math.min(last,index+1)].heading,blend);},
    get distance(){return lerp(frames[index].telemetry.distance,frames[Math.min(last,index+1)].telemetry.distance,blend);},
    seek,sample,setRate(next){rate=next===.5?.5:1;},
    advance(dt,watching) {if(Number.isFinite(dt)&&dt>0&&dt<2.4)seek(time+dt*(watching?rate:1));},
    pose(){
      const a=frames[index].state,b=frames[Math.min(last,index+1)].state;
      return {x:lerp(a.x,b.x,blend),z:lerp(a.z,b.z,blend),yaw:wrap(a.yaw,b.yaw,blend)};
    },
  };
}

export function ghostFollowTime(lapTime, offset, alpha, timedStep=physicsStep) {
  return Math.max(0,offset+lapTime-timedStep*(1-Math.max(0,Math.min(1,alpha))));
}

export function coachingCue(frame) {
  const {state,input,telemetry}=frame;
  if(telemetry.finished)return 'finish';
  if(telemetry.drift.outer)return 'bonus';
  if(input.handbrake)return 'handbrake';
  if(state.driftPhase==='link')return 'link';
  if(Number(input.brake)>.125)return Math.abs(state.beta)>.18?'trailBrake':'brake';
  if(state.driftPhase==='exit'||(Math.abs(state.beta)>.19&&Number(input.gas)<.19))return 'exit';
  if(Math.abs(state.beta)>.225&&state.beta*state.steerAngle>.025)return 'counter';
  if(Math.abs(state.beta)>.225)return 'hold';
  if(state.driftPhase==='entry')return 'turnIn';
  return Number(input.gas)>.29?'accelerate':'line';
}