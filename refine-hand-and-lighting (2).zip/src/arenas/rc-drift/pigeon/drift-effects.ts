import type * as Three from 'three';
import { CAR_SCALE } from './rmx-drift-adapter';
import type { DriftState, DriftWheel, WheelId } from './drift-physics.js';

export function createDriftEffects(T: typeof Three) {
  const root = new T.Group();
  root.name = 'Drift effects';
  const tyreKeys = ['FL', 'FR', 'RL', 'RR'] as const;
  const marks = 2400;
  const puffs = 280;

  // Skidmarks
  const trackPositions = new Float32Array(marks * 18);
  const trackInk = new Float32Array(marks * 6);
  const buffer = (array: Float32Array, size: number) => new T.BufferAttribute(array, size).setUsage(T.DynamicDrawUsage);
  const tracks = new T.BufferGeometry();
  tracks.setAttribute('position', buffer(trackPositions, 3));
  tracks.setAttribute('ink', buffer(trackInk, 1));
  tracks.setDrawRange(0, 0);
  const strips = new T.Mesh(
    tracks,
    new T.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -6,
      polygonOffsetUnits: -6,
      side: T.DoubleSide,
      vertexShader: `attribute float ink; varying float shade; void main(){shade=ink;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
      fragmentShader: `varying float shade; void main(){gl_FragColor=vec4(.065,.075,.072,shade);}`,
    }),
  );
  strips.frustumCulled = false;
  strips.renderOrder = 2;
  root.add(strips);

  let markIndex = 0;
  let markCount = 0;
  let marksDirty = false;
  const previous = Object.fromEntries(
    tyreKeys.map((id) => [id, { x: 0, y: 0, z: 0, dx: 0, dz: 0, ink: 0, active: false, smoke: 0 }]),
  ) as Record<WheelId, { x: number; y: number; z: number; dx: number; dz: number; ink: number; active: boolean; smoke: number }>;

  function rubber(id: WheelId, wheel: DriftWheel, opacity: number) {
    const p = previous[id];
    const sx = wheel.x - p.x;
    const sz = wheel.z - p.z;
    const wy = (wheel.worldY ?? wheel.height ?? 0) + 0.025;
    const distance = Math.hypot(sx, sz);
    if (distance < 0.14) return;
    if (distance > 2.4) {
      p.x = wheel.x;
      p.y = wy;
      p.z = wheel.z;
      p.active = false;
      return;
    }
    const half = (0.13 + opacity * 0.17) * CAR_SCALE;
    const dx = (sz / distance) * half;
    const dz = (-sx / distance) * half;
    if (!p.active) {
      p.x = wheel.x;
      p.y = wy;
      p.z = wheel.z;
      p.dx = dx;
      p.dz = dz;
      p.ink = 0;
      p.active = true;
      return;
    }
    const ya = p.y;
    const yb = wy;
    trackPositions.set(
      [
        p.x + p.dx, ya, p.z + p.dz,
        p.x - p.dx, ya, p.z - p.dz,
        wheel.x + dx, yb, wheel.z + dz,
        wheel.x + dx, yb, wheel.z + dz,
        p.x - p.dx, ya, p.z - p.dz,
        wheel.x - dx, yb, wheel.z - dz,
      ],
      markIndex * 18,
    );
    trackInk.set([p.ink, p.ink, opacity, opacity, p.ink, opacity], markIndex * 6);
    markIndex = (markIndex + 1) % marks;
    markCount = Math.min(marks, markCount + 1);
    marksDirty = true;
    p.x = wheel.x;
    p.y = wy;
    p.z = wheel.z;
    p.dx = dx;
    p.dz = dz;
    p.ink = opacity;
  }

  // Art of Rally stylized low-poly 3D volumetric drift smoke puffs
  const puffGeo = new T.IcosahedronGeometry(1, 1);
  const puffMat = new T.MeshLambertMaterial({
    color: 0xffffff,
    flatShading: true,
    emissive: 0x4d565e,
    emissiveIntensity: 0.34,
  });
  const puffMesh = new T.InstancedMesh(puffGeo, puffMat, puffs);
  puffMesh.frustumCulled = false;
  puffMesh.castShadow = false;
  puffMesh.receiveShadow = false;
  puffMesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
  const zeroMat = new T.Matrix4().makeScale(0, 0, 0);
  const tmpColor = new T.Color(1, 1, 1);
  for (let i = 0; i < puffs; i++) {
    puffMesh.setMatrixAt(i, zeroMat);
    puffMesh.setColorAt(i, tmpColor);
  }
  puffMesh.instanceMatrix.needsUpdate = true;
  if (puffMesh.instanceColor) puffMesh.instanceColor.needsUpdate = true;
  root.add(puffMesh);

  const particles = Array.from({ length: puffs }, () => ({
    x: 0,
    y: 0,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    age: 99,
    life: 1,
    size: 0.5,
    rx: 0,
    ry: 0,
    rz: 0,
    spin: 0,
    dust: 0,
  }));

  const m = new T.Matrix4();
  const q = new T.Quaternion();
  const e = new T.Euler();
  const pos = new T.Vector3();
  const scl = new T.Vector3();

  let next = 0;
  let seed = 1405;
  let active = 0;
  const rand = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };

  function spawn(wheel: DriftWheel, state: DriftState, intensity: number) {
    const p = particles[next];
    next = (next + 1) % puffs;
    const baseY = wheel.worldY ?? wheel.height ?? 0;
    const isDust = wheel.roughness > 0.55 ? 1 : 0;
    const sinY = Math.sin(state.yaw);
    const cosY = Math.cos(state.yaw);
    // Emit slightly behind and outboard of rear contact patch
    const backJit = -0.18 - rand() * 0.22;
    const sideJit = wheel.side * (0.06 + rand() * 0.14);
    p.x = wheel.x + sinY * backJit + cosY * sideJit + (rand() - 0.5) * 0.16;
    p.y = baseY + 0.17 + rand() * 0.12;
    p.z = wheel.z + cosY * backJit - sinY * sideJit + (rand() - 0.5) * 0.16;

    // Preserve a gentle fraction of slide momentum + buoyant upward billow
    p.vx = state.vx * 0.11 - sinY * (0.65 + rand() * 0.85) + (rand() - 0.5) * 1.1;
    p.vy = 0.72 + rand() * 0.78 + intensity * 0.45;
    p.vz = state.vz * 0.11 - cosY * (0.65 + rand() * 0.85) + (rand() - 0.5) * 1.1;

    p.age = 0;
    p.life = (isDust ? 0.95 : 1.08) + rand() * 0.72 + intensity * 0.35;
    p.size = (0.48 + rand() * 0.34 + intensity * 0.38) * CAR_SCALE * 1.25;
    p.rx = rand() * Math.PI * 2;
    p.ry = rand() * Math.PI * 2;
    p.rz = rand() * Math.PI * 2;
    p.spin = (rand() - 0.5) * 1.4;
    p.dust = isDust;

    if (isDust) {
      const shade = 0.88 + rand() * 0.14;
      tmpColor.setRGB(0.84 * shade, 0.72 * shade, 0.54 * shade);
    } else {
      const shade = 0.91 + rand() * 0.09;
      tmpColor.setRGB(0.98 * shade, 0.985 * shade, 0.975 * shade);
    }
    puffMesh.setColorAt(next === 0 ? puffs - 1 : next - 1, tmpColor);
    if (puffMesh.instanceColor) puffMesh.instanceColor.needsUpdate = true;
  }

  function step(dt: number, state: DriftState) {
    for (const id of tyreKeys) {
      const wheel = state.wheels[id];
      const p = previous[id];
      const rmxFx = state.rcSpeed !== undefined;
      if ((rmxFx ? (state.rcSpeed ?? 0) > 0.05 : (state.cueSpeed ?? state.speed) > 2.1) && wheel.slip > 0.31 && wheel.roughness < 0.6) {
        rubber(id, wheel, wheel.slip * (wheel.front ? 0.23 : 0.52));
      } else {
        p.active = false;
        p.x = wheel.x;
        p.y = (wheel.worldY ?? wheel.height ?? 0) + 0.025;
        p.z = wheel.z;
      }
      if (!wheel.front && (rmxFx || (state.cueSpeed ?? state.speed) > 2)) {
        const drift = Math.min(1, Math.abs(state.beta) * 2.2) * state.driftBlend;
        const speedMul = Math.min(1.4, (state.cueSpeed ?? state.speed) / 11);
        const strength = Math.max(
          wheel.roughness * 0.55 * speedMul,
          (wheel.slip - (rmxFx ? 0.34 : 0.25)) * (1.75 + drift * 0.95),
        );
        if (strength > 0) {
          p.smoke += strength * dt * 27;
          while (p.smoke >= 1) {
            p.smoke -= 1;
            spawn(wheel, state, Math.min(1, drift + strength * 0.35));
          }
        }
      }
    }

    const drag = Math.exp(-2.1 * dt);
    for (let i = 0; i < puffs; i++) {
      const p = particles[i];
      if (p.age >= p.life) continue;
      p.age += dt;
      p.vx *= drag;
      p.vz *= drag;
      p.vy = p.vy * Math.exp(-1.2 * dt) + 0.24 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.rx += p.spin * dt;
      p.ry += p.spin * 0.7 * dt;
    }
  }

  function update(_viewScale: number, cam?: Three.Vector3) {
    if (marksDirty) {
      tracks.attributes.position.needsUpdate = tracks.attributes.ink.needsUpdate = true;
      tracks.setDrawRange(0, markCount * 6);
      marksDirty = false;
    }
    let count = 0;
    for (let i = 0; i < puffs; i++) {
      const p = particles[i];
      if (p.age >= p.life) {
        if (p.age < 90) {
          p.age = 99;
          puffMesh.setMatrixAt(i, zeroMat);
        }
        continue;
      }
      const t = p.age / p.life;
      // Art of Rally puffy curve: rapid bloom, lush hold, soft shrink out
      const grow = Math.min(1, t * 5.2);
      const growEase = 1 - (1 - grow) * (1 - grow);
      const tail = Math.max(0, 1 - Math.max(0, (t - 0.42) / 0.58));
      const shrinkEase = tail * tail * (3 - 2 * tail);
      let sc = p.size * (0.28 + 0.92 * growEase) * shrinkEase;
      if (cam) {
        const dx = p.x - cam.x;
        const dy = p.y - cam.y;
        const dz = p.z - cam.z;
        const d = Math.hypot(dx, dy, dz);
        const fadeNear = Math.min(1, Math.max(0, (d - 2.1) / 3.4));
        sc *= fadeNear * fadeNear * (3 - 2 * fadeNear);
      }
      if (sc <= 0.002) {
        puffMesh.setMatrixAt(i, zeroMat);
        continue;
      }
      count++;
      e.set(p.rx, p.ry, p.rz);
      q.setFromEuler(e);
      pos.set(p.x, p.y, p.z);
      scl.set(sc * 1.12, sc * 0.88, sc * 1.12);
      m.compose(pos, q, scl);
      puffMesh.setMatrixAt(i, m);
    }
    active = count;
    puffMesh.instanceMatrix.needsUpdate = true;
  }

  function reset() {
    markIndex = markCount = next = active = 0;
    tracks.setDrawRange(0, 0);
    for (let i = 0; i < puffs; i++) {
      particles[i].age = 99;
      puffMesh.setMatrixAt(i, zeroMat);
    }
    puffMesh.instanceMatrix.needsUpdate = true;
    for (const p of Object.values(previous)) {
      p.active = false;
      p.smoke = 0;
    }
  }

  return {
    root,
    step,
    update,
    reset,
    get smoky() {
      return active > 0;
    },
  };
}