export type Phase = "loading" | "intro" | "drive" | "drone" | "finish";

export const live = {
  x: 0,
  z: 0,
  heading: 0,
  rx: 0,
  rz: 0,
  speed: 0,
  gear: 1,
  drift: 0,
  section: "Menara Air",
  sectionJp: "給水塔",
  corner: "",
  cornerSub: "",
  time: 0,
  best: 0,
  progress: 0,
  night: false,
  phase: "loading" as Phase,
  cam: "Rally",
  finished: null as number | null,
  gap: 0,
  muted: false,
  path: [] as { x: number; z: number }[],
  hairpin: [] as { x: number; z: number }[],
  tick: 0,
};

export const touch = {
  throttle: 0,
  brake: 0,
  steer: 0,
  handbrake: false,
};

type Actions = {
  startDrive: () => void;
  startDrone: () => void;
  reset: () => void;
  toggleNight: () => void;
  cycleCam: () => void;
  toggleMute: () => void;
  backToCar: () => void;
};

let actions: Actions | null = null;
const listeners = new Set<() => void>();

export function registerActions(a: Actions) {
  actions = a;
}

export function emit() {
  live.tick++;
  listeners.forEach((l) => l());
}

export function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export const ui = {
  startDrive: () => actions?.startDrive(),
  startDrone: () => actions?.startDrone(),
  reset: () => actions?.reset(),
  toggleNight: () => actions?.toggleNight(),
  cycleCam: () => actions?.cycleCam(),
  toggleMute: () => actions?.toggleMute(),
  backToCar: () => actions?.backToCar(),
};
